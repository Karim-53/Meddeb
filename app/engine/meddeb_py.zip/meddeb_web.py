"""Pyodide entry module of the Meddeb web app (03_platforms.md §9, P5.11): the shared backend (recite/app.py) in the
engine worker (engine_worker.js), the web twin of the Android app's meddeb_android.py. Every call comes from the
worker's single queue, one at a time.

The speech model runs in the encoder worker (encoder_worker.js, onnxruntime-web): the backend's injected encoder
(03_platforms.md §4) hands it the features and blocks until the ids and probabilities are back (meddeb_js.encode:
postMessage + Atomics.wait on a SharedArrayBuffer), so the tracker's step stays synchronous, as on the PC and the phone.
The profile is a folder of the worker's file system that engine_worker.js mirrors into the browser's Origin Private
File System after every call (profile_fs.js).

Under CPython (the tests) set_encoder() injects any encoder, e.g. onnxruntime's; nothing here imports js.
"""
from __future__ import annotations

import datetime as dt
import json
import platform
from pathlib import Path
from typing import Callable

import numpy as np

from recite import __version__
from recite.app import App
from recite.asr.onnx_ctc_backend import OnnxCtcBackend
from recite.profile import Profile, missing_kinds, partial_kinds

MODEL = "fastconformer_quran"
MODEL_RES = Path(__file__).resolve().parent / "meddeb_models" / MODEL     # tokens.txt (the ONNX file: encoder worker)
LOG_MAX = 256 * 1024          # meddeb.log is cut to its newest half above this (it is persisted after every call)

_app: App | None = None
_sess = None
_log: Path | None = None
_encoder: Callable[[np.ndarray], tuple[np.ndarray, np.ndarray]] | None = None
_backend: OnnxCtcBackend | None = None
_facts: dict = {}             # the browser's facts (engine.js): app version, user agent, threads, ...


def log(msg: str) -> None:
    if _log is None:
        return
    try:
        if _log.exists() and _log.stat().st_size > LOG_MAX:
            text = _log.read_text(encoding="utf-8", errors="replace")
            _log.write_text(text[len(text) // 2:].split("\n", 1)[-1], encoding="utf-8")
        with _log.open("a", encoding="utf-8") as f:
            f.write(f"{dt.datetime.now().isoformat(sep=' ', timespec='milliseconds')} [py] {msg}\n")
    except OSError:
        pass


def js_encoder(feats: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """features (80, T) -> (ids, probabilities) per 80 ms output frame, through the encoder worker (Pyodide only)."""
    import meddeb_js   # registered by engine_worker.js

    x = np.ascontiguousarray(feats, dtype="<f4")
    r = meddeb_js.encode(x, int(x.shape[0]), int(x.shape[1]))
    ids = np.asarray(r.ids.to_py(), dtype=np.int64)
    conf = np.asarray(r.conf.to_py(), dtype=np.float32)
    return ids, conf


def set_encoder(encoder: Callable[[np.ndarray], tuple[np.ndarray, np.ndarray]]) -> None:
    global _encoder, _backend
    _encoder, _backend = encoder, None


def backend() -> OnnxCtcBackend:
    global _backend
    if _backend is None:
        b = OnnxCtcBackend(MODEL, MODEL_RES, encoder=_encoder or js_encoder)
        b.load()                              # reads tokens.txt; the ONNX session lives in the encoder worker
        _backend = b
    return _backend


def start_app(profile_dir: str, facts_json: str = "") -> str:
    """The same backend as the PC server and the phone, on the browser's profile folder (D4.4)."""
    global _app, _sess, _log, _facts
    _facts = json.loads(facts_json) if facts_json else {}
    profile = Profile(profile_dir)
    _log = profile.logs_dir / "meddeb.log"
    _app, _sess = App(profile, lambda name: backend(), MODEL), None
    # #45 (v0.17): no checkpoints here yet: the OPFS mirror (profile_fs.js) rewrites a changed file whole at each call,
    # so a growing audio.pcm would cost a full copy every step; a closed tab still loses its running session
    _app.checkpoints = False
    log(f"app {_facts.get('app_version', __version__)} on {profile_dir}: Python {platform.python_version()}, "
        f"numpy {np.__version__}, {_facts.get('browser', '?')}")
    return "ok"


def versions() -> dict:
    """B3.8 versions for About (U1.12): the web app's version, Python and numpy from App.versions, then what the page
    knows (engine_worker.js adds Pyodide, ONNX Runtime Web, its threads and the browser)."""
    v = _app.versions("web")
    if _facts.get("app_version"):
        v["app"] = str(_facts["app_version"])
    v["items"] += [[k, str(val)] for k, val in _facts.get("items", [])]
    v["profile"] = "this browser (Origin Private File System)"
    return v


def report(p: dict) -> dict:
    """U1.16: the prefilled issue of the public repository (recite/report.py, platform web): the browser's facts, no
    screenshot."""
    device = {"app_version": _facts.get("app_version"), "browser": _facts.get("browser"), "os": _facts.get("os")}
    return _app.report({"session": p.get("session"), "folder": p.get("folder"), "platform": "web", "device": device})


def call(name: str, params_json: str) -> str:
    p = json.loads(params_json or "{}")
    a = _app
    if name == "chapters":
        r = a.chapters()
    elif name == "tajweed_legend":
        r = a.tajweed_legend()
    elif name == "locate":
        r = a.locate(int(p["surah"]), int(p.get("ayah") or 1))
    elif name == "page":
        r = a.page(int(p["page"]))
    elif name == "starter_hint":
        r = a.starter_hint(int(p["page"]))
    elif name == "progress":
        r = a.progress()
    elif name == "stats":
        r = a.stats()
    elif name == "settings":
        r = a.settings()
    elif name == "save_settings":
        r = a.save_settings(p)
    elif name == "mark":                       # #67 / #69 review: session = the saved session on screen
        r = a.add_mark(int(p["surah"]), int(p["ayah"]), int(p["idx"]), str(p["event"]), session=p.get("session"),
                       **({"ins": True} if p.get("ins") else {}))   # #72 (v0.19): an insertion before the word
    elif name == "sessions":
        r = a.sessions()
    elif name == "listen_targets":
        r = a.listen_targets()
    elif name == "listen_plan":
        r = a.listen_plan(p)
    elif name == "listen_reciters":                    # #93 (v0.20, D20) the Listen form's Reciter select
        r = a.listen_reciters()
    elif name == "reciter_clip":
        r = a.reciter_clip(p)
    elif name == "session_load":
        r = a.session_load(p)
    elif name == "storage":
        r = a.storage()
    elif name == "storage_delete":
        r = a.storage_delete(p)
        log(f"storage: delete {r.get('what')}: " + (f"{r['files']} files, {r['bytes']} bytes, {r['kept']} kept"
                                                     if r.get("ok") else f"refused ({r.get('reason')})"))
    elif name == "export_plan":                        # D4.9 (#71, v0.19) the export dialog's kinds and sizes
        r = a.export_plan()
    elif name == "export_files":                       # D4.9 the worker's files op: {kinds, files, manifest}
        r = a.export_files(p.get("kinds"))
    elif name == "report":
        r = report(p)
    elif name == "versions":
        r = versions()
    elif name == "import_profile":                     # D4.4: the zip the page picked, a read-only file of the worker
        backup = a.profile.import_zip(Path(p["path"]))
        log(f"profile imported from {p.get('name') or 'a zip'}; the previous one is kept as {backup.name}")
        r = {"ok": True, "backup": backup.name, "missing": missing_kinds(Path(p["path"])),   # D4.9 (#71)
             "partial": partial_kinds(Path(p["path"]))}
    else:
        raise ValueError(f"unknown call {name}")
    return json.dumps(r, ensure_ascii=False)


def clip(params_json: str) -> bytes:
    """B3.7 replay: the WAV of a session between start and end seconds, at one loudness (X2.18)."""
    p = json.loads(params_json)
    return _app.clip(p["session"], float(p["start"]), float(p["end"]), float(p.get("margin", 0.35)), p.get("folder"))


def session_start(params_json: str) -> str:
    global _sess
    params = json.loads(params_json)
    _sess = _app.start(params)
    log(f"session {_sess.id} started {params_json}")
    return json.dumps(_sess.started_message(), ensure_ascii=False)


def session_audio(pcm) -> bool:
    """Int16 PCM at 16 kHz (a JavaScript Uint8Array in the worker, bytes in the tests); True when a step is due."""
    data = pcm.to_bytes() if hasattr(pcm, "to_bytes") else bytes(pcm)
    return bool(_sess is not None and _sess.push_audio(data))


def session_step(final: bool) -> str:
    return json.dumps(_sess.step(bool(final)), ensure_ascii=False) if _sess is not None else ""


def session_command(msg_json: str) -> str:
    r = _sess.command(json.loads(msg_json)) if _sess is not None else None
    return json.dumps(r, ensure_ascii=False) if r else ""


def session_pause() -> str:
    return json.dumps(_sess.pause(), ensure_ascii=False) if _sess is not None else "[]"


def session_finish() -> str:
    global _sess
    if _sess is None:
        return ""
    done = _sess.finish()
    if done.get("search"):
        log(f"search done: found {done.get('found')}")
    else:
        log(f"session done: recited {done['n_recited']}, mistakes {done['n_mistakes']}, folder {done['folder']}")
    _sess = None
    return json.dumps(done, ensure_ascii=False)


def session_open() -> bool:
    return _sess is not None
