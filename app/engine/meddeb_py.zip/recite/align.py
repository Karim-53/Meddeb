"""Mistake detection = alignment of the recognized words to the EXPECTED words.

Detector v0 (used by the PoC benchmark and as the core of the MVP tracker):
  * weighted edit-distance alignment (N0-normalized words)
  * substitution cost shrinks with letter similarity, so near-identical words pair up
  * repetitions of recently recited words are tolerated (cost ~0, not a mistake)
  * hesitations (a prefix of the upcoming word) are tolerated
  * `free_end=True` for live use: the hypothesis may stop anywhere in the reference, words
    after that point are "pending", not "missing"
  * every expected word gets a suspicion score in [0, 1]: 0 = recited correctly,
    1 = missing; a wrong word scores by how different it is (1 - similarity).
    Thresholding the score gives the precision/recall trade-off (precision-first!).

Optional edges (ta'awwudh, basmala when not part of the passage, "sadaqa Allah al-azim")
are stripped by `strip_optional_edges` before alignment.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache

try:
    from rapidfuzz.distance import Levenshtein as _Lev

    def _ratio(a: str, b: str) -> float:
        return _Lev.normalized_similarity(a, b)
except Exception:  # pragma: no cover - fallback
    from difflib import SequenceMatcher

    def _ratio(a: str, b: str) -> float:
        return SequenceMatcher(None, a, b).ratio()


@lru_cache(maxsize=200_000)
def similarity(a: str, b: str) -> float:
    if a == b:
        return 1.0
    return _ratio(a, b)


TAAWWUDH = "اعوذ بالله من الشيطان الرجيم".split()
BASMALA = "بسم الله الرحمن الرحيم".split()
SADAQA = "صدق الله العظيم".split()


def _starts_with(seq: list[str], prefix: list[str], tol: float = 0.75) -> bool:
    if len(seq) < len(prefix):
        return False
    return all(similarity(s, p) >= tol for s, p in zip(seq, prefix))


def _ends_with(seq: list[str], suffix: list[str], tol: float = 0.75) -> bool:
    if len(seq) < len(suffix):
        return False
    return all(similarity(s, p) >= tol for s, p in zip(seq[-len(suffix):], suffix))


def strip_optional_edges(hyp: list[str], ref: list[str]) -> tuple[list[str], int, int]:
    """Remove optional prefix/suffix formulas from the hypothesis when the reference does not
    contain them at the same edge. Returns (hyp, n_dropped_front, n_dropped_back)."""
    front = back = 0
    if _starts_with(hyp, TAAWWUDH) and not _starts_with(ref, TAAWWUDH):
        hyp = hyp[len(TAAWWUDH):]
        front += len(TAAWWUDH)
    if _starts_with(hyp, BASMALA) and not _starts_with(ref, BASMALA):
        hyp = hyp[len(BASMALA):]
        front += len(BASMALA)
    if _ends_with(hyp, SADAQA) and not _ends_with(ref, SADAQA):
        hyp = hyp[: -len(SADAQA)]
        back += len(SADAQA)
    return hyp, front, back


@dataclass
class Verdict:
    ref_idx: int
    status: str                 # ok | wrong | missing | pending
    hyp_idx: int | None = None
    hyp_text: str | None = None
    score: float = 0.0          # suspicion 0..1
    prob: float | None = None   # ASR confidence of the paired hypothesis word
    extras_after: list[int] = field(default_factory=list)  # hyp indices inserted after this word


@dataclass
class Alignment:
    verdicts: list[Verdict]
    extras: list[tuple[int, int]]        # (after_ref_idx or -1, hyp_idx) insertions not explained
    repeats: list[int]                   # hyp indices judged to be repetitions / hesitations
    end_ref: int                         # number of reference words consumed
    cost: float
    repeat_of: dict[int, int] = field(default_factory=dict)  # hyp idx -> reference idx it repeats

    def flagged(self, threshold: float = 0.5) -> list[int]:
        return [v.ref_idx for v in self.verdicts if v.status in ("wrong", "missing") and v.score >= threshold]

    @property
    def span(self) -> tuple[int, int] | None:
        """(first, last) reference indices paired with a hypothesis word, or None."""
        idx = [v.ref_idx for v in self.verdicts if v.hyp_idx is not None]
        return (min(idx), max(idx)) if idx else None


def align(ref: list[str], hyp: list[str], hyp_probs: list[float] | None = None, *,
          ref_alt: list[str | None] | None = None, free_prefix: int = 0,
          free_end: bool = False, free_start: bool = False, repeat_window: int = 6,
          band: int | None = None, sub_floor: float = 0.5, ins_cost: float = 0.9,
          del_cost: float = 1.0, repeat_cost: float = 0.05, hesitation_cost: float = 0.15) -> Alignment:
    """Align hypothesis words to expected words (both N0-normalized).

    ref_alt[i]: an alternative correct spelling of ref[i] (Uthmani vs imla'i) that also counts
    as a match. free_prefix: the first free_prefix reference words are already settled: skipping
    them costs nothing and they can only be matched exactly (used for the live tracker's back
    window, so repeats move the cursor back without stealing new words). free_start: the hypothesis may begin anywhere in the reference (reference words
    before the first aligned one get status "before", not "missing"); free_end: it may stop
    anywhere (trailing words are "pending"). Both together = semi-global alignment, used to locate
    a clip of unknown extent inside a surah."""
    n, m = len(ref), len(hyp)
    INF = float("inf")
    alts: list[str | None] = list(ref_alt) if ref_alt is not None else [None] * n

    def eq(i: int, h: str) -> bool:
        return h == ref[i] or (alts[i] is not None and h == alts[i])

    def sim(i: int, h: str) -> float:
        s = similarity(ref[i], h)
        if alts[i] is not None and alts[i] != ref[i]:
            s = max(s, similarity(alts[i], h))
        return s
    if band is None:
        band = max(n, m) + 1
    # dp[i][j]: min cost aligning ref[:i] to hyp[:j]; back[i][j] = (di, dj, kind)
    dp = [[INF] * (m + 1) for _ in range(n + 1)]
    back: list[list[tuple[int, int, str] | None]] = [[None] * (m + 1) for _ in range(n + 1)]
    dp[0][0] = 0.0
    if free_start:
        for i in range(1, n + 1):
            dp[i][0] = 0.0
            back[i][0] = (1, 0, "before")
        band = max(n, m) + 1  # the band is meaningless with a free start
    for i in range(0, n + 1):
        jlo = max(0, i - band)
        jhi = min(m, i + band)
        for j in range(jlo, jhi + 1):
            cur = dp[i][j]
            if cur == INF:
                continue
            if i < n and j < m:
                h = hyp[j]
                if eq(i, h):
                    c = cur
                    if c < dp[i + 1][j + 1]:
                        dp[i + 1][j + 1], back[i + 1][j + 1] = c, (1, 1, "ok")
                elif i >= free_prefix:
                    s = sim(i, h)
                    c = cur + sub_floor + (1.0 - sub_floor) * (1.0 - s)
                    if c < dp[i + 1][j + 1]:
                        dp[i + 1][j + 1], back[i + 1][j + 1] = c, (1, 1, "wrong")
            if i < n:  # expected word not recited (free inside the settled prefix)
                if i < free_prefix:
                    c = cur
                    if c < dp[i + 1][j]:
                        dp[i + 1][j], back[i + 1][j] = c, (1, 0, "before")
                else:
                    c = cur + del_cost
                    if c < dp[i + 1][j]:
                        dp[i + 1][j], back[i + 1][j] = c, (1, 0, "missing")
            if j < m:  # extra hypothesis word
                h = hyp[j]
                kind, c = "extra", cur + ins_cost
                # the next hypothesis word is exactly the expected word -> h is very likely an
                # insertion (cheaper than "wrong + repeat")
                if i < n and j + 1 < m and not eq(i, h) and (
                        eq(i, hyp[j + 1])
                        or any(sim(k, hyp[j + 1]) >= 0.8 for k in range(max(0, i - 3), i))):
                    # ... or a restart from a recent word ("A B C X C D E"): the same insertion
                    c = cur + ins_cost * 0.7
                # repetition of a recently recited word (never of the expected word itself)
                lo = max(0, i - repeat_window)
                if (i >= n or not eq(i, h)) and any(sim(k, h) >= 0.8 for k in range(lo, i)):
                    kind, c = "repeat", cur + repeat_cost
                elif i < n and len(h) >= 2 and ref[i].startswith(h) and h != ref[i]:
                    kind, c = "hesitation", cur + hesitation_cost
                elif i > 0 and len(h) >= 2 and ref[i - 1].startswith(h) and h != ref[i - 1]:
                    kind, c = "hesitation", cur + hesitation_cost
                elif i > 0 and len(h) >= 2 and ref[i - 1].endswith(h) and h != ref[i - 1]:
                    # tail of the previous word: what is left of a committed word after the
                    # rolling buffer was cut inside it (live tracker), never a new word
                    kind, c = "hesitation", cur + hesitation_cost
                if c < dp[i][j + 1]:
                    dp[i][j + 1], back[i][j + 1] = c, (0, 1, kind)
    # choose the end cell
    if free_end:
        best_i, best_c = n, dp[n][m]
        for i in range(0, n + 1):
            if dp[i][m] < best_c - 1e-9:
                best_i, best_c = i, dp[i][m]
        # prefer the furthest position among equal costs
        for i in range(n, -1, -1):
            if abs(dp[i][m] - best_c) < 1e-9:
                best_i = i
                break
    else:
        best_i, best_c = n, dp[n][m]
    # backtrace
    verdicts: dict[int, Verdict] = {}
    extras: list[tuple[int, int]] = []
    repeats: list[int] = []
    repeat_of: dict[int, int] = {}
    i, j = best_i, m
    while i > 0 or j > 0:
        step = back[i][j]
        if step is None:  # unreachable inside band -> treat rest as missing/extra
            if i > 0:
                i -= 1
                verdicts[i] = Verdict(i, "missing", score=1.0)
            else:
                j -= 1
                extras.append((-1, j))
            continue
        di, dj, kind = step
        i, j = i - di, j - dj
        if kind == "before":
            verdicts[i] = Verdict(i, "before")
        elif kind == "ok":
            verdicts[i] = Verdict(i, "ok", j, hyp[j], 0.0, hyp_probs[j] if hyp_probs else None)
        elif kind == "wrong":
            verdicts[i] = Verdict(i, "wrong", j, hyp[j], 1.0 - sim(i, hyp[j]),
                                  hyp_probs[j] if hyp_probs else None)
        elif kind == "missing":
            verdicts[i] = Verdict(i, "missing", score=1.0)
        elif kind == "extra":
            extras.append((i - 1, j))
        else:  # repeat / hesitation
            repeats.append(j)
            lo_k = max(0, i - repeat_window)
            if i > lo_k:
                repeat_of[j] = max(range(lo_k, i), key=lambda k: sim(k, hyp[j]))
    for i2 in range(best_i, n):
        verdicts[i2] = Verdict(i2, "pending")
    out = [verdicts[k] for k in range(n)]
    for after, hj in extras:
        if 0 <= after < n:
            out[after].extras_after.append(hj)
    extras.sort(key=lambda p: p[1])
    repeats.sort()
    return Alignment(out, extras, repeats, best_i, best_c, repeat_of)


def detect(ref_words: list[str], hyp_words: list[str], hyp_probs: list[float] | None = None,
           **kw) -> Alignment:
    """Convenience: strip optional edges then align (non-streaming)."""
    hyp, front, _ = strip_optional_edges(hyp_words, ref_words)
    probs = hyp_probs[front: front + len(hyp)] if hyp_probs else None
    return align(ref_words, hyp, probs, **kw)
