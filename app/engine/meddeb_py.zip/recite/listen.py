"""What Listen plays (U1.13, B3.14): `listen_plan` turns a tab's input into the ordered per-ayah clips, `listen_targets`
turns the Progress numbers (U1.11) into the three quick-button ranges (Weak page, Learn page = the next to
learn, Manzil).

The players (static/listen_player.js on the PC and the web, Android's PlaybackService) fetch
reciter.base_url + key + ".mp3": one file per ayah (D4.5, EveryAyah). The basmala is the 001001 clip (Al-Fatiha 1:1),
played before ayah 1 of every surah but Al-Fatiha and At-Tawbah; EveryAyah's SSS000 files of surahs 1 and 9 are the
ta'awwudh: 001000 is used only by Android Auto's travel-dua intro (P5.15, #26: 43:13 from word 11 + 43:14, then the
ta'awwudh, before the car resumes the last listening), 009000 never; Listen plans never contain either. Pages come from
the 15-line layout (D12): a page always ends at the end of an ayah.
#31 (user, 2026-10-24, against the loop effect): a plan also carries its margins, the ayat a later pass may add before
and after the range (Vary, up to MARGIN_AYAT each side, never across the surah of the range's first / last ayah), each
with its distance to the range (step); the after-margin also carries what the fade-out needs (the file's length and the
word starts in its middle, D4.6). The players draw each pass's edges from them (the pass shape, ui_logic.js / Kotlin).
#93 (v0.20, plan D20): a plan is played by the reciter its params name (RECITERS, the Listen form's Reciter select;
Yasser Al-Dossary by default); RECITER (Yasser) stays the voice commands', the Recite cue's and the car intro's.
Pure: the standard library, recite.quran_text and recite.word_times only (it runs in Chaquopy, later in Pyodide).
"""
from __future__ import annotations

import bisect

from . import word_times
from .quran_text import N_PAGES, load_quran, page_ayat, page_of

EVERYAYAH = "https://everyayah.com/data/"


def _everyayah(rid: str, name: str, label: str, folder: str, speed: float, haram: bool = False) -> dict:
    return {"id": rid, "name": name, "label": label, "base_url": EVERYAYAH + folder + "/",
            "credit": f"Recitation: {name} — audio files: EveryAyah.com", "speed": speed, "haram": haram}


# #93 (v0.20, plan D20; user 2026-10-31: "add yasser Salama (Hadr), Mishary, Fares Abbed, Islam sabahi, all as Hafs ...
# yasser dussary as default ... add an icon at the end of their names if they ... prayed at masjid haram (even if not
# anymore)"): the Reciter select's entries in its order, the default first; all 6,236 ayat of each folder (checked
# against its 000_checksum.md5). label = the select's text, 🕋 after a sourced imam of Masjid al-Haram (haram; Yasser:
# Wikipedia "Yasir al-Dawsari", permanent imam from 12 Oct 2019; none verified for the others). Islam Sobhi: no
# per-ayah files anywhere (mp3quran: whole surahs only), not offered. speed = the reciter's length / Yasser's, for the
# untimed reciters' ms (#88: Yasser's ms x speed, an estimate): measured 2026-10-31 on 22 ayat spread over the mushaf
# (1:2 ... 114:6, 2-141 s each) from the files' headers (HEAD's Content-Length, a 16 KB Range for the ID3 size and the
# first frame's bitrate, the ID3v1 tail; Yasser's within 0.2 % of his timings, 6 spot checks within 1.5 % of ffprobe),
# as the ratio of the summed lengths (per ayah 0.58-1.34: one ayah can be off by a third, a range much less)
RECITERS = (
    _everyayah("yasser_ad-dussary", "Yasser Al-Dossary", "Yasser Al-Dossary 🕋", "Yasser_Ad-Dussary_128kbps", 1.0,
               haram=True),
    _everyayah("yaser_salamah", "Yasser Salamah", "Yasser Salamah (Hadr)", "Yaser_Salamah_128kbps", 0.94),
    _everyayah("alafasy", "Mishary Alafasy", "Mishary Alafasy", "Alafasy_128kbps", 1.09),
    _everyayah("fares_abbad", "Fares Abbad", "Fares Abbad", "Fares_Abbad_64kbps", 0.92),
)
RECITER = RECITERS[0]           # Yasser: the default, and always the voice commands', the Recite cue's, the car intro's
_BY_ID = {r["id"]: r for r in RECITERS}
BASMALA_KEY = "001001"
REPEAT_DEFAULT = 17             # extra plays of the whole range after the first (17 -> 18 plays), D1
NO_BASMALA = (1, 9)             # Al-Fatiha (its 1:1 is the basmala) and At-Tawbah
LEARN_MARGIN = 3                # Next to learn: the pages of the ayah and of the 3 ayat before and after it (D4)
MANZIL_EXTRA = 3                # Manzil: p .. p+k, k <= 3 recited pages following p without a gap (D3)
TABS = ("ayah", "page")
MARGIN_AYAT = 4                 # #31: a pass starts 0-4 ayat earlier and ends 0-4 ayat later (Vary, user 2026-10-24)
FADE_SPAN = (0.35, 0.65)        # #31: the fade-out stops on a word start within this part of the extra ayah's file
FADE_MIN_MS = 3000              # #31: no fade on an ayah under 3 s (U1.13): no cuts (the players check ms only without)


def reciter(rid) -> dict:
    """#93: the RECITERS entry of an id (spaces around it ignored); Yasser's for a missing, unknown or non-text id."""
    return _BY_ID.get(rid.strip(), RECITER) if isinstance(rid, str) else RECITER


def listen_reciters() -> list[dict]:
    """#93 (B3.14 `listen_reciters`): the Reciter select's options, [{id, label, name}] in RECITERS' order."""
    return [{"id": r["id"], "label": r["label"], "name": r["name"]} for r in RECITERS]


def ayah_key(surah: int, ayah: int) -> str:
    """EveryAyah's file name without .mp3: 2:255 -> "002255"."""
    return f"{int(surah):03d}{int(ayah):03d}"


def _int(v, default: int) -> int:
    """An int or a numeric string from the form; `default` for an empty or unreadable field."""
    if v is None or (isinstance(v, str) and not v.strip()):
        return default
    try:
        return int(v)
    except (TypeError, ValueError):
        try:
            return int(float(v))
        except (TypeError, ValueError, OverflowError):
            return default


def _clamp(v: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, v))


def _pages_text(p: int, r: int) -> str:
    return f"p. {p}" if p == r else f"p. {p}–{r}"


def plan_title(surahs: list[dict]) -> str:
    """"Al-Baqarah 2:1 – 2:16", "Al-Baqarah 2:255"; several surahs are all named: "Al-Fatihah 1:1 – Al-Baqarah 2:5",
    "Al-Ikhlas 112:1 – Al-Falaq – An-Nas 114:6"; more than two in the middle are counted ("– 13 more surahs –")."""
    f, last = surahs[0], surahs[-1]
    if len(surahs) == 1:
        if f["ayah_from"] == f["ayah_to"]:
            return f"{f['name']} {f['surah']}:{f['ayah_from']}"
        return f"{f['name']} {f['surah']}:{f['ayah_from']} – {f['surah']}:{f['ayah_to']}"
    middle = [m["name"] for m in surahs[1:-1]]
    if len(middle) > 2:
        middle = [f"{len(middle)} more surahs"]
    return " – ".join([f"{f['name']} {f['surah']}:{f['ayah_from']}", *middle,
                       f"{last['name']} {last['surah']}:{last['ayah_to']}"])


def _timed(rec: dict | None) -> bool:
    """#93: word timings (D4.6) exist for Yasser's files only."""
    return rec is None or rec["id"] == RECITER["id"]


def file_ms(s: int, a: int, rec: dict | None = None) -> int | None:
    """#88: the length in ms of Yasser's file of s:a (his word timings, D4.6); None for an untimed ayah. #93: another
    reciter's (rec, a RECITERS entry) is estimated: Yasser's x rec's speed, rounded to the ms."""
    t = word_times.timeline(s, a)
    if t is None:
        return None
    ms = int(round(t[1] * 1000))
    return ms if _timed(rec) else int(round(ms * rec["speed"]))


def _ayah_clips(s: int, a: int, rec: dict | None = None) -> list[dict]:
    """The clips of one ayah in a plan: its basmala first when it is ayah 1 of a surah that has one (D6), then the
    ayah's own file. #88: each carries `ms`, its file's length (the basmala is 1:1's file), for the page's estimate of
    how long a listening lasts (#93: rec's, file_ms)."""
    pg = page_of(s, a)
    out = []
    if a == 1 and s not in NO_BASMALA:
        out.append({"key": BASMALA_KEY, "kind": "basmala", "surah": s, "ayah": 0, "label": "Basmala", "page": pg,
                    "ms": file_ms(1, 1, rec)})
    out.append({"key": ayah_key(s, a), "kind": "ayah", "surah": s, "ayah": a, "label": f"{s}:{a}", "page": pg,
                "ms": file_ms(s, a, rec)})
    return out


def fade_points(s: int, a: int) -> tuple[int | None, list[int]]:
    """#31: (the ayah file's length in ms, the word starts in ms within FADE_SPAN of it, ascending; a word Yasser
    repeats counts at each start) from his word timings (D4.6); (None, []) for an untimed ayah. #31 review: no cuts
    for an ayah under FADE_MIN_MS (the pass shape fades to a cut whenever there is one: 20:28, 1.9 s, played at half
    volume and stopped at 0.84 s)."""
    t = word_times.timeline(s, a)
    if t is None:
        return None, []
    entries, dur = t
    ms = int(round(dur * 1000))
    if ms < FADE_MIN_MS:
        return ms, []
    starts = {int(round(x * 1000)) for _k, x in entries}
    return ms, sorted(x for x in starts if FADE_SPAN[0] * ms <= x <= FADE_SPAN[1] * ms)


def margins(first: tuple[int, int], last: tuple[int, int], q, rec: dict | None = None) -> tuple[list[dict], list[dict]]:
    """#31 (user, 2026-10-24: "randomize start and end with a +[0-4] eyats"): (margin_before, margin_after), the up to
    MARGIN_AYAT ayat before the range's first ayah and after its last one, in playing order, inside their surah (a surah
    boundary is a natural stop, and 1:1 / 114:6 stay the Qur'an's edges). Each clip is a plan clip plus `step` (1 = the
    adjacent ayah); a basmala comes with the ayah 1 it opens and its step (never for Al-Fatihah and At-Tawbah); the
    after-margin's clips also carry `cuts` (fade_points) for the fade-out (`ms`, like every plan clip, #88). #93: for an
    untimed reciter (rec other than Yasser) the estimated ms and no cuts (the players fade at 35-65 % of ms)."""
    (s0, a0), (s1, a1) = first, last
    before = [dict(c, step=a0 - a) for a in range(max(1, a0 - MARGIN_AYAT), a0) for c in _ayah_clips(s0, a, rec)]
    after = []
    for a in range(a1 + 1, min(q.n_ayat(s1), a1 + MARGIN_AYAT) + 1):
        ms, cuts = fade_points(s1, a) if _timed(rec) else (file_ms(s1, a, rec), [])
        after += [dict(c, step=a - a1, ms=ms, cuts=cuts) for c in _ayah_clips(s1, a, rec)]
    return before, after


def listen_plan(params: dict, q=None) -> dict:
    """{"tab": "ayah", "surah", "ayah_from", "ayah_to"} or {"tab": "page", "page_from", "page_to"} (ints or numeric
    strings, other keys ignored; clamped to the surah / to 1..604, a reversed range swapped; no end = the end of the
    surah / the start page) -> the clips in mushaf order, the surahs covered, a title (B3.14, plan §1.1), and the
    margins a varied pass may add around the range (#31: margin_before, margin_after); every clip carries its file's
    length (`ms`, None when untimed, #88). #93: params["reciter"] (an id of RECITERS; Yasser when missing or unknown)
    is the plan's reciter (its subtitle, credit and base_url, which the players put before every clip's key)."""
    q = q or load_quran()
    rec = reciter(params.get("reciter"))
    tab = str(params.get("tab") or ("ayah" if "surah" in params else "page"))
    if tab not in TABS:
        raise ValueError(f"unknown listen tab {tab!r}")
    if tab == "ayah":
        s = _clamp(_int(params.get("surah"), 1), 1, 114)
        n = q.n_ayat(s)
        a = _clamp(_int(params.get("ayah_from"), 1), 1, n)
        b = _clamp(_int(params.get("ayah_to"), n), 1, n)
        a, b = min(a, b), max(a, b)
        ayat = [(s, k) for k in range(a, b + 1)]
        p_from, p_to = page_of(s, a), page_of(s, b)
    else:
        p = _clamp(_int(params.get("page_from"), 1), 1, N_PAGES)
        r = _clamp(_int(params.get("page_to"), p), 1, N_PAGES)
        p_from, p_to = min(p, r), max(p, r)
        ayat = list(dict.fromkeys(sa for pg in range(p_from, p_to + 1) for sa in page_ayat(pg)))
    clips: list[dict] = []
    surahs: list[dict] = []
    for s, a in ayat:
        clips += _ayah_clips(s, a, rec)         # D6: a basmala at the range start and at each surah boundary, every pass
        if surahs and surahs[-1]["surah"] == s:
            surahs[-1]["ayah_to"] = a
        else:
            surahs.append({"surah": s, "name": q.chapter_name(s), "name_arabic": q.chapter_name_ar(s),
                           "ayah_from": a, "ayah_to": a})
    first = surahs[0]
    before, after = margins(ayat[0], ayat[-1], q, rec)
    return {"tab": tab, "title": plan_title(surahs), "subtitle": rec["name"],
            "surah": first["surah"], "ayah_from": first["ayah_from"], "ayah_to": first["ayah_to"],
            "page_from": p_from, "page_to": p_to, "surahs": surahs, "reciter": dict(rec), "clips": clips,
            "n_ayat": len(ayat), "margin_before": before, "margin_after": after}


def learn_pages(surah: int, ayah: int, q=None) -> tuple[int, int]:
    """D4: the pages holding the ayah and the LEARN_MARGIN ayat before and after it in mushaf order (across surahs,
    clamped at 1:1 and 114:6); 1 or 2 pages, 3 when the ayat are long (2:282)."""
    q = q or load_quran()
    order = sorted(q.ayat)
    k = _clamp(bisect.bisect_left(order, (surah, ayah)), 0, len(order) - 1)
    pages = [page_of(*sa) for sa in order[max(0, k - LEARN_MARGIN): k + LEARN_MARGIN + 1]]
    return min(pages), max(pages)


def _target(kind: str, label: str, detail: str, p_from: int, p_to: int, repeat: int, q, rid=None, **extra) -> dict:
    return {"kind": kind, "tab": "page", "page_from": p_from, "page_to": p_to, "repeat": repeat, **extra,
            "label": label, "detail": detail,
            "plan": listen_plan({"tab": "page", "page_from": p_from, "page_to": p_to, "reciter": rid}, q)}


def listen_targets(progress: dict, q=None, reciter=None) -> dict:
    """The quick buttons of U1.13 from a progress.progress() result; an entry is None when its Progress source is.
    Weak page: that page, repeat 17. Learn page (the next to learn): learn_pages, repeat 17. Manzil: p .. p+k where
    p+1 .. p+k are pages of the Progress table without a gap (k <= 3), repeat 0. Android Auto and the launcher shortcut
    name the learn entry "Next to learn" with their own strings. #93: the plans are the `reciter`'s (an id; Yasser by
    default)."""
    q = q or load_quran()
    out: dict[str, dict | None] = {"weak": None, "learn": None, "manzil": None}
    weak = progress.get("weak")
    if weak:
        p, err = int(weak["page"]), int(weak["err"])
        out["weak"] = _target("weak", "Weak page", f"p. {p} · {err} mistake{'' if err == 1 else 's'}", p, p,
                              REPEAT_DEFAULT, q, reciter)
    nxt = progress.get("next_to_learn")
    if nxt:
        s, a = int(nxt["surah"]), int(nxt["ayah"])
        lo, hi = learn_pages(s, a, q)
        out["learn"] = _target("learn", "Learn page", f"{s}:{a} · {_pages_text(lo, hi)}", lo, hi, REPEAT_DEFAULT, q,
                               reciter, surah=s, ayah=a)
    manzil = progress.get("manzil")
    if manzil:
        recited = {int(r["page"]) for r in progress.get("pages") or []}
        p = e = int(manzil["page"])
        while e + 1 in recited and e + 1 <= min(p + MANZIL_EXTRA, N_PAGES):
            e += 1
        out["manzil"] = _target("manzil", "Manzil", _pages_text(p, e), p, e, 0, q, reciter)
    return out
