"""What Listen plays (U1.13, B3.14): `listen_plan` turns a tab's input into the ordered per-ayah clips, `listen_targets`
turns the Progress numbers (U1.11) into the three quick-button ranges (Weak page, Learn page = the next to
learn, Oldest page = the manzil, #114: its key stays "manzil").

The players (static/listen_player.js on the PC and the web, Android's PlaybackService) fetch
reciter.base_url + key + ".mp3": one file per ayah (D4.5, EveryAyah). The basmala is the 001001 clip (Al-Fatiha 1:1),
played before ayah 1 of every surah but Al-Fatiha and At-Tawbah; EveryAyah's SSS000 files of surahs 1 and 9 are the
ta'awwudh: 001000 is used only by Android Auto's travel-dua intro (P5.15, #26: 43:13 from word 11 + 43:14, then the
ta'awwudh, before the car resumes the last listening), 009000 never; Listen plans never contain either. Pages come from
the 15-line layout (D12): a page always ends at the end of an ayah.
#31 (user, 2026-10-24, against the loop effect): a plan also carries its margins, the ayat a later pass may add before
and after the range (Vary, up to MARGIN_AYAT each side, never across the surah of the range's first / last ayah), each
with its distance to the range (step); the after-margin also carries what the fade-out needs (the file's length and the
word starts in its middle, D4.6). The players draw each pass's edges from them (the pass shape, ui_logic.js / Kotlin).
#93 (v0.20, plan D20): a plan is played by the reciter its params name (RECITERS, the Listen form's Reciter select;
Yasser Al-Dossary by default); RECITER (Yasser) stays the voice commands', the Recite cue's and the car intro's.
v0.21 (#92 / #93, round plan D9 / D10): every clip says what to play, `src` = {rid, name, url, from_ms?, to_ms?, ms,
fallback?}: Yasser Al-Dossary's clips are time ranges [from_ms, to_ms) of QuranicAudio's whole-surah file (no EveryAyah
ticks; recite.qa_times, D4.10) with his EveryAyah file as the fallback, the Meddeb selection's Islam Sobhi / Yasser
Salamah (Hadr) surahs ranges of their own surah files (selection_timings.json, D4.11), every other reciter its
EveryAyah file (no range). A Mix plan's clips also carry `mix` (a src per real reciter in VOICES' order: play k plays
mix[(k - 1) % len], the first play Yasser). `key` and `reciter.base_url` stay for the players of 0.20 (no src:
base_url + key + ".mp3").
v0.22 (#92 / #93, round plan D7 / D8): a banned file or range (recite.audio_ban, D4.12: the dev-phase tick scan) is
never a src, a fallback or a Mix src. Yasser Al-Dossary: QuranicAudio's surah file where it is clean; a surah whose
QuranicAudio file ticks plays his clean recording on archive.org whole (YASSER_AL-DOSSARI_MP3_QURAN, Meddeb's own times:
data/yasser_clean_timings.json.gz) once it is timed; an ayah with no clean audio of his (both ticked, not timed yet) is
left out of the plan (`skipped`), Mix gives his turn to the next reciter there. "Yasser Salamah" is his Hadr (TvQuran's
114 surah files, selection_timings.json), his murattal (EveryAyah) only where a surah has no times, named so; the
Meddeb selection's Al-Fatiha is Yasser's maqam Kurd clip (1:1 his ordinary basmala); #112 (v0.23, D13): the clip
re-encoded as Yasser-Al-Dussary_Al-Fatiha_Hafs_Kurd_v2.mp3 (louder, 1:2's start lifted, 1:7 up to the Aameen).
#92 (v0.23, D17): 72 of the 74 ayat with no clean audio of his play from that clean recording as units (clean_units:
ayat he joins without a pause, between two confirmed cuts), one clip per unit (`unit`, `ayah_to`, `ayah_starts`); a
range holding part of a unit plays all of it (`added`), the margins take a unit whole or stop.
Pure: the standard library, recite.quran_text, recite.word_times, recite.qa_times and recite.audio_ban only (it runs
in Chaquopy, later in Pyodide).
"""
from __future__ import annotations

import bisect
import gzip
import json
import zlib
from functools import lru_cache
from pathlib import Path
from urllib.parse import urlsplit

from . import audio_ban, qa_times, word_times
from .quran_text import N_PAGES, load_quran, page_ayat, page_of

EVERYAYAH = "https://everyayah.com/data/"
SELECTION_PATH = Path(__file__).resolve().parent / "data" / "selection_timings.json"
# v0.22 (#92, plan D7; user 2026-11-02: "just use a yasser al dussary audio that is not ticking like the one i found you
# from another source web site !!!"): Meddeb's own times inside Yasser's clean recording on archive.org (D4.12,
# tools/build_yasser_clean_timings.py; {"audio": template with {sss}, "surahs": {"S": {basmala, ayat, word_starts,
# file_ms, …}}, "untimed": {…}}); played only for the surahs whose QuranicAudio file ticks
CLEAN_PATH = Path(__file__).resolve().parent / "data" / "yasser_clean_timings.json.gz"
CLEAN_SID = "archive.org/YASSER_AL-DOSSARI_MP3_QURAN"


def _everyayah(rid: str, name: str, label: str, folder: str, speed: float, haram: bool = False,
               credit: str | None = None) -> dict:
    return {"id": rid, "name": name, "label": label, "base_url": EVERYAYAH + folder + "/",
            "credit": credit or f"Recitation: {name} — audio files: EveryAyah.com", "speed": speed, "haram": haram,
            "pseudo": False}


def _file_reciter(rid: str, name: str, credit: str, files: str, fallback: dict) -> dict:
    """v0.22 (#93, D8): a reciter of whole-surah files with Meddeb's own times (selection_timings.json's "<files>/<s>"
    entries) for every surah; `fallback` (an EveryAyah entry: base_url, speed) plays a surah without times and is each
    clip's fallback file."""
    return dict(fallback, id=rid, name=name, label=name, credit=credit, files=files, fallback_id=fallback["id"])


def _pseudo(rid: str, name: str, label: str, credit: str) -> dict:
    """v0.21 (#93, D10): a choice of the select that is not one reciter (Mix, the Meddeb selection): its plans' clips
    name their own reciters (src); base_url is Yasser's folder, for a player of 0.20 (no src: base_url + key)."""
    return dict(_everyayah(rid, name, label, "Yasser_Ad-Dussary_128kbps", 1.0, credit=credit), pseudo=True)


# #93 (v0.20, plan D20; user 2026-10-31: "add yasser Salama (Hadr), Mishary, Fares Abbed, Islam sabahi, all as Hafs ...
# yasser dussary as default ... add an icon at the end of their names if they ... prayed at masjid haram (even if not
# anymore)"): the Reciter select's entries in its order, the default first; all 6,236 ayat of each folder (checked
# against its 000_checksum.md5). label = the select's text, 🕋 after a sourced imam of Masjid al-Haram (haram; Yasser:
# Wikipedia "Yasir al-Dawsari", permanent imam from 12 Oct 2019; Sudais: Wikipedia "Abdul Rahman Al-Sudais", imam of
# the Grand Mosque of Mecca since 1984; none verified for the others). Islam Sobhi: no per-ayah files anywhere
# (mp3quran: whole surahs only), not a choice of his own (the Meddeb selection plays his Maryam, D4.11).
# v0.21 (#93 reopened, user 2026-11-01: "add Abdul-Rahman Al-Sudais - Hadr is when he read quickly, you can just
# confirm that if the length of each surah is shorter or longer than the mean"; D10): Sudais added (EveryAyah 64 kbps),
# Yasser Salamah without "(Hadr)" (EveryAyah's folder is his murattal, 1.02-1.16 x the mean; his Hadr plays in the
# Meddeb selection's 20 / 36 / 55), then Mix and the Meddeb selection (_pseudo). speed = the reciter's length /
# Yasser's, for the untimed reciters' ms (#88: Yasser's ms x speed, an estimate): re-measured 2026-11-01 on 897 ayat
# (surahs 1, 20, 36, 55, 67, 78-114; 0.20: 22 ayat) from the EveryAyah files' sizes (Content-Length x 8 / the folder's
# bitrate) as the ratio of the summed lengths; per surah group Sudais 0.74-0.94, Salamah 0.81-1.08, Alafasy 1.05-1.30,
# Fares 0.94-1.00 but Taha 0.77 (his folder's Taha is much faster than the rest of his files: another recording or a
# faster reading; his Taha lengths are overestimated by about a sixth)
# v0.22 (#93, plan D8; user 2026-11-02: "replace the 'Yasser Salamah' entry by the 'Yasser Salamah (Hadr)' entry that
# will be pure yasser in hadr mode"): his Hadr (TvQuran's 114 surah files on archive.org, D4.11's times) replaces the
# murattal in the select and in Mix; the murattal (EveryAyah) stays only as its fallback (_MURATTAL, named
# "(murattal)" wherever it plays) and the old id is an alias of the Hadr (saved settings move over)
_MURATTAL = _everyayah("yaser_salamah", "Yasser Salamah (murattal)", "Yasser Salamah (murattal)",
                       "Yaser_Salamah_128kbps", 1.06)
HADR = "yaser_salamah_hadr"
RECITERS = (
    _everyayah("yasser_ad-dussary", "Yasser Al-Dossary", "Yasser Al-Dossary 🕋", "Yasser_Ad-Dussary_128kbps", 1.0,
               haram=True, credit="Recitation: Yasser Al-Dossary — audio files: QuranicAudio.com (EveryAyah.com as "
                                  "the fallback)"),
    _everyayah("sudais", "Abdul-Rahman Al-Sudais", "Abdul-Rahman Al-Sudais 🕋", "Abdurrahmaan_As-Sudais_64kbps", 0.84,
               haram=True),
    _file_reciter(HADR, "Yasser Salamah (Hadr)", "Recitation: Yasser Salamah (Hadr) — audio files: archive.org "
                  "(TvQuran.com)", HADR, _MURATTAL),
    _everyayah("alafasy", "Mishary Alafasy", "Mishary Alafasy", "Alafasy_128kbps", 1.17),
    _everyayah("fares_abbad", "Fares Abbad", "Fares Abbad", "Fares_Abbad_64kbps", 0.91),
    _pseudo("mix", "Mix", "Mix (a reciter per pass)",
            "Recitation: Yasser Al-Dossary, Abdul-Rahman Al-Sudais, Yasser Salamah (Hadr), Mishary Alafasy and Fares "
            "Abbad, a reciter per play — audio files: QuranicAudio.com, EveryAyah.com, archive.org"),
    _pseudo("meddeb", "Meddeb selection", "Meddeb selection ❤", "Recitation (Meddeb selection)"),
)
RECITER = RECITERS[0]           # Yasser: the default, and always the voice commands', the Recite cue's, the car intro's
VOICES = tuple(r for r in RECITERS if not r["pseudo"])   # v0.21: the real reciters, in Mix's order
MIX, MEDDEB = "mix", "meddeb"
_BY_ID = {r["id"]: r for r in RECITERS}
_ALIASES = {_MURATTAL["id"]: HADR}      # v0.22 (D8): a saved "yaser_salamah" (0.20 / 0.21) is his Hadr
_ENTRIES = {**_BY_ID, _MURATTAL["id"]: _MURATTAL}    # the fallbacks too (never a choice of the select)
# v0.21 (#93 reopened, user 2026-11-01: "add in the combo box 'Meddeb selection <3'"; D10): who recites each surah in
# the Meddeb selection, the rest Yasser Al-Dossary (1 too, until the user's Kurd Fatiha has a source). Islam Sobhi's
# Maryam and Yasser Salamah's Hadr Taha / Yasin / Ar-Rahman are whole-surah files with Meddeb's own ayah times
# (selection_timings.json, D4.11), each with the EveryAyah reciter that replaces it when its entry is missing and whose
# file plays a clip when the surah file fails (Yasser for Islam Sobhi, who has no EveryAyah folder; Salamah's murattal
# for his Hadr)
MEDDEB_SELECTION = {16: "alafasy", 67: "fares_abbad", **{s: "alafasy" for s in range(78, 115)}}
# v0.22 (#93, D8; the user's answer "2.b as 'Yasser-Al-Dussary_Al-Fatiha_Hafs_Kurd.mp3'"): Al-Fatiha =
# Yasser's maqam Kurd clip on Meddeb's site (1:2-1:7; its 1:1 is null: his ordinary basmala, the fallback reciter's;
# #112, v0.23 D13: now Yasser-Al-Dussary_Al-Fatiha_Hafs_Kurd_v2.mp3, selection_timings.json's url);
# 20 / 36 / 55 keep the Hadr, now TvQuran's files (its entries are every surah's, the Hadr reciter's too)
MEDDEB_FILES = {1: ("yasser_kurd", "yasser_ad-dussary"), 19: ("islam_sobhi", "yasser_ad-dussary"),
                **{s: (HADR, "yaser_salamah") for s in (20, 36, 55)}}
BASMALA_KEY = "001001"
REPEAT_DEFAULT = 17             # extra plays of the whole range after the first (17 -> 18 plays), D1
NO_BASMALA = (1, 9)             # Al-Fatiha (its 1:1 is the basmala) and At-Tawbah
LEARN_MARGIN = 3                # Next to learn: the pages of the ayah and of the 3 ayat before and after it (D4)
MANZIL_EXTRA = 3                # Manzil: p .. p+k, k <= 3 recited pages following p without a gap (D3)
TABS = ("ayah", "page")
MARGIN_AYAT = 4                 # #31: a pass starts 0-4 ayat earlier and ends 0-4 ayat later (Vary, user 2026-10-24)
FADE_SPAN = (0.35, 0.65)        # #31: the fade-out stops on a word start within this part of the extra ayah's file
FADE_MIN_MS = 3000              # #31: no fade on an ayah under 3 s (U1.13): no cuts (the players check ms only without)


def reciter(rid) -> dict:
    """#93: the RECITERS entry of an id (spaces around it ignored); Yasser's for a missing, unknown or non-text id.
    v0.22 (D8): "yaser_salamah" (his murattal of 0.20 / 0.21) is his Hadr."""
    if not isinstance(rid, str):
        return RECITER
    rid = rid.strip()
    return _BY_ID.get(_ALIASES.get(rid, rid), RECITER)


def _entry(rid: str | None) -> dict:
    """A reciter entry by its own id, the fallbacks' too (his murattal for "yaser_salamah"); Yasser's for an unknown."""
    return _ENTRIES.get(rid or "", RECITER)


def listen_reciters() -> list[dict]:
    """#93 (B3.14 `listen_reciters`): the Reciter select's options, [{id, label, name}] in RECITERS' order."""
    return [{"id": r["id"], "label": r["label"], "name": r["name"]} for r in RECITERS]


@lru_cache(maxsize=1)
def _selection() -> dict:
    """D4.11: selection_timings.json's entries ({"<rid>/<surah>": entry}); {} when the file is missing or unreadable."""
    try:
        doc = json.loads(SELECTION_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    e = doc.get("entries") if isinstance(doc, dict) else None
    return e if isinstance(e, dict) else {}


def selection_entry(rid: str, surah: int) -> dict | None:
    """v0.21 (#93, D10): the Meddeb selection's whole-surah file of `rid` for `surah` (D4.11: url, name, credit,
    basmala, ayat, file_ms); None when there is none."""
    e = _selection().get(f"{rid}/{int(surah)}")
    return e if isinstance(e, dict) and e.get("url") and e.get("ayat") else None


@lru_cache(maxsize=1)
def _clean() -> dict:
    """v0.22 (D7): yasser_clean_timings.json.gz (gzip or plain JSON); {} when it is missing or unreadable (not built
    yet: the surahs whose QuranicAudio file ticks keep their clean ayat and leave the others out)."""
    try:
        raw = CLEAN_PATH.read_bytes()
        doc = json.loads(gzip.decompress(raw) if raw[:2] == b"\x1f\x8b" else raw)
    except (OSError, ValueError, EOFError, zlib.error):
        return {}
    return doc if isinstance(doc, dict) else {}


def clean_entry(surah: int) -> dict | None:
    """v0.22 (D7): Meddeb's times of surah `surah` inside Yasser's clean recording ({basmala, ayat, word_starts,
    file_ms, url}); None when that surah is not timed (or failed its gate: "untimed")."""
    doc = _clean()
    e = (doc.get("surahs") or {}).get(str(int(surah)))
    tpl = doc.get("audio")
    if not (isinstance(e, dict) and e.get("ayat") and isinstance(tpl, str) and "{sss}" in tpl):
        return None
    return dict(e, url=tpl.replace("{sss}", f"{int(surah):03d}"))


def clean_units(surah: int) -> list[dict]:
    """#92 (v0.23, D17): the units of surah `surah` in Yasser's clean recording, the runs of ayat Meddeb left out of its
    "ayat" because he joins them without a pause (waṣl: the cut between them was never confirmed) that lie between two
    confirmed cuts (tools/build_yasser_clean_timings.py `ayah_units`): [{"ayat": (first, last), "range": (from_ms,
    to_ms) in the surah file, "inner": the tracker's own starts of the following ayat (never a play boundary: the
    page's highlight), "word_starts": per ayah, None when not all its words were placed}]. A unit any ayah of which the
    ban names is dropped (D4.12: the rule is absolute), so is one holding a timed ayah, overlapping another or with a
    range outside the file."""
    e = clean_entry(surah)
    if not e:
        return []
    ayat, fms = e["ayat"], e.get("file_ms")
    out, seen = [], set()
    for u in e.get("units") or ():
        try:
            a, b = (int(x) for x in u["ayat"])
            lo, hi = (int(x) for x in u["range"])
        except (KeyError, TypeError, ValueError):
            continue
        if not (1 <= a <= b <= len(ayat) and 0 <= lo < hi and (not isinstance(fms, int) or hi <= fms)):
            continue
        if any(ayat[k - 1] or k in seen or audio_ban.banned_url(e["url"], k) for k in range(a, b + 1)):
            continue
        seen.update(range(a, b + 1))
        inner = [int(t) for t in u.get("inner") or () if lo < int(t) < hi]
        ws = u.get("word_starts")
        out.append({"ayat": (a, b), "range": (lo, hi), "inner": inner if len(inner) == b - a else [],
                    "word_starts": ws if isinstance(ws, list) else []})
    return out


def clean_unit(surah: int, ayah: int) -> dict | None:
    """#92 (v0.23, D17): the unit of clean_units holding surah:ayah, None when there is none (also for the voice
    commands' clip and the Recite cue, app.py, to play an ayah of the 74 from the clean recording)."""
    return next((u for u in clean_units(surah) if u["ayat"][0] <= int(ayah) <= u["ayat"][1]), None)


# the credit's name of a host (v0.22: the Meddeb selection names each source it plays from the clips' urls)
_HOSTS = {"download.quranicaudio.com": "QuranicAudio.com", "everyayah.com": "EveryAyah.com",
          "cdn.mp3quran.net": "mp3quran.net", "archive.org": "archive.org", "karim-53.github.io": "Meddeb's site"}


def _part(src: dict) -> str:
    """The credit's words for one src: "Yasser Salamah, Hadr (archive.org)", "Islam Sobhi (mp3quran.net)"."""
    host = urlsplit(src["url"]).netloc.lower().removeprefix("www.")
    name = src["name"].replace(" (", ", ").removesuffix(")") if src["name"].endswith(")") else src["name"]
    return f"{name} ({_HOSTS.get(host, host)})"


def _ea_url(rec: dict, key: str) -> str | None:
    """rec's EveryAyah file of key; None when it is banned (D4.12: never played, never a fallback)."""
    url = rec["base_url"] + key + ".mp3"
    return None if audio_ban.banned_url(url) else url


def _ea_source(rec: dict) -> dict:
    return {"rid": rec["id"], "name": rec["name"], "rec": rec, "file": None}


def _file_source(rid: str, e: dict, rec: dict, alt, own1=None) -> dict:
    """A whole-surah file of D4.11 (or the clean recording): `rec` = the EveryAyah entry of the fallback files and the
    estimated ms; `alt` () -> the source of an ayah the file does not hold (null range) or holds banned; `own1` () ->
    the same reciter's Al-Fatiha source, whose 1:1 is the basmala of a file that has none."""
    ayat = e["ayat"]
    ws = e.get("word_starts")
    words = (lambda _s, a: ws[a - 1] if 1 <= a <= len(ws) else None) if isinstance(ws, list) else None
    return {"rid": rid, "name": str(e.get("name") or rec["name"]), "rec": rec, "alt": alt, "own1": own1,
            "file": {"url": e["url"], "basmala": e.get("basmala"), "words": words,
                     "range": lambda a: ayat[a - 1] if 1 <= a <= len(ayat) else None}}


def _yasser_source(s: int) -> dict:
    """Yasser Al-Dossary's surah s (D4.10, D4.12): QuranicAudio's surah file where it holds no banned range; a surah
    whose QuranicAudio file ticks: his clean recording on archive.org once timed (one recording for the whole surah),
    QuranicAudio's clean ayat until then; an ayah neither holds clean: his EveryAyah file when that is clean, else none."""
    ea = _ea_source(RECITER)
    url = qa_times.qa_url(s)
    qa = None
    if url:
        qa = {"rid": RECITER["id"], "name": RECITER["name"], "rec": RECITER, "alt": lambda: ea,
              "own1": (lambda: _yasser_source(1)) if s != 1 else None,
              "file": {"url": url, "basmala": qa_times.qa_basmala(s), "words": qa_times.qa_word_starts,
                       "range": lambda a: qa_times.qa_range(s, a)}}
        if not audio_ban.banned_in_surah(audio_ban.QA_YASSER, s):
            return qa
    e = clean_entry(s)
    if e:
        out = _file_source(RECITER["id"], dict(e, name=RECITER["name"]), RECITER,
                           (lambda: qa) if qa else (lambda: ea), (lambda: _yasser_source(1)) if s != 1 else None)
        out["file"]["unit"] = lambda a: clean_unit(s, a)      # #92 (v0.23, D17): the ayat he joins, played whole
        return out
    return qa or ea


def _selection_source(rid: str, s: int, alt_rid: str) -> dict | None:
    """D4.11's file of rid for surah s ({rid}/{s} in selection_timings.json), alt_rid's source where it holds no
    clean range; None when there is no entry."""
    e = selection_entry(rid, s)
    if not e:
        return None
    own1 = (lambda: _selection_source(rid, 1, alt_rid) or _source(_entry(alt_rid), 1)) if s != 1 else None
    return _file_source(rid, e, _entry(alt_rid), lambda: _source(_entry(alt_rid), s), own1)


def _source(rec: dict, s: int) -> dict:
    """v0.21 (D9 / D10): where the clips of surah s come from in a plan of `rec` (a reciter entry; Mix asks once per
    voice): {rid, name, rec (the EveryAyah entry: its per-ayah files, the fallback, the estimated ms), file (None, or a
    whole-surah file {url, basmala, range: a -> [from, to] or None, words: (s, a) -> starts or None}), alt, own1
    (_file_source)}. Yasser: _yasser_source. v0.22 (D8): the Hadr's file of every surah (his murattal's EveryAyah
    files where a surah has no times); the Meddeb selection's files of 1 / 19 / 20 / 36 / 55."""
    if rec["id"] == MEDDEB:
        own, alt = MEDDEB_FILES.get(s, (None, None))
        f = _selection_source(own, s, alt) if own else None
        if f:
            return f
        rec = _entry(alt) if alt else reciter(MEDDEB_SELECTION.get(s, RECITER["id"]))
    if rec.get("files"):
        return _selection_source(rec["files"], s, rec["fallback_id"]) or _ea_source(_entry(rec["fallback_id"]))
    if rec["id"] == RECITER["id"]:
        return _yasser_source(s)
    return _ea_source(rec)


def _resolve(source: dict, s: int, a: int, key: str) -> tuple[dict | None, dict]:
    """(the src of one clip, the source it comes from): ayah a of surah s (a = 0: the basmala before its ayah 1; key =
    its EveryAyah file). A range of the source's surah file, with the EveryAyah file as the fallback when that is
    clean; a file without basmala takes its reciter's Al-Fatiha 1:1 range (own1: QuranicAudio's 79-114 take Yasser's
    1:1 in his 001 file, as EveryAyah's 001001); an ayah the file does not hold, or holds banned, goes to `alt`; else
    the EveryAyah file (its estimated ms). v0.22 (D7): None when every one of them is banned (the ayah is left out)."""
    f = source["file"]
    if f:
        rng = f["basmala"] if a == 0 else f["range"](a)
        if not rng and a == 0 and source.get("own1"):
            return _resolve(source["own1"](), 1, 1, key)
        if rng and not audio_ban.banned_url(f["url"], a):
            lo, hi = int(rng[0]), int(rng[1])
            out = {"rid": source["rid"], "name": source["name"], "url": f["url"], "from_ms": lo, "to_ms": hi,
                   "ms": hi - lo}
            fb = _ea_url(source["rec"], key)
            if fb:
                out["fallback"] = fb
            return out, source
        if source.get("alt"):
            return _resolve(source["alt"](), s, a, key)
    rec = source["rec"]
    url = _ea_url(rec, key)
    if url is None:
        return None, source
    return {"rid": rec["id"], "name": rec["name"], "url": url,
            "ms": file_ms(*((1, 1) if a == 0 else (s, a)), rec)}, source


def _src(source: dict, s: int, a: int, key: str) -> dict | None:
    return _resolve(source, s, a, key)[0]


def _cuts(source: dict, s: int, a: int, src: dict) -> list[int]:
    """#31's fade cuts of an after-margin clip, in ms from the clip's start: the word starts within FADE_SPAN of its
    ms, none under FADE_MIN_MS. `source` = the one the src came from (_resolve). A range: its surah file's word starts
    (QuranicAudio's, D4.10; the clean recording's, D4.12; D4.11's files have none); an EveryAyah file: Yasser's word
    timings (fade_points, D4.6), none for the other reciters."""
    if "from_ms" not in src:
        return fade_points(s, a)[1] if _timed(source["rec"]) and src["rid"] == RECITER["id"] else []
    words = source["file"]["words"]
    starts = words(s, a) if words else None
    ms = src["ms"]
    if not starts or ms < FADE_MIN_MS:
        return []
    rel = {int(x) - src["from_ms"] for x in starts}
    return sorted(x for x in rel if FADE_SPAN[0] * ms <= x <= FADE_SPAN[1] * ms)


def ayah_key(surah: int, ayah: int) -> str:
    """EveryAyah's file name without .mp3: 2:255 -> "002255"."""
    return f"{int(surah):03d}{int(ayah):03d}"


def _int(v, default: int) -> int:
    """An int or a numeric string from the form; `default` for an empty or unreadable field."""
    if v is None or (isinstance(v, str) and not v.strip()):
        return default
    try:
        return int(v)
    except (TypeError, ValueError):
        try:
            return int(float(v))
        except (TypeError, ValueError, OverflowError):
            return default


def _clamp(v: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, v))


def _pages_text(p: int, r: int) -> str:
    return f"p. {p}" if p == r else f"p. {p}–{r}"


def plan_title(surahs: list[dict]) -> str:
    """"Al-Baqarah 2:1 – 2:16", "Al-Baqarah 2:255"; several surahs are all named: "Al-Fatihah 1:1 – Al-Baqarah 2:5",
    "Al-Ikhlas 112:1 – Al-Falaq – An-Nas 114:6"; more than two in the middle are counted ("– 13 more surahs –")."""
    f, last = surahs[0], surahs[-1]
    if len(surahs) == 1:
        if f["ayah_from"] == f["ayah_to"]:
            return f"{f['name']} {f['surah']}:{f['ayah_from']}"
        return f"{f['name']} {f['surah']}:{f['ayah_from']} – {f['surah']}:{f['ayah_to']}"
    middle = [m["name"] for m in surahs[1:-1]]
    if len(middle) > 2:
        middle = [f"{len(middle)} more surahs"]
    return " – ".join([f"{f['name']} {f['surah']}:{f['ayah_from']}", *middle,
                       f"{last['name']} {last['surah']}:{last['ayah_to']}"])


def _timed(rec: dict | None) -> bool:
    """#93: word timings (D4.6) exist for Yasser's files only."""
    return rec is None or rec["id"] == RECITER["id"]


def file_ms(s: int, a: int, rec: dict | None = None) -> int | None:
    """#88: the length in ms of Yasser's file of s:a (his word timings, D4.6); None for an untimed ayah. #93: another
    reciter's (rec, a RECITERS entry) is estimated: Yasser's x rec's speed, rounded to the ms."""
    t = word_times.timeline(s, a)
    if t is None:
        return None
    ms = int(round(t[1] * 1000))
    return ms if _timed(rec) else int(round(ms * rec["speed"]))


def _lacking_unit(s: int, a: int, rec: dict) -> dict | None:
    """#92 (v0.23, D17): the clean recording's unit (clean_unit) that ayah s:a of a plan of `rec` plays: only for an
    ayah with no clean audio of its own (every source of _resolve banned or untimed: the 74) in a surah Yasser plays
    from that recording (his own plans and the Meddeb selection's); None elsewhere. Mix keeps v0.22's rule (Yasser's
    turn goes to the next voice: its clips are per ayah for every voice)."""
    if rec["id"] == MIX or a < 1:
        return None
    source = _source(rec, s)
    unit = (source.get("file") or {}).get("unit")
    if unit is None or _src(source, s, a, ayah_key(s, a)) is not None:
        return None
    return unit(a)


def _unit_cuts(u: dict) -> list[int]:
    """#31's fade cuts of a unit in the after-margin: its ayat's word starts within FADE_SPAN of its length, ms from
    its start; none under FADE_MIN_MS."""
    lo, hi = u["range"]
    ms = hi - lo
    if ms < FADE_MIN_MS:
        return []
    rel = {int(x) - lo for ws in u["word_starts"] if isinstance(ws, list) for x in ws}
    return sorted(x for x in rel if FADE_SPAN[0] * ms <= x <= FADE_SPAN[1] * ms)


def _unit_clip(s: int, u: dict, source: dict, cuts: bool = False) -> dict:
    """#92 (v0.23, D17): one clip for a whole unit: key, ayah, page of its first ayah, `ayah_to` its last, `unit` [first,
    last], label "s:a-b", src = its range of the clean recording's surah file (no fallback: no per-ayah file holds it),
    `ayah_starts` [[ayah, ms from the clip's start]] (the tracker's own starts, for the page's highlight; never a play
    boundary); cuts: its after-margin fade cuts (_unit_cuts)."""
    a, b = u["ayat"]
    lo, hi = u["range"]
    src = {"rid": source["rid"], "name": source["name"], "url": source["file"]["url"], "from_ms": lo, "to_ms": hi,
           "ms": hi - lo}
    clip = {"key": ayah_key(s, a), "kind": "ayah", "surah": s, "ayah": a, "ayah_to": b, "unit": [a, b],
            "label": f"{s}:{a}" + (f"-{b}" if b > a else ""), "page": page_of(s, a), "ms": hi - lo, "src": src,
            "ayah_starts": [[a, 0]] + [[a + 1 + i, t - lo] for i, t in enumerate(u["inner"])]}
    if cuts:
        clip["cuts"] = _unit_cuts(u)
    return clip


def _ayah_clips(s: int, a: int, rec: dict | None = None, cuts: bool = False, unit: dict | None = None) -> list[dict]:
    """The clips of one ayah in a plan: its basmala first when it is ayah 1 of a surah that has one (D6), then the
    ayah's own file. #88: each carries `ms`, its file's length (the basmala is 1:1's file), for the page's estimate of
    how long a listening lasts (#93: rec's, file_ms). v0.21 (D9 / D10): each carries `src`, what to play (_source,
    _src), and ms = src's; a Mix plan's also `mix`, a src per VOICES entry (src = the first's). cuts: the clips also
    carry their fade cuts (`cuts`, the after-margin's #31; for Mix inside each mix src too). v0.22 (D7): a part with
    no clean audio is left out (Yasser's ayah ticked in every source he has timed); in Mix a voice without one plays
    the next voice's src in VOICES' order (Mix skips Yasser there; the rotation keeps its length). #92 (v0.23, D17):
    `unit` (_lacking_unit's): the clips of the whole unit instead, its basmala when it opens a surah, then _unit_clip."""
    rec = rec or RECITER
    sources = [_source(v, s) for v in (VOICES if rec["id"] == MIX else (rec,))]
    if unit:
        a = unit["ayat"][0]
    pg = page_of(s, a)
    parts = [({"key": ayah_key(s, a), "kind": "ayah", "surah": s, "ayah": a, "label": f"{s}:{a}", "page": pg}, a)]
    if a == 1 and s not in NO_BASMALA:
        parts.insert(0, ({"key": BASMALA_KEY, "kind": "basmala", "surah": s, "ayah": 0, "label": "Basmala",
                          "page": pg}, 0))
    out = []
    for clip, k in parts:
        if k and unit:
            out.append(_unit_clip(s, unit, sources[0], cuts))
            continue
        got = [_resolve(src, s, k, clip["key"]) for src in sources]
        if cuts:
            for x, used in got:
                if x is not None:
                    x["cuts"] = _cuts(used, s, k, x) if k else []
        n = len(got)
        srcs = [next((got[(i + j) % n][0] for j in range(n) if got[(i + j) % n][0] is not None), None)
                for i in range(n)]
        if srcs[0] is None:
            continue
        srcs = [dict(x) for x in srcs]          # a voice that borrows the next one's src gets its own copy
        first = {x: v for x, v in srcs[0].items() if x != "cuts"}
        clip.update(ms=first["ms"], src=first)
        if cuts:
            clip["cuts"] = srcs[0]["cuts"]
        if rec["id"] == MIX:
            clip["mix"] = srcs
        out.append(clip)
    return out


def _credit(rec: dict, clips: list[dict], skipped: int = 0, added: list[str] = ()) -> str:
    """The credit under the Listen form: the entry's own; the Meddeb selection's names every source the plan plays,
    in playing order ("Recitation (Meddeb selection): Islam Sobhi (mp3quran.net), Yasser Salamah, Hadr (archive.org)").
    v0.22: a plan that plays Yasser's clean recording (D7) or Salamah's murattal (D8, a surah without Hadr times)
    says so, and how many ayat it leaves out (no clean audio yet). #92 (v0.23, D17): and the ayat it adds to complete a
    unit ("· 30:10 added: Yasser joins it to the range without a pause in his clean recording")."""
    srcs = [x for c in clips for x in (c.get("mix") or [c["src"]])]
    if rec["id"] == MEDDEB:
        parts = dict.fromkeys(_part(x) for x in srcs)
        out = f"{rec['credit']}: {', '.join(parts)}"
    else:
        out = rec["credit"]
        if any(x["rid"] == RECITER["id"] and (audio_ban.source_of(x["url"]) or ("",))[0] == CLEAN_SID for x in srcs):
            out += "; his recording on archive.org (mp3quran.net) where QuranicAudio's files tick"
        if any(x["rid"] == _MURATTAL["id"] for x in srcs):
            out += "; Yasser Salamah (murattal), EveryAyah.com, where a surah has no Hadr times"
    if added:
        out += (f" · {', '.join(added)} added: Yasser joins {'it' if len(added) == 1 else 'them'} to the range without a "
                f"pause in his clean recording")
    if skipped:
        out += f" · {skipped} {'ayah' if skipped == 1 else 'ayat'} left out: no recording without ticks yet"
    return out


def fade_points(s: int, a: int) -> tuple[int | None, list[int]]:
    """#31: (the ayah file's length in ms, the word starts in ms within FADE_SPAN of it, ascending; a word Yasser
    repeats counts at each start) from his word timings (D4.6); (None, []) for an untimed ayah. #31 review: no cuts
    for an ayah under FADE_MIN_MS (the pass shape fades to a cut whenever there is one: 20:28, 1.9 s, played at half
    volume and stopped at 0.84 s)."""
    t = word_times.timeline(s, a)
    if t is None:
        return None, []
    entries, dur = t
    ms = int(round(dur * 1000))
    if ms < FADE_MIN_MS:
        return ms, []
    starts = {int(round(x * 1000)) for _k, x in entries}
    return ms, sorted(x for x in starts if FADE_SPAN[0] * ms <= x <= FADE_SPAN[1] * ms)


def margins(first: tuple[int, int], last: tuple[int, int], q, rec: dict | None = None) -> tuple[list[dict], list[dict]]:
    """#31 (user, 2026-10-24: "randomize start and end with a +[0-4] eyats"): (margin_before, margin_after), the up to
    MARGIN_AYAT ayat before the range's first ayah and after its last one, in playing order, inside their surah (a surah
    boundary is a natural stop, and 1:1 / 114:6 stay the Qur'an's edges). Each clip is a plan clip plus `step` (1 = the
    adjacent ayah); a basmala comes with the ayah 1 it opens and its step (never for Al-Fatihah and At-Tawbah); the
    after-margin's clips also carry `cuts` (fade_points) for the fade-out (`ms`, like every plan clip, #88). #93: for an
    untimed reciter (rec other than Yasser) the estimated ms and no cuts (the players fade at 35-65 % of ms). v0.21:
    the ms is the clip's src's, a ranged clip's cuts its surah file's word starts from the clip's start (_cuts).
    #92 (v0.23, D17): an ayah with no clean audio of its own enters as its whole unit (_unit_clip, the step of its
    member nearest to the range; it may reach past MARGIN_AYAT), when the unit's other ayat lie further out; a margin
    stops at an ayah it cannot play (no clean audio and no such unit): a pass never skips an ayah inside it."""
    rec = rec or RECITER
    (s0, a0), (s1, a1) = first, last
    before, a = [], a0 - 1
    while a >= max(1, a0 - MARGIN_AYAT):
        got, nxt = _margin_clips(s0, a, rec, -1)
        if not got:
            break
        before = [dict(c, step=a0 - a) for c in got] + before
        a = nxt
    after, a = [], a1 + 1
    while a <= min(q.n_ayat(s1), a1 + MARGIN_AYAT):
        got, nxt = _margin_clips(s1, a, rec, 1)
        if not got:
            break
        after += [dict(c, step=a - a1) for c in got]
        a = nxt
    return before, after


def _margin_clips(s: int, a: int, rec: dict, side: int) -> tuple[list[dict], int]:
    """(the clips of margin ayah s:a, the next ayah further out); ([], a) when it cannot play: no clean audio, and no
    unit of the clean recording that begins (side 1: after the range) or ends (side -1: before it) at a. #92 (v0.23)."""
    got = _ayah_clips(s, a, rec, cuts=side > 0)
    if any(c["kind"] == "ayah" for c in got):
        return got, a + side
    u = _lacking_unit(s, a, rec)
    if u is None or u["ayat"][0 if side > 0 else 1] != a:
        return [], a
    return _ayah_clips(s, a, rec, cuts=side > 0, unit=u), u["ayat"][1] + 1 if side > 0 else u["ayat"][0] - 1


def listen_plan(params: dict, q=None) -> dict:
    """{"tab": "ayah", "surah", "ayah_from", "ayah_to"} or {"tab": "page", "page_from", "page_to"} (ints or numeric
    strings, other keys ignored; clamped to the surah / to 1..604, a reversed range swapped; no end = the end of the
    surah / the start page) -> the clips in mushaf order, the surahs covered, a title (B3.14, plan §1.1), and the
    margins a varied pass may add around the range (#31: margin_before, margin_after); every clip carries its file's
    length (`ms`, None when untimed, #88). #93: params["reciter"] (an id of RECITERS; Yasser when missing or unknown)
    is the plan's reciter (its subtitle, credit and base_url, which the players put before every clip's key). v0.21
    (D9 / D10): every clip's `src` says what to play (the module's docstring); the credit names the plan's sources.
    v0.22 (D7): `skipped` = the ayat of the range left out ("s:a": no audio of the reciter without ticks yet; the
    credit counts them); n_ayat counts the range's ayat. #92 (v0.23, D17): an ayah with no clean audio of its own
    that is in a unit of Yasser's clean recording plays that whole unit, one clip (_unit_clip); a range holding part of
    such a unit is extended to all of it (`added` = ["s:a"] the ayat added; the title, pages, n_ayat and the credit
    follow), never a skip, never a ticked file."""
    q = q or load_quran()
    rec = reciter(params.get("reciter"))
    tab = str(params.get("tab") or ("ayah" if "surah" in params else "page"))
    if tab not in TABS:
        raise ValueError(f"unknown listen tab {tab!r}")
    if tab == "ayah":
        s = _clamp(_int(params.get("surah"), 1), 1, 114)
        n = q.n_ayat(s)
        a = _clamp(_int(params.get("ayah_from"), 1), 1, n)
        b = _clamp(_int(params.get("ayah_to"), n), 1, n)
        a, b = min(a, b), max(a, b)
        ayat = [(s, k) for k in range(a, b + 1)]
        p_from, p_to = page_of(s, a), page_of(s, b)
    else:
        p = _clamp(_int(params.get("page_from"), 1), 1, N_PAGES)
        r = _clamp(_int(params.get("page_to"), p), 1, N_PAGES)
        p_from, p_to = min(p, r), max(p, r)
        ayat = list(dict.fromkeys(sa for pg in range(p_from, p_to + 1) for sa in page_ayat(pg)))
    asked = set(ayat)
    units = _plan_units(ayat, rec)              # #92 (v0.23, D17): {(s, a): unit} of every unit the range plays
    (s0, a0), (s1, a1) = ayat[0], ayat[-1]
    if (s0, a0) in units:                       # part of a unit: the whole unit (one ayah more, never a skip)
        ayat = [(s0, k) for k in range(units[(s0, a0)]["ayat"][0], a0)] + ayat
    if (s1, a1) in units:
        ayat = ayat + [(s1, k) for k in range(a1 + 1, units[(s1, a1)]["ayat"][1] + 1)]
    p_from, p_to = min(p_from, page_of(*ayat[0])), max(p_to, page_of(*ayat[-1]))
    clips: list[dict] = []
    surahs: list[dict] = []
    for s, a in ayat:
        u = units.get((s, a))
        if u is None:
            clips += _ayah_clips(s, a, rec)     # D6: a basmala at the range start and at each surah boundary, every pass
        elif a == u["ayat"][0]:
            clips += _ayah_clips(s, a, rec, unit=u)
        if surahs and surahs[-1]["surah"] == s:
            surahs[-1]["ayah_to"] = a
        else:
            surahs.append({"surah": s, "name": q.chapter_name(s), "name_arabic": q.chapter_name_ar(s),
                           "ayah_from": a, "ayah_to": a})
    first = surahs[0]
    before, after = margins(ayat[0], ayat[-1], q, rec)
    played = {(c["surah"], k) for c in clips if c["kind"] == "ayah"
              for k in range(c["ayah"], c.get("ayah_to", c["ayah"]) + 1)}   # a unit: each of its ayat
    skipped = [f"{s}:{a}" for s, a in ayat if (s, a) not in played]
    added = [f"{s}:{a}" for s, a in ayat if (s, a) not in asked]
    return {"tab": tab, "title": plan_title(surahs), "subtitle": rec["name"],
            "surah": first["surah"], "ayah_from": first["ayah_from"], "ayah_to": first["ayah_to"],
            "page_from": p_from, "page_to": p_to, "surahs": surahs,
            "reciter": dict(rec, credit=_credit(rec, clips + before + after, len(skipped), added)), "clips": clips,
            "n_ayat": len(ayat), "margin_before": before, "margin_after": after, "skipped": skipped, "added": added}


def _plan_units(ayat: list[tuple[int, int]], rec: dict) -> dict[tuple[int, int], dict]:
    """#92 (v0.23, D17): {(s, a): unit} for every ayah of every unit the range needs: one of its ayat in the range has
    no clean audio of its own (_lacking_unit); an ayah of a unit whose ayat in the range all have their own plays alone
    (16:103, clean in QuranicAudio, without 16:102)."""
    used: dict[tuple[int, int], dict] = {}
    for s, a in ayat:
        if (s, a) not in used:
            u = _lacking_unit(s, a, rec)
            if u:
                used.update({(s, k): u for k in range(u["ayat"][0], u["ayat"][1] + 1)})
    return used


def learn_pages(surah: int, ayah: int, q=None) -> tuple[int, int]:
    """D4: the pages holding the ayah and the LEARN_MARGIN ayat before and after it in mushaf order (across surahs,
    clamped at 1:1 and 114:6); 1 or 2 pages, 3 when the ayat are long (2:282)."""
    q = q or load_quran()
    order = sorted(q.ayat)
    k = _clamp(bisect.bisect_left(order, (surah, ayah)), 0, len(order) - 1)
    pages = [page_of(*sa) for sa in order[max(0, k - LEARN_MARGIN): k + LEARN_MARGIN + 1]]
    return min(pages), max(pages)


def _target(kind: str, label: str, detail: str, p_from: int, p_to: int, repeat: int, q, rid=None, **extra) -> dict:
    return {"kind": kind, "tab": "page", "page_from": p_from, "page_to": p_to, "repeat": repeat, **extra,
            "label": label, "detail": detail,
            "plan": listen_plan({"tab": "page", "page_from": p_from, "page_to": p_to, "reciter": rid}, q)}


def listen_targets(progress: dict, q=None, reciter=None, review=None) -> dict:
    """The quick buttons of U1.13 from a progress.progress() result; an entry is None when its Progress source is.
    Weak page: that page, repeat 17. Learn page (the next to learn): learn_pages, repeat 17. Oldest page (the manzil,
    #114: key "manzil"): p .. p+k where p+1 .. p+k are pages of the Progress table without a gap (k <= 3), repeat 0.
    Android Auto and the launcher shortcut name the learn entry "Next to learn" with their own strings. #93: the plans
    are the `reciter`'s (an id; Yasser by default). #91 (v0.21, D4): a locked Next to learn (progress' learn_lock)
    gives the learn entry `locked` (the
    reason) and `lock` (learn_lock itself): the page's Learn page button, the presets file and the car say 🔒. v0.21
    review: a lock hidden only by done today gives `locked_next_day` = {date, reason} (the car's LearnLock reads it once
    the date is later: a presets file written today, read on a cold start tomorrow). #101 (v0.22, plan D5; user,
    2026-11-02: "multiple recite buttons: General recite, manzil, review, weak page, next to learn"): review = {card: a
    review_queue card, plan: its review_card, due: the cards due} (App's first card not waiting for its retry) gives the
    car's Recite review entry {kind, label, detail "N due · s:a-b", surah, ayah: the run-up's first ayah, card,
    target, page, cue, start: the card session's start meta}; None without one. No plan: it is recited, not played."""
    q = q or load_quran()
    out: dict[str, dict | None] = {"weak": None, "learn": None, "manzil": None, "review": None}
    if review and review.get("card") and review.get("plan"):
        c, p = review["card"], review["plan"]
        s, (a1, a2) = int(c["surah"]), (int(x) for x in c["target"])
        due = int(review.get("due") or 1)
        out["review"] = {"kind": "review", "label": "Recite review",
                         "detail": f"{due} due · {s}:{a1}" + (f"-{a2}" if a2 != a1 else ""),
                         "surah": s, "ayah": int(p["runup_from"]), "card": c["id"], "target": [a1, a2],
                         "page": p.get("page"), "cue": p.get("cue"), "start": p.get("start")}
    weak = progress.get("weak")
    if weak:
        p, err = int(weak["page"]), int(weak["err"])
        out["weak"] = _target("weak", "Weak page", f"p. {p} · {err} mistake{'' if err == 1 else 's'}", p, p,
                              REPEAT_DEFAULT, q, reciter)
    nxt = progress.get("next_to_learn")
    if nxt:
        s, a = int(nxt["surah"]), int(nxt["ayah"])
        lo, hi = learn_pages(s, a, q)
        out["learn"] = _target("learn", "Learn page", f"{s}:{a} · {_pages_text(lo, hi)}", lo, hi, REPEAT_DEFAULT, q,
                               reciter, surah=s, ayah=a)
        lock = progress.get("learn_lock")
        if lock:                                    # #91 (D4): advice only, the entry still plays its range
            out["learn"].update(locked=lock["reason"], lock=lock)
        elif progress.get("learn_lock_next_day"):   # v0.21 review: hidden by done today, locked from the next day on
            later = progress["learn_lock_next_day"]
            out["learn"]["locked_next_day"] = {"date": later["date"], "reason": later["reason"]}
    manzil = progress.get("manzil")
    if manzil:
        recited = {int(r["page"]) for r in progress.get("pages") or []}
        p = e = int(manzil["page"])
        while e + 1 in recited and e + 1 <= min(p + MANZIL_EXTRA, N_PAGES):
            e += 1
        # #114 (v0.23, D6; user 2026-11-04: "the word Manzil might be difficult to grasp"): "Oldest page" on screen
        # (it pairs with "Weakest page"); the key, the media ids and the stored data stay "manzil"
        out["manzil"] = _target("manzil", "Oldest page", _pages_text(p, e), p, e, 0, q, reciter)
    return out
