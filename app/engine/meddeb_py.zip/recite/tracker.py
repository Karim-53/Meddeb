"""Live recitation tracker: streaming audio -> rolling ASR window -> alignment to the expected
passage -> committed / provisional word verdicts.

Whisper-family models are not streaming models, so we emulate streaming with a *rolling
buffer* that is re-decoded every tick (about 1 s of new audio). Words far enough from the end
of the buffer are considered stable and get *committed*: the expected-word pointer advances and
the audio before them is dropped, keeping every decode short (<= max_window seconds).

Behaviour (v3, see 02_requirements.md):
  * EVIDENCE across decodes: "ok" after one correct sighting, "wrong" after the same disagreement in
    >= 3 successive decodes (wrong_evidence), "missing" after >= 3 successive decodes that covered its position.
  * GRADED SUSPICION SCORES in [0, 1] (wrong: 0.5 + 0.5 * dissimilarity; missing: 0.6-0.9 from the
    silence gap; lost: 0.8; in-session hint: 1.0). The user's threshold decides what is shown/counted.
  * CURSOR = the reference word matched by the last decoded word (repeats included), so saying
    "A B C D E" then "B C D E F" moves the cursor back to B and forward again.
  * LOST rule: if the first matched word skips more than `max_skip` expected words, the words already
    heard are settled as Stop does (correct; the attempt when extra words before one were seen in 2+
    decodes) and the first word never heard is marked as a mistake, concealed (the client shows a
    placeholder) until it is said or hinted; nothing advances meanwhile. The jump is measured
    again from that first word never heard (issue #6, 2026-10-10: the committed pointer often lags
    behind the words heard): a jump of max_skip words or fewer from there is no jump, unless the decode
    does not fit there either (off-track there: another passage said instead). What was heard there is
    where the speech went on, never a word already heard (review 2026-10-11); its replay span is that heard form's,
    or the gap before the speech went on (#35, v0.15), never the whole decode.
  * NO EVIDENCE (issue #6, 2026-10-10, _no_evidence): a heard form no reciter would say (a lone letter,
    a 2-letter non-Qur'an form, a non-Qur'an form unlike the word and its neighbours, the beginning or
    end of a neighbouring word: a cut word, a hesitation) decides nothing: neither heard nor wrong nor
    skipped, never an attempt nor the heard form of a lost word; a word heard only that way is correct
    at its commit. The real evidence of the other decodes still decides (review 2026-10-11): a real
    wrong form or skip seen in 2+ decodes once the evidence window (wrong_evidence / missing_evidence
    decodes, these included) is full; seen in one decode only among them, it is outvoted (precision
    first); never a wait for the 24 s buffer limit.
  * SAID (2026-10-10): a word heard correctly once (also a committed one said again within the back
    window) is `said`: the client never shows the expected word of an unsaid mistake in Hidden / Blind
    during a session, and a concealed word said is shown (it stays a mistake).
  * MID-PAGE START: before anything was matched, words that clearly fit further on than the first
    expected word start the session there; the words before are not recited (never mistakes). While
    the first words could be in two places (too few, or a phrase repeated on the page), nothing is
    decided yet. #33 (v0.15): a decode of fewer than start_jump_min matched words never fixes the start; while at
    most 2 words are committed from the first word and nothing was hinted or marked (_start_open), a decode the
    current place explains badly that clearly fits further on the start page restarts the session there; the words
    said before a new start are dropped with their audio (#33 review: never judged there).
  * WRONG ATTEMPTS: words inserted between two expected words that are neither a repeat nor a
    hesitation (A B C X Y D E F) are a failed attempt at the next expected word: D is "wrong"
    (heard "X Y") once the extras were seen in `wrong_evidence` successive decodes, even though D
    was said correctly afterwards. Leftovers of a cut word at the buffer head, tails/prefixes of a
    neighbouring word and words shorter than `attempt_min_len` letters never count.
  * HINTS during a session count as mistakes (brown) and advance past the hinted word; words
    revealed before a session are just visible. A hint on a word that already is a mistake (lost,
    wrong, skipped) keeps its verdict and moves nothing when it is behind the pointer (◂ reveals the
    red bar first, issue #1); the words before the hinted one heard behind an attempt not confirmed
    yet are settled as Stop does (issue #5); so are the words heard after a hinted word the reciter
    already passed (the page's earliest bar), and the audio of the words not settled is kept.
  * A provisional verdict is never downgraded to "pending" by a later decode that did not cover
    the word again: what the screen has shown stays shown until the word is settled.
  * WORD TIMES for replay: median over the observations of successive decodes, snapped to speech
    energy; missing words take the gap between their neighbours.
  * off-track (side talk / another passage) commits nothing; ta'awwudh / basmala before the passage
    are ignored; hallucination loops and garbage tokens are removed.
  * NEXT SURAH (X2.1d): the passage can be extended (extend()) with the following surahs; at a surah boundary
    the basmala (before At-Tawbah too, K6) and a ta'awwudh are optional: dropped from the decoded words when they
    sit between the end of one surah and the start of the next, so they are never a mistake nor an attempt.
    Words that fit the surah just recited as well as the next one (the same surah said again to memorize it) are
    held back from the next surah; a surah with fewer than start_jump_min words heard is never given a mistake at
    Stop (words said after the last surah, e.g. «صدق الله العظيم» or «آمين», are no attempt at the next one).
  * VOICE COMMANDS (X2.15, B3.15, recite/voice.py): before anything else sees the decoded words, the words of consumed
    spans (commands already fired) are dropped, then «صدق الله العظيم» and the command phrases (voice.COMMAND_TEMPLATES)
    are matched in the same rolling decode (no other model) and dropped (with the commands off too); a fired command is
    reported in `voice` (Session applies it). This runs before the X2.16 foreign rule, so a command word is never
    dropped as side talk before it is seen. The only extra decode: a lone short burst between two silences of 1 s is
    decoded once more alone (island word «كلمة», 2026-10-10, and the other island words, phrases and the formula said
    alone, 2026-10-11: _island_pass), with the commands on only.
  * ANOTHER LANGUAGE (X2.16): a decoded word that is no Qur'an word and unlike the expected words where it sits is
    dropped before the alignment (never a mistake), but still shows ⚠ off-track; Stop never marks a word never said
    for the extras before it; ◂ / ⏮ keep the words already heard as correct. One such word alone in a word's slot
    between heard words is kept (a garbled word there: no evidence, issue #6), not dropped into a skip.
"""
from __future__ import annotations

import statistics
from dataclasses import dataclass, field

import numpy as np

from . import voice as vc
from .align import align, similarity
from .normalize import clean_hyp, normalize
from .quran_text import vocabulary

TAAWWUDH = "اعوذ بالله من الشيطان الرجيم".split()
BASMALA = "بسم الله الرحمن الرحيم".split()
FINAL_STATUSES = ("ok", "wrong", "missing", "hinted", "revealed")
MISTAKE_STATUSES = ("wrong", "missing", "hinted")
# Issue #6 N4 (2026-10-10): a 3+-letter token that is a strict prefix / suffix of another expected word among the 3 before
# and the one after (a cut word, a hesitation; «وات» of «واتوا») is no evidence either. Shipped because the real-model
# gates are the same with and without it (2026-10-11: calibration 0 alarms, the 8 sessions' flagged words identical;
# replay_sessions.py --n4 off compares).
NO_EVIDENCE_N4 = True


@dataclass
class WordState:
    status: str = "pending"      # pending | ok | wrong | missing | hinted | provisional_ok | provisional_wrong | provisional_missing
    score: float = 0.0           # suspicion in [0, 1]; compared with the user's threshold
    hyp: str | None = None
    final: bool = False
    hinted: bool = False         # revealed by "next word" / "next ayah" during the session
    lost: bool = False           # flagged by the lost rule
    concealed: bool = False      # a lost word not said nor revealed yet: the client shows a placeholder, not the word
    said: bool = False           # a final word heard correctly later (also re-said in the back window; word_dict "said")
    user_marked: bool = False    # the user overruled the verdict
    auto: tuple | None = None    # (status, score, final) before the user's first mark: unmark() restores it
    t_start: float | None = None  # session seconds of what was heard for this word
    t_end: float | None = None
    t_obs: list = field(default_factory=list)   # (start, end) observations across decodes
    # evidence across decodes
    ok_seen: int = 0
    wrong_run: int = 0
    miss_run: int = 0
    extra_run: int = 0           # successive decodes with a wrong attempt (extra words) right before this word
    extra_hyp: str | None = None  # the extra words of the last such decode
    extra_score: float = 0.0     # suspicion of the attempt: 0.5 + 0.5 x dissimilarity of its closest word
    extra_t0: float | None = None  # session time of the first extra word
    unsure: int = 0              # issue #6: decodes that paired a no-evidence form with this word (Tracker._no_evidence)


@dataclass
class TrackerConfig:
    sr: int = 16000
    max_window_s: float = 24.0     # force a commit when the buffer gets longer than this
    stable_s: float = 2.0          # hypothesis words ending earlier than (end - stable_s) are stable
    min_commit_s: float = 4.0      # do not commit before the buffer holds this much audio
    cut_margin_s: float = 0.5      # keep this much audio before the last committed word
    expect_window: int = 60        # expected words considered ahead of the committed pointer
    back_window: int = 8           # committed words kept in the alignment window (cursor / repeats)
    max_skip: int = 3              # more skipped words than this = lost
    off_track_min_words: int = 4
    off_track_match_ratio: float = 0.35
    off_track_debounce: int = 2    # consecutive off-track decodes before reporting it
    energy_gate: float = 0.004     # absolute frame RMS below which there is never speech
    # Noise floor = low percentile of the 20 ms frame RMS over the last floor_hist_s of the SESSION
    # (not of the buffer alone: a buffer of continuous recitation has no quiet frame, its own p10-p15
    # is speech). Constant fan noise never exceeds 1.8 x its floor (measured on the user's sessions),
    # speech is 5-11 x the floor. The rule is only armed once floor_min_s of audio has been heard.
    floor_pct: float = 10.0
    floor_mult: float = 3.0        # a frame is "quiet" (no possible speech) below floor_mult x floor ...
    floor_cap: float = 0.012       # ... but never above this absolute RMS (-38 dBFS): a session without
                                   # any pause has a speech-level "floor", the cap keeps soft speech safe
    floor_hist_s: float = 30.0     # length of the frame-RMS history the floor is estimated on
    floor_min_s: float = 3.0       # history needed before the floor rule is applied
    head_keep_s: float = 0.5       # audio kept before the first energetic frame when the quiet head is dropped
    noise_keep_s: float = 2.0      # buffer kept (and no decode run) while it holds no energetic frame at all
    no_words_keep_s: float = 6.0   # buffer kept after a decode that returned no word (long enough for a
                                   # sustained madd whose first seconds Whisper has not transcribed yet)
    preprocess: str | None = None  # recite.audio.PREPROCESSORS variant applied to the buffer before each decode
    wrong_evidence: int = 3        # successive decodes needed to commit "wrong" (3: fewer false alarms on phone audio)
    missing_evidence: int = 3      # successive decodes needed to commit "missing"
    threshold: float = 0.6         # suspicion >= threshold counts as a mistake (user-tunable; 0.6 since 2026-09-20: one-letter
                                   # slips such as ض->س (score 0.6) count, 0.57-class near-misses still do not)
    attempt_rule: bool = True      # extra words before an expected word = a wrong attempt at it (X2.4e)
    attempt_min_len: int = 3       # letters an extra word needs to count as an attempt (shorter = CTC fragments)
    head_guard_s: float = 0.8      # extras starting this close to the buffer head are leftovers of the last cut word
    start_jump_min: int = 3        # X2.1c: matched words needed to start the session further on than its first word
    start_jump_ratio: float = 0.6  # ... and the share of the decoded words they must be
    start_search_words: int = 400  # expected words searched for that start, at most (Tracker.start_page_end limits it to
                                   # the session's start page)
    voice_commands: bool = True    # X2.15: False = nothing fires (the formula and the command phrases are still
                                   # dropped from the verdicts, R4)
    foreign_rule: bool = True      # X2.16 R1: side talk (no Qur'an word, unlike the expected words there) is dropped
    foreign_min_len: int = 3       # letters a decoded word needs to be judged foreign (shorter: CTC fragments)
    foreign_max_sim: float = 0.55  # foreign = similarity below this to every nearby expected word (replay of the 8
                                   # sessions: 38 alarms at 0.55, 39 at 0.5 with 4 scripted side-talk cases left)


@dataclass
class Tracker:
    expected_norm: list[str]
    config: TrackerConfig = field(default_factory=TrackerConfig)
    expected_alt: list[str | None] | None = None   # alternative (Uthmani) spelling per word
    committed: int = 0
    cursor: int = -1                # index of the last processed word (-1 = nothing yet)
    states: list[WordState] = field(default_factory=list)
    buffer: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=np.float32))
    buffer_t0: float = 0.0          # session time of buffer[0]
    total_samples: int = 0
    off_track: bool = False
    off_track_count: int = 0
    last_hyp: str = ""
    last_latency: float = 0.0
    edge_skipped: int = 0           # basmala / ta'awwudh words dropped at the very beginning
    first: int = 0                  # X2.1c: where the reciter actually started (the words before are not recited)
    started: bool = False
    changed: set = field(default_factory=set)      # word indices modified since the last snapshot
    decode_log: list = field(default_factory=list)  # (session_time, hyp) per decode
    skipped_decodes: int = 0        # steps that ran no ASR because the buffer held no speech (noise only)
    noise_floor: float | None = None  # session noise floor (frame RMS); None until floor_min_s of audio
    rms_hist: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=np.float32))  # frame RMS history
    _pending: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=np.float32))  # < 1 frame of audio
    surah_starts: dict = field(default_factory=dict)  # X2.1d: word index -> the surah that starts there (index > 0)
    stopped: bool = False           # frozen by a final step (Stop): the passage is never extended again
    accepted: dict = field(default_factory=dict)   # X2.17: expected word (N0) -> heard forms the user accepted
    start_page_end: int | None = None  # X2.1c: words [0, start_page_end) are printed on the session's start page, the
                                       # only place the reciter may start further on (None: no page, start_search_words)
    consumed: list = field(default_factory=list)       # B3.15: (t0, t1) session seconds of the commands fired
    voice: list = field(default_factory=list)          # X2.15: commands fired, not taken yet (Session.step drains it)
    voice_log: list = field(default_factory=list)      # words dropped by the voice / foreign rules (decodes.jsonl)
    last_fired: dict = field(default_factory=dict)     # B3.15: command -> session end of its last consumed span (REPEAT_S)
    n_foreign: int = 0              # X2.16: foreign words dropped from the current decode
    formula_strip: tuple = (0, None)  # #41: (start-formula words stripped from the current decode, buffer end of the
                                      # complete formulas at its head or None)
    islands_done: list = field(default_factory=list)   # B3.15 island word: session starts of the bursts decoded alone

    def __post_init__(self) -> None:
        self.states = [WordState() for _ in self.expected_norm]

    def extend(self, norms: list[str], alts: list[str | None] | None = None, surah: int | None = None) -> None:
        """X2.1d: append the next surah's words (normalized, with their alternative spellings) to the passage: the
        session follows the reciter into it. `surah` marks a surah boundary (its basmala / ta'awwudh are optional)."""
        start = len(self.expected_norm)
        self.expected_norm = list(self.expected_norm) + list(norms)
        if self.expected_alt is not None or alts is not None:
            old = self.expected_alt if self.expected_alt is not None else [None] * start
            self.expected_alt = list(old) + (list(alts) if alts is not None else [None] * len(norms))
        self.states.extend(WordState() for _ in norms)
        if surah is not None:
            self.surah_starts[start] = surah

    # ------------------------------------------------------------------ audio in
    def push_audio(self, samples: np.ndarray) -> None:
        samples = samples.astype(np.float32)
        self.buffer = np.concatenate([self.buffer, samples])
        self.total_samples += len(samples)
        self._update_floor(samples)

    def _update_floor(self, samples: np.ndarray, frame_s: float = 0.02) -> None:
        """Feed the frame-RMS history (whole session, independent of what the buffer drops)."""
        cfg = self.config
        n = int(frame_s * cfg.sr)
        x = np.concatenate([self._pending, samples]) if len(self._pending) else samples
        k = len(x) // n
        self._pending = x[k * n:]
        if k == 0:
            return
        rms = np.sqrt((x[: k * n].reshape(k, n) ** 2).mean(axis=1))
        keep = int(cfg.floor_hist_s / frame_s)
        self.rms_hist = np.concatenate([self.rms_hist, rms.astype(np.float32)])[-keep:]
        if len(self.rms_hist) * frame_s >= cfg.floor_min_s:
            self.noise_floor = float(np.percentile(self.rms_hist, cfg.floor_pct))

    @property
    def done(self) -> bool:
        return self.committed >= len(self.expected_norm)

    @property
    def session_time(self) -> float:
        return self.total_samples / self.config.sr

    # ------------------------------------------------------------------ helpers
    def _touch(self, i: int) -> None:
        self.changed.add(i)

    def _strip_start_formulas(self, hyp_words, hyp_start, hyp_end, hyp_prob):
        """Before the first expected word is committed, drop leading ta'awwudh / basmala words, even
        when only the beginning of the formula has been decoded so far (the buffer still starts with
        them after the first match: kept, they would be extras before the first word, X2.4e). #41: formula_strip =
        (the words dropped, the buffer end of the formulas dropped when every one of them is complete, else None), for
        step's empty decode. #41 review: once the buffer was cut, a leftover of the cut word at its head
        (_head_leftover) is dropped with the formulas after it (never alone)."""
        lead = int(self.buffer_t0 > 0 and self._head_leftover(hyp_words[0], hyp_start[0]))
        drop = whole = lead
        for formula in (TAAWWUDH, BASMALA):
            if self.expected_norm[self.first: self.first + len(formula)] == formula:
                continue
            k = 0
            while drop + k < len(hyp_words) and k < len(formula) and \
                    similarity(hyp_words[drop + k], formula[k]) >= 0.75:
                k += 1
            if k >= 1 and (k == len(formula) or drop + k == len(hyp_words)):
                drop += k
                if k == len(formula) and whole == drop - k:
                    whole = drop             # #41: the complete formulas at the head (their audio may go)
        if drop == lead:
            drop = 0                         # no formula after the leftover: kept (head_guard_s covers it)
        # #41 review: the audio may go only when every formula dropped is complete: after a complete ta'awwudh and the
        # start of a basmala still being said (one breath), the cut fell on the model's end of «الرجيم» (one 80 ms frame,
        # often early), the cut word's tail opened the next decode and the basmala was no formula any more
        self.formula_strip = (drop, hyp_end[drop - 1] if drop and whole == drop else None)
        if drop:
            self.edge_skipped += drop
            return hyp_words[drop:], hyp_start[drop:], hyp_end[drop:], hyp_prob[drop:]
        return hyp_words, hyp_start, hyp_end, hyp_prob

    def _head_leftover(self, word: str, start: float) -> bool:
        """#41 review: the decoded word at the head of a cut buffer is a leftover of the cut word: it starts within
        head_guard_s and is shorter than attempt_min_len letters (a CTC fragment) or the end of a formula word («يم» of
        «الرجيم»)."""
        cfg = self.config
        return start < cfg.head_guard_s and (len(word) < cfg.attempt_min_len or
                                             any(w != word and w.endswith(word) for f in (TAAWWUDH, BASMALA) for w in f))

    @staticmethod
    def _formula_run(words: list[str], j: int, formulas) -> int:
        """Number of words from words[j] on that are the ta'awwudh and/or the basmala, in that order (0: none): a
        formula counts whole, by its first two words, or by any beginning that reaches the end of the decoded words
        (still being said)."""
        k = j
        for formula in formulas:
            m = 0
            while k + m < len(words) and m < len(formula) and similarity(words[k + m], formula[m]) >= 0.75:
                m += 1
            if m == len(formula) or m >= 2 or (m >= 1 and k + m == len(words)):
                k += m
        return k - j

    def _strip_boundary_formulas(self, al, ref, alt, lo: int, off: int, hyp_words, hyp_start, hyp_end, hyp_prob):
        """X2.1d: a basmala and / or a ta'awwudh said between the end of a surah and the start of the next one is not
        part of the passage: drop it from the decoded words, so that it is never a mistake, an attempt (X2.4e) or a
        reason to go off-track. Before At-Tawbah too (K6: not recited there in Hafs, yet never a mistake on 9:1).
        Only when it sits exactly at the boundary: the decoded word
        before it is one of the last 3 words of the surah (or nothing was decoded before it and the surah's end is
        committed), the one after it one of the first 4 words of the next surah (or nothing yet: still being said),
        each side with a correct word among its 3 nearest, and the alignment is not worse without it. Inside a surah
        nothing changes (27:30 keeps its basmala). Returns (al, hyp_words, hyp_start, hyp_end, hyp_prob), stripped or
        not."""
        hi = lo + len(ref)
        for b, surah in sorted(self.surah_starts.items()):
            if not lo < b < hi:
                continue
            formulas = (TAAWWUDH, BASMALA)                # K6: a basmala before At-Tawbah is ignored too (P0.1)
            bw = b - lo                                   # window index of the next surah's first word
            for j in range(len(hyp_words)):
                k = self._formula_run(hyp_words, j, formulas)
                if not k:
                    continue
                keep = [x for x in range(len(hyp_words)) if not j <= x < j + k]
                hw, hp = [hyp_words[x] for x in keep], [hyp_prob[x] for x in keep]
                al2 = align(ref, hw, hp, ref_alt=alt, free_prefix=off, free_end=True)
                if al2.cost > al.cost + 1e-9:
                    continue
                by_hyp = {v.hyp_idx: v for v in al2.verdicts if v.hyp_idx is not None}
                before = [by_hyp[x] for x in range(j) if x in by_hyp]
                after = [by_hyp[x] for x in range(j, len(hw)) if x in by_hyp]
                if any(v.ref_idx >= bw for v in before) or any(v.ref_idx < bw for v in after):
                    continue
                if before:
                    anchored_before = before[-1].ref_idx >= bw - 3 and any(v.status == "ok" for v in before[-3:])
                else:
                    anchored_before = self.committed >= b - 1
                if after:
                    anchored_after = after[0].ref_idx <= bw + 3 and any(v.status == "ok" for v in after[:3])
                else:
                    anchored_after = j + k == len(hyp_words)
                if not (anchored_before and anchored_after):
                    continue
                self.edge_skipped += k
                return (al2, hw, [hyp_start[x] for x in keep], [hyp_end[x] for x in keep], hp)
        return al, hyp_words, hyp_start, hyp_end, hyp_prob

    @staticmethod
    def _pick(keep: list[int], *cols: list) -> tuple:
        return tuple([c[k] for k in keep] for c in cols)

    @staticmethod
    def _words_of(tr, dur: float):
        """A transcript's normalized words with their (start, end, prob), garbage tokens and hallucination loops removed."""
        hyp_words: list[str] = []
        hyp_start: list[float] = []
        hyp_end: list[float] = []
        hyp_prob: list[float] = []
        for w in tr.words:
            for tok in normalize(w.text).split():
                hyp_words.append(tok)
                hyp_start.append(w.start if w.start is not None else 0.0)
                hyp_end.append(w.end if w.end is not None else dur)
                hyp_prob.append(w.prob if w.prob is not None else 1.0)
        keep = clean_hyp(hyp_words)  # garbage tokens + ASR hallucination loops
        if len(keep) != len(hyp_words):
            return Tracker._pick(keep, hyp_words, hyp_start, hyp_end, hyp_prob)
        return hyp_words, hyp_start, hyp_end, hyp_prob

    def _decode(self, asr, buf: np.ndarray, sr: int, buf_s: float, final: bool = False):
        if self.config.preprocess:
            from .audio import preprocess

            buf = preprocess(buf, self.config.preprocess)
        hyp_words, hyp_start, hyp_end, hyp_prob = self._words_of(asr.transcribe(buf, sr), buf_s)
        island_end = None if final else self._island_pass(asr, buf, sr, hyp_words, hyp_start, hyp_end)
        hyp_words, hyp_start, hyp_end, hyp_prob = self._voice_pass(buf_s, hyp_words, hyp_start, hyp_end, hyp_prob, final,
                                                                   island_end)
        if (not self.started or self.committed == self.first) and hyp_words:
            hyp_words, hyp_start, hyp_end, hyp_prob = self._strip_start_formulas(hyp_words, hyp_start, hyp_end, hyp_prob)
        self.last_hyp = " ".join(hyp_words)
        self.decode_log.append((round(self.session_time, 2), self.last_hyp))
        return hyp_words, hyp_start, hyp_end, hyp_prob

    # ------------------------------------------------------------------ voice commands (X2.15, B3.15)
    def consume(self, t0: float, t1: float) -> None:
        """B3.15: the audio [t0, t1] (session seconds) is no recitation: the words of every later decode lying mostly
        inside it, or starting in it, are dropped before anything else sees them."""
        self.consumed.append((t0, t1))

    def _expected_range(self) -> tuple[int, int]:
        """The expected words around the place (B3.15): 3 before the committed pointer to 6 after the cursor."""
        return max(0, self.committed - 3), min(len(self.expected_norm), max(self.committed, self.cursor + 1) + 6)

    def _local_expected(self) -> list[str]:
        """The expected words a command word must not resemble (B3.15): _expected_range, both spellings."""
        a, b = self._expected_range()
        out = list(self.expected_norm[a:b])
        if self.expected_alt:
            out += [x for x in self.expected_alt[a:b] if x]
        return out

    def _command_templates(self) -> list:
        """voice.COMMAND_TEMPLATES without the ones matching the expected words around the place (either spelling):
        there the phrase is recitation (B3.15; none of the shipped ones occurs in the mushaf, a guard)."""
        a, b = self._expected_range()
        seqs = [self.expected_norm[a:b]]
        if self.expected_alt:
            seqs.append([x or r for x, r in zip(self.expected_alt[a:b], self.expected_norm[a:b])])
        recited = vc.recited_templates(seqs, vc.COMMAND_TEMPLATES)
        return [tp for tp in vc.COMMAND_TEMPLATES if tp.key not in recited]

    def _fire(self, name: str, via: str, heard: str, t0: float, t1: float, report: bool = True) -> float | None:
        """Consume the command's span (never twice over the same audio) and report it (Session takes it from `voice`);
        the same command again within REPEAT_S of the end of the last one is the command said twice: consumed, not
        reported. Returns the session end of the span when the command was reported, else None."""
        span = (round(t0 - vc.CONSUME_PAD_S, 2), round(t1 + vc.CONSUME_PAD_S, 2))
        if vc.overlaps(*span, self.consumed):
            return None
        self.consumed.append(span)
        last = self.last_fired.get(name)
        self.last_fired[name] = span[1] if last is None else max(last, span[1])
        if not report:
            return None
        if last is not None and span[0] - last < vc.REPEAT_S:
            self._log_drop("repeat", [heard])
            return None
        self.voice.append({"name": name, "via": via, "heard": heard, "t0": span[0], "t1": span[1]})
        return span[1]

    def _log_drop(self, rule: str, words: list[str]) -> None:
        """voice_log (decodes.jsonl): words a rule dropped from a decode, once while the re-decodes repeat them."""
        entry = {"t": round(self.session_time, 2), "rule": rule, "dropped": " ".join(words)}
        last = next((e for e in reversed(self.voice_log) if e.get("rule") == rule), None)
        if last is None or last["dropped"] != entry["dropped"]:
            self.voice_log.append(entry)

    def _voice_pass(self, buf_s: float, hyp_words, hyp_start, hyp_end, hyp_prob, final: bool,
                    island_end: float | None = None):
        """B3.15, before anything else sees the decoded words: the words of consumed spans are dropped (a command fires
        once although the buffer is re-decoded every 0.8 s); «صدق الله العظيم» (via "formula": stop) and the command
        phrases (voice.COMMAND_TEMPLATES, via "phrase") fire once complete and are always dropped (R4: consumed silently
        with the commands off or at Stop); a beginning of either at the end of the decode is held out of it. The words
        after a command fired here (or by the island decode of this step: island_end, its session end) wait for the next
        decode: Session applies next / eyah from the words heard before it."""
        t0 = self.buffer_t0
        live = self.config.voice_commands and not final
        keep = list(range(len(hyp_words)))
        if self.consumed:
            keep = [k for k in keep if not vc.in_spans(t0 + hyp_start[k], t0 + hyp_end[k], self.consumed)]
        fired: list[float] = [] if island_end is None else [island_end]
        expected = self._local_expected()
        drop: set[int] = set()
        for i, j, complete in vc.formula_hits([hyp_words[k] for k in keep], [hyp_end[k] for k in keep], buf_s, expected):
            drop.update(keep[i: j + 1])
            if complete:
                heard = " ".join(hyp_words[k] for k in keep[i: j + 1])
                end = self._fire("stop", "formula", heard, t0 + hyp_start[keep[i]], t0 + hyp_end[keep[j]], report=live)
                if end is not None:
                    fired.append(end)
        if drop:
            self._log_drop("formula", [hyp_words[k] for k in sorted(drop)])
        keep = [k for k in keep if k not in drop]
        tps = self._command_templates()
        drop = set()
        words = [hyp_words[k] for k in keep]
        for i, j, tp in vc.command_hits(words, tps, expected):
            drop.update(keep[i: j + 1])
            wait = vc.COMMAND_SETTLE_S
            if j == len(keep) - 1 and vc.extendable(words[i: j + 1], tp, tps):
                wait = vc.EXTEND_WAIT_S                                  # the rest of a longer phrase may still come
            if hyp_end[keep[j]] <= buf_s - wait:                          # complete (else still being said: held)
                heard = " ".join(hyp_words[k] for k in keep[i: j + 1])
                end = self._fire(tp.cmd, "phrase", heard, t0 + hyp_start[keep[i]], t0 + hyp_end[keep[j]], report=live)
                if end is not None:
                    fired.append(end)
        rest = [k for k in keep if k not in drop]
        p = vc.partial_at_end([hyp_words[k] for k in rest], tps)
        if p is not None and not any(vc.expected_hit(hyp_words[k], expected) for k in rest[p:]):
            drop.update(rest[p:])                                   # a phrase still being said: held out of this decode
        if drop:
            self._log_drop("command", [hyp_words[k] for k in sorted(drop)])
        keep = [k for k in keep if k not in drop]
        if fired:
            keep = [k for k in keep if t0 + hyp_start[k] < min(fired)]
            self.voice.sort(key=lambda v: v["t0"])                       # the formula block ran first: spoken order
        if len(keep) == len(hyp_words):
            return hyp_words, hyp_start, hyp_end, hyp_prob
        return self._pick(keep, hyp_words, hyp_start, hyp_end, hyp_prob)

    def _island_expected(self) -> list[str]:
        """The expected words a lone word must not sound like: _local_expected, or the whole start page (both
        spellings) while the session has not started (X2.1c: the reciter may start anywhere on it)."""
        if self.started:
            return self._local_expected()
        b = min(len(self.expected_norm), self._start_search_end())
        return list(self.expected_norm[:b]) + [x for x in (self.expected_alt or [])[:b] if x]

    def _island_pass(self, asr, buf: np.ndarray, sr: int, hyp_words, hyp_start, hyp_end) -> float | None:
        """B3.15 island word (user, 2026-10-10: «كلمة» said alone): the rolling decode glues a lone short word onto the
        word before it (or drops it), so a burst of speech of voice.ISLAND_MIN_S-ISLAND_MAX_S with voice.ISLAND_GAP_S of
        quiet frames before and after it (the session's frame energy, rms_hist: the buffer's own head is trimmed by
        _buffer_hygiene) is decoded once more, alone, by the same model, padded with its own quiet. Each burst once; not
        when the rolling decode heard an expected word there (recitation). One word of voice.ISLAND_WORDS there, not like
        the expected words (voice.lone_guarded), or exactly a phrase of voice.ISLAND_PHRASES (not voice.phrase_guarded),
        fires the command (via "island"); so does a whole command phrase (_command_templates) there, and (2026-10-11) a
        whole complete «صدق الله العظيم» (voice.formula_hits: stop). Commands off or off-track: no island decode at all.
        Returns the session end of the span of a reported command, else None."""
        cfg = self.config
        if not cfg.voice_commands or self.off_track or len(self.rms_hist) == 0:
            return None
        fs = 0.02                                                 # _update_floor's frame
        h0 = self.session_time - len(self._pending) / cfg.sr - len(self.rms_hist) * fs   # session time of rms_hist[0]
        t0 = self.buffer_t0
        for a, b in vc.island_bursts(self.rms_hist >= self.quiet_threshold(), fs):
            s, e = round(h0 + a * fs, 2), round(h0 + b * fs, 2)
            if s < t0 or any(abs(s - x) < 0.15 for x in self.islands_done) or vc.overlaps(s, e, self.consumed):
                continue
            self.islands_done.append(s)
            inside = [k for k in range(len(hyp_words))
                      if min(e + 0.1, t0 + hyp_end[k]) - max(s - 0.1, t0 + hyp_start[k]) >= 0.5 * (hyp_end[k] - hyp_start[k])]
            if any(vc.expected_hit(hyp_words[k], self._local_expected()) for k in inside):
                continue                                          # the rolling decode heard recitation there
            ia, ib = int((s - t0) * sr), int((e - t0) * sr)
            q = int(vc.ISLAND_QUIET_S * sr)
            pre_q, post_q = buf[max(0, ia - q): ia], buf[ib: ib + q]
            npre, npost = int(vc.ISLAND_PRE_S * sr), int(vc.ISLAND_POST_S * sr)
            pre = np.tile(pre_q, npre // max(1, len(pre_q)) + 1)[-npre:] if len(pre_q) else np.zeros(npre, np.float32)
            post = np.tile(post_q, npost // max(1, len(post_q)) + 1)[:npost] if len(post_q) else np.zeros(npost, np.float32)
            audio = np.concatenate([pre, buf[ia:ib], post]).astype(np.float32)
            words, _, ends, _ = self._words_of(asr.transcribe(audio, sr), len(audio) / sr)
            self.voice_log.append({"t": round(self.session_time, 2), "rule": "island", "span": [s, e],
                                   "heard": " ".join(words)})
            expected = self._island_expected()
            cmd = vc.island_command(words, expected)
            if cmd is not None:
                return self._fire(cmd, "island", " ".join(words), s, e)
            hits = vc.command_hits(words, self._command_templates(), expected)
            if len(hits) == 1 and hits[0][:2] == (0, len(words) - 1):
                # a whole command phrase said alone, which the rolling decode wrote otherwise («الكلمه تال» for the
                # island's «الكللمه التال», measured 2026-10-11): the island decode is a decode of the same audio
                return self._fire(hits[0][2].cmd, "island", " ".join(words), s, e)
            stop = [h for h in vc.formula_hits(words, ends, len(audio) / sr, expected) if h[2]]
            if len(stop) == 1 and stop[0][:2] == (0, len(words) - 1):
                # «صدق الله (مولانا) العظيم» said alone, which the rolling decode wrote too far from it («سبقا لهم نار
                # عظيم» for the island's «صبق الله النار العظيم», the user's recording, 2026-10-11)
                return self._fire("stop", "island", " ".join(words), s, e)
        return None

    # ------------------------------------------------------------------ another language (X2.16)
    def _window(self):
        """The alignment window of a decode: (lo, off, ref, alt), back_window committed words + expect_window ahead."""
        cfg = self.config
        lo = max(0, self.committed - cfg.back_window)
        hi = min(len(self.expected_norm), self.committed + cfg.expect_window)
        return lo, self.committed - lo, self.expected_norm[lo:hi], self.expected_alt[lo:hi] if self.expected_alt else None

    def _unlike(self, t: str, ref: list[str], alt: list[str | None] | None) -> bool:
        """t resembles none of the expected words `ref` (and their spellings `alt`): similarity < foreign_max_sim, no
        prefix / suffix of one (or one of 3+ letters inside t: a word glued to a fragment), no two neighbours glued
        together (a CTC merge, «وخذنا» = «واذ اخذنا»)."""
        cfg = self.config
        for w in list(ref) + [x for x in (alt or []) if x]:
            if similarity(w, t) >= cfg.foreign_max_sim or w.startswith(t) or w.endswith(t) or \
                    (len(w) >= 3 and (t.startswith(w) or t.endswith(w))):
                return False
        spellings = [x or r for x, r in zip(alt, ref)] if alt else []
        return all(similarity(a + b, t) < cfg.foreign_max_sim for seq in (ref, spellings) for a, b in zip(seq, seq[1:]))

    def _drop_foreign(self, hyp_words, hyp_start, hyp_end, hyp_prob):
        """X2.16 R1: side talk in another language reaches the model as Arabic-looking fragments. A decoded word of
        foreign_min_len+ letters that is no Qur'an word (vocabulary()) and unlike the expected words around the place the
        alignment gives it (its pair, or the word after the one it is inserted after: 3 words before to max_skip + 1
        after) is dropped before the alignment, and so is a word between two dropped ones (a phrase): it is never an
        extra, an attempt, a wrong word, a skip or a jump. Repeats / hesitations are never foreign, nor one such word alone
        in a word's slot between heard words (issue #6: no evidence there). Measured: 0.14 % of real recitation tokens
        dropped; a one-letter slip («بعوسه» for «بعوضه») stays like its word and is still caught.
        Returns the kept words + the alignment of the current window when it still holds (nothing dropped), else None."""
        cfg = self.config
        vocab = vocabulary()
        cand = [j for j, t in enumerate(hyp_words) if len(t) >= cfg.foreign_min_len and t not in vocab]
        if not cand:
            return hyp_words, hyp_start, hyp_end, hyp_prob, None
        lo, off, ref, alt = self._window()
        al = align(ref, hyp_words, hyp_prob, ref_alt=alt, free_prefix=off, free_end=True)
        place: dict[int, int] = {}
        for v in al.verdicts:
            if v.hyp_idx is not None:
                place[v.hyp_idx] = v.ref_idx
            for j in v.extras_after:
                place[j] = v.ref_idx + 1
        repeats = set(al.repeats)
        n = len(hyp_words)
        foreign = [False] * n
        for j in cand:
            if j in repeats:
                continue
            r = place.get(j, off)
            a, z = max(0, r - 3), min(len(ref), r + cfg.max_skip + 2)
            foreign[j] = self._unlike(hyp_words[j], ref[a:z], alt[a:z] if alt else None)
        for k in range(1, n - 1):                       # a word inside a foreign phrase
            if foreign[k - 1] and foreign[k + 1]:
                foreign[k] = True
        paired = {v.hyp_idx: v for v in al.verdicts if v.hyp_idx is not None}
        oks = {v.hyp_idx for v in al.verdicts if v.status == "ok" and v.hyp_idx is not None}
        for j in range(n):
            # issue #6 (2026-10-10): one garbled word alone in a live word's slot (paired 1:1 with it, heard words after
            # it and before it, or nothing before) is that word said badly, not side talk: kept (no evidence, step()),
            # never dropped into a skip; 2+ foreign words in a row stay side talk
            v = paired.get(j)
            if foreign[j] and v is not None and v.status == "wrong" and v.ref_idx >= off \
                    and (j == 0 or j - 1 in oks) and j + 1 in oks:
                foreign[j] = False
        self.n_foreign = sum(foreign)
        if not self.n_foreign:
            return hyp_words, hyp_start, hyp_end, hyp_prob, al
        self._log_drop("foreign", [w for w, f in zip(hyp_words, foreign) if f])
        hw, hs, he, hp = self._pick([k for k in range(n) if not foreign[k]], hyp_words, hyp_start, hyp_end, hyp_prob)
        self.last_hyp = " ".join(hw)
        self.decode_log[-1] = (self.decode_log[-1][0], self.last_hyp)
        return hw, hs, he, hp, None

    def _note_off_track(self, off: bool) -> None:
        """X2.7 (debounced ⚠); X2.16 R2: a decode that dropped 2+ foreign words counts as an off-track decode too, but
        the verdicts go on with the other words."""
        if off or self.n_foreign >= 2:
            self.off_track_count += 1
            self.off_track = self.off_track_count >= self.config.off_track_debounce
        else:
            self.off_track_count = 0
            self.off_track = False

    @staticmethod
    def _frame_rms(buf: np.ndarray, sr: int, frame_s: float = 0.02) -> np.ndarray:
        n = int(frame_s * sr)
        if len(buf) < n:
            return np.zeros(0, dtype=np.float32)
        frames = buf[: len(buf) // n * n].reshape(-1, n)
        return np.sqrt((frames ** 2).mean(axis=1))

    def _speech_frames(self, buf: np.ndarray, sr: int, frame_s: float = 0.02) -> np.ndarray:
        """Boolean per 20 ms frame, used ONLY to snap replay time spans onto speech: a frame is
        speech when its RMS is above the absolute gate and above 0.15 x the buffer's 95th
        percentile (relative rule). Never used to drop audio (it would cut quiet word onsets)."""
        rms = self._frame_rms(buf, sr, frame_s)
        if len(rms) == 0:
            return np.zeros(0, dtype=bool)
        thr = max(self.config.energy_gate, 0.15 * float(np.percentile(rms, 95)))
        return rms >= thr

    def quiet_threshold(self) -> float:
        """Frame RMS below which a frame cannot hold speech: floor_mult x the session noise floor,
        capped at floor_cap so that a pause-free (speech-only) history never raises it into the
        speech range; energy_gate when the floor is not known yet."""
        cfg = self.config
        if self.noise_floor is None:
            return cfg.energy_gate
        return min(max(cfg.energy_gate, cfg.floor_mult * self.noise_floor), cfg.floor_cap)

    def _energetic_frames(self, buf: np.ndarray, sr: int, frame_s: float = 0.02) -> np.ndarray:
        """Boolean per 20 ms frame: could this frame hold speech? (conservative: only frames below
        quiet_threshold() are ruled out; constant fan noise stays < 2 x its floor and is ruled out
        once the floor is armed)."""
        rms = self._frame_rms(buf, sr, frame_s)
        if len(rms) == 0:
            return np.zeros(0, dtype=bool)
        return rms >= self.quiet_threshold()

    def _buffer_hygiene(self, sr: int, frame_s: float = 0.02) -> bool:
        """Before a decode: drop the speech-free head of the buffer (keeping head_keep_s before the
        first speech frame) and, when the buffer holds no speech at all, keep only the last
        noise_keep_s. Returns True when there is speech to decode."""
        cfg = self.config
        energetic = self._energetic_frames(self.buffer, sr, frame_s)
        if len(energetic) == 0:
            return False
        if not energetic.any():
            keep = int(cfg.noise_keep_s * sr)
            if len(self.buffer) > keep:
                self._drop_audio(len(self.buffer) - keep)
            return False
        first = int(np.argmax(energetic)) * int(frame_s * sr)
        head = first - int(cfg.head_keep_s * sr)
        if head > int(cfg.cut_margin_s * sr):
            # the head holds only frames below the quiet threshold (no possible speech) and
            # committed words are always before buffer_t0: nothing is lost by dropping it
            self._drop_audio(head)
        return True

    @staticmethod
    def _snap(start: float, end: float, speech: np.ndarray, frame_s: float = 0.02) -> tuple[float, float]:
        """Move a word span onto speech: start forward to the next speech frame (<= 0.5 s), end
        backward to the previous speech frame (<= 0.5 s)."""
        if len(speech) == 0:
            return start, end
        i0 = int(max(0, min(len(speech) - 1, start / frame_s)))
        i1 = int(max(0, min(len(speech) - 1, end / frame_s)))
        lim = int(0.5 / frame_s)
        j = i0
        while j < min(len(speech), i0 + lim) and not speech[j]:
            j += 1
        if j < len(speech) and speech[j]:
            i0 = j
        j = i1
        while j > max(0, i1 - lim) and not speech[j]:
            j -= 1
        if speech[j]:
            i1 = j
        s2, e2 = i0 * frame_s, (i1 + 1) * frame_s
        if e2 <= s2:
            return start, end
        return s2, e2

    def _observe_time(self, st: WordState, start: float, end: float) -> None:
        st.t_obs.append((start, end))
        if len(st.t_obs) > 15:
            st.t_obs = st.t_obs[-15:]
        recent = st.t_obs[-3:]   # the latest decodes see the word closest to the buffer start
        st.t_start = statistics.median(o[0] for o in recent)
        st.t_end = max(st.t_start + 0.15, statistics.median(o[1] for o in recent))

    def _finalize_status(self, st: WordState, i: int, status: str, score: float, hyp: str | None) -> None:
        """Apply a final verdict. Hinted words keep their 'hinted' verdict (already a mistake)."""
        if st.hinted and not st.user_marked:
            status, score = "hinted", 1.0
        st.status, st.score, st.hyp, st.final = status, score, hyp, True
        self._touch(i)

    def _finalize_attempt(self, st: WordState, i: int) -> None:
        """The word was preceded by a confirmed wrong attempt (X2.4e): it is wrong, 'heard' = the
        extra words; the replay span starts at the first extra word."""
        self._finalize_status(st, i, "wrong", st.extra_score, st.extra_hyp)
        if st.extra_t0 is not None:
            st.t_start = st.extra_t0 if st.t_start is None else min(st.t_start, st.extra_t0)
            if st.t_end is None or st.t_end <= st.t_start:
                st.t_end = st.t_start + 0.5

    def _is_word(self, i: int, heard: str | None) -> bool:
        """The heard token is expected word i (either spelling, or a near-identical spelling)."""
        if not heard or not 0 <= i < len(self.expected_norm):
            return False
        h = normalize(heard).replace(" ", "")
        return any(h == f or similarity(h, f) >= 0.8 for f in self._forms(i))

    def _forms(self, i: int) -> list[str]:
        return [self.expected_norm[i]] + ([self.expected_alt[i]] if self.expected_alt and self.expected_alt[i] else [])

    def _fragment(self, i: int, heard: str | None) -> bool:
        """X2.17: the heard form is a single letter of expected word i: the model dropped the rest of a short word
        («د» for «ود»); nobody recites one letter, so it is the word heard, never a wrong word."""
        h = normalize(heard).replace(" ", "") if heard else ""
        return len(h) == 1 and 0 <= i < len(self.expected_norm) and any(h in f for f in self._forms(i))

    def _no_evidence(self, i: int, heard: str | None) -> bool:
        """Issue #6 (user, 2026-10-10): a heard form no reciter would say is never the evidence of a mistake on expected
        word i (a wrong word, an attempt, the heard form of a lost word): every token of it is N1 a lone letter (nobody
        recites one letter; one of word i's letters is the word heard, X2.17 _fragment), N2 a 2-letter form that is no
        Qur'an word (a CTC fragment), N3 no Qur'an word (vocabulary()) and unlike word i and its neighbours (_unlike:
        similarity < foreign_max_sim, no prefix / suffix, no glued pair), or N4 (NO_EVIDENCE_N4 only) a 3+-letter strict
        prefix / suffix of another expected word among the 3 before and the one after (a cut word, a hesitation). A token
        that is one of word i's forms is always evidence; so are a one-letter slip («بعوسه» for «بعوضه», 0.8 alike) and a
        Qur'an word said instead («لن» for «لا»). step(): such a pairing decides nothing (neither heard nor wrong); a word
        heard only that way is correct at its commit."""
        if not heard or not 0 <= i < len(self.expected_norm):
            return False
        toks = normalize(heard).split()
        if not toks:
            return False
        vocab = vocabulary()
        n = len(self.expected_norm)
        a, z = max(0, i - 1), min(n, i + 2)
        ref, alt = self.expected_norm[a:z], (self.expected_alt[a:z] if self.expected_alt else None)
        forms = self._forms(i)
        near = [f for k in range(max(0, i - 3), min(n, i + 2)) if k != i for f in self._forms(k)] if NO_EVIDENCE_N4 else []
        for t in toks:
            if t in forms:
                return False
            if len(t) == 1:                                                   # N1
                continue
            if t not in vocab and (len(t) == 2 or self._unlike(t, ref, alt)):  # N2, N3
                continue
            if len(t) >= 3 and any(f != t and (f.startswith(t) or f.endswith(t)) for f in near):   # N4
                continue
            return False
        return True

    def _accepted_form(self, i: int, heard: str | None) -> bool:
        """X2.17: a heard form the user accepted as correct for this word (keyed by the word's text)."""
        if not heard or not self.accepted or not 0 <= i < len(self.expected_norm):
            return False
        h = normalize(heard).replace(" ", "")
        return any(h in self.accepted.get(f, ()) for f in self._forms(i))

    def _accept_variants(self, al, lo: int) -> None:
        """X2.17: 'wrong' pairings with an accepted heard form become matches (before any rule reads the alignment)."""
        for v in al.verdicts:
            if v.status == "wrong" and self._accepted_form(lo + v.ref_idx, v.hyp_text):
                v.status, v.score = "ok", 0.0

    @staticmethod
    def _demote_trailing_wrong(al) -> None:
        """Hypothesis words paired as "wrong" after the last matched word, with nothing matched
        after them, are ambiguous as long as the reciter has not gone on (a failed attempt at the
        next word, a mispronounced next word, or a jump?). They become extras after the last matched
        word: the cursor stays there and nothing turns orange; the following decodes resolve them
        (X2.4e: extras before a word said later = wrong attempt; a word paired "wrong" with matches
        after it = wrong word)."""
        paired = sorted((v for v in al.verdicts if v.hyp_idx is not None), key=lambda v: v.hyp_idx)
        k = len(paired)
        while k > 0 and paired[k - 1].status == "wrong":
            k -= 1
        if k == 0 or k == len(paired):
            return   # nothing matched before them (off-track / lost rules decide) or no trailing run
        anchor, trailing = paired[k - 1], paired[k:]
        if any(j > trailing[0].hyp_idx for j in al.repeats):
            return   # a repeat / hesitation follows them: they are inside the flow, not trailing
        for v in trailing:
            anchor.extras_after.append(v.hyp_idx)
            al.extras.append((anchor.ref_idx, v.hyp_idx))
            v.status, v.hyp_idx, v.hyp_text, v.score, v.prob = "pending", None, None, 0.0, None
        for v in al.verdicts:
            if v.ref_idx > anchor.ref_idx and v.status == "missing":
                v.status, v.score = "pending", 0.0
        anchor.extras_after.sort()
        al.extras.sort(key=lambda pr: pr[1])

    def _wrong_attempts(self, al, ref, hyp_words, hyp_start, hyp_end, lo: int, off: int, stable_t: float) -> dict:
        """{window index of an expected word: ([hyp indices of the extra words said right before it],
        suspicion)} for the extras that count as a failed attempt at that word (X2.4e): stable
        (fully decoded), at least attempt_min_len letters, not a leftover at the head of a cut
        buffer, no form no reciter says there (_no_evidence, issue #6), attached to a matched expected
        word (never before the first match) and aimed at a live word. Repeats and hesitations are not
        extras (align.py), so they never count."""
        cfg = self.config
        out: dict[int, tuple[list[int], float]] = {}
        for v in al.verdicts:
            if not v.extras_after:
                continue
            target = v.ref_idx + 1
            if target < off or target >= len(ref):
                continue
            js = [j for j in v.extras_after
                  if len(hyp_words[j]) >= cfg.attempt_min_len and hyp_end[j] <= stable_t
                  and not (self.buffer_t0 > 0 and hyp_start[j] < cfg.head_guard_s)
                  and not self._no_evidence(lo + target, hyp_words[j])]
            if not js:
                continue
            sim = max(similarity(hyp_words[j], ref[target]) for j in js)
            out[target] = (sorted(js), 0.5 + 0.5 * (1.0 - sim))
        return out

    def _lost_jump(self, al, lo: int, off: int, ref, alt, hyp_words, hyp_prob) -> tuple[bool, int]:
        """The lost rule's test on the alignment `al` of the window (lo, off, ref, alt): (lost, the expected word the
        speech fits from, -1 when nothing fits). Lost = the first live match is more than max_skip words after the
        window's first live word, or a semi-global alignment of the live window clearly fits further ahead (the normal
        alignment prefers "k wrong words" over "k skipped words")."""
        cfg = self.config
        live_ok = [v for v in al.verdicts if v.status == "ok" and v.ref_idx >= off]
        if live_ok:
            first = min(v.ref_idx for v in live_ok)
            if first - off > cfg.max_skip:
                return True, lo + first
        if len(hyp_words) >= 2:
            al2 = align(ref[off:], hyp_words, hyp_prob, ref_alt=alt[off:] if alt else None, free_start=True,
                        free_end=True)
            sp = al2.span
            n_ok2 = sum(1 for v in al2.verdicts if v.status == "ok")
            if sp and sp[0] > cfg.max_skip and n_ok2 >= 2 and al2.cost + 0.5 < al.cost:
                return True, lo + off + sp[0]
        return False, (lo + min(v.ref_idx for v in live_ok)) if live_ok else -1

    # ------------------------------------------------------------------ decode step
    def step(self, asr, final: bool = False) -> dict:
        """Decode the current buffer with `asr` (ASRBackend) and update the states.
        final=True (session stop): decode whatever is left, commit everything aligned and freeze
        the remaining provisional states."""
        cfg = self.config
        sr = cfg.sr
        if self.done:
            if final:
                self._freeze()       # issue #7 (2026-10-10): Stop always shows the concealed words, passage end or not
            return self.snapshot()
        if len(self.buffer) >= sr and not self._buffer_hygiene(sr):
            # fan noise / silence only: no ASR call, the buffer stays <= noise_keep_s
            self.skipped_decodes += 1
            self.last_hyp = ""
            if final:
                self._freeze()
            return self.snapshot()
        buf = self.buffer
        if final and 0 < len(buf) < sr:
            buf = np.concatenate([buf, np.zeros(sr - len(buf), dtype=np.float32)])
        buf_s = len(buf) / sr
        if buf_s < 1.0:
            if final:
                self._freeze()
            return self.snapshot()
        self.n_foreign = 0
        self.formula_strip = (0, None)
        hyp_words, hyp_start, hyp_end, hyp_prob = self._decode(asr, buf, sr, buf_s, final=final)
        force = buf_s >= cfg.max_window_s or final
        al = None                                       # the alignment of the window, when R1 already computed it
        if cfg.foreign_rule and hyp_words:
            hyp_words, hyp_start, hyp_end, hyp_prob, al = self._drop_foreign(hyp_words, hyp_start, hyp_end, hyp_prob)
        if not hyp_words:
            # the model heard no word (silence, noise the energy rule let through, or the first
            # seconds of a sustained madd): keep the recent audio only, so that noise never fills the
            # 24 s window and every idle decode stays short
            if self.n_foreign >= 2:
                self._note_off_track(True)              # X2.16 R2: only side talk was heard
            n_formula, formula_end = self.formula_strip
            if n_formula and buf_s <= cfg.max_window_s:
                # #41 (user, 2026-10-24: "I started reciting from the beginning of the surah and it is only showing from
                # the middle of it"): only the ta'awwudh / basmala before the first word were heard. Never cut inside
                # them: the 6 s rule below cut a slow ta'awwudh + basmala (> 6 s), and its tail at the buffer head, no
                # formula any more for _strip_start_formulas, was paired wrong with the first words (hidden in Hidden /
                # Blind). The complete formulas go with their audio once stable (as a commit cuts), else the buffer is
                # kept; past the rolling window the 6 s rule applies again (bounded), as at a surah boundary (X2.1d)
                if formula_end is not None and formula_end <= buf_s - cfg.stable_s:
                    self._drop_audio(int(formula_end * sr))
            else:
                keep = int(cfg.no_words_keep_s * sr)
                if len(self.buffer) > keep:
                    self._drop_audio(len(self.buffer) - keep)
            if final:
                self._freeze()
            return self.snapshot()
        committed0 = self.committed
        if not self.started and self.committed == 0 and self.cursor < 0:
            jump, j = self._start_jump(hyp_words, hyp_prob, decide=final or buf_s >= cfg.max_window_s)
            if jump == "wait":
                return self.snapshot()   # X2.1c: too few words to tell where the reciter started: wait for more
            if j:
                buf, hyp_words, hyp_start, hyp_end, hyp_prob = self._drop_said_before(j, buf, hyp_words, hyp_start,
                                                                                      hyp_end, hyp_prob)
                buf_s = len(buf) / sr
        lo, off, ref, alt = self._window()              # off: window index of the first live word
        if al is None or self.committed != committed0:
            al = align(ref, hyp_words, hyp_prob, ref_alt=alt, free_prefix=off, free_end=True)
        if self.cursor >= 0 and len(hyp_words) >= cfg.start_jump_min and self._start_open():
            # #33 (user, 2026-10-22: "the recite is not following me and still waiting at the begining"): a stray first
            # match (1-2 words: the model wrote «وقالت», 2:113's first word, for «وقال» of 2:118) no longer fixes the
            # start. While it is open, a decode the current place explains badly (a lost word, or fewer than
            # start_jump_min matched words) that clearly fits further on the start page restarts the session there
            # (_start_jump: the same rules as the start; the words before go back to not recited)
            self._accept_variants(al, lo)
            if sum(1 for v in al.verdicts if v.status == "ok") < cfg.start_jump_min or \
                    self._lost_jump(al, lo, off, ref, alt, hyp_words, hyp_prob)[0]:
                # #33 review: the decode's first words that the current place explains as the words already heard there
                # (up to the cursor: «وقالت اليهود», still in the buffer) were said before the restart: never located
                # with the new start (one paired wrong with the word before it moved the start a word early)
                place = {v.hyp_idx: lo + v.ref_idx for v in al.verdicts if v.status == "ok"}   # exact: never a repeat
                p = 0                                                   # (2:118's «وقال» is one of 2:113's «وقالت»)
                while p < len(hyp_words) and place.get(p, self.cursor + 1) <= self.cursor:
                    p += 1
                jump, j = self._start_jump(hyp_words[p:], hyp_prob[p:], decide=force)
                if jump == "wait":
                    return self.snapshot()   # the same words fit as well earlier: wait for more (never a verdict yet)
                if jump == "jump":
                    if p + j:
                        buf, hyp_words, hyp_start, hyp_end, hyp_prob = self._drop_said_before(
                            p + j, buf, hyp_words, hyp_start, hyp_end, hyp_prob)
                        buf_s = len(buf) / sr
                    lo, off, ref, alt = self._window()
                    al = align(ref, hyp_words, hyp_prob, ref_alt=alt, free_prefix=off, free_end=True)
        if self.cursor >= 0 and len(hyp_words) < cfg.start_jump_min and not final and self._start_open():
            # #33 review: while the start is open a decode of fewer than start_jump_min words decides nothing either,
            # as at the start (the cap cut «وقالت» off «وقالت … وقال الذين»: «وقال الذين» alone, 2:118's first words,
            # was committed as 2:113's next words, red); the next decode holds more words, Stop decides
            self._cap_before_start()
            return self.snapshot()
        hold = None          # X2.1d repeat: (boundary window index, decoded words kept, strict) when words are held back
        held_cut = None      # ... and the buffer seconds (from bt0) of held-back words that can be dropped
        bt0 = self.buffer_t0
        if self.surah_starts:
            n_hyp, end0 = len(hyp_words), hyp_end
            al, hyp_words, hyp_start, hyp_end, hyp_prob = self._strip_boundary_formulas(
                al, ref, alt, lo, off, hyp_words, hyp_start, hyp_end, hyp_prob)
            if len(hyp_words) != n_hyp:
                self.last_hyp = " ".join(hyp_words)
                self.decode_log[-1] = (self.decode_log[-1][0], self.last_hyp)
                if not hyp_words:
                    # only a boundary formula (and the pause after it): never keep it all, the buffer would grow with
                    # every decode; once the formula is older than no_words_keep_s keep the recent audio only, as
                    # after a decode without words (never cut inside the formula)
                    keep = int(cfg.no_words_keep_s * sr)
                    if max(end0) <= buf_s - cfg.no_words_keep_s and len(self.buffer) > keep:
                        self._drop_audio(len(self.buffer) - keep)
                    if final:
                        self._freeze()
                    return self.snapshot()
            hold = self._hold_repeat(al, lo, off, hyp_words, hyp_prob, decide=force and not final)
            if hold is not None:
                bw, j_keep, strict = hold
                if strict:      # clearly the surah said again: its stable words are dropped (never the next surah)
                    stable = [hyp_end[j] for j in range(j_keep, len(hyp_words)) if hyp_end[j] <= buf_s - cfg.stable_s or force]
                    if stable:
                        held_cut = max(0.0, max(stable) - cfg.cut_margin_s)
                hyp_words, hyp_start, hyp_end, hyp_prob = (hyp_words[:j_keep], hyp_start[:j_keep], hyp_end[:j_keep],
                                                           hyp_prob[:j_keep])
                ref, alt = ref[:bw], (alt[:bw] if alt else None)
                if not hyp_words:
                    if held_cut is not None:
                        self._drop_audio(int(held_cut * sr))
                    if final:
                        self._freeze()
                    return self.snapshot()
                al = align(ref, hyp_words, hyp_prob, ref_alt=alt, free_prefix=off, free_end=True)
        self._accept_variants(al, lo)
        if cfg.attempt_rule:
            self._demote_trailing_wrong(al)
        n_matched = sum(1 for v in al.verdicts if v.status == "ok")
        # ----- lost rule: the reciter jumped more than max_skip expected words ahead (_lost_jump)
        t0 = self.buffer_t0
        lost_here, lost_to = self._lost_jump(al, lo, off, ref, alt, hyp_words, hyp_prob)
        before_start = not self.started and self.cursor < 0 and self.committed == self.first
        if lost_here and (before_start or self._start_open()) and not final and \
                (len(hyp_words) < cfg.start_jump_min or not force) and lost_to < self._start_search_end():
            # nothing heard yet (or the start still open, #33) and the words fit further on the start page: too few
            # words, or too few of them matched yet (a word still being said, «تبت يدا اب», emulator 2026-10-01), for the
            # X2.1c start: wait for the next decode (never "lost" yet, never a mistake on the session's first words); a
            # full buffer decides
            self._cap_before_start()     # #33 review: fewer than start_jump_min words wait even at a full buffer
            return self.snapshot()
        if before_start and n_matched == 0 and not force and self._fits_further(hyp_words, hyp_prob):
            # X2.1c: nothing heard fits the session's first words, but it fits further on in the passage («تبت يداه»,
            # a word still being said, on page 603 started at 109:1: emulator 2026-10-01): decide nothing yet (no
            # verdict on the first words), the next decodes hold enough words for the start; a full buffer decides
            return self.snapshot()
        if lost_here:
            # the words already heard (shown as correct) stay correct, settled as Stop does (one heard after extra words
            # seen in 2+ decodes is the X2.4e attempt, review 2026-10-11): the mistake is the first word never heard
            k = self.committed
            while k < len(self.states) and self._settle_heard(self.states[k], k):
                k += 1
            moved = k > self.committed
            self.committed = k
            if hold is None and k < len(self.states) and (moved or self._is_word(k, hyp_words[0])):
                # the committed pointer lagged behind the words already heard: the jump is measured again from the first
                # word never heard, aligned from there like any decode. X2.16 (2026-10-05): the word heard first IS that
                # word («وإذ» opens 2:49, 2:50 and 2:51): no jump; issues #5 / #6 (2026-10-10): a decode starting with the
                # last word heard said again, or a jump of max_skip words or fewer from there (2:25 «متشابها» then
                # «ولهم»: 1 word), is no jump either (the usual evidence decides). A decode that does not fit from there
                # either (off-track there: another passage said instead) stays a jump (replay 2026-10-11: 2:91 «بما»,
                # the words of 2:13 said instead, a user-marked mistake)
                lo, off, ref, alt = self._window()
                al = align(ref, hyp_words, hyp_prob, ref_alt=alt, free_prefix=off, free_end=True)
                self._accept_variants(al, lo)
                if cfg.attempt_rule:
                    self._demote_trailing_wrong(al)
                n_matched = sum(1 for v in al.verdicts if v.status == "ok")
                elsewhere = len(hyp_words) >= cfg.off_track_min_words and \
                    n_matched < cfg.off_track_match_ratio * len(hyp_words)
                lost_here = not self._is_word(k, hyp_words[0]) and \
                    (elsewhere or self._lost_jump(al, lo, off, ref, alt, hyp_words, hyp_prob)[0])
        if lost_here:
            k = self.committed
            if k < len(self.states):
                st = self.states[k]
                if not st.final:
                    st.lost = st.concealed = True
                    # issue #6: what was heard = the first decoded word that is evidence where the speech went on: never
                    # a word already heard (placed before the lost word, or one of the back_window words before it said
                    # again: the head of the decode, review 2026-10-11), a fragment, nor the word itself (issue #5);
                    # None if there is none
                    place = {v.hyp_idx: lo + v.ref_idx for v in al.verdicts if v.hyp_idx is not None}
                    place.update((j, lo + r) for j, r in al.repeat_of.items())
                    before = range(max(0, k - cfg.back_window), k)
                    hj = next((j for j, h in enumerate(hyp_words)
                               if place.get(j, k) >= k and not any(self._is_word(m, h) for m in before)
                               and not self._no_evidence(k, h) and not self._is_word(k, h)), None)
                    self._finalize_status(st, k, "wrong", 0.8, None if hj is None else hyp_words[hj])
                    # issue #35 (user, 2026-10-23: "when I clic play word another set of word is played"): the replay
                    # span is what was heard there (paired with the word or said before the next one, and no word of
                    # the passage further on), never the whole decode (up to 24 s: the words heard before it and every
                    # word of the jump); nothing heard there (the speech went on with a later word): the gap after the
                    # last word heard up to where the speech went on, at most 2 s (as a skipped word, B3.7). Only
                    # replay times, never a verdict
                    later = range(k + 1, lo + len(ref))
                    if hj is not None and place.get(hj, k) == k and not any(self._is_word(m, hyp_words[hj]) for m in later):
                        s, e = self._snap(hyp_start[hj], hyp_end[hj], self._speech_frames(buf, sr))
                        st.t_start, st.t_end = t0 + s, t0 + e
                    else:
                        prev = self.states[k - 1].t_end if k > 0 else None
                        a = prev if prev is not None else t0 + hyp_start[0]
                        nxt = t0 + hyp_start[hj] if hj is not None else \
                            min((t0 + hyp_start[j] for j in range(len(hyp_words)) if place.get(j, -1) > k), default=a + 0.5)
                        st.t_start, st.t_end = a, max(a + 0.15, min(nxt, a + 2.0))
            self._cap_before_start()
            if final:
                self._freeze()
            return self.snapshot()   # nothing advances until the word is said or hinted
        elsewhere = len(hyp_words) >= cfg.off_track_min_words and n_matched < cfg.off_track_match_ratio * len(hyp_words)
        self._note_off_track(elsewhere)
        if elsewhere:
            if buf_s > cfg.max_window_s:
                self._drop_audio(len(buf) - int(cfg.stable_s * sr))
            if final:
                self._freeze()
            return self.snapshot()
        if n_matched >= cfg.start_jump_min:
            self.started = True      # #33: a decode of fewer matched words (a stray first match) never fixes the start
        t0 = self.buffer_t0
        speech = self._speech_frames(buf, sr)
        # ----- cursor: the reference word behind the last decoded word
        by_hyp = {v.hyp_idx: v.ref_idx for v in al.verdicts if v.hyp_idx is not None}
        for j in range(len(hyp_words) - 1, -1, -1):
            if j in by_hyp:
                self.cursor = lo + by_hyp[j]
                break
            if j in al.repeat_of:
                self.cursor = lo + al.repeat_of[j]
                break
        # ----- evidence + provisional states + time observations (live words only)
        aligned = [v.ref_idx for v in al.verdicts if v.hyp_idx is not None]
        last_aligned = max(aligned) if aligned else -1
        span: dict[int, tuple[float, float]] = {}
        for v in al.verdicts:
            if v.hyp_idx is not None:
                s, e = self._snap(hyp_start[v.hyp_idx], hyp_end[v.hyp_idx], speech)
                span[v.ref_idx] = (t0 + s, t0 + e)
        stable_t = buf_s - cfg.stable_s
        attempts = self._wrong_attempts(al, ref, hyp_words, hyp_start, hyp_end, lo, off, stable_t) \
            if cfg.attempt_rule else {}
        for v in al.verdicts:
            i = lo + v.ref_idx
            st = self.states[i]
            if v.status == "ok" and st.final and not st.said:
                st.said = True         # said correctly at last, also behind the pointer (an exact repeat, back window)
                if st.ok_seen == 0:
                    self._touch(i)     # word_dict "said" changes
            if st.concealed and v.status == "ok":
                st.concealed = False   # the lost word was said at last: shown (it stays a mistake)
                self._touch(i)
            if v.ref_idx < off or st.final:
                continue
            js, score = attempts.get(v.ref_idx, (None, 0.0))
            if js and st.ok_seen >= 1 and st.t_start is not None and t0 + hyp_start[js[0]] >= st.t_start - 0.05:
                # no attempt before the word (X2.4e): the word itself, already heard correctly, decoded again worse
                # from the same audio («ولا الضل» after «ولا الضالين» at the end of Al-Fatiha, emulator 2026-10-01)
                js = None
            if js:
                st.extra_run += 1
                st.extra_hyp = " ".join(hyp_words[j] for j in js)
                st.extra_score = score
                st.extra_t0 = t0 + hyp_start[js[0]]
                self._touch(i)
            elif v.ref_idx <= last_aligned:
                st.extra_run = 0   # this decode covered the position without the extra words: not successive
            if v.status == "ok" or (v.status == "wrong" and self._fragment(i, v.hyp_text)):
                # X2.17: a lone letter of the expected word («د» for «ود») is the word heard, never a wrong word; the
                # alignment itself is left alone (accepting such letters there moved other words, replay 2026-10-05)
                st.ok_seen += 1
                st.wrong_run = 0
                st.miss_run = 0
                st.status, st.score, st.hyp = "provisional_ok", 0.0, v.hyp_text
                self._observe_time(st, *span[v.ref_idx])
            elif v.status == "wrong" and self._no_evidence(i, v.hyp_text):
                # issue #6 (user, 2026-10-10): what no reciter says decides nothing, neither heard nor wrong nor
                # skipped: the real evidence of the other decodes decides (wrong_run / miss_run are left as they are).
                # Once the evidence window is full, a real wrong form or skip seen in one decode only among such
                # decodes is outvoted (precision first, P0.1; review 2026-10-11: never a stall until the 24 s buffer
                # limit). Shown as heard unless real evidence against the word still stands
                st.unsure += 1
                if st.wrong_run == 1 and 1 + st.unsure >= cfg.wrong_evidence:
                    st.wrong_run = 0
                if st.miss_run == 1 and 1 + st.unsure >= cfg.missing_evidence:
                    st.miss_run = 0
                if not (st.wrong_run or st.miss_run):
                    st.status, st.score, st.hyp = "provisional_ok", 0.0, v.hyp_text
                self._observe_time(st, *span[v.ref_idx])
            elif v.status == "wrong":
                st.wrong_run += 1
                st.miss_run = 0
                st.status, st.score, st.hyp = "provisional_wrong", 0.5 + 0.5 * v.score, v.hyp_text
                self._observe_time(st, *span[v.ref_idx])
            elif v.status == "missing":
                if v.ref_idx < last_aligned:  # this decode covered the position and skipped it
                    st.miss_run += 1
                st.wrong_run = 0
                prev_end = max([e for k, (s, e) in span.items() if k < v.ref_idx], default=t0)
                next_start = min([s for k, (s, e) in span.items() if k > v.ref_idx], default=t0 + buf_s)
                gap = next_start - prev_end
                st.status, st.hyp = "provisional_missing", None
                st.score = 0.9 if gap < 0.25 else (0.75 if gap < 0.7 else 0.6)
                st.t_start, st.t_end = prev_end, max(prev_end + 0.15, next_start)
            elif not st.status.startswith("provisional"):  # pending, unless a provisional verdict was already shown
                st.status, st.score, st.hyp = "pending", 0.0, None
            self._touch(i)
        # ----- commit stable words, but only with enough evidence
        if buf_s >= cfg.min_commit_s or force:
            last_stable_ref = -1
            for v in al.verdicts:
                if v.hyp_idx is not None and (hyp_end[v.hyp_idx] <= stable_t or force):
                    last_stable_ref = max(last_stable_ref, v.ref_idx)
            if force and last_stable_ref < 0 and aligned:
                last_stable_ref = last_aligned
            if not force and aligned and last_stable_ref == last_aligned and hold is None:
                last_stable_ref -= 1  # the last aligned word may still be growing (not when held-back words follow it)
            commit_upto = -1
            for k in range(off, last_stable_ref + 1):
                v = al.verdicts[k]
                i = lo + k
                st = self.states[i]
                if st.final:
                    commit_upto = k
                    continue
                if st.extra_run >= cfg.wrong_evidence or (force and st.extra_run >= 2):
                    self._finalize_attempt(st, i)   # said correctly in the end, but only after wrong words
                elif 0 < st.extra_run and not force:
                    break  # a wrong attempt is being confirmed: wait for the next decodes
                elif st.ok_seen >= 1:
                    self._finalize_status(st, i, "ok", 0.0, st.hyp if st.status == "provisional_ok" else None)
                elif v.status == "wrong" and self._no_evidence(i, v.hyp_text):
                    # issue #6: this decode decides nothing. The real evidence seen decides once the evidence window is
                    # full (with these decodes; a real form seen once was outvoted above) or at a forced commit (the
                    # real wrong form / skip heard before); nothing real against the word: heard, correct
                    if st.wrong_run and (force or st.wrong_run + st.unsure >= cfg.wrong_evidence):
                        self._finalize_status(st, i, "wrong", st.score, st.hyp)
                    elif st.miss_run and (force or st.miss_run + st.unsure >= cfg.missing_evidence):
                        self._finalize_status(st, i, "missing", st.score, None)
                    elif st.wrong_run or st.miss_run:
                        break  # the evidence window is not full yet: wait for the next decodes
                    else:
                        self._finalize_status(st, i, "ok", 0.0, st.hyp)
                elif v.status == "wrong" and st.wrong_run >= cfg.wrong_evidence:
                    self._finalize_status(st, i, "wrong", 0.5 + 0.5 * v.score, v.hyp_text)
                elif v.status == "missing" and st.miss_run >= cfg.missing_evidence:
                    self._finalize_status(st, i, "missing", st.score, None)
                elif force:
                    if v.status == "wrong":
                        self._finalize_status(st, i, "wrong", 0.5 + 0.5 * v.score, v.hyp_text)
                    elif v.status == "missing":
                        self._finalize_status(st, i, "missing", st.score, None)
                    else:
                        self._finalize_status(st, i, "ok", 0.0, v.hyp_text)
                else:
                    break  # not enough evidence yet: wait for the next decodes
                if v.extras_after and st.status == "ok":
                    st.score = max(st.score, 0.6)
                commit_upto = k
            if commit_upto >= off:
                self.committed = lo + commit_upto + 1
                ends = [hyp_end[v.hyp_idx] for v in al.verdicts[: commit_upto + 1] if v.hyp_idx is not None]
                if ends:
                    cut = int(max(0.0, max(ends) - cfg.cut_margin_s) * sr)
                    self._drop_audio(cut)
        if held_cut is not None and held_cut > self.buffer_t0 - bt0:
            self._drop_audio(int((held_cut - (self.buffer_t0 - bt0)) * sr))
        if self.committed - self.first > 2:
            self.started = True      # #33: more than 2 words committed from the first word: the start is fixed (_start_open)
        self._cap_before_start()     # #33 review: a word nothing explains (the cap cut «ومن اظلم» to «اظلم») commits nothing
        if final:
            self._freeze()
        return self.snapshot()

    def _start_open(self) -> bool:
        """#33 (v0.15): the session's start is still open: no decode of start_jump_min matched words fixed it (started),
        at most 2 words are committed from the session's first word and nothing was hinted or marked, so a later decode
        that clearly fits further on the start page may still restart the session there (step, _start_jump). Only with a
        start page (start_page_end: every Session has one); a tracker without one (the lost rule's unit tests, the
        calibration's whole surahs) keeps its first place."""
        return self.start_page_end is not None and not self.started and self.committed - self.first <= 2 and \
            not any(st.hinted or st.user_marked for st in self.states)

    def _cap_before_start(self) -> None:
        """#33: before the session started nothing else ever cuts the buffer while a lost word or the open start waits:
        keep the rolling window (B3.3), never an ever-growing decode (40 s and more on 2026-10-22)."""
        cap = int(self.config.max_window_s * self.config.sr)
        if not self.started and len(self.buffer) > cap:
            self._drop_audio(len(self.buffer) - cap)

    def _hold_repeat(self, al, lo: int, off: int, hyp_words, hyp_prob, decide: bool):
        """X2.1d: decoded words aligned into a surah that follows the one being recited, before any word of it was
        committed, may be that same surah said again (memorization), whose first words often open the next one too
        («قل» in 112, 113 and 114). They are compared with the start and the end of the surah just recited: when they
        fit there at least as well as at the start of the next surah, they are held back (None: they are not; on a tie
        `decide` (a full buffer) goes on into the next surah, Stop does not). Returns (window index of the boundary,
        number of decoded words kept, strict = the repeat fits better)."""
        cfg = self.config
        hi = lo + len(al.verdicts)
        bs = sorted(b for b in self.surah_starts if lo < b < hi and b > self.first and b >= self.committed)
        if not bs:
            return None
        b = bs[0]
        bw = b - lo
        into = [v.hyp_idx for v in al.verdicts if v.hyp_idx is not None and v.ref_idx >= bw]
        if not into and self.committed < b:
            return None       # nothing aimed at the next surah (once the surah is committed, every new word is)
        before = [v.hyp_idx for v in al.verdicts if v.hyp_idx is not None and v.ref_idx < bw]
        before += [j for j, r in al.repeat_of.items() if r < bw and j < min(into, default=len(hyp_words))]
        j_keep = max(before, default=-1) + 1              # the decoded words after the last one of the surah recited
        hw, hp = hyp_words[j_keep:], hyp_prob[j_keep:]
        if not hw:
            return None
        alts = self.expected_alt

        def cost(a: int, z: int, free_start: bool) -> float:
            return align(self.expected_norm[a:z], hw, hp, ref_alt=alts[a:z] if alts else None, free_start=free_start,
                         free_end=True, repeat_window=0).cost

        nxt = cost(b, min(len(self.expected_norm), b + len(hw) + 2 * cfg.max_skip), False)
        pb = max([k for k in self.surah_starts if k < b] + [0])
        span = len(hw) + 2 * cfg.max_skip + 20
        if b - pb <= 2 * span:
            prev = cost(pb, b, True)
        else:                                             # a long surah: said again from its start or its end
            prev = min(cost(pb, pb + span, True), cost(b - span, b, True))
        if prev < nxt - 1e-9:
            return bw, j_keep, True
        if prev <= nxt + 1e-9 and not decide:
            return bw, j_keep, False                      # cannot tell yet (e.g. «قل» alone): wait for the next words
        return None

    def _start_context_end(self) -> int:
        """X2.1c: the expected words the first words heard are located in (start_search_words): wider than the start
        page, so that words said after the page end still tell where on the page the reciter started."""
        return min(len(self.expected_norm), self.config.start_search_words)

    def _start_search_end(self) -> int:
        """X2.1c: the end (exclusive) of the expected words where the reciter may start: the session's start page
        (start_page_end), at most start_search_words."""
        n = self._start_context_end()
        return n if self.start_page_end is None else min(n, self.start_page_end)

    def _fits_further(self, hyp_words: list[str], hyp_prob: list[float]) -> bool:
        """Before the start: at least half of the words heard fit together further on than the session's first words
        on the session's start page (_start_search_end), where the reciter may have started (X2.1c)."""
        cfg = self.config
        n = self._start_search_end()
        alt = self.expected_alt[:n] if self.expected_alt else None
        al = align(self.expected_norm[:n], hyp_words, hyp_prob, ref_alt=alt, free_start=True, free_end=True,
                   repeat_window=0)
        n_ok = sum(1 for v in al.verdicts if v.status == "ok")
        return bool(al.span and al.span[0] > cfg.max_skip and n_ok >= 1 and 2 * n_ok >= len(hyp_words))

    def _start_jump(self, hyp_words: list[str], hyp_prob: list[float], decide: bool = True) -> str:
        """X2.1c: the first words heard fit clearly further on than the session's first word (the reciter started in the
        middle of the page): the session starts there, the words before are simply not recited. Nothing is decided
        ("wait": the decode is not used, the next one holds more words) while the words heard are too few to tell and
        fit the session's start as well as further on (e.g. «قل», which opens 112, 113 and 114 on page 604, X2.1d),
        nor while they fit as well somewhere before the place found (a phrase repeated on the page, e.g. «قل اعوذ برب»
        opening 113 and 114). `decide` (Stop, or a full buffer): never wait, the earlier place. The words are located in the
        wider context (_start_context_end: words said after the page end still place the start, e.g. a reciter starting at
        a page's last ayah), but the start itself must be on the session's start page (_start_search_end): words that
        fit a later page better («ولما جاءهم رسول» for «ولما جاءهم كتاب», 2:89 / 2:101, replay 2026-09-19 23-27-39) are a
        mistake at the session's start. #33 (v0.15): also a restart while the start is open (_start_open): measured from
        the words committed so far, and the words before the new start go back to not recited (a lost bar cleared).
        Returns ("jump" | "wait" | "none", j): on a jump, j = the decoded words said before the new start (located before
        it: the old place's words still in the buffer, #33 review), which step() drops with their audio; else 0."""
        cfg = self.config
        n = self._start_context_end()
        base = self.committed            # 0 at the session's start; a restart (#33): 1 or 2 words may be committed

        def locate(n_ref: int):
            alt = self.expected_alt[:n_ref] if self.expected_alt else None
            al = align(self.expected_norm[:n_ref], hyp_words, hyp_prob, ref_alt=alt, free_start=True, free_end=True,
                       repeat_window=0)   # locating: a free start must not turn the first words into repeats
            return al, sum(1 for v in al.verdicts if v.status == "ok")

        al, n_ok = locate(n)
        sp = al.span
        if len(hyp_words) < cfg.start_jump_min:
            if decide or not (sp and sp[0] > base + cfg.max_skip and n_ok >= 1):
                return "none", 0
            al0, _ = locate(min(n, base + cfg.max_skip + 1 + len(hyp_words)))   # ... and as well at the session's start?
            return ("wait" if al0.cost <= al.cost + 1e-9 else "none"), 0
        if not (sp and sp[0] > base + cfg.max_skip and n_ok >= cfg.start_jump_min
                and n_ok >= cfg.start_jump_ratio * len(hyp_words)):
            return "none", 0
        start, at = sp[0], al
        while start > 0:                 # the same words just as well earlier on?
            al2, n_ok2 = locate(start)
            if not (al2.span and n_ok2 >= n_ok and al2.cost <= al.cost + 1e-9):
                break
            if not decide:
                return "wait", 0
            start, at = al2.span[0], al2
        if start <= base + cfg.max_skip or start >= self._start_search_end():   # the start itself must be on the start page
            return "none", 0
        for i in range(self.first, start):
            st = self.states[i]
            if st != WordState() and not (st.user_marked or st.hinted):
                # #33: not recited (no verdict, never a mistake, a lost bar cleared); #33 review: never the user's own mark
                # (+ Mistake before reciting, then a start further on: the X2.1c start has no _start_open guard)
                self.states[i] = WordState()
                self._touch(i)
        self.committed = self.first = start
        self.cursor = -1
        return "jump", min((v.hyp_idx for v in at.verdicts if v.hyp_idx is not None and v.ref_idx >= start), default=0)

    def _drop_said_before(self, j: int, buf: np.ndarray, hyp_words, hyp_start, hyp_end, hyp_prob):
        """#33 review (a restart left 2:113's «وقالت» in the buffer: decoded again before 2:116's first word, it became an
        attempt at it or was paired wrong with it, a red word): after a start jump the j decoded words said before the new
        start are dropped from this decode, and their audio up to cut_margin_s before the new first word (never into it;
        as a commit's cut: a leftover tail is a head-of-buffer leftover, head_guard_s). Returns the buffer and the words
        left, their times from the new buffer start."""
        n = int(round(max(0.0, hyp_start[j] - self.config.cut_margin_s) * self.config.sr))
        self._drop_audio(n)
        d = n / self.config.sr
        out = hyp_words[j:], [s - d for s in hyp_start[j:]], [e - d for e in hyp_end[j:]], hyp_prob[j:]
        self.last_hyp = " ".join(out[0])
        self.decode_log[-1] = (self.decode_log[-1][0], self.last_hyp)
        return buf[n:], *out

    def _freeze(self) -> None:
        """Session over: provisional verdicts become final, untouched words stay pending, concealed words are shown.
        X2.1d: a surah entered after the session's start with fewer than start_jump_min words heard (the same evidence
        as an X2.1c start) was not reached: a stray word after the last surah, the start of a repeat, or the tail of
        the last word heard as the next surah's first word («الم» in the pause after Al-Fatiha, emulator 2026-10-01).
        Its words go back to pending, so that it is no mistake and not part of the session (Session.reached), unless
        the user hinted or marked one of its words."""
        bounds = sorted(self.surah_starts) + [len(self.states)]
        for b, e in zip(bounds, bounds[1:]):
            if b <= self.first:
                continue
            heard = [st for st in self.states[b:e] if st.ok_seen >= 1 or st.status in ("ok", "provisional_ok")]
            if len(heard) >= self.config.start_jump_min or any(st.hinted or st.user_marked for st in self.states[b:e]):
                continue
            for i in range(b, e):
                if self.states[i] != WordState():
                    self.states[i] = WordState()                 # never a verdict on a surah not reached
                    self._touch(i)
        for i, st in enumerate(self.states):
            if st.concealed:
                st.concealed = False
                self._touch(i)
            if st.final:
                continue
            if st.extra_run >= 2 and st.ok_seen >= 1:   # X2.4e needs the word said after the wrong words (X2.16 R3)
                self._finalize_attempt(st, i)
            elif st.ok_seen >= 1 or st.status == "provisional_ok":
                self._finalize_status(st, i, "ok", 0.0, st.hyp)
            elif st.status == "provisional_wrong":
                self._finalize_status(st, i, "wrong", st.score, st.hyp)
            elif st.status == "provisional_missing":
                self._finalize_status(st, i, "missing", st.score, None)
        self.committed = len(self.states)
        self.stopped = True

    def _drop_audio(self, n_samples: int) -> None:
        n_samples = max(0, min(n_samples, len(self.buffer)))
        self.buffer = self.buffer[n_samples:]
        self.buffer_t0 += n_samples / self.config.sr

    # ------------------------------------------------------------------ user actions
    def _heard(self, st: WordState) -> bool:
        """Shown as heard (green), not committed yet, no wrong attempt before it: heard correctly, or heard only as forms
        no reciter says (issue #6: correct at its commit)."""
        return not st.final and st.extra_run == 0 and (st.ok_seen >= 1 or st.status == "provisional_ok")

    def _settle_heard(self, st: WordState, i: int) -> bool:
        """◂ / ⏮ / the lost rule pass a word shown as heard but not settled yet: settled as Stop does (_freeze): heard
        after extra words seen in 2+ decodes = the wrong attempt (X2.4e), else correct (an attempt seen once, or a word
        heard only as a no-evidence form, issue #6). Never "skipped" with the word itself as what was heard (issue #5).
        Returns True when the word was settled."""
        if st.final or not (st.ok_seen >= 1 or st.status == "provisional_ok"):
            return False
        if st.extra_run >= 2 and st.ok_seen >= 1:
            self._finalize_attempt(st, i)
        else:
            self._finalize_status(st, i, "ok", 0.0, st.hyp)
        return True

    def _restart_buffer(self, keep_from: float | None) -> None:
        """After ◂ / ⏮ the decoded audio is done with; a voice command keeps what was said after it (keep_from, session
        seconds)."""
        if keep_from is None:
            self.buffer = np.zeros(0, dtype=np.float32)
            self.buffer_t0 = self.session_time
        else:
            self._drop_audio(int(round((keep_from - self.buffer_t0) * self.config.sr)))

    def hint(self, word_index: int, keep_from: float | None = None) -> None:
        """'Next word' during a session (◂, voice «الكلمة التالية»): the word is shown, counted as a mistake (brown) and
        the pointer moves past it. The words before it already heard stay correct (X2.16; heard behind an attempt not
        confirmed yet: settled as Stop does, issue #5), the others were skipped. A word that already is a mistake
        (concealed, or a final wrong / skipped word) keeps its verdict and what was heard (issue #1, 2026-10-10: ◂
        reveals the red bar first); behind the pointer nothing else moves (no buffer restart); the cursor never moves
        back. On a word the reciter already passed (before the cursor: the page's earliest bar, D1), the words heard
        after it are settled as Stop does too, and the audio of the words not settled is kept (review 2026-10-11)."""
        if not (0 <= word_index < len(self.states)):
            return
        st = self.states[word_index]
        revealed_lost = st.concealed or (st.final and st.status in ("wrong", "missing"))   # keeps red (and underlined)
        st.hinted = True
        st.concealed = False
        if not st.user_marked and not revealed_lost:
            st.status, st.score, st.hyp, st.final = "hinted", 1.0, None, True
        self._touch(word_index)
        if word_index >= self.committed:
            for k in range(self.committed, word_index):
                s2 = self.states[k]
                if not self._settle_heard(s2, k) and not s2.final:
                    # words before the hinted one that were never heard: skipped (nothing heard there)
                    s2.status, s2.score, s2.hyp, s2.final = "missing", 0.75, None, True
                    self._touch(k)
            k = word_index + 1
            if word_index < self.cursor:
                # the reciter is further on: the words heard after the hinted one are settled (correct, or the attempt),
                # up to the first one not heard yet, whose audio stays in the buffer (from the end of the last word
                # settled, as a commit cuts; all of it when that end is not known)
                while k <= self.cursor and self._settle_heard(self.states[k], k):
                    k += 1
                if k <= self.cursor or keep_from is None:
                    last = self.states[k - 1]
                    t_keep = self.buffer_t0 if last.t_end is None or last.lost \
                        else last.t_end - self.config.cut_margin_s
                    keep_from = t_keep if keep_from is None else min(keep_from, t_keep)
            self.committed = k
            self.cursor = max(self.cursor, word_index)
            self._restart_buffer(keep_from)
        self.started = True

    def skip_to(self, word_index: int, keep_from: float | None = None) -> None:
        """'Next ayah' during a session (⏮, voice «باقي الآية»): every unsettled word before word_index becomes a hint
        (counted), except the words already heard (correct, X2.16; heard behind an attempt not confirmed yet: settled as
        Stop does, issue #5), and the pointer jumps there."""
        word_index = max(self.committed, min(word_index, len(self.expected_norm)))
        for k in range(self.committed, word_index):
            st = self.states[k]
            if self._settle_heard(st, k):
                continue
            st.hinted = True
            st.concealed = False
            if not st.final:
                st.status, st.score, st.hyp, st.final = "hinted", 1.0, None, True
            self._touch(k)
        self.committed = word_index
        self.cursor = word_index - 1
        self._restart_buffer(keep_from)
        self.started = True

    def settle_before(self, t: float) -> None:
        """Before a voice next / eyah (B3.15): the words heard correctly before the command (ending by t + 0.1 s, the
        same evidence as the lost rule's) become final ok and the pointer moves past them."""
        k = self.committed
        while k < len(self.states) and self._heard(self.states[k]) and (self.states[k].t_end or 0.0) <= t + 0.1:
            self._finalize_status(self.states[k], k, "ok", 0.0, self.states[k].hyp)
            k += 1
        self.committed = max(self.committed, k)

    def next_hidden(self) -> int | None:
        """The word ◂ (without a word) and «الكلمة التالية» reveal: the concealed lost word the tracker waits on (X2.4c,
        issue #1; not once the user marked it: seen), else the first one from max(first, cursor + 1) on not heard yet
        (None: the passage end). ⏮ / «باقي الآية» reveal the rest of that word's ayah (so the lost word's first)."""
        k = self.committed
        if k < len(self.states) and self.states[k].concealed and not self.states[k].user_marked:
            return k
        for i in range(max(self.first, self.cursor + 1), len(self.states)):
            if self.states[i].status == "pending":
                return i
        return None

    def mark(self, word_index: int, status: str) -> None:
        """User overrules a verdict after listening to the replay: status in {'ok', 'wrong'}. A concealed (lost) word
        marked correct is shown (review 2026-10-11, as app.state_after_mark after Stop)."""
        if 0 <= word_index < len(self.states) and status in ("ok", "wrong"):
            st = self.states[word_index]
            if not st.user_marked:
                st.auto = (st.status, st.score, st.final, st.concealed)
            st.user_marked = True
            st.final = True
            st.status = status
            st.score = 0.0 if status == "ok" else 1.0
            if status == "ok":
                st.concealed = False
            self._touch(word_index)

    def unmark(self, word_index: int) -> None:
        """Undo the user's overrule ('Remove last' on a word of the running session, X2.12); a lost word still unsaid
        and not revealed is concealed again."""
        if 0 <= word_index < len(self.states):
            st = self.states[word_index]
            if st.user_marked and st.auto is not None:
                st.status, st.score, st.final, concealed = st.auto
                st.concealed = st.concealed or (concealed and not (st.said or st.hinted or self.stopped))
                st.user_marked, st.auto = False, None
                self._touch(word_index)

    def set_threshold(self, value: float) -> None:
        self.config.threshold = max(0.0, min(1.0, float(value)))

    # ------------------------------------------------------------------ output
    def word_dict(self, i: int) -> dict:
        s = self.states[i]
        return {"i": i, "status": s.status, "score": round(s.score, 3), "hyp": s.hyp,
                "hinted": s.hinted, "lost": s.lost, "concealed": s.concealed, "user": s.user_marked,
                "said": s.ok_seen >= 1 or s.said,     # heard correctly once (B3.8, 2026-10-10)
                "t0": None if s.t_start is None else round(s.t_start, 2),
                "t1": None if s.t_end is None else round(s.t_end, 2)}

    def snapshot(self, delta: bool = False) -> dict:
        idx = sorted(self.changed) if delta else range(len(self.states))
        out = {
            "committed": self.committed,
            "cursor": self.cursor,
            "first": self.first,
            "done": self.done,
            "off_track": self.off_track,
            "hyp": self.last_hyp,
            "buffer_s": round(len(self.buffer) / self.config.sr, 2),
            "speech_s": self.unsettled_speech_s(),
            "session_s": round(self.session_time, 2),
            "words": [self.word_dict(i) for i in idx],
            "delta": delta,
        }
        if delta:
            self.changed = set()
        return out

    def unsettled_speech_s(self) -> float:
        """Seconds of speech-like audio (frames above the quiet threshold) still in the rolling
        buffer, i.e. what the reciter said that is not settled yet. Silence and fan noise count
        for nothing, so the lag bar (U1.2c) stays empty while nobody recites."""
        if len(self.buffer) < self.config.sr // 10:
            return 0.0
        return round(float(self._energetic_frames(self.buffer, self.config.sr).sum()) * 0.02, 2)

    def summary(self, threshold: float | None = None, lo: int = 0, hi: int | None = None) -> dict:
        """Counts over the words lo..hi-1 (X2.1d: the surahs the session reached; default the whole passage)."""
        thr = self.config.threshold if threshold is None else threshold
        hi = len(self.states) if hi is None else hi
        n = hi - lo
        span = [(i, self.states[i]) for i in range(lo, hi)]
        mistakes = [i for i, s in span if s.status in MISTAKE_STATUSES and (s.score >= thr or s.user_marked)]
        hinted = [i for i, s in span if s.hinted]
        not_recited = [i for i, s in span if s.status == "pending"]
        n_recited = n - len(not_recited)
        return {"n_words": n, "n_recited": n_recited, "n_mistakes": len(mistakes), "mistakes": mistakes,
                "hinted": hinted, "not_recited": len(not_recited), "threshold": thr,
                "accuracy": round(1 - len(mistakes) / n_recited, 4) if n_recited else 0.0}
