"""Meddeb's platform-neutral backend (03_platforms.md §4): pages, reading history, manual marks, progress, settings,
replay clips and the live session (the B3.8 protocol without its transport). The PC server (d04_meddeb/server.py)
serves it over HTTP + WebSocket; the Android app calls it through Chaquopy; the web version will run it in Pyodide.
Only numpy and the standard library: no web framework, no soundfile, no model runtime."""
from __future__ import annotations

import datetime as dt
import io
import json
import os
import platform
import re
import shutil
import threading
import time
import uuid
import wave
from pathlib import Path
from typing import Callable

import numpy as np

from . import audio_ban, listen, qa_times, review
from . import __version__, word_times
from .loudness import RECITER_GAIN, normalize_replay
from .normalize import clean_hyp, normalize
from .profile import (MISTAKE_STATUSES, Learned, Profile, effective_marks, export_manifest, heard_is_the_word, learn,
                      summarize, word_key)
from .progress import progress as compute_progress
from .stats import stats as compute_stats
from .search import near_pages, search_place, word_place
from .storage import DELETABLE as STORAGE_DELETABLE, EXPORT_KINDS, KINDS as STORAGE_KINDS, NEEDS_NO_SESSION, RECITING
from .storage import export_files, export_kind
from .quran_text import (DATA, context_words, hizb_of, juz_of, load_quran, n_pages, page_lines, page_of, page_start,
                         start_page_end)
from .report import issue_text, issue_url, report_repo, session_label
from .tajweed_html import TAJWEED_COLORS, TAJWEED_LABELS, ayah_word_html, tajweed_css
from .tracker import TAAWWUDH, Tracker, TrackerConfig

APP_NAME = "Meddeb"
SR = 16000
STEP_SAMPLES = int(0.8 * SR)       # B3.3: one decode per ~0.8 s of new audio
MAX_LIVE = 5                       # sessions whose audio stays in memory for replay
FOLDER_RE = re.compile(r"[\w .()-]+")
SEARCH_WINDOW_S = 20.0             # X2.13: seconds of audio the search transcribes at every step
BEFORE_MAX_S = 30.0                # #36: the ayah before a session longer than this plays only its end ...
BEFORE_TAIL_S = 20.0               # ... from its first word starting in its last 20 s (2:282: 141 s; Claude's default)
# v0.23 review (#92, D17): the tracker's starts inside a unit of the clean recording are unconfirmed, and some are off by
# up to 38 s (30:17: 35.4 s for EveryAyah's 6.2 s): a unit part or word cut longer than UNIT_RATIO x EveryAyah's length
# of the same words + UNIT_SLACK_MS is not trusted (text only); the first word start must lie within UNIT_START_TOL_MS
# of the part's start (Claude's defaults)
UNIT_RATIO, UNIT_SLACK_MS, UNIT_START_TOL_MS = 2.5, 3000, 1000
TAAWWUDH_KEY = "001000"            # #36: EveryAyah's ta'awwudh file; #58 (D11): the cue's opening at the car's start
# #58 (v0.18, D11): the recorded «سورة …» of each surah (tools/make_surah_names.py from data/surah_names_tts.json), in
# the page's own folder: the same relative path on the PC server and inside the Android assets
SURAH_NAME_URL = "static/audio/surah_names/{:03d}.mp3"
# X2.9 (#45, v0.17): a running session's checkpoint, <profile>/unsaved/<session id>/ (App.recover_unsaved)
CHECKPOINT_S = 5.0                 # at most one checkpoint per 5 s of session time while verdicts change
CHECKPOINT_WORDS_PER_S = 200       # v0.17 review: past 1000 words recited, 1 s more per 200 (a whole Al-Baqarah: 30 s)
CHECKPOINT = "checkpoint.json"     # the session as ■ would save it at that moment
CHECKPOINT_PREV = "checkpoint.prev.json"   # the checkpoint before it (a torn checkpoint.json falls back to it)
CHECKPOINT_PCM = "audio.pcm"       # the recording so far, 16 kHz int16, appended at each step
CHECKPOINT_DECODES = "decodes.jsonl"   # the decode lines so far, appended at each step (#45 review: never rewritten)
CHECKPOINT_LOCK = "lock"           # held by the session recording into the folder, or by its recovery (_DirLock)
CHECKPOINT_FORMAT = 1
# v0.22 (#101 P1, plan D1; user 2026-11-02: "I am ok with the proposal do them all"): a session is an invisible group of
# readings: the microphone only goes off and on in it (no ■); the engine closes it (the same save: one folder) after
# GROUP_GAP_S without activity (App.tick), at a start elsewhere (App.start) and at the app's exit / the car's leave
GROUP_GAP_S = 600.0
GROUP_BACK, GROUP_AHEAD = 10, 40      # a find from the open group's cursor - 10 to + 40 words goes on in that group
ENDED_BY = ("stop", "idle", "elsewhere", "exit", "car", "recovered")   # session.json "ended_by"


def name_clip(surah: int) -> dict:
    """#58 (D11): the cue step that says «سورة …» of a surah: a clip of the reciter_clip shape (key name019, the whole
    file, untimed), kind 'name', at unity gain (the clips are made at -18 LUFS, X2.18)."""
    s = int(surah)
    return {"key": f"name{s:03d}", "url": SURAH_NAME_URL.format(s), "t0_ms": 0, "t1_ms": None, "timed": False,
            "surah": s, "ayah": 0, "kind": "name", "gain": 1.0}


def _qa_ms(surah: int, ayah: int, t_ms: int | None, rng: tuple[int, int], starts: list | None = None) -> int:
    """v0.22 (D7): a time of Yasser's EveryAyah file of surah:ayah (t_ms, a reciter_clip bound: 0 = the file start,
    None = its end) inside the QuranicAudio range rng of the same ayah. Both are cuts of one master recording: with as
    many word starts on both sides, a word start maps to its twin (repeats included, in time order); else the time
    shifts by the first words' offset; capped to the range."""
    lo, hi = int(rng[0]), int(rng[1])
    if t_ms is None:
        return hi
    if t_ms <= 0:
        return lo
    t = word_times.timeline(surah, ayah)
    starts = qa_times.qa_word_starts(surah, ayah) if starts is None else starts   # v0.22 review: the clean recording's
    if t and t[0] and starts:
        ea = [int(round(x * 1000)) for _k, x in t[0]]
        if len(ea) == len(starts):
            i = min(range(len(ea)), key=lambda k: abs(ea[k] - t_ms))
            if abs(ea[i] - t_ms) <= 20:
                return max(lo, min(hi, int(starts[i]) + t_ms - ea[i]))
        return max(lo, min(hi, t_ms + int(starts[0]) - ea[0]))
    return max(lo, min(hi, lo + t_ms))


def _clean_cut(clip: dict, rng, starts: list | None) -> tuple[int, int] | None:
    """v0.22 review 2 (#92, D7): the clip's words from_idx..to_idx in Yasser's clean recording, cut on its own word
    starts (another, slower recording than EveryAyah's: a shift of EveryAyah's times played another word, or nothing
    for 352 single words): from the first word's start (the range's start for word 0) to the next word's start after
    it (two written words may share one start), else the range's end. None: no word starts for every word."""
    lo, hi = int(rng[0]), int(rng[1])
    n = len(starts or ())
    if not n:
        return None
    i = int(clip.get("from_idx") or 0)
    j = int(clip["to_idx"]) if clip.get("to_idx") is not None else n - 1
    if not (0 <= i <= j < n):
        return None
    t0 = lo if i == 0 else max(lo, min(hi - 1, int(starts[i])))
    t1 = next((int(x) for x in starts[j + 1:] if int(x) > t0), hi)
    return t0, max(t0 + 1, min(hi, t1))


def off_banned(clip: dict) -> dict:
    """v0.22 (#92, plan D7; user 2026-11-02: "EveryAyah's [ticked] audio must be banned and never never used"): a
    reciter_clip-shaped clip of Yasser's EveryAyah file, unchanged when that file is clean (D4.12); a banned one plays
    the same words from QuranicAudio's surah file where its range is clean (key "qaSSS": the surah file, t0 / t1 in it,
    _qa_ms), v0.22 review (user 2026-11-02: "just use a yasser al dussary audio that is not ticking"): else from his
    clean recording (archive.org, listen.clean_entry: Meddeb's range and word starts of the ayah; the same key "qaSSS",
    a range of a whole-surah file, which ClipSpec / AudioBan judge by the clip's ayah), else nothing: url None and
    `banned` (the page shows the text, the car goes on with the next step)."""
    if not clip.get("url") or not audio_ban.banned_url(clip["url"]):
        return clip
    s, a = int(clip["surah"]), int(clip["ayah"])
    url, rng = qa_times.qa_url(s), (qa_times.qa_range(s, a) if a else None)
    if url and rng and not audio_ban.banned_url(url, a):
        return dict(clip, key=f"qa{s:03d}", url=url, t0_ms=_qa_ms(s, a, clip["t0_ms"], rng),
                    t1_ms=_qa_ms(s, a, clip["t1_ms"], rng), timed=True)
    ce = listen.clean_entry(s) if a else None
    ayat, starts = (ce.get("ayat") or [], ce.get("word_starts") or []) if ce else ([], [])
    rng = ayat[a - 1] if 0 < a <= len(ayat) else None
    if ce and rng and len(rng) == 2 and not audio_ban.banned_url(ce["url"], a):
        st = starts[a - 1] if a <= len(starts) and starts[a - 1] else None
        cut = _clean_cut(clip, rng, st)
        if cut is None:                         # no word starts of its own: EveryAyah's times shifted (_qa_ms)
            cut = (_qa_ms(s, a, clip["t0_ms"], rng, st), _qa_ms(s, a, clip["t1_ms"], rng, st))
        return dict(clip, key=f"qa{s:03d}", url=ce["url"], t0_ms=cut[0], t1_ms=cut[1], timed=True)
    part = _unit_part(clip, ce) if ce and a else None
    if part:
        return part
    return dict(clip, url=None, t0_ms=0, t1_ms=None, timed=False, banned=True)


def _unit_part(clip: dict, ce: dict) -> dict | None:
    """#92 (v0.23, D17): an ayah of the 74 (no clean range of its own) inside a unit of the clean recording
    (listen.clean_unit: ayat Yasser joins without a pause) plays its own part of the unit in Recite: from its start (the
    unit's start, else the tracker's start of the ayah, `inner`) to the tracker's start of the next ayah (the unit's
    end for its last ayah). Never the whole unit: its next ayah may be the one the session is about to recite (the cue
    before it, a voice command). A few words are cut on its own word starts (_clean_cut); without word starts for
    every word (24:31) only the whole ayah plays. None: no unit, no inner starts, or words it cannot cut. v0.23 review:
    those starts are the tracker's, unconfirmed: a part longer than EveryAyah's same words allow (_unit_plausible) is
    None (30:17, 30:34, 8:59), so are words cut on starts that cannot be trusted (_unit_starts) or a cut too long."""
    s, a = int(clip["surah"]), int(clip["ayah"])
    g = _unit_geom(s, a)
    if g is None:
        return None
    (first, last), rng, n, ws = g
    i = int(clip.get("from_idx") or 0)
    j = n - 1 if clip.get("to_idx") is None else int(clip["to_idx"])
    if i == 0 and j >= n - 1:
        cut = rng
    elif ws is not None:
        cut = _clean_cut(clip, rng, ws)
        if cut is not None and not _unit_plausible(s, a, i, min(j, n - 1), cut[1] - cut[0]):
            cut = None                          # v0.23 review: a cut far longer than its words (a repeat, a wrong start)
    else:
        cut = None
    if cut is None:
        return None
    return dict(clip, key=f"qa{s:03d}", url=ce["url"], t0_ms=cut[0], t1_ms=cut[1], timed=True, unit=[first, last])


def _unit_geom(s: int, a: int) -> tuple | None:
    """#92 (v0.23, D17) / v0.23 review: ((first, last) of the unit holding s:a, its part (t0, t1) in the clean surah
    file, its number of words, its word starts when they can be trusted (_unit_starts), else None); None when it has no
    unit, no inner starts, a part EveryAyah's times do not allow (_unit_plausible: never play what may be another ayah)
    or, in a unit of several ayat, a part bounded by the tracker's inner starts that its own word starts do not bear
    out (only a unit of one, 24:31, between two confirmed cuts, plays without them)."""
    u = listen.clean_unit(s, a)
    if not u:
        return None
    (first, last), (lo, hi), inner = u["ayat"], u["range"], u["inner"]
    k = a - first
    if last > first and len(inner) != last - first:
        return None
    rng = (lo if k == 0 else inner[k - 1], hi if a == last else inner[k])
    n = len(load_quran().ayah(s, a).words)
    if not _unit_plausible(s, a, 0, n - 1, rng[1] - rng[0]):
        return None
    ws = _unit_starts(s, a, (u["word_starts"] or [None] * (last - first + 1))[k], rng, n)
    if ws is None and last > first:
        return None                             # a tracker bound (inner) its own word starts do not bear out (31:14)
    return (first, last), rng, n, ws


def _unit_plausible(s: int, a: int, i: int, j: int, ms: int) -> bool:
    """v0.23 review (#92, D17): `ms` of the clean recording may hold the words i..j of s:a: at most UNIT_RATIO x
    EveryAyah's length of the same words (word_times.clip_ms, his other recording) + UNIT_SLACK_MS. False when
    EveryAyah's times of the ayah are unknown (nothing to check the tracker's starts against)."""
    t = word_times.timeline(s, a)
    if t is None:
        return False
    t0, t1 = word_times.clip_ms(s, a, i, j)
    ea = (t[1] * 1000 if t1 is None else t1) - t0
    return ms <= UNIT_RATIO * ea + UNIT_SLACK_MS


def _unit_starts(s: int, a: int, ws, rng, n: int) -> list[int] | None:
    """v0.23 review (#92, D17): a unit ayah's word starts (the tracker's) when they can be trusted for a cut: one per
    word, in time order, inside the part, the first within UNIT_START_TOL_MS of the part's start (the unit's start or
    its inner start) and every word's span (to the next word's start, the part's end for the last) plausible against
    EveryAyah's words up to it (_unit_plausible over words 0..i: the span may hold a repeat of the ayah's earlier
    words, never more: 31:14's word 0 spans 17 s, 30:17's 31.6 s); else None (a few words are text only). A cut is
    checked on its own words again (_unit_part)."""
    lo, hi = int(rng[0]), int(rng[1])
    if not isinstance(ws, list) or len(ws) != n or not all(isinstance(x, (int, float)) for x in ws):
        return None
    ws = [int(x) for x in ws]
    if any(y < x for x, y in zip(ws, ws[1:])) or abs(ws[0] - lo) > UNIT_START_TOL_MS or ws[-1] >= hi:
        return None
    starts = [lo] + [max(lo, x) for x in ws[1:]]
    ends = starts[1:] + [hi]
    if not all(_unit_plausible(s, a, 0, i, ends[i] - starts[i]) for i in range(n)):
        return None
    return ws


def _cap_clean(moved: dict, clip: dict) -> dict:
    """v0.23 review (#36 cap, B3.8): the cue's ayah before, `moved` to Yasser's clean recording (off_banned: its range
    of the ayah, or a unit part), longer than BEFORE_MAX_S plays from the first of that recording's own word starts in
    its last BEFORE_TAIL_S (the clean range's word_starts, or the unit's when _unit_starts trusts them); no word start
    to cut on, or still over BEFORE_MAX_S from the last one: text only (`banned`, as 24:31's 74 s ayah). `clip`: the
    EveryAyah clip it was moved from (the text-only form keeps its key)."""
    t0, t1 = int(moved["t0_ms"]), moved.get("t1_ms")
    if t1 is None or t1 - t0 <= BEFORE_MAX_S * 1000:
        return moved
    s, a = int(moved["surah"]), int(moved["ayah"])
    if moved.get("unit"):
        g = _unit_geom(s, a)
        ws = g[3] if g else None
    else:
        ce = listen.clean_entry(s)
        st = (ce.get("word_starts") or []) if ce else []
        ws = st[a - 1] if 0 < a <= len(st) else None
    said = sorted((int(x), k) for k, x in enumerate(ws or ()) if x is not None and t0 <= int(x) < t1)
    pick = next(((x, k) for x, k in said if x >= t1 - BEFORE_TAIL_S * 1000), said[-1] if said else None)
    if pick is None or t1 - pick[0] > BEFORE_MAX_S * 1000:
        return dict(clip, url=None, t0_ms=0, t1_ms=None, timed=False, banned=True)
    return dict(moved, from_idx=pick[1], t0_ms=pick[0])


def wav_bytes(audio: np.ndarray | list[np.ndarray], sr: int = SR) -> bytes:
    """16-bit PCM mono WAV with the stdlib (no soundfile on the phone or in the browser). audio: one array, or a list of
    arrays (a session's chunks: converted one by one, never one float copy of a long session; the same bytes)."""
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        group, n = [], 0
        for part in (audio if isinstance(audio, list) else [audio]):
            group.append(np.asarray(part, dtype=np.float32).reshape(-1))
            n += len(group[-1])
            if n >= 1 << 20:                    # ~1 M samples at a time (0.1 s chunks are slow to convert one by one)
                w.writeframes(_pcm16(group))
                group, n = [], 0
        w.writeframes(_pcm16(group))
    return buf.getvalue()


def _pcm16(parts: list[np.ndarray]) -> bytes:
    x = np.concatenate(parts) if parts else np.zeros(0, dtype=np.float32)
    return (np.clip(x, -1.0, 1.0) * 32767).astype("<i2").tobytes()


def read_wav(path: Path, a: int = 0, b: int | None = None) -> np.ndarray:
    """A 16 kHz 16-bit WAV as float32 (/ 32768). #71 (v0.19, D9, X2.18): frames [a, b) only (wave setpos +
    readframes): a replay of a saved session reads its seconds, not the whole hour."""
    with wave.open(str(path), "rb") as w:
        if w.getsampwidth() != 2 or w.getframerate() != SR:
            raise ValueError(f"{path.name}: expected 16 kHz 16-bit PCM")
        n = w.getnframes()
        a = min(max(0, int(a)), n)
        b = n if b is None else min(max(a, int(b)), n)
        w.setpos(a)
        pcm = np.frombuffer(w.readframes(b - a), dtype="<i2").astype(np.float32)
        if w.getnchannels() > 1:
            pcm = pcm.reshape(-1, w.getnchannels()).mean(axis=1)
    return pcm / 32768.0


def wav_frames(path: Path) -> int:
    """The number of frames of a WAV (its header only)."""
    with wave.open(str(path), "rb") as w:
        return w.getnframes()


def mushaf_lines(page: int, ayahs: list[dict]) -> list[dict]:
    """The 15 lines of the Madani page (U1.1b): [{n, kind: words|surah|basmala|empty, runs: [[start, n_words,
    ayah_end]], surah}] where start indexes the page's word list and ayah_end is the ayah number when the run closes
    its ayah (the marker goes after it). Surah headers and basmalas take the lines before the surah's first words
    (data: recite/data/mushaf_lines.json in recite word numbering, tools/fetch_mushaf_lines.py). #40 (v0.15): a surah
    that opens the next page on line 2 (its basmala on line 1; 18 pages) has its header on this page's line 15, the
    only line the layout leaves free there, as printed (it was drawn on neither page)."""
    starts = {(a["surah"], a["ayah"]): a for a in ayahs}
    lines: dict[int, dict] = {n: {"n": n, "kind": "empty", "runs": []} for n in range(1, 16)}
    first_line: dict[int, int] = {}
    for ln, s, a, idx, n in page_lines(page):
        ay = starts.get((s, a))
        if ay is None or ln not in lines:
            continue
        lines[ln]["kind"] = "words"
        lines[ln]["runs"].append([ay["start"] + idx - ay["first_idx"], n, a if idx + n == ay["n_total"] else 0])
        if a == 1 and idx == 0:
            first_line[s] = ln
    for s, ln in first_line.items():
        ay = starts[(s, 1)]
        head = ln - 2 if ay["basmala"] else ln - 1
        if ay["basmala"] and ln - 1 in lines and lines[ln - 1]["kind"] == "empty":
            lines[ln - 1].update(kind="basmala", surah=s)
        if head in lines and lines[head]["kind"] == "empty":
            lines[head].update(kind="surah", surah=s, surah_name_ar=ay["surah_name_ar"], surah_name=ay["surah_name"])
    nxt = page_lines(page + 1) if page < n_pages() else []
    if nxt and nxt[0][2] == 1 and nxt[0][3] == 0:
        # #40: the next page opens a surah too high for its header (and basmala): they take this page's last lines
        ln, s = nxt[0][0], nxt[0][1]
        q = load_quran()
        heads = [(ln - 1, {"kind": "basmala", "surah": s})] if s not in (1, 9) else []
        heads.append((ln - 1 - len(heads), {"kind": "surah", "surah": s, "surah_name_ar": q.chapter_name_ar(s),
                                            "surah_name": q.chapter_name(s)}))
        for at, line in heads:
            if at < 1 and 15 + at in lines and lines[15 + at]["kind"] == "empty":
                lines[15 + at].update(line)
    return [lines[n] for n in range(1, 16)]


def is_joined(surah: int, ayah: int, idx: int) -> bool:
    """U1.1e (v0.12, #22): the spoken (imla'i) word has no written word of its own: the written word before it holds
    both (يَٰبَنِىَّ = يا + بني, بَعْدَمَا = بعد + ما; 369 in the mushaf). The page draws nothing for it (empty tajweed
    html); its partner is always the previous word of its ayah. False past the ayah's last word."""
    html = ayah_word_html(surah, ayah)
    return 0 < idx < len(html) and not html[idx].strip()


def written_text(q, surah: int, ayah: int, idx: int) -> str:
    """U1.5 (#22, D1): the Uthmani text that names word idx in a list: the written word the page draws it in (is_joined,
    the page's grouping), i.e. its head word's Uthmani + every joined part's. A joined part has no Uthmani of its own
    in 367 places (يَٰبَنِىَّ + ""), its own in two (2:181 and 13:37: بَعْدَ + مَا = بَعْدَمَا; review of v0.12: the
    summaries named the part)."""
    words = q.ayah(surah, ayah).words
    k = idx
    while k > 0 and is_joined(surah, ayah, k):
        k -= 1
    m = k + 1
    while m < len(words) and is_joined(surah, ayah, m):
        m += 1
    return "".join(w.uthmani for w in words[k:m])


def _row_text(q, r: dict) -> str:
    """The text of a saved session row (summary.md, session_load): the written word that holds it (written_text) when
    it is a joined part (its saved uthmani is "" or, at 2:181 / 13:37, the part's own; also in sessions saved before
    v0.12: rows are never rewritten) or the head of one; else its uthmani."""
    try:
        s, a, i = r["surah"], r["ayah"], r["idx"]
        if not r.get("uthmani") or is_joined(s, a, i) or is_joined(s, a, i + 1):
            return written_text(q, s, a, i)
    except (KeyError, IndexError, TypeError, ValueError):
        pass
    return r.get("uthmani") or ""


MANUAL_LABEL = "manual labeled mistake"     # X2.12(a) (user, 2026-10-01)


def is_manual_mistake(r: dict) -> bool:
    """A session row whose mistake the user set (X2.12a): no "heard" text, what the model heard is not the reason."""
    return bool(r.get("user")) and r.get("status") in MISTAKE_STATUSES


def verdict_label(r: dict) -> str:
    """manual labeled mistake / wrong / skipped / hint / lost, as in the on-screen summary; #72 (v0.19, X2.12b): an
    insertion before the word, "extra word before" (the user's own: "manual labeled insertion")."""
    if is_manual_mistake(r):
        return "manual labeled insertion" if r.get("ins") else MANUAL_LABEL
    if r.get("ins") and r.get("status") == "wrong":
        return "extra word before"
    if r.get("lost"):
        return "lost"
    return {"wrong": "wrong", "missing": "skipped", "hinted": "hint"}.get(r["status"], r["status"])


def session_words(doc: dict, q) -> list:
    """The word list of a saved session, the one its rows' "i" index (Session.save, X2.1d): from passage{surah,
    ayah_from} to the end of surah_to. surah/ayah_from/ayah_to name the first surah reached only. Sessions saved
    before X2.1d (no passage / surah_to) are the passage they name."""
    p = doc.get("passage") or {"surah": doc["surah"], "ayah_from": doc["ayah_from"]}
    s_to = doc.get("surah_to", doc["surah"])
    if p["surah"] == doc["surah"] == s_to:
        return q.passage(doc["surah"], p["ayah_from"], doc["ayah_to"])
    words = q.passage(p["surah"], p["ayah_from"], q.n_ayat(p["surah"]))
    for s in range(p["surah"] + 1, s_to + 1):
        words += q.surah(s)
    return words


def summary_markdown(doc: dict, q) -> str:
    """summary.md of a saved session: the U1.5 enumeration of mistakes, then the table of flagged words."""
    started = dt.datetime.fromisoformat(doc["started_at"])
    summ, thr, rows = doc["summary"], doc["threshold"], doc["words"]
    s, s_to = doc["surah"], doc.get("surah_to", doc["surah"])
    if s_to != s:       # X2.1d: the rows run to the end of the last surah reached
        last = rows[-1]["ayah"] if rows else q.n_ayat(s_to)
        where = f"Surah {s} ({q.chapter_name(s)}) {doc['ayah_from']} – Surah {s_to} ({q.chapter_name(s_to)}) {last}"
    else:
        where = f"Surah {s} ({q.chapter_name(s)}), ayah {doc['ayah_from']}–{doc['ayah_to']}"
    lines = [f"# {APP_NAME} session {started.strftime('%Y-%m-%d %H:%M:%S')}",
             f"{where}, model {doc['model']}, mode {doc.get('mode')}, threshold {thr}",
             f"Duration {doc['duration_s']} s — accuracy {round(summ['accuracy'] * 100)} %, "
             f"{summ['n_mistakes']} mistakes in {summ['n_recited']} recited words, {len(summ['hinted'])} hints", ""]
    listed = [r for r in rows if r["status"] in MISTAKE_STATUSES and (r["score"] >= thr or r["user"])]
    lines.append(f"## Mistakes ({len(listed)})" if listed else "No mistakes detected.")
    for k, r in enumerate(listed, 1):       # a listed row set by the user is a manual labeled mistake: no heard
        lines.append(f"{k}. {_row_text(q, r)} — {r['surah']}:{r['ayah']} w{r['idx'] + 1} — {verdict_label(r)}"
                     + (f" — heard {r['heard']}" if r["heard"] and not is_manual_mistake(r) else ""))
    lines += ["", "## All flagged words",
              "| word | position | verdict | heard | suspicion | corrected by you |", "|---|---|---|---|---|---|"]
    for r in rows:
        if r["status"] in MISTAKE_STATUSES or r["user"]:
            manual = is_manual_mistake(r)
            lines.append(f"| {_row_text(q, r)} | {r['surah']}:{r['ayah']} w{r['idx'] + 1} | "
                         f"{MANUAL_LABEL if manual else r['status']} | {'—' if manual else r['heard'] or '—'} | "
                         f"{r['score']} | {'yes' if r['user'] else ''} |")
    return "\n".join(lines) + "\n"


def rows_summary(rows: list[dict], thr: float) -> dict:
    """Tracker.summary over a saved session's rows (session_load): the same counts at threshold thr."""
    mistakes = [r["i"] for r in rows if r["status"] in MISTAKE_STATUSES and (float(r["score"] or 0) >= thr or r.get("user"))]
    not_recited = sum(r["status"] == "pending" for r in rows)
    n_recited = len(rows) - not_recited
    return {"n_words": len(rows), "n_recited": n_recited, "n_mistakes": len(mistakes), "mistakes": mistakes,
            "hinted": [r["i"] for r in rows if r.get("hinted")], "not_recited": not_recited, "threshold": thr,
            "accuracy": round(1 - len(mistakes) / n_recited, 4) if n_recited else 0.0}


_LABEL_KEYS = ("auto", "via", "unshow", "prev", "prevH", "viaGap")   # ui_logic.js LABEL_KEYS: what a label adds (#72: viaGap)


def _plain(st: dict) -> dict:
    return {k: v for k, v in st.items() if k not in _LABEL_KEYS}


def state_after_mark(st: dict, event: str, ins: bool = False) -> dict:
    """ui_logic.js stateAfterMark in Python (X2.12 after Stop): + Mistake makes the word a mistake (wrong, 1), + Correct
    and Remove make it correct (ok, 0, not lost); a user verdict, never concealed. Issue #67: the verdict under the
    user's first label stays with the word (auto: the session's own state, never a pending one), and "unmark" gives it
    back (no auto: the user's own reading stays). #72 (v0.19, X2.12b): a mistake with ins is an insertion before the
    word (ins), any other mark clears it (a plain + Mistake is a mistake of the word itself); unmark gives Meddeb's
    nature back with its verdict."""
    base = st or {"status": "pending", "score": 0, "hyp": None}
    if event == "unmark":
        if not base.get("auto"):
            return _plain(base)
        out = {k: v for k, v in _plain(base).items() if k != "ins"}
        return {**out, "user": False, "concealed": False, **base["auto"]}
    auto = base.get("auto") if base.get("user") else (_plain(base) if base.get("status") not in (None, "pending") else None)
    out = _plain(base)
    out.pop("ins", None)
    if event == "mistake":
        out.update(status="wrong", score=1)
        if ins:
            out["ins"] = True
    else:
        out.update(status="ok", score=0, lost=False)
    out.update(user=True, concealed=False)
    if auto:
        out["auto"] = auto
    return out


def _when(t: str | None) -> dt.datetime | None:
    try:
        return dt.datetime.fromisoformat(str(t)).replace(tzinfo=None) if t else None
    except ValueError:
        return None


def apply_marks(words: list[dict], marks: list[dict], t_from: dt.datetime, t_to: dt.datetime | None,
                session: str | None = None) -> list[dict]:
    """A saved session's state words as the page drew them once it finished: the marks made on its words from its
    start (t_from) until the next session started (t_to, None: no next session; Start clears the page) applied in
    order (stateAfterMark); a mark undone by a double tap again counts for nothing (issue #24: effective_marks over the
    whole file, then the window). A mark that names a session ("session": an "unmark", issue #67; since the #67 / #69
    review any mark made while a saved session was on screen, Profile.add_mark) counts for that session alone
    (session: this one's started_at), whatever the window: the unmark of a session loaded with ◀ once a newer one
    exists is still its own. words carry surah / ayah / idx."""
    at = {(w["surah"], w["ayah"], w["idx"]): k for k, w in enumerate(words)}
    out = list(words)
    for m in effective_marks(marks):
        t = _when(m.get("t"))
        k = at.get((m.get("surah"), m.get("ayah"), m.get("idx")))
        if k is None or t is None:
            continue
        if m.get("session") is not None:
            if session is not None and m["session"] == session and t >= t_from:
                out[k] = state_after_mark(out[k], m["event"], m.get("ins") is True)
        elif m["event"] != "unmark" and t >= t_from and (t_to is None or t < t_to):
            out[k] = state_after_mark(out[k], m["event"], m.get("ins") is True)   # #72: + Inserted before
    return out


def _labelled_autos(doc: dict) -> dict[int, dict]:
    """Issue #67: per row index "i", the tracker's own state under the user's labels during a saved session (the page's
    `auto`, session_load), from its `corrections` log: the status (and, since v0.18, the score: from_score) before his
    first mark after his last unmark (Tracker.unmark puts the tracker's verdict back), a hint too when a mark of his
    since then removed it (unhint: the first one, the double tap, or a later one after + Correct; #67 review); none for
    a word read in silence (#49: his own reading, no verdict of the tracker's) or marked before the tracker reached it
    (pending). The score of an older log: 1 for a mistake status (it was one on screen), else 0. #72 (v0.19): ins when
    that verdict was an insertion (from_ins)."""
    first: dict = {}
    silent: set = set()
    unhinted: set = set()
    for c in doc.get("corrections") or ():
        if not isinstance(c, dict) or c.get("i") is None:
            continue
        if c.get("silent"):
            silent.add(c["i"])
        elif c.get("to") == "auto":
            first.pop(c["i"], None)
            unhinted.discard(c["i"])
        else:
            first.setdefault(c["i"], c)
            if c.get("unhint"):
                unhinted.add(c["i"])
    out = {}
    for i, c in first.items():
        status = c.get("from")
        if i in silent or status in (None, "pending"):
            continue
        score = c.get("from_score")
        if score is None:
            score = 1.0 if status in MISTAKE_STATUSES or str(status).startswith("provisional") else 0.0
        out[i] = {"status": status, "score": float(score), "hinted": status == "hinted" or i in unhinted}
        if c.get("from_ins") and status == "wrong":
            out[i]["ins"] = True
    return out


def _settled(status: str, score: float, thr: float) -> tuple[str, float]:
    """#67 review: a verdict being confirmed (taupe, provisional) as ■ settles it (Tracker._freeze, ui_logic.js
    settledState): a provisional wrong / skipped at or above the threshold stays that mistake, anything else under it
    is correct (score 0), as the history reads it; any other status as it is."""
    if not str(status).startswith("provisional"):
        return status, score
    if status in ("provisional_wrong", "provisional_missing") and score >= thr:
        return status[len("provisional_"):], score
    return "ok", 0.0


class _DirLock:
    """X2.9 (#45 review, 2026-10-27): an OS lock on unsaved/<id>/lock, held by the session recording into that folder
    (from its first write until its checkpoint goes) and by the recovery saving it. Another process on the same profile
    (a second PC server, the --ssl instance, a double launch: make_app recovers before the server binds its port) never
    takes over a session that is still recording: it used to save it as recovered and delete its checkpoint, and the
    session's own ■ then saved the same recitation again as "… (2)". msvcrt.locking on Windows, fcntl.flock elsewhere
    (Android's Python has it): both bind the lock to this open file, so a second open (another process, or another App
    in this one) cannot take it, and the system drops it when the process ends, however it ends."""

    def __init__(self, fd: int) -> None:
        self.fd: int | None = fd

    @classmethod
    def acquire(cls, path: Path) -> "_DirLock | None":
        """The lock, or None: held by another (or the file cannot be opened: never taken over either)."""
        try:
            fd = os.open(path, os.O_RDWR | os.O_CREAT | getattr(os, "O_BINARY", 0), 0o644)
        except OSError:
            return None
        try:
            if os.name == "nt":
                import msvcrt
                os.lseek(fd, 0, os.SEEK_SET)
                msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
            else:
                try:
                    import fcntl
                except ImportError:         # no file locks at all (a browser's file system; no checkpoints there)
                    return cls(fd)
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            os.close(fd)
            return None
        return cls(fd)

    def release(self) -> None:
        fd, self.fd = self.fd, None
        if fd is None:
            return
        try:
            if os.name == "nt":
                import msvcrt
                os.lseek(fd, 0, os.SEEK_SET)
                msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
        except OSError:
            pass
        finally:
            os.close(fd)                    # (closing it drops the lock anyway)

    def __del__(self) -> None:              # a session dropped without ■ lets go, as its process ending would
        try:
            self.release()
        except Exception:  # noqa: BLE001 - never from a finalizer
            pass


def _unlink(p: Path) -> None:
    try:
        if p.is_dir() and not p.is_symlink():
            shutil.rmtree(p, ignore_errors=True)
        else:
            p.unlink(missing_ok=True)
    except OSError:
        pass


def _remove_tree(d: Path, lock: _DirLock | None = None, tries: int = 5) -> bool:
    """A checkpoint folder removed (X2.9, #45): a few tries 50 ms apart, since Windows refuses to delete a file another
    process still holds a moment after it was written (the virus scanner reading it). #45 review: checkpoint.json goes
    last, once everything else is gone: a removal stopped half way (a file still held, a kill) leaves it, and it names
    the folder the session was saved into (■ and the recovery write that name first), so the next start finds that
    folder complete and only removes the rest; never a " (2)" twin out of checkpoint.prev.json, nor the audio kept for
    ever without its checkpoint. lock: the folder's lock (_DirLock), held until checkpoint.json is gone, then released
    (Windows deletes no open file), also when the folder stays. True: gone."""
    try:
        for k in range(tries):
            try:
                rest = [f for f in d.iterdir() if f.name not in (CHECKPOINT, CHECKPOINT_LOCK)]
            except OSError:
                rest = []                       # gone already (or not a folder: nothing of ours)
            for f in rest:
                _unlink(f)
            if not any(f.exists() or f.is_symlink() for f in rest):
                _unlink(d / CHECKPOINT)
                if not (d / CHECKPOINT).exists():
                    if lock is not None:
                        lock.release()
                    _unlink(d / CHECKPOINT_LOCK)
                    try:
                        d.rmdir()
                    except OSError:
                        pass
            if not d.exists():
                return True
            time.sleep(0.05 * (k + 1))
        return False
    finally:
        if lock is not None:
            lock.release()                  # the folder stays (its checkpoint.json naming the saved folder), unlocked


def _write_atomic(path: Path, data: bytes, keep_prev: str | None = None) -> None:
    """X2.9 (#45): path written whole or not at all: a temporary file, synced, renamed over it. keep_prev: the name
    the file it replaces is kept under (the checkpoint before)."""
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        try:
            os.fsync(f.fileno())
        except OSError:                     # a file system without it (an in-memory one): the rename still is atomic
            pass
    if keep_prev and path.exists():
        os.replace(path, path.with_name(keep_prev))
    os.replace(tmp, path)


def practice_words(rows: list[dict], mode: str | None, modes, corrections) -> set[int]:
    """#73 (v0.21, D5; user 2026-11-01: "Hidden : do not log ok but log mistakes … part of session is treated
    seperately"): the session indexes ("i") of the rows whose verdict came while the text mode in effect was Hidden
    (practice words: their correct readings count nowhere, Profile.counted). `mode`: the session's mode at its start;
    `modes`: the meta's [{mode, at, c}] in the order logged (at: session time; c: how many corrections were logged
    before it, since 0.21: a session with the microphone off or paused gives every act the same time). A heard row
    goes by its t0 (session time); a row the user set (a mark, a silent read: "user") by its last correction (by `c`,
    or by its time for an entry without it, a 0.20 checkpoint); a row with neither, by the last mode; pending rows never
    (no verdict)."""
    timeline = [x for x in (modes or ()) if isinstance(x, dict)]
    log = list(corrections or ())
    last: dict = {}
    for k, e in enumerate(log):
        if isinstance(e, dict) and "i" in e:
            last[e["i"]] = k

    def by_time(t: float) -> str | None:
        cur = mode
        for x in timeline:
            if float(x.get("at") or 0) <= t:
                cur = x.get("mode")
        return cur

    def by_correction(k: int) -> str | None:
        cur, t = mode, float(log[k].get("at") or 0)
        for x in timeline:
            if (x["c"] <= k) if isinstance(x.get("c"), int) else (float(x.get("at") or 0) <= t):
                cur = x.get("mode")
        return cur
    end = timeline[-1].get("mode") if timeline else mode
    out = set()
    for r in rows:
        if r.get("status", "pending") == "pending":
            continue
        i = r.get("i")
        if r.get("user") and i in last:
            m = by_correction(last[i])
        elif r.get("t0") is not None:
            m = by_time(float(r["t0"]))
        else:
            m = end
        if m == "hide":
            out.add(i)
    return out


def _touched(st) -> bool:
    """A word state whose row may differ from _plain_row's (a superset: _write_checkpoint's own test decides)."""
    return (st.status != "pending" or bool(st.score) or st.hyp is not None or st.hinted or st.lost or st.concealed
            or st.user_marked or st.t_start is not None or st.t_end is not None)


def _plain_row(i: int, w) -> dict:
    """A session.json row of a word the session never touched (pending, nothing heard): a checkpoint leaves these out
    (an Al-Baqarah session holds ~6000), the recovery writes them back (#45)."""
    return {"i": i, "surah": w.surah, "ayah": w.ayah, "idx": w.idx, "word": w.simple, "uthmani": w.uthmani,
            "status": "pending", "score": 0.0, "heard": None, "hinted": False, "lost": False, "concealed": False,
            "user": False, "t0": None, "t1": None}


def _decode_lines(decodes: list[dict], rules: list[dict]) -> list[dict]:
    """decodes.jsonl's lines (X2.9): every decode {t, hyp}, plus the words dropped by the voice / foreign rules {t, rule,
    ...} (B3.15, X2.16), each list in the order it came, in time order (a stable sort: at one time the decodes first).
    Session._doc for ■, and the recovery from a checkpoint's decodes.jsonl, where they were appended as they came."""
    return sorted(list(decodes) + list(rules), key=lambda x: x["t"])


def _read_decodes(path: Path) -> list[dict]:
    """A checkpoint's decodes.jsonl (#45 review) -> _decode_lines of it; a torn last line (killed while appending) is
    left out; no file: none."""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    raw = []
    for line in text.splitlines():
        try:
            x = json.loads(line)
        except ValueError:
            continue
        if isinstance(x, dict) and "t" in x:
            raw.append(x)
    return _decode_lines([x for x in raw if "rule" not in x], [x for x in raw if "rule" in x])


def _write_wav_blocks(dst: Path, blocks) -> None:
    """audio.wav from blocks of int16 samples, one block at a time (an hour is 115 MB): the bytes wav_bytes writes
    for the same audio (each sample through float32 / 32768, then × 32767 truncated, as v0.18 saved them)."""
    with wave.open(str(dst), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        for block in blocks:
            w.writeframes(_pcm16([np.asarray(block, dtype=np.int16).astype(np.float32) / 32768.0]))


def _pcm_blocks(pcm: Path):
    """A checkpoint's audio.pcm (whole samples) in 2 MB blocks."""
    with open(pcm, "rb") as f:
        while block := f.read(1 << 21):
            yield np.frombuffer(block[:len(block) // 2 * 2], dtype="<i2")


def _chunk_blocks(chunks: list[np.ndarray]):
    """A session's int16 chunks (0.1 s each) grouped into blocks of ~1 M samples (one by one is slow)."""
    group, n = [], 0
    for c in chunks:
        group.append(c)
        n += len(c)
        if n >= 1 << 20:
            yield np.concatenate(group)
            group, n = [], 0
    if group:
        yield np.concatenate(group)


def _write_wav_from_pcm(dst: Path, pcm: Path) -> None:
    """audio.wav from a checkpoint's audio.pcm (whole samples), block by block: the bytes wav_bytes writes for the same
    audio."""
    _write_wav_blocks(dst, _pcm_blocks(pcm))


def write_session_folder(profile: Profile, folder: Path, doc: dict, lines: list[dict],
                         audio: list[np.ndarray] | Path | None) -> Path:
    """X2.9: one session folder, the one writer of ■ (Session.save) and of a session recovered after a kill
    (App.recover_unsaved, #45): audio.wav (audio: the recording's int16 chunks, or a checkpoint's audio.pcm; None:
    none), decodes.jsonl, summary.md, then session.json last and atomically (a folder is a saved session, for the
    history and the browser, only once complete). #71 (v0.19, D9): audio.wav is written block by block either way,
    never built whole in memory (v0.18: 115 MB an hour in a BytesIO, then a copy)."""
    folder.mkdir(parents=True, exist_ok=True)
    if isinstance(audio, Path):
        _write_wav_from_pcm(folder / "audio.wav", audio)
    elif audio is not None:
        _write_wav_blocks(folder / "audio.wav", _chunk_blocks(audio))
    files = Session._files(doc, lines)
    for name in ("decodes.jsonl", "summary.md"):
        (folder / name).write_bytes(files[name])
    _write_atomic(folder / "session.json", files["session.json"])
    profile.session_saved()
    return folder


# v0.21 review (#73, D5): the most a mode{} message's `ago` moves its switch back (the page's settle is 1.5 s)
MODE_AGO_MAX_S = 3.0


class Session:
    """One live session (B3.8): audio in, verdicts out, saved into the profile when it ends."""

    def __init__(self, app: "App", words: list, backend, meta: dict, threshold: float,
                 voice_commands: bool = True, learned: Learned | None = None, client: str | None = None) -> None:
        self.app, self.words, self.backend, self.meta = app, list(words), backend, meta
        self.id = uuid.uuid4().hex[:10]
        self.created = time.time()
        # #59 (v0.18, D12): the start's `client` tag (Android's car: "car-3"), echoed in `started` and in session_attach,
        # so that a page loaded later tells the car's session from its own
        self.client = client
        alt = [(normalize(w.uthmani) or None) for w in words]
        starts = {i: w.surah for i, w in enumerate(self.words) if i > 0 and w.ayah == 1 and w.idx == 0}   # X2.1d
        # #111 / #62 (v0.23, D16): what the profile's labels teach (App.learned, at Start): the forms that travel by text
        # (X2.17's table), the places' rules by index (_learn_places)
        self.learned = learned if learned is not None else Learned()
        self.tracker = Tracker([w.norm for w in words], TrackerConfig(threshold=threshold, voice_commands=voice_commands),
                               expected_alt=alt, surah_starts=starts,
                               start_page_end=start_page_end(self.words),   # X2.1c: the start page
                               accepted=self.learned.text)                   # X2.17: forms the user accepted
        self._learn_places(0)
        self.n_initial = self.n_known = len(self.words)   # X2.1d: words in `started` / known by the client
        self.chunks: list[np.ndarray] = []  # #71 (v0.19, D9): the recording as int16 (v0.18: float32, twice the RAM)
        self.last_step_samples = 0
        self.folder: Path | None = None
        self.finished = False
        self.paused = False                 # #59 (v0.18): the last pause() with no audio since (session_attach says it)
        self.paused_at = 0.0                # v0.21 review 2: the session time of the last pause() (mode{ago} never before)
        self.save_failed = False            # U1.17: its save raised (e.g. a full phone): it no longer blocks a delete
        self.voice_out: list[dict] = []     # X2.15: fired commands not sent yet (one per state)
        self.voice_fired: list[dict] = []   # every command of the session (session.json)
        self.after_search: dict | None = None   # #20: {first, carry_s} when it goes on from a search (logs)
        # #36 (v0.16): a voice cue was given before the first word (a first «next», or a replay's; never the car's own
        # start cue): the next «next» reveals (_apply_voice). In session.json as the voice entry with words null + before
        self.voice_cue_given = False
        # #36 review: the words ◂ revealed before Start (start{revealed}, on screen and counted as hints, #17)
        self.revealed_before = {str(k) for k in meta.get("revealed") or ()}
        # U1.16 (2026-10-10, v0.9): the PC's POST /api/report names the session (folder_name) in a request thread
        # while a decode may run in the executor: step, command, pause, finish, save and folder_name hold this lock
        # (Android: one engine thread)
        self.lock = threading.RLock()
        # #45 (v0.17): what may have changed the verdicts (steps, commands), App._history_now's cache key
        self.changes = 0
        # X2.9 (#45): the checkpoint in unsaved/<id>/ (checkpoint()): chunks and bytes already in audio.pcm, the session
        # time of the last checkpoint.json (None: none yet), verdicts changed since
        self._pcm_chunks = self._pcm_bytes = 0
        self._ckpt_at: float | None = None
        self._dirty = False
        # #45 review (2026-10-27): decode / rule lines and bytes already in its decodes.jsonl; the folder's lock
        # (_DirLock, from the first write until the checkpoint goes); the kinds of write failing now (one log line each)
        self._dec_lines = self._rule_lines = self._dec_bytes = 0
        self._dir_lock: _DirLock | None = None
        self._failing: set[str] = set()
        # #67 (v0.18): the hints a double tap undid (mark{unhint}): unmark gives them back
        self.unhinted: set[int] = set()
        # v0.22 (plan D1): the group's last activity (the app's clock: a verdict heard, an act of the user's), idle_due's
        # start; the `done` messages of the groups its start closed (App.start: started.closed)
        self.last_act = app.clock()
        self.closed_before: list[dict] = []
        self._seen: dict[int, tuple] = {}   # v0.22: the verdict of each word the tracker changed (_heard_change)

    def started_message(self, known: int | None = None, closed: bool = True) -> dict:
        """B3.8 `started`; #36 (v0.15): + before, the cue of the session's first word (before_cue). #59 (v0.18): + client
        (the start's tag, when it had one) and review (the card's meta, B3.16, when it is a card's session). known: the
        index map and n_words over the first `known` words (session_attach: the words known now, X2.1d); by default the
        words the session started with. closed (v0.22 review): False for a resume or an attach, which never send the
        groups the start closed again (stale "Saved · N mistakes" toasts)."""
        m = self.meta
        n = self.n_initial if known is None else known
        out = {"type": "started", "n_words": n, "model": m["model"], "session": self.id,
               "index_map": self._index_map(0, n), "surah": m["surah"], "ayah_from": m["ayah_from"],
               "ayah_to": m["ayah_to"], "before": self.before_cue()}
        if self.client:
            out["client"] = self.client
        if m.get("review"):
            out["review"] = dict(m["review"])
        if closed and self.closed_before:   # v0.22 (D1): the groups this start closed ("Saved · N mistakes")
            out["closed"] = list(self.closed_before)
        return out

    def attach(self) -> dict:
        """#59 (v0.18, D12; user 2026-10-28: "since I got into recite mode in the car I expect that the phone will follow
        automatically"): App.session_attach's answer for this session, {started, state}: the `started` message with its
        index map and n_words over the words known now (n_known: the client that started it learned the later ones from
        `extended`), and the tracker's full state (delta false) over those words, as the page receives a `state`. Under
        the lock and without side effects: never state() (its _extend would move n_known, and the next step would no
        longer carry `extended` to the session's own client) nor a delta snapshot (it would empty the tracker's changed
        words: the next step's delta would miss them)."""
        with self.lock:
            if self.finished or self.save_failed:         # v0.18 review: finished since App picked it: none
                return None
            n = self.n_known
            snap = self.tracker.snapshot(delta=False)       # delta False: tracker.changed stays as it is
            snap["words"] = [w for w in snap["words"] if w["i"] < n]
            snap["type"] = "state"
            # v0.18 review: paused (the car left, its ❚❚): the page shows the microphone off, as the car's player is.
            # Page review 2026-10-29: any pause since the last audio, a clip's too (pause{for: clip}: Engine.kt calls
            # session_pause for every pause): a phone page that reloads during its own clip pause finds its microphone
            # off (no clip-end resume comes), so it counts; the car's cue and Yasser's clips end with the car's own
            # resume, so for the car's session the page follows the car's player instead (listen_state, source
            # 'recite': index.html attachCarSession)
            return {"started": self.started_message(known=n, closed=False), "state": snap, "paused": self.paused}

    def before_cue(self) -> dict:
        """#36: App.before_cue of the session's first word (tracker.first: the first ayah of the session, or the place
        Find where I am found, X2.13)."""
        w = self.words[min(self.tracker.first, len(self.words) - 1)]
        return self.app.before_cue(w.surah, w.ayah, w.idx)

    def audio(self) -> np.ndarray:
        """The whole recording as float32 (/ 32768; tests and tools: a replay reads audio_range)."""
        return np.concatenate(self.chunks).astype(np.float32) / 32768.0 if self.chunks else np.zeros(0, dtype=np.float32)

    def n_samples(self) -> int:
        return sum(len(c) for c in list(self.chunks))

    def audio_range(self, a: int, b: int) -> np.ndarray:
        """#71 (v0.19, D9, X2.18): samples [a, b) of the recording as float32 (/ 32768, the values the tracker heard),
        from the chunks that hold them only (v0.18 concatenated the whole session at every replay: 230 MB an hour)."""
        chunks = list(self.chunks)          # a snapshot: the PC's replay runs beside the session's own thread
        ends = np.cumsum([len(c) for c in chunks]) if chunks else np.zeros(0, dtype=np.int64)
        n = int(ends[-1]) if len(ends) else 0
        a, b = min(max(0, a), n), min(max(0, b), n)
        if b <= a:
            return np.zeros(0, dtype=np.float32)
        i = int(np.searchsorted(ends, a, side="right"))          # the chunk holding sample a
        j = int(np.searchsorted(ends, b, side="left"))           # the chunk holding sample b - 1
        lo = int(ends[i]) - len(chunks[i])
        x = np.concatenate(chunks[i:j + 1])[a - lo:b - lo]
        return x.astype(np.float32) / 32768.0

    def push_audio(self, pcm16: bytes) -> bool:
        """Int16 PCM at 16 kHz. True when a decode step is due (~0.8 s of new audio since the last one)."""
        raw = np.frombuffer(pcm16, dtype="<i2")
        pcm = raw.astype(np.float32) / 32768.0
        if self.paused:                     # v0.22 review (D1): the microphone on again is an act of the user's: the
            self.last_act = self.app.clock()   # idle tick never closes the group seconds after a resume
        self.paused = False                 # #59: audio again: listening
        self.chunks.append(raw)             # #71 (D9): kept as int16; the tracker gets the float32 it always had
        self.tracker.push_audio(pcm)
        return self.tracker.total_samples - self.last_step_samples >= STEP_SAMPLES

    def begin_at(self, first: int) -> None:
        """#73 (v0.19, D3): the session begins at word `first`: the tracker's first and committed word (the words before
        it are not recited, X2.1c; hint{} without i reveals `first`, Tracker.next_hidden). App.start's `at` (the silent
        session ◂ / ⏮ start in Blind) and go_on_after_search."""
        with self.lock:
            self.tracker.first = self.tracker.committed = first
            self.changes += 1

    def is_car(self) -> bool:
        """#73 (v0.19, D4): the car's session (Android's start tag `car-N`, ReciteProgress.startMessage)."""
        return bool(re.fullmatch(r"car-\d+", self.client or ""))

    def practice(self) -> bool:
        """#73 (v0.19, D4; user 2026-10-29: "hidden mode … nor does it count the page even if recited"): a practice
        session = in Hidden at its start or at any moment while open (the meta's `modes`, mode{}); never the car's (it
        starts in Hidden, no screen to read). #73 (v0.21, D5): practice is per word since (practice_words, the rows'
        "practice" in _doc): this only says the session went into Hidden (the switch's own checkpoint, command)."""
        if self.is_car():
            return False
        return self.meta.get("mode") == "hide" or any(m.get("mode") == "hide" for m in self.meta.get("modes") or ())

    def go_on_after_search(self, first: int, carry: np.ndarray) -> None:
        """#20 (X2.13): the session goes on from a search (App._go_on_after_search): the reciter is at word `first` (#94:
        the found place's first heard word, found.start; found.next for a 0.20 client; the words before it are not
        recited, X2.1c) and `carry` is the audio heard from that word on (it opens the session's audio, so the saved
        recording and the word times include it)."""
        with self.lock:
            self.begin_at(first)
            self.after_search = {"first": first, "carry_s": round(len(carry) / SR, 2)}
            self.push_audio((np.clip(carry, -1.0, 32767 / 32768) * 32768).round().astype("<i2").tobytes())
            self.changes += 1

    def _index_map(self, lo: int, hi: int) -> list[dict]:
        return [{"surah": w.surah, "ayah": w.ayah, "start": i} for i, w in enumerate(self.words[lo:hi], lo) if w.idx == 0]

    def _extend(self) -> None:
        """X2.1d: once the reciter is within expect_window + 20 words of the passage end, append the next surah(s): the
        session follows into them. Never for an explicit ayah range, before anything was heard, after Stop or past
        An-Nas."""
        tr = self.tracker
        if not self.meta.get("continues") or tr.stopped or not tr.started:
            return
        n0 = len(self.words)
        while self.words[-1].surah < 114 and \
                max(tr.committed, tr.cursor + 1) >= len(self.words) - (tr.config.expect_window + 20):
            s = self.words[-1].surah + 1
            new = load_quran().surah(s)
            self.words.extend(new)
            tr.extend([w.norm for w in new], [(normalize(w.uthmani) or None) for w in new], surah=s)
        self._learn_places(n0)

    def _learn_places(self, start: int) -> None:
        """#111 / #62 (v0.23, D16): the place rules of the profile's labels (Learned, keyed by word) on the passage's
        words from `start` on, by the tracker's index: the forms accepted there, the known false-alarm places, the watch
        list (X2.1d: again for the surahs appended)."""
        lt, tr = self.learned, self.tracker
        if not (lt.at or lt.priors or lt.watch):
            return
        for i in range(start, len(self.words)):
            key = self.words[i].key
            if key in lt.at:
                tr.learned[i] = lt.at[key]
            if key in lt.priors:
                tr.priors.add(i)
            if key in lt.watch:
                tr.watch[i] = lt.watch[key]

    def reached(self, tr: Tracker | None = None) -> tuple[int, int]:
        """X2.1d: [lo, hi) of the words of the surahs the reciter reached, from the surah of the actual start (X2.1c)
        to the end of the last surah holding a verdict (the start surah when nothing was heard); the passage's other
        surahs are not part of the session (not "not recited"). tr: another tracker of these words (#45: a frozen
        copy, preview_doc); the session's own by default."""
        tr, ws = (self.tracker if tr is None else tr), self.words
        touched = [i for i, st in enumerate(tr.states) if st.status != "pending"]
        a, b = min(touched + [tr.first]), max(touched, default=tr.first)
        lo = next(i for i, w in enumerate(ws) if w.surah == ws[a].surah)
        hi = max(i for i, w in enumerate(ws) if w.surah == ws[b].surah) + 1
        return lo, hi

    def step(self, final: bool = False) -> dict:
        """One decode; a voice command fired in it is applied (next / eyah) and its `voice` goes into this state
        (B3.8; one per state: a second one fired in the same decode goes into the next state, none after Stop)."""
        with self.lock:
            t0 = time.perf_counter()
            self._extend()
            self.tracker.step(self.backend, final)
            self.last_step_samples = self.tracker.total_samples
            self._apply_voice()
            self.changes += 1
            self._dirty = self._dirty or bool(self.tracker.changed)    # before state() hands the changes out
            if self._heard_change():
                self.last_act = self.app.clock()                        # v0.22 (D1): a verdict heard: activity
            if final:
                self.voice_out.clear()
            extra = {"voice": self.voice_out.pop(0)} if self.voice_out else {}
            out = self.state(latency_s=round(time.perf_counter() - t0, 2), **extra)
            self._autosave(final)
            return out

    # ---- the checkpoint (X2.9, #45 v0.17): a session the app could not stop (a crash, a kill) ends like ■
    def is_a_session(self) -> bool:
        """X2.9: ■ saves it: 1 s of audio, or a verdict of the user's on a word (v0.17, #49: a card read in silence
        after a microphone stopped within its first second; a + Mistake / + Correct). The preview, the checkpoint and
        the recovery follow the same rule."""
        return self.tracker.total_samples >= SR or any(st.user_marked for st in self.tracker.states)

    def unsaved_dir(self) -> Path:
        """<profile>/unsaved/<session id>/: audio.pcm, decodes.jsonl, checkpoint.json, checkpoint.prev.json, lock
        (App.recover_unsaved)."""
        return self.app.profile.unsaved_dir / self.id

    def _autosave(self, final: bool) -> None:
        """After a step: audio.pcm and decodes.jsonl get what is new; checkpoint.json once the session has 1 s of audio,
        then at most every CHECKPOINT_S of session time while verdicts change (■'s final step: save() writes it)."""
        try:
            self._flush()
            self._failing.discard("audio")
        except OSError as e:
            self._write_failed("audio", e)
        # v0.17 review: a checkpoint costs about its rows (Al-Baqarah recited whole: ~80 ms on the PC, several times that
        # on a phone, on the engine thread): its interval grows with the passage recited (the audio still goes at once)
        every = max(CHECKPOINT_S, max(0, self.tracker.cursor - self.tracker.first) / CHECKPOINT_WORDS_PER_S)
        if not final and (self._ckpt_at is None or
                          (self._dirty and self.tracker.session_time - self._ckpt_at >= every)):
            self.checkpoint()

    def _write_failed(self, what: str, e: OSError) -> None:
        """#45 review (2026-10-27): a checkpoint write refused (a full phone refuses one at every step): one log line per
        kind ("audio", "checkpoint") until a write of that kind succeeds again; App._log never raises (Android's file
        logger does on a full phone: it used to stop the engine thread from inside these handlers)."""
        if what not in self._failing:
            self._failing.add(what)
            self.app._log(f"checkpoint {self.id}: {'audio not written' if what == 'audio' else 'not written'} ({e})")

    def _hold(self) -> Path:
        """unsaved/<id>/, created, its lock held from the session's first write on (_DirLock; until _drop_checkpoint).
        OSError when the lock cannot be taken (a recovery in another app holds it a moment: the write waits for the next
        step)."""
        d = self.unsaved_dir()
        if self._dir_lock is None or self._dir_lock.fd is None or not d.is_dir():
            if self._dir_lock is not None:
                self._dir_lock.release()        # the folder went (Settings > Space used after a failed save): anew
            d.mkdir(parents=True, exist_ok=True)
            self._dir_lock = _DirLock.acquire(d / CHECKPOINT_LOCK)
            if self._dir_lock is None:
                raise OSError(f"{d / CHECKPOINT_LOCK}: held by another app")
        return d

    def _flush(self) -> None:
        """Once it is a session (is_a_session: 1 s of audio, or a verdict of the user's), unsaved/<id>/ gets what it does
        not hold yet: audio.pcm the chunks (16 kHz int16), decodes.jsonl the new decode lines, then the new rule lines
        (the tracker's decode_log and voice_log only ever grow; _read_decodes orders them as ■ does). #45 review: they
        used to be rewritten whole into checkpoint.json at every checkpoint (an Al-Baqarah session: a multi-MB file every
        5 s). A file that is not what was written (a write that failed half way, the file deleted) is written again whole."""
        if not self.app.checkpoints or self.finished or not self.is_a_session():
            return                                  # finished: saved, its checkpoint gone (late frames add none)
        tr = self.tracker
        if self._pcm_chunks >= len(self.chunks) and self._dec_lines >= len(tr.decode_log) \
                and self._rule_lines >= len(tr.voice_log):
            return                                  # nothing new
        d = self._hold()
        if self._pcm_chunks < len(self.chunks):
            with open(d / CHECKPOINT_PCM, "ab") as f:
                if f.tell() != self._pcm_bytes:     # a write that failed half way, or the file deleted: again whole
                    f.truncate(0)
                    self._pcm_chunks = self._pcm_bytes = 0
                new = self.chunks[self._pcm_chunks:]
                data = b"".join(c.astype("<i2").tobytes() for c in new)    # push_audio's int16 (#71: kept as such)
                f.write(data)
            self._pcm_chunks += len(new)
            self._pcm_bytes += len(data)
        if self._dec_lines < len(tr.decode_log) or self._rule_lines < len(tr.voice_log):
            with open(d / CHECKPOINT_DECODES, "ab") as f:
                if f.tell() != self._dec_bytes:
                    f.truncate(0)
                    self._dec_lines = self._rule_lines = self._dec_bytes = 0
                dec, rules = tr.decode_log[self._dec_lines:], tr.voice_log[self._rule_lines:]
                data = "".join(json.dumps(x, ensure_ascii=False) + "\n"
                               for x in [{"t": t, "hyp": h} for t, h in dec] + list(rules)).encode("utf-8")
                f.write(data)
            self._dec_lines += len(dec)
            self._rule_lines += len(rules)
            self._dec_bytes += len(data)

    def _complete_pcm(self) -> Path | None:
        """#71 (D9): unsaved/<id>/audio.pcm when it holds the whole recording (every chunk flushed, the file's size what
        was written), else None."""
        p = self.unsaved_dir() / CHECKPOINT_PCM
        try:
            whole = self._pcm_chunks == len(self.chunks) and p.stat().st_size == self._pcm_bytes \
                == 2 * sum(len(c) for c in self.chunks)
        except OSError:
            return None
        return p if whole and self._pcm_bytes else None

    def checkpoint(self) -> bool:
        """X2.9 (#45, v0.17; user 2026-10-26: "the app crashes, or gets closed (terminated) … should not lead to a
        different result than like a classical button stop"): unsaved/<id>/ now: audio.pcm and decodes.jsonl get what is
        new (_flush), checkpoint.json = {format, session, saved_at, samples, span: [lo, hi) of the rows, doc:
        session.json as ■ would save it now (preview_doc's frozen rows; the rows of words never touched left out)},
        written atomically, the one before kept as checkpoint.prev.json. Called after steps (_autosave), at ❚❚, after
        hint / skip_to / mark / unmark, after a mode{} that makes it practice (review of 0.19), and by the platform when
        the app goes to the background (App.checkpoint). False: nothing written (no session yet: under 1 s of audio and
        no verdict of the user's, saved already, or the disk refused: the session goes on and ■ saves it as ever)."""
        with self.lock:
            if not self.app.checkpoints or self.finished or not self.is_a_session():
                return False
            try:
                self._flush()
                self._write_checkpoint(self._doc(self.tracker.frozen_copy(), lines=False, touched=True)[0])
            except OSError as e:
                self._write_failed("checkpoint", e)
                return False
            self._failing.clear()
            self._ckpt_at, self._dirty = self.tracker.session_time, False
            return True

    def _write_checkpoint(self, doc: dict, folder: str | None = None) -> None:
        """checkpoint.json of doc (+ folder: the session folder ■ is writing, save())."""
        rows = doc["words"]
        body = {"format": CHECKPOINT_FORMAT, "session": self.id, "saved_at": self.app.clock().isoformat(),
                "samples": self.tracker.total_samples, "span": [rows[0]["i"], rows[-1]["i"] + 1],
                "doc": {**doc, "words": [r for r in rows if r["status"] != "pending"
                                         or r != _plain_row(r["i"], self.words[r["i"]])]}}
        if folder is not None:
            body["folder"] = folder
        d = self._hold()
        _write_atomic(d / CHECKPOINT, json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                      keep_prev=CHECKPOINT_PREV)

    def _drop_checkpoint(self) -> None:
        """unsaved/<id>/ goes (checkpoint.json last, _remove_tree), then the lock."""
        lock, self._dir_lock = self._dir_lock, None
        _remove_tree(self.unsaved_dir(), lock)
        try:
            self.app.profile.unsaved_dir.rmdir()        # only when empty
        except OSError:
            pass

    def _ayah_bounds(self, i: int) -> tuple[int, int]:
        """First and last session word index of the ayah of word i."""
        key = (self.words[i].surah, self.words[i].ayah)
        a, b = i, i
        while a > 0 and (self.words[a - 1].surah, self.words[a - 1].ayah) == key:
            a -= 1
        while b + 1 < len(self.words) and (self.words[b + 1].surah, self.words[b + 1].ayah) == key:
            b += 1
        return a, b

    def _hint_written(self, i: int, keep_from: float | None = None, silent: bool = False) -> int:
        """◂ / the voice «الكلمة التالية» on word i (X2.4, U1.1e, #22): tracker.hint(i), then the following parts of
        its written word (يَٰبَنِىَّ = يا + بني) that were not heard yet: pending, or a mistake not said (concealed, or a
        final wrong / skipped verdict that is neither the user's nor hinted). A part already heard, also provisionally,
        is never hinted (tracker.hint would turn a correct word into a hint). Returns the last index revealed. silent
        (#49): the same parts, each one hint(silent): the user's correct reading."""
        tr = self.tracker
        tr.hint(i, keep_from=keep_from, silent=silent)
        j = i
        while j + 1 < len(tr.states) and is_joined(self.words[j + 1].surah, self.words[j + 1].ayah, self.words[j + 1].idx):
            st = tr.states[j + 1]
            unsaid = not (st.user_marked or st.said or st.hinted) and \
                (st.concealed or (st.final and st.status in ("wrong", "missing")))
            if st.status != "pending" and not unsaid:
                break
            j += 1
            tr.hint(j, keep_from=keep_from, silent=silent)
        return j

    def _shown_before_start(self, i: int | None) -> bool:
        """#36 review: word i was revealed with ◂ before Start (start{revealed}): it is on screen."""
        return i is not None and 0 <= i < len(self.words) and self.words[i].key in self.revealed_before

    def _apply_voice(self) -> None:
        """X2.15: the commands the tracker fired in the last decode -> voice_out (B3.8 `voice`, with `words`). The engine
        applies next / eyah itself, as ◂ / ⏮ on the word ◂ would reveal (hint / skip_to to the end of its ayah), after
        settling the words heard before the command and keeping the audio after it: words = the revealed ones (Yasser
        plays them). replay: the cursor's ayah from its first word to the cursor; nothing recited yet from the session's
        first word: words None and `before` = the cue of that first word (#36, before_cue). #36 (v0.16): before the
        first word (not after Find where I am) the first next is such a cue too, unless a cue was given already
        (voice_cue_given: a replay's counts); the second next reveals. #36 review: a first word revealed with ◂ before
        Start (revealed_before) is on screen: next reveals at once, the word after those. stop / pause are the client's
        (words None)."""
        tr = self.tracker
        fired, tr.voice = tr.voice, []
        for v in fired:
            words, cue = None, False
            before_first = tr.cursor < tr.first             # nothing recited yet from the session's first word
            if v["name"] == "next" and before_first and self.after_search is None and not self.voice_cue_given \
                    and not self._shown_before_start(tr.first):
                # #36 (v0.16; user, 2026-10-25: "since I didn't start yet, it is better to start with a line hint rather
                # than showing a word and counting it as a mistake … I directly say kalima, you read the hint. Then I say
                # kalima again, you read and show the next word and count it as mistake"): the first «next» before the
                # first word plays the cue, as replay: nothing revealed, nothing counted, the tracker unchanged. After
                # Find where I am the reciter has recited and the next word is known: it reveals (X2.13)
                cue = True
            elif v["name"] in ("next", "eyah"):
                tr.settle_before(v["t0"])
                i = tr.next_hidden()
                while v["name"] == "next" and self._shown_before_start(i) and tr.states[i].status == "pending":
                    # #36 review: a word ◂ revealed before Start is on screen already: a hint now (as ◂ in the session
                    # would have made it), and «next» reveals the word after it, never the one on screen again
                    tr.hint(i, keep_from=v["t1"])
                    i = tr.next_hidden()
                if i is not None and v["name"] == "next":
                    words = [i, self._hint_written(i, keep_from=v["t1"])]   # U1.1e: the whole written word
                elif i is not None:
                    last = self._ayah_bounds(i)[1]
                    tr.skip_to(last + 1, keep_from=v["t1"])
                    words = [i, last]
            elif v["name"] == "replay" and not before_first:
                words = [self._ayah_bounds(tr.cursor)[0], tr.cursor]
            out = {**v, "words": words}
            if cue or (v["name"] == "replay" and words is None):
                # #36 (user, 2026-10-23): «عاودها» before anything is recited plays what comes before the first word;
                # v0.16: so does the first «next» (B3.8: words null + before = a cue, whatever the name)
                out["before"] = self.before_cue()
                self.voice_cue_given = True                 # v0.16: "the second voice call" reveals
            self.voice_out.append(out)
            self.voice_fired.append({**out, "at": round(tr.session_time, 2)})

    def state(self, full: bool = False, **extra) -> dict:
        """The tracker's snapshot as a `state` message; the first one after the passage grew (X2.1d) carries
        extended{index_map (the new ayat), n_words}, before any of the new words can be in a state."""
        self._extend()
        snap = self.tracker.snapshot(delta=not full)
        snap["type"] = "state"
        if len(self.words) > self.n_known:
            snap["extended"] = {"index_map": self._index_map(self.n_known, len(self.words)), "n_words": len(self.words)}
            self.n_known = len(self.words)
        snap.update(extra)
        return snap

    def summary(self) -> dict:
        """tracker.summary() over the surahs reached + the Uthmani text of the listed mistakes (the client may be on
        another page)."""
        lo, hi = self.reached()
        s = self.tracker.summary(lo=lo, hi=hi)
        q = load_quran()      # U1.5 (#22): a joined word is named by its written word
        s["words"] = {str(i): written_text(q, self.words[i].surah, self.words[i].ayah, self.words[i].idx)
                      for i in s["mistakes"]}
        return s

    def command(self, msg: dict) -> dict | None:
        """hint / skip_to / mark / unmark / threshold / summary / mode (#73) -> the state message to send (None: nothing
        to send; mode{} never replies).
        The reply carries reply_to = the command type (B3.8, 2026-10-01): the page turns only for new recitation
        (X2.12b). hint / skip_to without i (X2.4b, 2026-10-09): the next word not heard yet after the cursor (the word a
        voice «الكلمة التالية» reveals) / the rest of its ayah; the reply carries revealed = [i_from, i_to] (None:
        nothing left in the passage), so the page shows them whatever page it was on. hint{i} (D1, 2026-10-10: ◂ on the
        page's earliest bar) replies revealed = [i, i] too. summary{} (D11, 2026-10-10: the long press on ✗ n) only
        replies with the live summary. U1.1e (v0.12, #22): a hint also reveals the joined part of its written word that
        was not heard yet, and revealed = [i, j] spans both (_hint_written)."""
        with self.lock:
            was = self.practice()
            out = self._command(msg)
            kind = msg.get("type")
            if kind not in ("summary", "mode"):
                self.last_act = self.app.clock()    # v0.22 (D1): an act of the user's (hint, mark, ...) is activity
            if kind != "summary":
                self.changes += 1                   # #45: App._history_now's cache key
            if kind in ("hint", "skip_to", "mark", "unmark"):
                self.checkpoint()                   # X2.9 (#45): the user's own acts are never lost
            elif kind in ("threshold", "mode"):     # #73: mode{} is no user act: the next checkpoint carries it
                self._dirty = True
                if kind == "mode" and not was and self.practice():
                    # review of 0.19 (C9): the first switch into Hidden is checkpointed at once (a paused session takes
                    # no step: killed before its resume, its words judged in Hidden were recovered as not practice)
                    self.checkpoint()
            return out

    def _command(self, msg: dict) -> dict | None:
        """command() under the lock. #49 (v0.17): hint{silent: true} / skip_to{silent: true} (◂ / ⏮ while the
        microphone is off in a Review card's session, the user reciting in his mind) reveal the same words with the same
        reply, each one the user's correct reading (Tracker.hint / skip_to silent); `corrections` logs them
        ({i, from, to: 'ok', silent: true, at})."""
        kind, tr = msg.get("type"), self.tracker
        if kind == "summary":
            return self.state(summary=self.summary(), reply_to=kind)
        if kind in ("hint", "skip_to"):
            silent = bool(msg.get("silent"))
            before = [(st.status, st.user_marked) for st in tr.states] if silent else []
            reply: dict = {}
            if msg.get("i") is None:
                i = tr.next_hidden()
                if i is None:
                    reply["revealed"] = None
                elif kind == "hint":
                    reply["revealed"] = [i, self._hint_written(i, silent=silent)]
                else:
                    last = self._ayah_bounds(i)[1]
                    tr.skip_to(last + 1, silent=silent)
                    reply["revealed"] = [i, last]
            elif kind == "hint":
                i = int(msg["i"])
                # out of range: nothing to reveal
                reply["revealed"] = [i, self._hint_written(i, silent=silent)] if 0 <= i < len(tr.states) else None
            else:
                tr.skip_to(int(msg["i"]), silent=silent)
            for k, ((was, marked), st) in enumerate(zip(before, tr.states)):
                if st.user_marked and not marked:       # #49: read in silence
                    self.meta["corrections"].append({"i": k, "from": was, "to": st.status, "silent": True,
                                                     "at": round(tr.session_time, 2)})
            return self.state(reply_to=kind, **reply)
        if kind in ("mark", "unmark"):
            i = int(msg["i"])
            if not 0 <= i < len(tr.states):
                return None
            st = tr.states[i]
            before, before_score, before_ins = st.status, round(st.score, 3), st.ins
            entry = {"i": i, "from": before}
            if kind == "mark":
                # #72 (v0.19, X2.12b): ins = an insertion before the word (+ Inserted before, a double tap between two
                # words); the log keeps Meddeb's own insertion under the label (from_ins) for an unmark after ■
                tr.mark(i, str(msg.get("status", "ok")), ins=bool(msg.get("ins")))
                entry["from_score"] = before_score   # #67 / #69: the verdict's score before the mark (the threshold's)
                if before_ins:
                    entry["from_ins"] = True
                if st.ins:
                    entry["ins"] = True
                # #67 (user, 2026-10-29: "S11* --> double clic go to S10* that undo the hint labeling"): the double tap
                # on a hint also undoes the hint (no longer counted: the summary's hints, the row, the history);
                # unmark gives it back. + Correct in the popover leaves the hint
                if msg.get("unhint") and st.hinted:
                    st.hinted = False
                    self.unhinted.add(i)
                    entry["unhint"] = True
            else:
                if i in self.unhinted:               # #67: the hint first, so that unmark leaves the word revealed
                    st.hinted = True
                    self.unhinted.discard(i)
                tr.unmark(i)
            entry.update({"to": st.status if kind == "mark" else "auto", "at": round(tr.session_time, 2)})
            self.meta["corrections"].append(entry)
            return self.state(summary=self.summary(), reply_to=kind)
        if kind == "threshold":
            tr.set_threshold(float(msg["value"]))
            return self.state(summary=self.summary(), reply_to=kind)
        if kind == "mode":
            # #73 (v0.19, D4): the page's text mode changed while this session is open; no reply. v0.21 (D5): the
            # words judged in Hidden are practice (practice_words); c = the corrections logged before it (the acts of a
            # session with the microphone off or paused all come at the same session time)
            # v0.21 review: `ago` = seconds since the press (the H key's mode is sent once it settled, 1.5 s later):
            # the switch goes at the press (capped at MODE_AGO_MAX_S, never before the previous switch nor 0). v0.21
            # review 2: ago is wall time, the session time stands still while paused: never before the last pause
            if msg.get("mode") in ("show", "hide", "blind"):
                modes = self.meta.setdefault("modes", [])
                try:
                    ago = min(max(0.0, float(msg.get("ago") or 0)), MODE_AGO_MAX_S)
                except (TypeError, ValueError):
                    ago = 0.0
                at = max(tr.session_time - ago, self.paused_at, modes[-1]["at"] if modes else 0.0, 0.0)
                modes.append({"mode": msg["mode"], "at": round(at, 2), "c": len(self.meta.get("corrections") or ())})
            return None
        return None

    def pause(self) -> list[dict]:
        """X2.1b: finish what was heard (not final: words without enough evidence stay provisional). B3.15: the client
        pauses the microphone for ❚❚ and while Yasser plays a voice command's words (X2.14), so the reciter has seen
        the app react: the same command said after the pause is a new one, not the command said twice (REPEAT_S)."""
        with self.lock:
            st = self.step()
            st["paused"] = True
            self.paused = True                      # #59: session_attach says it
            self.paused_at = self.tracker.session_time   # v0.21 review 2: mode{ago} never goes back over it
            self.tracker.last_fired.clear()
            self.checkpoint()                       # X2.9 (#45): killed while paused, it ends as ❚❚ then ■
            return [st, {"type": "paused"}]

    def finish(self) -> dict:
        """Save into the profile (X2.9) once and return the `done` message; call it after the final step. done.nav (D11,
        2026-10-10): the saved sessions around this one (Profile.session_nav; not saved: older = the newest)."""
        with self.lock:
            if not self.finished:
                try:
                    self.folder = self.save()
                except Exception:
                    self.save_failed = True     # a full disk must not lock Settings > Space used (U1.17)
                    raise
                self.finished = True
            s = self.summary()
            folder = self.folder.name if self.folder else None
            s.update(type="done", session=self.id, folder=folder, nav=self.app.profile.session_nav(folder))
            return s

    def stop(self, ended_by: str | None = None) -> list[dict]:
        """For synchronous transports (Android): final decode + save -> [state, done]. ended_by (v0.22, D1): why it
        ended, in session.json ("stop" by default: stop{}; "exit": the app left; "car": the car's leave)."""
        with self.lock:
            self.meta.setdefault("ended_by", ended_by if ended_by in ENDED_BY else "stop")
            return [self.step(final=True), self.finish()]

    def _heard_change(self) -> bool:
        """v0.22 (D1): the last decode changed a verdict (a word's status: heard, not a score refreshed in silence)."""
        out = False
        for i in self.tracker.changed:
            st = self.tracker.states[i]
            v = (st.status, st.hinted, st.user_marked)
            if self._seen.get(i) != v:
                self._seen[i] = v
                out = out or st.status != "pending"
        return out

    def idle_due(self, now: dt.datetime | None = None) -> bool:
        """v0.22 (#101 P1, plan D1): the group is open and nothing happened in it for GROUP_GAP_S (no verdict heard, no
        act of the user's), paused or with the microphone on in silence."""
        now = self.app.clock() if now is None else now
        return not self.finished and not self.save_failed and (now - self.last_act).total_seconds() >= GROUP_GAP_S

    def close(self, ended_by: str) -> list[dict]:
        """v0.22 (plan D1): the engine closes the group (stop's final decode and save) -> [state, done{auto: true,
        ended_by, mic_off}] (mic_off: the microphone was on: the client turns it off); [] when already finished."""
        with self.lock:
            if self.finished:
                return []
            mic_on = not self.paused
            self.meta["ended_by"] = ended_by
            st, done = self.stop(ended_by)
            done.update(auto=True, ended_by=ended_by, mic_off=mic_on)
            return [st, done]

    def preview_doc(self) -> dict | None:
        """#45 (v0.17): session.json as ■ would save it if pressed now, nothing saved: the rows of a frozen copy of the
        tracker (Tracker.frozen_copy: a provisional verdict final, as Stop's _freeze makes it; the last 1-2 s not
        decoded yet are the one difference with ■'s final decode). None while it is no session (is_a_session: under
        1 s of audio and no verdict of the user's; save() saves nothing)."""
        with self.lock:
            if not self.is_a_session():
                return None
            return self._doc(self.tracker.frozen_copy())[0]

    def _doc(self, tr: Tracker | None = None, lines: bool = True, touched: bool = False) -> tuple[dict, list[dict]]:
        """session.json and decodes.jsonl of what was heard so far (save); tr: a frozen copy of the tracker (#45,
        preview_doc), the session's own by default; lines False: no decodes.jsonl lines (the checkpoint appends them);
        touched (the checkpoint, v0.17 review): only the rows of words the session touched, plus the range's first and
        last rows (its span), since the checkpoint leaves the others out anyway (an Al-Baqarah session holds ~6000)."""
        tr, m = (self.tracker if tr is None else tr), self.meta
        # X2.1d: rows, summary and history cover the surahs reached (row "i" stays the session word index: the one of
        # the client and of `corrections`; `passage` says where index 0 is)
        lo, hi = self.reached(tr)
        w0, w1 = self.words[lo], self.words[hi - 1]
        rows = [{"i": i, "surah": w.surah, "ayah": w.ayah, "idx": w.idx, "word": w.simple, "uthmani": w.uthmani,
                 "status": st.status, "score": round(st.score, 3), "heard": st.hyp, "hinted": st.hinted, "lost": st.lost,
                 "concealed": st.concealed,         # D7 (2026-10-10): a lost word still a bar (session cut off)
                 "user": st.user_marked, "t0": st.t_start, "t1": st.t_end,
                 **({"ins": True, "w0": st.w0} if st.ins else {})}   # #72 (v0.19): an insertion before it (optional)
                for i, w, st in zip(range(lo, hi), self.words[lo:hi], tr.states[lo:hi])
                if not touched or i in (lo, hi - 1) or _touched(st)]
        ayah_to = m["ayah_to"] if w0.surah == m["surah"] else load_quran().n_ayat(w0.surah)
        doc = {"app": APP_NAME, "model": m["model"], "mode": m.get("mode"), "started_at": m["started"].isoformat(),
               "ended_at": self.app.clock().isoformat(), "surah": w0.surah, "ayah_from": w0.ayah,
               "ayah_to": ayah_to, "surah_to": w1.surah, "passage": {"surah": m["surah"], "ayah_from": m["ayah_from"]},
               "threshold": tr.config.threshold, "duration_s": round(tr.session_time, 2),
               "summary": tr.summary(lo=lo, hi=hi), "words": rows, "corrections": m.get("corrections", []),
               "revealed_before_start": m.get("revealed", []),
               "voice_commands": tr.config.voice_commands, "voice": self.voice_fired}       # X2.15
        if m.get("review"):                     # B3.16 (#39): a review card's session says which card it was
            doc["review"] = m["review"]
        if m.get("ended_by"):                   # v0.22 (D1): why the group closed (readers ignore it)
            doc["ended_by"] = m["ended_by"]
        # #73 (v0.19, D4): the text-mode changes, a practice session (Hidden: its correct readings do not count,
        # Profile.counted), the car's session (never practice; its start tag car-N). v0.21 (D5): practice per word:
        # the rows judged in Hidden carry "practice" (practice_words), "practice_rows" says so to the readers (a doc
        # with "practice" and no row flags is a 0.19/0.20 one: the whole session); "practice" stays for the 0.20 ones
        if m.get("modes"):
            doc["modes"] = list(m["modes"])
        prac = set() if self.is_car() else practice_words(rows, m.get("mode"), m.get("modes"), m.get("corrections"))
        if prac:
            for r in rows:
                if r["i"] in prac:
                    r["practice"] = True
            doc["practice"] = doc["practice_rows"] = True
        if self.is_car():
            doc["client"] = "car"
        # every decode, plus the words dropped by the voice / foreign rules (B3.15, X2.16)
        return doc, (_decode_lines([{"t": t, "hyp": h} for t, h in tr.decode_log], tr.voice_log) if lines else [])

    @staticmethod
    def _files(doc: dict, lines: list[dict]) -> dict[str, bytes]:
        """The text files of a session folder (the audio aside)."""
        return {"session.json": json.dumps(doc, ensure_ascii=False, indent=1).encode("utf-8"),
                "decodes.jsonl": "".join(json.dumps(x, ensure_ascii=False) + "\n" for x in lines).encode("utf-8"),
                "summary.md": summary_markdown(doc, load_quran()).encode("utf-8")}

    def _folder_key(self) -> tuple[int, int, dt.datetime]:
        """(surah, ayah, started) the session's folder is named after (X2.9): session.json's surah and ayah_from (the
        first of its words in the surahs reached, X2.1d) and the start time."""
        w0 = self.words[self.reached()[0]]
        return w0.surah, w0.ayah, self.meta["started"]

    def folder_name(self) -> str:
        """U1.16 (v0.9, user 2026-10-11): the session's folder name, the saved one, else the one save() would create now
        (Profile.new_session_folder: a same-second twin's " (k)" included). The bug report names a running session by
        it."""
        with self.lock:     # the naming too: a save meanwhile would make its folder a " (2)" twin (review 2026-10-11)
            if self.folder is not None:
                return self.folder.name
            return self.app.profile.new_session_folder(*self._folder_key()).name

    def save(self) -> Path | None:
        """X2.9: the session folder (write_session_folder: session.json last). #45 (v0.17): the checkpoint gets this
        doc and the folder's name first, so a kill while the folder is written ends in that folder (App.recover_unsaved);
        unsaved/<id>/ goes once the folder is complete. No session (is_a_session: under 1 s of audio and no verdict of
        the user's) saves nothing and leaves no checkpoint; v0.17 (#49): a verdict of the user's makes one, also under
        1 s (a card read in silence); no audio at all: no audio.wav."""
        with self.lock:
            if not self.is_a_session():             # nothing recited
                self._drop_checkpoint()
                return None
            doc, lines = self._doc()
            folder = self.app.profile.new_session_folder(*self._folder_key())   # = folder_name() until now
            pcm = None
            try:
                if self.app.checkpoints:
                    self._flush()
                    pcm = self._complete_pcm()
                    self._write_checkpoint(doc, folder=folder.name)
            except OSError as e:
                self._write_failed("checkpoint", e)
            # #71 (v0.19, D9): from the checkpoint's audio.pcm when the flush wrote all of it (streamed, as the
            # recovery does), else from the chunks (the web, a failed flush); block by block either way
            audio = (pcm if pcm is not None else self.chunks) if self.tracker.total_samples else None
            write_session_folder(self.app.profile, folder, doc, lines, audio)
            self._drop_checkpoint()
            return folder


class SearchSession:
    """X2.13 Find where I am: listens (same transport and messages as a Session), transcribes the last SEARCH_WINDOW_S
    seconds at every step and reports the place once it is certain. Never saved, never in the history.
    #20 (emulator 2026-10-17): once found, it keeps the audio of the place on (`carry`, and everything heard since); the
    session started with `after_search` = this id begins with it (App.start), so the words said while that session was
    being started are heard, never lost. #94 (Meddeb 0.19, 2026-10-31, D1): the carry starts CARRY_MARGIN_S before the
    first heard word of the place (found.start), where that session starts: the words the search needed to be sure (a
    short ayah, 26:73) are recited in it, no longer used up; `carry_next` samples of it come before the found word's end
    (the 0.20 clients start at found.next: they get the carry from there, as before).
    v0.22 (#102, #100, plan D3; user 2026-11-01: "make it more efficient and faster to jump to the target once
    identified"): the first decode once FIRST_DECODE_S are heard, then every STEP_SAMPLES (0.21: at 3.2 s, then every
    1.6 s); `near` ({page}: the page shown at the press) is search_place's prior; the message adds `raw` (the model's
    text), `candidates` (the places it hesitates between, at most 6) and `n_places`; choose{global} settles on one of the
    last candidates (the reciter's tap); `go_on` (the start params of the session to open, as start{} takes them) makes
    the engine start that session itself on the find, in the same step (App.start with after_search = this id: no
    round trip through the client), the search message then carrying `started` (that session's started message); from
    then on this object hands every call to that session (`session`), so the transport keeps talking to the same
    object. With go_on and a shown page, a voice command heard before any place (X2.15: «الكلمة التالية» first, the
    Hidden / Blind cue) means "I am on this page": the session opens at the page's first ayah with the audio from the
    command on, and the command acts in it as in any session (plan D3). A place found in the open group's next words
    goes on in that group (App.go_on_in_group) rather than a new one."""

    kind = "search"
    CARRY_MARGIN_S = TrackerConfig.cut_margin_s
    # #94: the carry opens the session's first decode, kept under the tracker's forced commit (max_window_s, 24 s): at
    # most CARRY_HEAD_MAX_S of it are heard before the find (a longer place starts at its first heard word within
    # them), and the session's first push is at most CARRY_MAX_S (it starts at a later heard word when the carry grew
    # longer: `carry_marks`). v0.21 review: it is dropped once CARRY_AFTER_MAX_S of audio came after the find (the
    # 0.20 allowance; counting its whole length left a session ~5.5 s to start after a late find)
    CARRY_MAX_S = TrackerConfig.max_window_s - 2.0
    CARRY_HEAD_MAX_S = 16.0
    CARRY_AFTER_MAX_S = SEARCH_WINDOW_S
    FIRST_DECODE_S = 1.0                # v0.22 (#102): the first decode once this much audio is heard

    def __init__(self, app: "App", backend, params: dict | None = None) -> None:
        params = params or {}
        self.app, self.backend = app, backend
        self.id = uuid.uuid4().hex[:10]
        self.created = time.time()
        self.buffer = np.zeros(0, dtype=np.float32)
        self.total = self.last_step = 0
        self.decoded = False                    # v0.22: a decode ran (the first one at FIRST_DECODE_S)
        self.found: dict | None = None
        self.hyp = ""
        self.raw = ""                           # #100: the model's text of the last decode
        self.candidates: list[dict] = []        # #100: the last decode's places (search_place), with their `heard`
        self.n_places = 0
        self.near = params.get("near") if isinstance(params.get("near"), dict) else None
        self.go_on = dict(params["go_on"]) if isinstance(params.get("go_on"), dict) else None
        self.session: "Session | None" = None   # v0.22: the session the engine opened on the find (go_on)
        self._last: tuple | None = None         # #100: (transcript, src, total, buffer length) of the last decode
        self.carry: np.ndarray | None = None   # #20: the audio of the place on (float32, 16 kHz), #94: from found.start
        self.carry_next = 0                     # #94: its samples before the found word's end (a start at found.next)
        self.carry_found = 0                    # v0.21 review: its length at the find (the audio after it = the rest)
        self.carry_marks: list[tuple[int, dict]] = []   # v0.21 review: (offset in it, place) of each heard word, then
                                                        # (carry_next, found.next): where a session may start in it

    def started_message(self) -> dict:
        return {"type": "started", "search": True, "session": self.id}

    def __getattr__(self, name: str):
        # v0.22 (go_on): once the engine opened the session, what only a Session has (checkpoint, lock, tracker, ...)
        # is that session's (the platforms' bridges call them on the object they hold)
        session = self.__dict__.get("session")
        if session is None:
            raise AttributeError(name)
        return getattr(session, name)

    def push_audio(self, pcm16: bytes) -> bool:
        if self.session is not None:
            return self.session.push_audio(pcm16)
        pcm = np.frombuffer(pcm16, dtype="<i2").astype(np.float32) / 32768.0
        self.buffer = np.concatenate([self.buffer, pcm])[-int(SEARCH_WINDOW_S * SR):]
        self.total += len(pcm)
        if self.carry is not None:
            self.carry = np.concatenate([self.carry, pcm])
            if len(self.carry) - self.carry_found > self.CARRY_AFTER_MAX_S * SR:
                self.carry = None              # no session followed: it would no longer start at the found word
        if not self.decoded:
            return len(self.buffer) >= self.FIRST_DECODE_S * SR
        return self.total - self.last_step >= STEP_SAMPLES

    def message(self, **extra) -> dict:
        """B3.8 `search`: hyp (the normalized words), raw (#100: the model's text), found, candidates (without their
        heard words), n_places, heard_s."""
        cands = [{k: v for k, v in c.items() if k != "heard"} for c in self.candidates]
        return {"type": "search", "session": self.id, "hyp": self.hyp, "raw": self.raw, "found": self.found,
                "candidates": cands, "n_places": self.n_places, "heard_s": round(self.total / SR, 1), **extra}

    def step(self, final: bool = False) -> dict:
        if self.session is not None:
            return self.session.step(final)
        if final and self.go_on is not None:
            # v0.22 review: the microphone off during the search (stop, a pause; Android's session_step(true)) = "the
            # search ends, nothing found": no last decode, whose find opened the session (go_on) the user turned off,
            # closed the group behind the search ("elsewhere", or a find in it then closed) and saved words never
            # decoded. Nothing found: the client gives the paused group back
            self.last_step = self.total
            return self.message()
        if self.found is None and len(self.buffer) >= self.FIRST_DECODE_S * SR:
            self.last_step, self.decoded = self.total, True
            tr = self.backend.transcribe(self.buffer, SR)
            toks, src = [], []                  # the normalized words heard, and the transcript word of each
            for k, w in enumerate(tr.words):
                for t in normalize(w.text).split():
                    toks.append(t)
                    src.append(k)
            keep = clean_hyp(toks)
            toks, src = [toks[k] for k in keep], [src[k] for k in keep]
            self.hyp, self.raw = " ".join(toks), tr.text
            r = search_place(toks, load_quran(), near=self.near)
            self.candidates, self.n_places = r["candidates"], r["n_places"]
            self._last = (tr, src, self.total, len(self.buffer))
            if r["found"] is not None:
                self._settle(r["found"], r["heard"], tr, src, len(self.buffer), 0)
            elif self.go_on is not None and near_pages(self.near) and not self.candidates:
                cmd = self._voice_first(toks, src, tr)
                if cmd is not None:
                    return self._open_on_page(cmd)
            if self.found is not None and self.go_on is not None:
                return self._open_session()
        else:
            self.last_step = self.total
        return self.message()

    def _settle(self, found: dict, heard: list[tuple[int, int]], tr, src: list[int], dec_len: int, delta: int) -> None:
        """The place is `found` (#94: the carry from its first heard word within CARRY_HEAD_MAX_S); `heard` and the
        transcript are a decode's over `dec_len` samples whose sample x is the current buffer's x + delta (choose{}
        after more audio came: delta < 0; the carry is None once its head left the buffer)."""
        q = load_quran()
        self.found = found
        buf_s = dec_len / SR

        def start_s(j: int) -> float:
            t = tr.words[src[j]].start
            return 0.0 if t is None else min(max(0.0, float(t)), buf_s)

        # #94: from the first heard word of the place, or its first one within CARRY_HEAD_MAX_S
        j0, g0 = next(((j, g) for j, g in heard if start_s(j) >= buf_s - self.CARRY_HEAD_MAX_S), heard[-1])
        if g0 != heard[0][1]:
            self.found["start"] = word_place(g0, q)
        end = tr.words[src[heard[-1][0]]].end
        end = buf_s if end is None else min(float(end), buf_s)
        head = max(0, int((start_s(j0) - self.CARRY_MARGIN_S) * SR))
        if head + delta < 0:                    # #100: that audio left the 20 s buffer: no carry, the session
            self.carry = None                   # starts at found.start with nothing heard yet
            return
        self.carry = self.buffer[head + delta:].copy()
        self.carry_next = max(0, int((end - self.CARRY_MARGIN_S) * SR) - head)
        self.carry_found = len(self.carry)
        k0 = next(i for i, (j, _g) in enumerate(heard) if j == j0)
        self.carry_marks = [(max(0, int((start_s(j) - self.CARRY_MARGIN_S) * SR) - head), word_place(g, q))
                            for j, g in heard[k0:]]
        self.carry_marks[0] = (0, self.found.get("start") or self.carry_marks[0][1])
        self.carry_marks.append((self.carry_next, self.found["next"]))

    def _open_session(self, extra: dict | None = None) -> dict:
        """go_on: the session at found.start, opened by the engine in this step (App.start with after_search: the
        carry, #20 / #94), or the open group going on (App.go_on_in_group); the search message carries its `started`."""
        at = self.found["start"]
        params = {**self.go_on, "surah": at["surah"], "ayah_from": at["ayah"], "after_search": self.id}
        params.pop("ayah_to", None)
        params.pop("search", None)
        group = self.app.go_on_in_group(self)
        if group is not None:
            self.session = group
            started = {**group.started_message(known=group.n_known, closed=False), "resumed": True}
        else:
            self.session = self.app.start(params, backend=self.backend)
            if self.carry is None:              # #100: chosen after its audio left the buffer: at found.start
                k = next((i for i, w in enumerate(self.session.words)
                          if (w.surah, w.ayah, w.idx) == (at["surah"], at["ayah"], at["idx"])), None)
                if k is not None:
                    self.session.begin_at(k)
            started = self.session.started_message()
        return self.message(started=started, **(extra or {}))

    def _voice_first(self, toks: list[str], src: list[int], tr) -> float | None:
        """plan D3 (s102 decision 2): the start (s) of a voice command phrase heard before any place (X2.15's
        templates: next / eyah / replay), None when none."""
        from . import voice as vc

        for i, _j, tp in vc.command_hits(toks, vc.COMMAND_TEMPLATES):
            if tp.cmd in ("next", "eyah", "replay"):
                t = tr.words[src[i]].start
                return 0.0 if t is None else max(0.0, float(t))
        return None

    def _open_on_page(self, t0: float) -> dict:
        """plan D3: a voice command before any place = "I am on this page": the session at the shown page's first ayah,
        its audio from the command on (its tracker hears the command and acts as in any session: the cue first, X2.15)."""
        s, a = page_start(int(self.near["page"]))
        params = {**self.go_on, "surah": s, "ayah_from": a}
        for k in ("ayah_to", "search", "after_search"):
            params.pop(k, None)
        self.session = self.app.start(params, backend=self.backend)
        head = max(0, int((t0 - self.CARRY_MARGIN_S) * SR))
        carry = self.buffer[head:]
        self.session.push_audio((np.clip(carry, -1.0, 32767 / 32768) * 32768).round().astype("<i2").tobytes())
        return self.message(started=self.session.started_message(), on_page=True)

    def command(self, msg: dict) -> dict | None:
        """#100: choose{global} (the reciter's tap on a place): one of the last decode's candidates becomes the found
        place, `chosen` (its carry from that decode's first heard word, shifted by the audio heard since; none once
        that audio left the buffer); with go_on the session opens at once. Anything else, or an unknown place: None."""
        if self.session is not None:
            return self.session.command(msg)
        if msg.get("type") != "choose" or self.found is not None or self._last is None:
            return None
        try:
            g = int(msg.get("global"))
        except (TypeError, ValueError):
            return None
        c = next((c for c in self.candidates if c["global"] == g), None)
        if c is None:
            return None
        tr, src, total, n = self._last
        delta = (total - n) - (self.total - len(self.buffer))   # the decode's buffer head, in the current buffer
        found = {k: c[k] for k in ("surah", "ayah", "idx", "global", "matched", "next", "start")}
        found.update(page=word_place(g + 1 if g + 1 < len(load_quran().all_words) else g, load_quran())["page"],
                     chosen=True)
        self._settle(found, c["heard"], tr, src, n, delta)
        if self.go_on is not None:
            return self._open_session({"reply_to": "choose"})
        return self.message(reply_to="choose")

    def pause(self) -> list[dict]:
        if self.session is not None:
            return self.session.pause()
        return [self.step(final=True), {"type": "paused"}]   # v0.22 review: with go_on, no decode (as stop)

    def finish(self) -> dict:
        if self.session is not None:
            return self.session.finish()
        return {"type": "done", "search": True, "session": self.id, "found": self.found, "folder": None}

    def stop(self, ended_by: str | None = None) -> list[dict]:
        if self.session is not None:
            return self.session.stop(ended_by)
        return [self.step(final=True), self.finish()]


class App:
    def __init__(self, profile: Profile, asr_factory: Callable[[str], object], default_model: str,
                 clock: Callable[[], dt.datetime] = dt.datetime.now) -> None:
        self.profile = profile
        self.asr_factory = asr_factory          # model name -> loaded ASR backend (platform code)
        self.default_model = default_model
        self.clock = clock
        self.live: dict[str, Session] = {}
        self.last_clip: dict | None = None      # X2.18: the last replay's {level, gain_db, limited, seconds} (logs)
        self.last_search: SearchSession | None = None   # #20: the search a start{after_search} goes on from
        self._now_cache: tuple | None = None    # #45: (saved history, running sessions' key, counted, merged history)
        self.log: Callable[[str], None] = lambda msg: None    # the platform's log line (the PC prints it, Android logs);
        # the engine calls it through _log
        # X2.9 (#45): running sessions keep a checkpoint in unsaved/ (Session.checkpoint); False for a platform whose
        # disk rewrites a growing file whole at every call (the web's OPFS mirror, d05_web/profile_fs.js)
        self.checkpoints = True

    def chapters(self) -> list[dict]:
        return json.loads((DATA / "chapters.json").read_text(encoding="utf-8"))

    def tajweed_legend(self) -> dict:
        return {"colors": TAJWEED_COLORS, "labels": TAJWEED_LABELS, "css": tajweed_css()}

    def locate(self, surah: int, ayah: int = 1) -> dict:
        return {"page": page_of(surah, ayah), "juz": juz_of(surah, ayah), "hizb": hizb_of(surah, ayah)}

    def history_for(self, words) -> list[dict | None]:
        hist, newest = self.profile.history(), self.profile.newest_session()   # #67: the readings of the newest: last
        return [summarize(hist.get(word_key(w["surah"], w["ayah"], w["idx"]) if isinstance(w, dict) else w.key),
                          newest=newest) for w in words]

    def _page_spans(self, n: int) -> dict[tuple[int, int], list[int]]:
        """(surah, ayah) -> [first, end) word range on page n, in reading order: from the 15-line layout, or from the
        page table (whole ayat) when there is no layout."""
        spans: dict[tuple[int, int], list[int]] = {}
        for _ln, s, a, idx, cnt in page_lines(n):
            lo, hi = spans.get((s, a), (idx, idx + cnt))
            spans[(s, a)] = [min(lo, idx), max(hi, idx + cnt)]
        if spans:
            return spans
        q = load_quran()
        s, a = page_start(n)
        end = page_start(n + 1) if n < n_pages() else (115, 1)
        while (s, a) < end and s <= 114:
            spans[(s, a)] = [0, len(q.ayah(s, a).words)]
            a += 1
            if a > q.n_ayat(s):
                s, a = s + 1, 1
        return spans

    @staticmethod
    def _page_ayahs(spans: dict[tuple[int, int], list[int]]) -> list[dict]:
        """The page's ayah entries (page() `ayahs`, what mushaf_lines reads) from its _page_spans. #107 (v0.23, D10;
        user 2026-11-02: a tap on the ayah marker underlines the fewest words before it that tell the place): link = k
        of quran_text.context_words(s, a + 1), the words before the next ayah (ending at this marker, back over ayat
        and pages, never out of the surah) that occur only once in the Qur'an, link_header = they reach the surah's
        start (its header is part of them); a surah's last ayah: link None, link_header False. No new call: the page
        holds the words on its own page, the rest is a count."""
        q = load_quran()
        out, start = [], 0
        for (s, a), (lo, hi) in spans.items():
            link, header = context_words(s, a + 1) if a < q.n_ayat(s) else (None, False)
            out.append({"surah": s, "ayah": a, "start": start, "n": hi - lo, "first_idx": lo,
                        "n_total": len(q.ayah(s, a).words), "first_of_surah": a == 1 and lo == 0,
                        "surah_name": q.chapter_name(s), "surah_name_ar": q.chapter_name_ar(s),
                        "basmala": a == 1 and lo == 0 and s not in (1, 9), "link": link, "link_header": header})
            start += hi - lo
        return out

    def starter_hint(self, page: int) -> dict:
        """#40 (X2.2, user 2026-10-24: "in blind mode, and page still empty … I need to know the eyats before … the
        minimum lines + a random 0 to 2 extra lines"): what a pull down on the empty page shows, the last lines of the
        page before that tell where this page starts. -> {page, prev_page (None for page 1), k and header
        (quran_text.context_words of the page's first ayah: every page begins at an ayah's first word), surah_start:
        {surah, name, header_on_prev} | None (the page opens a surah: its header is the hint; header_on_prev on the 18
        pages whose header is line 15 of the page before, U1.1b), n_min (the minimum lines), lines (line numbers 1-15
        of prev_page, top to bottom: the n_min minimum lines last, up to 2 candidate lines above them, never above the
        page's first line holding something; the page draws 0-2 of them at random from its own page{prev_page} call),
        words (the k words of the context, {surah, ayah, idx} in reading order)}. A surah header on this page itself:
        no line (the toast names the surah). The context itself: _context_lines (#39 shares it for the review cue)."""
        q = load_quran()
        n = max(1, min(int(page), n_pages()))
        s, a = page_start(n)
        ctx = self._context_lines(s, a)
        k, header = ctx["k"], ctx["header"]
        prev = n - 1 if n > 1 else None
        out = {"page": n, "prev_page": prev, "k": k, "header": header, "surah_start": None, "n_min": 0, "lines": [],
               "words": []}
        lines = mushaf_lines(prev, self._page_ayahs(self._page_spans(prev))) if prev else []
        heads = ctx["header_lines"].get(prev, {}) if prev else {}
        if a == 1:
            head = heads.get("surah")
            out["surah_start"] = {"surah": s, "name": q.chapter_name(s), "header_on_prev": head is not None}
            if head is None:
                return out
            at = [head]
        else:
            out["words"] = ctx["words"]
            at = list(ctx["lines"].get(prev, []))
            if header:                          # the surah's header (and basmala) name the start of the context
                at += list(heads.values())
            if not at:
                return out
        lo, hi = min(at), max(at)
        top = max(lo - 2, min(ln["n"] for ln in lines if ln["kind"] != "empty"))
        out.update(n_min=hi - lo + 1, lines=list(range(top, hi + 1)))
        return out

    def _context_lines(self, s: int, a: int) -> dict:
        """#40 / #39 (X2.2, X2.19): the context that tells where ayah s:a starts, shared by starter_hint and the review
        cue. -> {surah, ayah, k, header (quran_text.context_words: the fewest words before it that occur once, never
        leaving the surah; header: they reach its start), words (those k words, {surah, ayah, idx} in reading order),
        lines ({page: the line numbers holding them}), header_lines ({page: {"surah": line, "basmala": line}}: the surah's
        header and basmala, on the page of its ayah 1 or, on 18 pages, line 15 of the page before)}."""
        q = load_quran()
        s, a = int(s), int(a)
        k, header = context_words(s, a)
        ctx, b = [], a - 1
        while len(ctx) < k and b >= 1:          # the context never leaves the surah (context_words)
            ctx = list(q.ayah(s, b).words) + ctx
            b -= 1
        ctx = ctx[len(ctx) - k:]
        word_line: dict[tuple[int, int, int], tuple[int, int]] = {}
        for pg in sorted({page_of(w.surah, w.ayah) for w in ctx}):
            word_line.update({(ws, wa, i): (pg, ln) for ln, ws, wa, idx, cnt in page_lines(pg)
                              for i in range(idx, idx + cnt)})
        lines: dict[int, set[int]] = {}
        for w in ctx:
            at = word_line.get((w.surah, w.ayah, w.idx))
            if at is not None:
                lines.setdefault(at[0], set()).add(at[1])
        heads: dict[int, dict[str, int]] = {}
        first = page_of(s, 1)
        for pg in (first - 1, first):
            if pg >= 1:
                for ln in mushaf_lines(pg, self._page_ayahs(self._page_spans(pg))):
                    if ln["kind"] in ("surah", "basmala") and ln.get("surah") == s:
                        heads.setdefault(pg, {})[ln["kind"]] = ln["n"]
        return {"surah": s, "ayah": a, "k": k, "header": header,
                "words": [{"surah": w.surah, "ayah": w.ayah, "idx": w.idx} for w in ctx],
                "lines": {pg: sorted(v) for pg, v in lines.items()}, "header_lines": heads}

    def page(self, n: int) -> dict:
        """One mushaf page (Madani 604-page numbering), exactly the words its 15 lines hold (an ayah running over two
        pages shows its first words on one and the rest on the next): words with tajweed html and `joined` (U1.1e),
        ayah entries, lines, history (U1.1b, U1.2b)."""
        q = load_quran()
        n = max(1, min(int(n), n_pages()))
        spans = self._page_spans(n)
        words, ayahs = [], self._page_ayahs(spans)
        for (s, a), (lo, hi) in spans.items():
            ay = q.ayah(s, a)
            htmls = ayah_word_html(s, a)
            for w, h in zip(ay.words[lo:hi], htmls[lo:hi]):
                # U1.1e (#22): joined = no written word of its own (the previous one holds it): the page draws one span
                words.append({"surah": w.surah, "ayah": w.ayah, "idx": w.idx, "html": h, "uthmani": w.uthmani,
                              "simple": w.simple, "norm": w.norm, "joined": w.idx > 0 and not h.strip()})
        s0, a0 = next(iter(spans))
        return {"page": n, "n_pages": n_pages(), "juz": juz_of(s0, a0), "hizb": hizb_of(s0, a0),
                "start": {"surah": s0, "ayah": a0}, "words": words, "ayahs": ayahs,
                "lines": mushaf_lines(n, ayahs), "history": self.history_for(words)}

    def history(self, surah: int, ayah_from: int, ayah_to: int) -> dict:
        words = load_quran().passage(surah, ayah_from, ayah_to)
        return {"items": [{"surah": w.surah, "ayah": w.ayah, "idx": w.idx, **h}
                          for w, h in zip(words, self.history_for(words)) if h]}

    def _history_now(self, counted: bool = True) -> dict:
        """#45 (v0.17, user 2026-10-26: "a recite session is ongoing and a page was fully read. I expect the progress
        page to be already updated"): the history with every running session counted as if ■ were pressed now
        (Session.preview_doc into Profile.history_with; nothing saved); the saved history itself when none runs (or
        none is a session yet: Session.is_a_session). The merged dict is kept while neither the saved history nor a running session changed
        (review.py's cache is keyed on the dict's identity: the queue, a card and an action share one). A session is
        read under its lock: one saved meanwhile is finished, and the saved history read before it then lacks it (the
        next call has it), never counts it twice. #73 (v0.19, D4): the counted history (Profile.counted: without the
        practice sessions' correct readings, the running ones' previews included), also when no session runs (cached
        on the saved history's identity, _counted_base); counted False: the whole merged history (#69's detection)."""
        base = self.profile.history()
        running = [s for s in list(self.live.values()) if isinstance(s, Session)]

        def key_of(s: Session) -> tuple | None:
            return None if s.finished or not s.is_a_session() else (s.id, s.changes)
        key = [k for s in running if (k := key_of(s)) is not None]
        cached = self._now_cache
        if not key:
            return self._counted_base(base) if counted else base
        if cached is not None and cached[0] is base and cached[1] == key:
            return cached[2] if counted else cached[3]
        key, docs = [], []
        for s in running:
            with s.lock:
                if (k := key_of(s)) is not None:
                    key.append(k)
                    docs.append(s.preview_doc())
        if not docs:
            return self._counted_base(base) if counted else base
        merged = self.profile.history_with(docs)
        hist = self.profile.counted(merged, docs)
        self._now_cache = (base, key, hist, merged)
        return hist if counted else merged

    def _counted_base(self, base: dict) -> dict:
        """#73: Profile.counted(base): the profile keeps it while the saved history is the same dict (review.py's cache is
        keyed on the dict it gets: the same one back while nothing changed; #73 review: a mark refilters its word
        alone); base itself without a practice session."""
        return self.profile.counted(base)

    def progress(self) -> dict:
        """U1.11; #45: the running session counts as if stopped now (_history_now). #91 (v0.21, D4): learn_lock counts
        the Review backlog (review.due_backlog) only when the red pages do not lock Next to learn already and it did
        not move forward today (Android runs progress() after every mark)."""
        hist, q, today = self._history_now(), load_quran(), self.clock().date()
        # #116 (v0.23): the backlog locks Next to learn above a day's cards (Settings > Review > Cards a day)
        return compute_progress(hist, q, today,
                                due=lambda: review.due_backlog(hist, q, today, self.profile.review_events()),
                                lock_due=review.daily_cards(self.profile.settings()))

    def stats(self) -> dict:
        """U1.19 (issue #13): the Stats page, computed only when it opens (never inside progress(), B3.8); #45: the
        running session counts as if stopped now. #73 (v0.19, D4): the counted history (a practice session's correct
        readings are not recited), but #69's detection over every reading (the AI judged a practice session's audio
        too): a second pass only when a practice session left readings out."""
        q, today = load_quran(), self.clock().date()
        hist = self._history_now()
        out = compute_stats(hist, q, today)
        full = self._history_now(counted=False)
        if full is not hist:
            out["detection"] = compute_stats(full, q, today)["detection"]
        return out

    # ---- Review (U1.20, X2.19, B3.16; issue #39, v0.16): recite/review.py over the history and review.jsonl
    def _review_cards(self) -> tuple[list, dt.date]:
        today = self.clock().date()
        return review.cards(self._history_now(), load_quran(), today, self.profile.review_events()), today

    def review_queue(self, params: dict | None = None) -> dict:
        """review_queue{} -> {today, counters{red, green, total_due, suspended, waiting}, cards (today's round, in its
        order), suspended} (B3.16). Computed when the Review page or Progress opens, never inside progress(). #45: the
        running session counts as if stopped now (_history_now). #81 (v0.20, D8): with the time, a card failed today waits
        45 min from its last showing (its cards' `wait_until`, "HH:MM")."""
        now = self.clock()
        # #116 (v0.23): today's caps follow Settings > Review > Cards a day (review_daily, 15 by default)
        return review.queue(self._history_now(), load_quran(), now.date(), self.profile.review_events(), now=now,
                            daily=review.daily_cards(self.profile.settings()))

    def review_card(self, params: dict) -> dict:
        """review_card{card, level?} -> the card session's plan: {card, surah, runup_from, target, page, level, why,
        words, cue{lines, prev_page, prev_lines, header}, start{surah, ayah_from, review{card, target, level}}} (B3.16);
        level (Recite the join: 0) replaces the card's own. #103 (v0.22, plan D6): join = n, challenge n of the card's
        `similar` (review.join_plan: ayah i greyed, the session from i + 1, level 0, start.review.join = [s, i]) + join,
        member. LookupError: no such card or challenge."""
        cid = review.card_id(params.get("card"))
        allc, today = self._review_cards()
        c = review.find(allc, cid)
        if c is None:
            raise LookupError(f"no card {cid}")
        if params.get("join") is not None and str(params.get("join")).strip() not in ("", "null", "undefined"):
            found = self._join_find(allc, cid, params["join"], params.get("member"))
            if found is None:
                raise LookupError(f"no challenge {params['join']} on card {c.id}")
            c, n, m = found
            p = review.join_plan(c, m, load_quran())
            return {"card": c.id, "surah": m["target"][0], "runup_from": p["runup_from"],
                    "target": list(p["start"]["review"]["target"]), "page": p["page"], "level": 0, "why": c.why,
                    "words": list(c.words), "cue": p["cue"], "start": p["start"], "join": n, "member": dict(m)}
        lv = params.get("level")
        level = c.level if lv is None or str(lv).strip() in ("", "null", "undefined") else max(0, min(3, int(lv)))
        p = review.plan(c, level, today, self._context_lines,
                        lambda n: mushaf_lines(n, self._page_ayahs(self._page_spans(n))))
        target = [c.target[0], c.target[1]]
        return {"card": c.id, "surah": c.surah, "runup_from": p["runup_from"], "target": target, "page": p["page"],
                "level": level, "why": c.why, "words": list(c.words), "cue": p["cue"],
                "start": {"surah": c.surah, "ayah_from": p["runup_from"],
                          "review": {"card": c.id, "target": target, "level": level}}}

    def review_result(self, params: dict) -> dict:
        """review_result{card, folder} -> {card, ayat[{surah, ayah, ok, role}], passed, next_due, retries_left, why,
        help, due_days, wait_min} (B3.16): the saved session (its `review` meta) against the history that now holds it. #73 review: its ✓ / ✗
        from every reading (a practice session's correct ones too: a flawless Hidden card is no ✗), the card from the
        counted history (review.result says a Hidden pass did not count). #101 P5 (v0.22, plan D4): without a
        `folder` key, the newest group that read the target, a card session or not (review.range_result; since: an ISO
        time, the groups started from then on) + folder (that group's, None while it runs); folder null: no session
        saved, as before. #103 (D6): join = n, the card's challenge n (review.join_result) + join (the member). #106
        (v0.23, D8): + due_days (the card's due date - today) and wait_min (the minutes before its retry today, at App's
        clock; review._wait_min); the page asks again after a mark on the card's words (the mark amends the session)."""
        cid = review.card_id(params.get("card"))
        allc, today = self._review_cards()
        q, card, now = load_quran(), review.find(allc, cid), self.clock()
        if "folder" not in params:
            since = params.get("since")
            r = review.range_result(cid, card, self._history_now(counted=False), q, today,
                                    since=since if isinstance(since, str) and since else None, allc=allc, now=now)
            r["folder"] = self.profile.folder_of(r.pop("session"))
            return r
        doc = self._saved_doc(params.get("folder"))
        found = self._join_find(allc, cid, params.get("join"), params.get("member"))
        if found is not None:
            card, _n, member = found
            return review.join_result(cid, card, member, doc, self._history_now(counted=False), q, today, allc=allc,
                                      now=now)
        # #87 (v0.20): every living card, so that a merged card's session (its id gone) names its parts' earliest review
        return review.result(cid, card, doc, self._history_now(counted=False), q, today, allc=allc, now=now)

    @staticmethod
    def _join_find(allc: list, cid: str, n, member=None) -> tuple | None:
        """#103 (v0.22 review): a join chain's step -> (card, n, member), None: no join asked or no such challenge. The
        chain names its card by the id it started with: a card merged for the day (#87) splits once its own challenge
        passed, its id gone (review.find then may give the ordinary part, no challenges: "Cannot open the card", or a
        result graded by the whole ayah). So the member the page sends (its cue and target, from the queue's `similar`)
        is looked for in that card, then in every card; without one, challenge n of the card of that id, else of the
        card with challenges holding most of its words."""
        if n is None or str(n).strip() in ("", "null", "undefined"):
            return None
        try:
            k = int(n)
        except (TypeError, ValueError):
            return None
        card = review.find(allc, cid)
        if isinstance(member, dict) and member.get("cue") is not None and member.get("target") is not None:
            want = (list(member["cue"]), list(member["target"]))
            for c in ([card] if card is not None else []) + list(allc):
                for j, m in enumerate(c.similar):
                    if (list(m["cue"]), list(m["target"])) == want:
                        return c, j, m
        if card is not None and card.id == cid and 0 <= k < len(card.similar):
            return card, k, card.similar[k]
        joins = [c for c in allc if len(c.similar) > k]
        c = review.find(joins, cid) if joins else None
        if c is None and card is not None and 0 <= k < len(card.similar):
            c = card
        return (c, k, c.similar[k]) if c is not None else None

    @staticmethod
    def _join_member(card, n) -> dict | None:
        """#103: challenge n of the card's `similar` (None: no join asked, or no such challenge)."""
        if card is None or n is None or str(n).strip() in ("", "null", "undefined"):
            return None
        try:
            k = int(n)
        except (TypeError, ValueError):
            return None
        return card.similar[k] if 0 <= k < len(card.similar) else None

    def review_help(self, params: dict) -> dict:
        """review_help{card, folder} -> {words: [{surah, ayah, idx, word, heard, kind, twins, context, unique, text}],
        method, sources} (B3.16; #57, v0.18, D8): the Help panel of a card's result, pass or fail (review.card_help: per
        ✗ word of the target in that saved session, what happened and its mutashabihat from the Qur'an text, learned
        places first; then the learning method). Words are named by their written word (written_text). Costs: the
        cards (cached since review_result), the word-pair index of the Qur'an once (Find where I am's), the learned rule
        of each place found. ValueError: no card id. #103 (v0.22, plan D6): joins = [{member: n, folder}], the join
        challenges played (folder: its saved session, none: not played) -> review.join_help: the group, the split tree
        of their openings, per challenge what was said, the method."""
        cid = review.card_id(params.get("card"))
        allc, _today = self._review_cards()
        q = load_quran()
        if isinstance(params.get("joins"), list):
            card = review.find(allc, cid)
            # v0.22 review: each challenge by the member the page sends too (a merged card split: _join_find)
            played = [(f[2], self._saved_doc(j.get("folder"))) for j in params["joins"] if isinstance(j, dict)
                      if (f := self._join_find(allc, cid, j.get("member"), j.get("detail"))) is not None]
            return review.join_help(cid, card, played, self._history_now(counted=False), q,
                                    lambda k: written_text(q, *review.parts(k)), lambda k: is_joined(*review.parts(k)))
        doc = self._saved_doc(params.get("folder"))
        # #73 review: the ✗ words from every reading (review_result's), the learned places from the counted history
        return review.card_help(cid, review.find(allc, cid), doc, self._history_now(counted=False), q,
                                lambda k: written_text(q, *review.parts(k)), lambda k: is_joined(*review.parts(k)),
                                counted=self._history_now())

    def _saved_doc(self, folder) -> dict | None:
        """session.json of a saved session folder (a name, FOLDER_RE), None when there is none or it is unreadable."""
        if not (isinstance(folder, str) and FOLDER_RE.fullmatch(folder)):
            return None
        try:
            doc = json.loads((self.profile.sessions_dir / folder / "session.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        return doc if isinstance(doc, dict) else None

    def review_action(self, params: dict) -> dict:
        """review_action{card, action: suspend | unsuspend | bury | shown | skip} -> review.jsonl (D4.8), then the new
        review_queue. ValueError: another action or no card id."""
        action = str(params.get("action") or "")
        if action not in review.EVENTS:
            raise ValueError(f"unknown review action {action!r}")
        cid = review.card_id(params.get("card"))
        allc, _today = self._review_cards()
        # #87 (v0.20, D13) review: an id gone (a merged card split once a part passed) reaches every part it overlaps
        words, new = review.action_cards(allc, cid)
        self.profile.add_review_event(action, cid, words, t=self.clock().isoformat(timespec="seconds"),
                                      new=action == "shown" and new)   # #39 review: the caps
        return self.review_queue()

    def listen_targets(self) -> dict:
        """U1.13 quick buttons (Weak page, Next to learn, Manzil) from the Progress numbers (B3.14). #93 (v0.20, D20):
        played by the saved reciter (settings.listen.reciter: no parameter, the page, the Android bridge and presets()
        call it bare). #101 (v0.22, plan D5): + review, the car's Recite review: the first card of review_queue that
        does not wait for its retry, with its card session's plan (review_card); None: no such card."""
        saved = self.profile.settings().get("listen")
        rid = saved.get("reciter") if isinstance(saved, dict) else None
        rv = None
        q = self.review_queue()
        first = next((c for c in q["cards"] if not c.get("wait_until")), None)
        if first is not None:
            try:
                rv = {"card": first, "plan": self.review_card({"card": first["id"]}),
                      "due": q["counters"]["total_due"]}
            except LookupError:
                rv = None
        return listen.listen_targets(self.progress(), load_quran(), reciter=rid, review=rv)

    def listen_plan(self, params: dict) -> dict:
        """U1.13: {tab: ayah, surah, ayah_from, ayah_to} | {tab: page, page_from, page_to} -> the clips to play (B3.14);
        #93: + reciter (an id); without one, the saved reciter (review of #93: the car's page range asked by voice names
        none), Yasser by default."""
        if not params.get("reciter"):
            saved = self.profile.settings().get("listen")
            params = dict(params, reciter=saved.get("reciter") if isinstance(saved, dict) else None)
        return listen.listen_plan(params, load_quran())

    def listen_reciters(self) -> list[dict]:
        """#93 (B3.14): the Listen form's Reciter select, [{id, label, name}], the default first."""
        return listen.listen_reciters()

    def reciter_clip(self, params: dict) -> dict:
        """B3.8 reciter_clip{surah, ayah, from_idx?, to_idx?} -> the reciter's ayah file and the part the players cut
        for a voice command (X2.15, D4.6): words from_idx..to_idx (first occurrences), t0_ms from the file start, t1_ms
        None = to the end of the file. Defaults: the whole ayah; indices are clamped to the ayah's words; timed False
        (no timings for that ayah) = the whole file. v0.22 (D7): never a banned file (off_banned: QuranicAudio's range
        of the same words, else url None and `banned`)."""
        return off_banned(self._ea_clip(params))

    def _ea_clip(self, params: dict) -> dict:
        """reciter_clip's clip in Yasser's EveryAyah file (his word timings' times, D4.6), banned or not."""
        q = load_quran()
        surah, ayah = int(params["surah"]), int(params["ayah"])
        if not (1 <= surah <= 114 and 1 <= ayah <= q.n_ayat(surah)):
            raise ValueError(f"no ayah {surah}:{ayah}")
        last = len(q.ayah(surah, ayah).words) - 1

        def idx(v, default: int) -> int:
            return default if v is None or str(v).strip() in ("", "null", "undefined") else int(v)
        lo = max(0, min(idx(params.get("from_idx"), 0), last))
        hi = max(lo, min(idx(params.get("to_idx"), last), last))
        t0, t1 = word_times.clip_ms(surah, ayah, lo, hi)
        key = listen.ayah_key(surah, ayah)
        return {"key": key, "url": listen.RECITER["base_url"] + key + ".mp3", "t0_ms": t0, "t1_ms": t1,
                "timed": word_times.timeline(surah, ayah) is not None, "surah": surah, "ayah": ayah,
                "from_idx": lo, "to_idx": hi,
                "gain": RECITER_GAIN}   # X2.18 (2026-10-10): his -14.2 LUFS at the -18 of every Recite sound (volume)

    def before_cue(self, surah: int, ayah: int, idx: int = 0) -> dict:
        """#36 (X2.15, user 2026-10-23: "it should play the Eya before this page, but if a new sourat starts at the
        beginning of this page then just say the sourat name in arabic 'sourat al-bakarah'"): what comes before a
        session's first word (surah:ayah word idx), for a replay said before anything is recited and the car's start
        (B3.8 `before`). #58 (v0.18, D11; user 2026-10-28: "whether I start in middle of surah or at the beginning of a
        surah I should hear the eya before and eventually the surah name … I hear a3outhou billeh, last eya of Al-Kahf,
        'sourat Mariem'"): {kind, surah, ayah, name (kind surah only), steps: [clip, ...] played in order, opening: the
        ta'awwudh 001000}. The car's automatic start plays opening then steps; a replay, the first «كلمة» and the car's
        Repeat before the first word play the steps alone (B3.8, X2.15). Word idx > 0 (a session going on from Find where
        I am inside an ayah): kind words, steps = its words 0..idx-1; an ayah a > 1: kind ayah, surah:ayah = a-1, steps =
        Yasser's ayah a-1 (_ayah_before_clip: capped); an ayah 1: kind surah, surah:1 and the surah's name (the page and
        the car say "Maryam begins"), steps = the previous surah's last ayah (capped the same way; none before 1:1), then
        the surah's recorded «سورة …» (name_clip). Never the basmala (the reciter says it, #41): 9:1 = 8:75 + «سورة
        التوبة». The TTS path (text «سورة …» for the device's offline Arabic voice, Yasser's basmala as its fallback) is
        gone: the user's Samsung has no such voice (#58). The clips are reciter_clip answers, the name clip the shape of
        name_clip. Every page begins at an ayah's first word, so before a page's first ayah = before the page."""
        q = load_quran()
        surah, ayah, idx = int(surah), int(ayah), int(idx)
        opening = off_banned({"key": TAAWWUDH_KEY, "url": listen.RECITER["base_url"] + TAAWWUDH_KEY + ".mp3",
                              "t0_ms": 0, "t1_ms": None, "timed": False, "surah": 1, "ayah": 0, "from_idx": 0,
                              "to_idx": len(TAAWWUDH) - 1, "gain": RECITER_GAIN})
        if idx > 0:
            return {"kind": "words", "surah": surah, "ayah": ayah,
                    "steps": [self.reciter_clip({"surah": surah, "ayah": ayah, "from_idx": 0, "to_idx": idx - 1})],
                    "opening": opening}
        if ayah > 1:
            return {"kind": "ayah", "surah": surah, "ayah": ayah - 1, "steps": [self._ayah_before_clip(surah, ayah - 1)],
                    "opening": opening}
        steps = [self._ayah_before_clip(surah - 1, q.n_ayat(surah - 1))] if surah > 1 else []
        return {"kind": "surah", "surah": surah, "ayah": 1, "name": q.chapter_name(surah),
                "steps": steps + [name_clip(surah)], "opening": opening}

    def _ayah_before_clip(self, surah: int, ayah: int) -> dict:
        """#36: Yasser's ayah surah:ayah as the cue plays it (reciter_clip), a clip longer than BEFORE_MAX_S cut to its
        end: from the first word he starts in its last BEFORE_TAIL_S, repeats included. #58: the ayah before a session's
        first ayah, or the previous surah's last ayah before an ayah 1 (18:110, 38.7 s, before Maryam). v0.22 (D7): an
        EveryAyah file is cut on his EveryAyah times, a banned one moved to QuranicAudio's range (the same master
        recording) after that cut. v0.23 review: one moved to the clean recording (its range, or a unit part, D17) is
        cut on that recording's own times and word starts (_cap_clean): EveryAyah's 47:38 is 49.5 s, its unit part
        100 s; EveryAyah's 50:23 is under 30 s, its clean range 65 s."""
        clip = self._ea_clip({"surah": surah, "ayah": ayah})
        moved = off_banned(clip)
        if moved is not clip and moved.get("url") and moved["url"] != qa_times.qa_url(surah):
            return _cap_clean(moved, clip)
        t = word_times.timeline(surah, ayah)
        end = None if t is None else (t[1] if clip["t1_ms"] is None else clip["t1_ms"] / 1000)
        if end is not None and end > BEFORE_MAX_S:
            # #36 review: the cap is measured on the clip played (46:22's file holds the ayah twice, its clip only the
            # first reading) and cuts by time over every word Yasser says, repeats included (50:27: words 0-8, 0-8,
            # 5-8, 9: by first occurrences the cue was word 9 alone, 3.2 s)
            said = [(k, s) for k, s in t[0] if s < end]
            k, s = next(((k, s) for k, s in said if s >= end - BEFORE_TAIL_S), said[-1])
            clip.update(from_idx=k, t0_ms=int(round(s * 1000)))
        return off_banned(clip)

    def versions(self, platform_name: str = "pc") -> dict:
        """B3.8 versions (U1.12 About title): the app version (recite.__version__) and the engine's own components;
        the PC server adds its runtimes and the served model's state, Android answers this call in Kotlin."""
        return {"app": __version__, "platform": platform_name,
                "items": [["Python", platform.python_version()], ["numpy", np.__version__]],
                "profile": str(self.profile.root)}

    def settings(self) -> dict:
        return self.profile.settings()

    def save_settings(self, changes: dict) -> dict:
        return self.profile.save_settings(changes)

    def learned(self) -> Learned:
        """#111 / #62 (v0.23, D16): what this profile's labels teach the tracker (profile.learn over its history: the
        learned forms, the known false-alarm places, the watch list), rebuilt at each Start; nothing new is stored."""
        return learn(self.profile.history())

    def accepted_forms(self) -> dict[str, set[str]]:
        """X2.17 (rewritten by #111, v0.23, D16, profile.learn): {expected word (N0): heard forms (N0)} the user's labels
        accept, at one of its places (Learned.at: a correct reading of theirs, a session verdict overruled, + Correct on
        a mistake, a mistake removed, that carries what the model heard, with the guards of learn) or wherever that text
        is expected (Learned.text: labelled twice, no Qur'an word, no mistake confirmed there). A view by text for the
        tests and the logs: the tracker gets the places themselves (Session._learn_places). Review of 0.19 (C4, X2.12b):
        never the heard of an insertion overruled (Reading.ai_ins): the extra words said before the word, not a form of
        it (the reading keeps them for an unmark, which gives the ⚡ back with what was heard)."""
        lt, q, out = self.learned(), load_quran(), {}
        for key, forms in lt.at.items():
            s, a, i = (int(x) for x in key.split(":"))
            out.setdefault(q.ayah(s, a).words[i].norm, set()).update(forms)
        for text, forms in lt.text.items():
            out.setdefault(text, set()).update(forms)
        return out

    # ---- a session the app could not stop (X2.9, #45 v0.17): checkpoints and their recovery
    def checkpoint(self) -> int:
        """Every running session's checkpoint now (Session.checkpoint): Android calls it when the app goes to the
        background, where the system may kill it. -> how many were written."""
        return sum(s.checkpoint() for s in list(self.live.values()) if isinstance(s, Session) and not s.finished)

    def recover_unsaved(self) -> list[str]:
        """X2.9 (#45, v0.17; user 2026-10-26: "the app crashes, or gets closed (terminated) by the end user during an
        ongoing session. definitely this should not lead to a different result than like a classical button stop"):
        each unsaved/<id>/ of a session not running in this app (it was killed: a crash, out of memory, a force stop, the
        system) becomes the folder ■ would have saved at its last checkpoint. The platforms call it once at start (the PC
        server's make_app, Android's start_app). -> the folders saved. Per checkpoint: checkpoint.json, else its .tmp
        (killed between the renames), else checkpoint.prev.json (a torn file); the rows left out written back; audio.wav
        from the whole audio.pcm (whole samples), duration_s and ended_at moved on by the audio recorded after the
        checkpoint; + ended_by "recovered"; decodes.jsonl from the checkpoint's own (_read_decodes; an older checkpoint's
        "decodes" list); session.json written last (write_session_folder); then unsaved/<id>/ goes (checkpoint.json
        last, _remove_tree). A checkpoint ■ was saving (its `folder`): that folder completed, never a " (2)" twin; already
        complete: only the checkpoint goes. #45 review (2026-10-27): the recovery names its folder in checkpoint.json
        before writing it, as ■ does, so a recovery killed half way (an hour of audio on a phone takes a while) is
        completed into that folder by the next one; a session still recording in another app on this profile (its lock
        held, _DirLock: a second PC server, a double launch) is left alone, never saved nor deleted. No readable
        checkpoint: the audio stays where it is (never deleted silently; Settings > Space used counts it). One failure
        never stops the others (a log line each; a log that raises stops nothing, _log)."""
        try:
            dirs = sorted(d for d in self.profile.unsaved_dir.iterdir() if d.is_dir())
        except OSError:
            return []
        out = []
        for d in dirs:
            if d.name in self.live:
                continue                                    # running here: its own ■ saves it
            try:
                name = self._recover(d)
            except Exception as e:  # noqa: BLE001 - one bad checkpoint must not stop the app
                self._log(f"recover {d.name}: failed ({e!r}); kept")
                continue
            if name:
                out.append(name)
        try:
            self.profile.unsaved_dir.rmdir()                # only when empty
        except OSError:
            pass
        return out

    def _log(self, msg: str) -> None:
        """self.log (the platform's), never raising (#45 review, 2026-10-27: Android's file logger raises on a full phone,
        where every checkpoint write fails too: called from those failures' handlers it stopped the engine thread)."""
        try:
            self.log(msg)
        except Exception:  # noqa: BLE001 - a log line is never worth the session
            pass

    def _recover(self, d: Path) -> str | None:
        lock = _DirLock.acquire(d / CHECKPOINT_LOCK)
        if lock is None:
            self._log(f"recover {d.name}: still recording in another app (its lock is held); left as it is")
            return None
        try:
            return self._recover_locked(d, lock)
        finally:
            lock.release()

    def _recover_locked(self, d: Path, lock: _DirLock) -> str | None:
        ck = None
        for name in (CHECKPOINT, CHECKPOINT + ".tmp", CHECKPOINT_PREV):
            try:
                c = json.loads((d / name).read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if isinstance(c, dict) and c.get("format") == CHECKPOINT_FORMAT and isinstance(c.get("doc"), dict):
                ck = c
                break
        pcm = d / CHECKPOINT_PCM
        n = pcm.stat().st_size // 2 if pcm.is_file() else 0
        if ck is None:
            if n:
                self._log(f"recover {d.name}: no readable checkpoint; its audio ({n / SR:.1f} s) kept in {d}")
                return None
            _remove_tree(d, lock)
            return None
        sessions = self.profile.sessions_dir
        target = None
        if isinstance(ck.get("folder"), str) and FOLDER_RE.fullmatch(ck["folder"]):
            target = sessions / ck["folder"]
            try:
                complete = isinstance(json.loads((target / "session.json").read_text(encoding="utf-8")), dict)
            except (OSError, ValueError):
                complete = False
            if complete:                                    # ■ (or a recovery) saved it; killed before the checkpoint went
                _remove_tree(d, lock)
                self._log(f"recover {d.name}: already saved as {target.name}")
                return None
        doc = dict(ck["doc"])
        words = session_words(doc, load_quran())
        lo, hi = ck["span"]
        given = {r["i"]: r for r in doc["words"]}
        doc["words"] = [given.get(i) or _plain_row(i, words[i]) for i in range(lo, hi)]
        later = (n - int(ck.get("samples") or 0)) / SR       # audio recorded after the checkpoint
        if later > 0:
            doc["duration_s"] = round(n / SR, 2)
            doc["ended_at"] = (dt.datetime.fromisoformat(doc["ended_at"]) + dt.timedelta(seconds=later)).isoformat()
        doc["ended_by"] = "recovered"
        folder = target or self.profile.new_session_folder(doc["surah"], doc["ayah_from"],
                                                           dt.datetime.fromisoformat(doc["started_at"]))
        if target is None:
            # #45 review: the folder's name first, atomically, as ■ does (save): killed while it is written, the next
            # start completes that folder (never a " (2)" twin beside a half one)
            _write_atomic(d / CHECKPOINT, json.dumps({**ck, "folder": folder.name}, ensure_ascii=False).encode("utf-8"))
        lines = list(ck["decodes"]) if isinstance(ck.get("decodes"), list) else _read_decodes(d / CHECKPOINT_DECODES)
        write_session_folder(self.profile, folder, doc, lines, pcm if n else None)
        _remove_tree(d, lock)
        self._log(f"recovered session {d.name} (killed before ■) into {folder.name}: {doc['duration_s']} s")
        return folder.name

    # ---- the export's kinds (D4.9, v0.19, #71)
    def export_plan(self) -> dict:
        """export_plan{} -> {kinds: [{id: settings | mistakes | recordings, bytes, files}]} in the dialog's order: the
        sizes on disk, those of Space used's rows (the same walk and kinds, recite/storage.py)."""
        rows = {k: {"id": k, "bytes": 0, "files": 0} for k in EXPORT_KINDS}
        for rel, size in export_files(self.profile.root, EXPORT_KINDS):
            r = rows[export_kind(rel)]
            r["bytes"] += size
            r["files"] += 1
        return {"kinds": [rows[k] for k in EXPORT_KINDS]}

    def export_files(self, kinds=None) -> dict:
        """export_files{kinds} (None = all; ValueError for another kind) -> {kinds, files: [[rel, size]], manifest}: what
        the web's and Android's export zip (the page / Kotlin write the zip; manifest = profile1/export.json, first)."""
        asked = list(EXPORT_KINDS) if kinds is None else [str(k) for k in kinds]
        files = export_files(self.profile.root, asked)                  # ValueError for another kind
        kinds = [k for k in EXPORT_KINDS if k in asked]
        return {"kinds": kinds, "files": [[rel, size] for rel, size in files],
                "manifest": export_manifest(kinds, self.profile.now())}

    # ---- Settings > Space used (U1.17, issue #14)
    def recording(self) -> bool:
        """A recitation not saved yet (running, paused, or stopping before its save; the car's too). A search is never
        saved; a session whose save failed (a full disk) does not count, so the user can free space."""
        return any(isinstance(s, Session) and not s.finished and not s.save_failed for s in list(self.live.values()))

    def storage(self) -> dict:
        """storage{} -> {rows: [{id, bytes, files, deletable, orphans?, sessions?, marks?, folders?}] in STORAGE_KINDS
        order, recording}. Android's android_storage adds the phone's rows (Listen audio, the model, the app, ...)."""
        rows = self.profile.storage()
        return {"rows": [rows[k] for k in STORAGE_KINDS], "recording": self.recording()}

    def storage_delete(self, params: dict) -> dict:
        """storage_delete{what} -> {ok: true, what, bytes, files, kept} | {ok: false, what, reason}: the recordings and
        the history are refused while a recitation is not saved (its save writes those files). ValueError for a kind it
        never deletes."""
        what = str(params.get("what") or "")
        if what not in STORAGE_DELETABLE:
            raise ValueError(f"{what!r} cannot be deleted here")
        if what in NEEDS_NO_SESSION and self.recording():
            return {"ok": False, "what": what, "reason": RECITING}
        r = self.profile.delete(what)
        if what == "recordings":       # the voice kept in memory for replay goes too
            for k in [k for k, s in list(self.live.items()) if isinstance(s, Session) and s.finished]:
                self.live.pop(k, None)
        return r

    def add_mark(self, surah: int, ayah: int, idx: int, event: str, session: str | None = None,
                 ins: bool = False) -> dict:
        """X2.12 for a word outside the running session: + Mistake / + Correct / Remove last, and "undo" (issue #24: a
        double tap again cancels the word's newest mark still in effect), "unmark" (issue #67: a double tap on a label of
        the user's gives that session's own verdict back, Profile.add_mark). session (#67 / #69 review: the saved
        session on screen, its folder; the platforms pass the page's `session` on): the mark labels that session's
        reading of the word (Profile.add_mark). + Correct right after a mistake verdict keeps what was heard then (that
        session's newest reading of the word, else the word's newest): that form is accepted for this word from then on
        (X2.17). ins (#72, v0.19, X2.12b): a mistake that is an insertion before the word (+ Inserted before, a double
        tap between two words)."""
        key = word_key(surah, ayah, idx)
        readings = self.profile.history().get(key) or []
        named = self.profile.session_named(session) if session and event == "correct" else None
        last = next((r for r in reversed(readings) if r.session == named), None) if named else None
        last = last or (readings[-1] if readings else None)
        # review of 0.19 (C4, X2.12b): an insertion's heard is the extra words before the word, never a form of it
        heard = last.heard if event == "correct" and last is not None and last.outcome == "mistake" \
            and not (last.ins or last.ai_ins) else None
        self.profile.add_mark(surah, ayah, idx, event, heard=heard, session=session, ins=bool(ins))
        return {"key": key, "history": summarize(self.profile.history().get(key), newest=self.profile.newest_session())}

    def sessions(self, limit: int = 30) -> list[dict]:
        out = []
        for folder, d in reversed(self.profile.session_docs()):
            try:
                out.append({"folder": folder, "surah": d["surah"], "ayah_from": d["ayah_from"], "ayah_to": d["ayah_to"],
                            "surah_to": d.get("surah_to", d["surah"]), "accuracy": d["summary"]["accuracy"],
                            "n_mistakes": d["summary"]["n_mistakes"], "duration_s": d["duration_s"]})
            except KeyError:
                continue
            if len(out) >= limit:
                break
        return out

    def clip(self, sid: str, start: float, end: float, margin: float = 0.35, folder: str | None = None) -> bytes:
        """WAV of a session between start and end (+ margin): live audio, or the saved file after a restart (B3.7).
        X2.18 (2026-10-10): brought to one loudness (recite/loudness.normalize_replay: -18 LUFS-like, -12..+30 dB, peak
        <= -1 dBFS); what it did stays in last_clip {level, gain_db, limited, seconds} for the logs. The saved audio never
        changes."""
        sess = self.live.get(sid)
        path = self.profile.sessions_dir / folder / "audio.wav" if folder and FOLDER_RE.fullmatch(folder) else None
        # #71 (v0.19, D9): only the range is read: the live chunks that hold it, or its frames of audio.wav
        if sess is not None:
            n, read = sess.n_samples(), sess.audio_range
        elif path is not None and path.exists():
            n, read = wav_frames(path), (lambda lo, hi: read_wav(path, lo, hi))
        elif path is not None and (path.parent / "session.json").exists():
            raise LookupError("this session's recording was deleted")      # Settings > Space used (U1.17)
        else:
            raise LookupError("unknown session")
        a = int(max(0.0, start - margin) * SR)
        b = int(min(n / SR, end + margin) * SR)
        if b <= a:
            raise ValueError("empty range")
        y, info = normalize_replay(read(a, b), SR)
        self.last_clip = {**info, "seconds": round((b - a) / SR, 2)}
        return wav_bytes(y)

    def session_load(self, params: dict) -> dict:
        """D11 (2026-10-10) session_load{folder?, rel?: older | newer, threshold?}: a saved session onto the page, as the
        page had it once it finished (U1.5 ◀ / ▶). {} = the newest; rel moves from folder (no folder: from the session in
        memory, newer than every saved one). -> {folder, nav, started_at, ended_at, duration_s, model, mode, threshold,
        index_map (every ayah of its rows), words (B3.8 state words of its rows; a row still pending without a mark of
        the user's is left out: the page draws a word it was not sent as pending), summary (`done` at the threshold:
        its own by default, every row counted)}. The marks made on its words before the next session started are
        applied (X2.12, stateAfterMark); a v0.5 verdict whose heard form is the word reads correct (issue #5).
        LookupError: no such session / past the ends."""
        def arg(k):
            v = params.get(k)
            return None if v is None or str(v).strip() in ("", "null", "undefined") else str(v)
        folder, rel = arg("folder"), arg("rel")
        if rel not in (None, "older", "newer"):
            raise ValueError(f"rel is older or newer, not {rel!r}")
        names = self.profile.session_folders()
        if folder is not None and (not FOLDER_RE.fullmatch(folder) or folder not in names):
            raise LookupError(f"no saved session {folder!r}")
        target = (folder or (names[-1] if names else None)) if rel is None else \
            self.profile.session_nav(folder, names)[rel]
        if target is None:
            raise LookupError("no saved session there")
        doc = json.loads((self.profile.sessions_dir / target / "session.json").read_text(encoding="utf-8"))
        thr = float(arg("threshold") or doc.get("threshold", TrackerConfig.threshold))
        words, autos = [], _labelled_autos(doc)
        for r in doc.get("words", []):
            w = {"i": r["i"], "surah": r["surah"], "ayah": r["ayah"], "idx": r["idx"], "status": r["status"],
                 "score": r.get("score") or 0, "hyp": r.get("heard"), "hinted": bool(r.get("hinted")),
                 "lost": bool(r.get("lost")), "concealed": bool(r.get("concealed", False)), "user": bool(r.get("user")),
                 "t0": None if r.get("t0") is None else round(r["t0"], 2),
                 "t1": None if r.get("t1") is None else round(r["t1"], 2)}
            if r.get("ins"):                                # #72 (v0.19): an insertion before the word, its own start
                w.update(ins=True, w0=None if r.get("w0") is None else round(r["w0"], 2))
            if not w["user"] and heard_is_the_word(r):      # issue #5: as the history reads it
                w.update(status="ok", score=0.0, lost=False, concealed=False)
            elif w["user"] and r["i"] in autos:             # #67: the tracker's own state under the user's label
                a = autos[r["i"]]
                status, score = _settled(a["status"], a["score"], thr)   # #67 review: being confirmed, as ■ settles it
                w["auto"] = {"status": status, "score": score, "hyp": w["hyp"],
                             "hinted": w["hinted"] or a["hinted"], "lost": w["lost"], "concealed": False}
                if a.get("ins") and status == "wrong":      # #72: Meddeb's insertion under the user's label
                    w["auto"]["ins"] = True
            words.append(w)
        k = names.index(target)
        t_next = None
        if k + 1 < len(names):
            try:
                t_next = dt.datetime.strptime(names[k + 1][:19], "%Y-%m-%d %H-%M-%S")
            except ValueError:
                t_next = None
        t_from = _when(doc.get("started_at"))
        if t_from is not None:
            words = apply_marks(words, self.profile.marks(), t_from, t_next, session=doc.get("started_at"))
        q = load_quran()      # U1.5 (#22): a joined word's row holds uthmani "": its written word names it
        rows = {r["i"]: r for r in doc.get("words", [])}
        nav = self.profile.session_nav(target, names)
        summary = rows_summary(words, thr)
        # the mistakes' rows only (_row_text reads the ayah's tajweed html: not for every word of a long session)
        summary.update(words={str(i): _row_text(q, rows[i]) if i in rows else None for i in summary["mistakes"]},
                       type="done", session="saved", folder=target, nav=nav)
        index_map, seen = [], set()
        for w in words:                             # the ayat of its rows (each from its first word)
            if (w["surah"], w["ayah"]) not in seen:
                seen.add((w["surah"], w["ayah"]))
                index_map.append({"surah": w["surah"], "ayah": w["ayah"], "start": w["i"] - w["idx"]})
        return {"folder": target, "nav": nav, "started_at": doc.get("started_at"), "ended_at": doc.get("ended_at"),
                "duration_s": doc.get("duration_s"), "model": doc.get("model"), "mode": doc.get("mode"),
                "threshold": thr, "surah": doc.get("surah"), "ayah_from": doc.get("ayah_from"),
                "ayah_to": doc.get("ayah_to"), "surah_to": doc.get("surah_to", doc.get("surah")),
                "index_map": index_map,
                "audio": (self.profile.sessions_dir / target / "audio.wav").is_file(),   # U1.17: its recording kept
                # a row still pending without a mark of the user's is what the page draws for a word it was not sent:
                # left out (an Al-Baqarah session's rows were 0.7-0.9 MB of JSON per ◀ / ▶, review of 2026-10-11)
                "words": [{k2: v for k2, v in w.items() if k2 not in ("surah", "ayah", "idx")} for w in words
                          if w["status"] != "pending" or w["user"]],
                "summary": summary}

    def report(self, params: dict) -> dict:
        """U1.16 Report a bug (D3, v0.9, user 2026-10-11, issue #8) report{session?, folder?, screenshot?, device?,
        platform?} -> {title, body, url, session_name}: the prefilled GitHub issue (recite/report.py) naming the app
        version (device: the platform's facts; the PC: recite's), the phone or computer, the screenshot the platform
        took (android_report_shot's {ok, name, folder} or a name; None: none) and the session (session_name, see
        report_session). Writes nothing, sends nothing: the user describes the bug and submits the issue."""
        folder, note = self.report_session(params)
        shot = params.get("screenshot")
        if isinstance(shot, str) and isinstance(params.get("screenshot_folder"), str) and params["screenshot_folder"]:
            shot = {"ok": True, "name": shot, "folder": params["screenshot_folder"]}   # Android: the shot's real folder
        plat = params.get("platform") or "pc"
        title, body = issue_text({"platform": plat, "device": params.get("device"), "screenshot": shot,
                                  "session": folder, "session_note": note})
        return {"title": title, "body": body, "url": issue_url(report_repo(plat), title, body),
                "session_name": session_label(folder, note)}

    def report_session(self, params: dict) -> tuple[str | None, str | None]:
        """(folder name, note) of the session a bug report names: params.session (the page's session: its id, or {id,
        folder}) running or paused -> the folder it will be saved under, "running, not saved yet"; finished -> its saved
        folder (too short to be saved: no folder, a note saying so); else params.folder (or session.folder: a saved
        session the page shows, U1.5) when it is one; else (None, None): "no session". A search (X2.13) is none."""
        s = params.get("session")
        sid = s.get("id") if isinstance(s, dict) else s
        folder = (s.get("folder") if isinstance(s, dict) else None) or params.get("folder")
        sess = self.live.get(sid) if isinstance(sid, str) else None
        if isinstance(sess, Session):
            with sess.lock:     # PC: the stop saves it in another thread; the check and the name are one moment
                if not sess.finished:
                    return sess.folder_name(), "running, not saved yet"
                if sess.folder is not None:
                    return sess.folder.name, None
            if not (isinstance(folder, str) and folder):
                return None, "too short to be saved"
        if isinstance(folder, str) and FOLDER_RE.fullmatch(folder) and folder in self.profile.session_folders():
            return folder, None
        return None, None

    def session_attach(self, params: dict | None = None) -> dict | None:
        """B3.16 session_attach{} (#59, v0.18, D12): the recitation open now (started, not stopped nor failed to save:
        the newest of them; Android runs one at a time) as {started, state} (Session.attach: its `started` over the words
        known now, with its client, and a full `state`), so that a page loaded while the car's session runs follows it;
        None when no recitation is open. Find where I am (a SearchSession) is never attached. Nothing changes."""
        open_ = [s for s in list(self.live.values()) if isinstance(s, Session) and not s.finished and not s.save_failed]
        for s in reversed(open_):                  # v0.18 review: one finished meanwhile answers None under its lock
            a = s.attach()
            if a is not None:
                return a
        return None

    def start(self, params: dict, backend=None) -> Session | SearchSession:
        """B3.8 start{surah, ayah_from, ayah_to?, model, mode, threshold, revealed[], voice_commands} or start{search:
        true} (X2.13); a platform that loads models asynchronously passes the loaded backend. voice_commands (X2.15,
        default true; off: no command fires, the command words are still dropped from the verdicts). after_search (#20:
        the id of the search that found the place): the session goes on from it (_go_on_after_search). review (B3.16,
        #39: {card, target, level, practice?}, a Review card's session): kept in the meta and saved in session.json.
        client (#59, v0.18: Android's tag, e.g. "car-3"): kept on the session, echoed in `started` and session_attach.
        at (#73, v0.19, D3: {surah, ayah, idx}, only with mic_off and never after a search): the silent session ◂ / ⏮
        start in Blind begins at that word (Session.begin_at)."""
        if params.get("search"):
            self.last_search = SearchSession(self, backend if backend is not None else self.asr_factory(
                params.get("model") or self.default_model), params)
            return self.last_search
        closed = self.close_open("elsewhere")   # v0.22 (D1): a start elsewhere closes the open group first
        q = load_quran()
        surah = int(params["surah"])
        a_from = int(params.get("ayah_from", 1))
        a_to = int(params.get("ayah_to") or q.n_ayat(surah))
        model = params.get("model") or self.default_model
        backend = backend if backend is not None else self.asr_factory(model)
        # X2.1d: a session that runs to the end of its surah follows the reciter into the next ones (Session._extend);
        # it starts with the page's later surahs too, so that starting anywhere on the page (X2.1c) finds them
        words = q.passage(surah, a_from, a_to)
        continues = a_to >= q.n_ayat(surah)
        if continues:
            page, s_last = page_of(surah, a_from), surah
            while s_last < 114 and page_of(s_last + 1, 1) == page:
                s_last += 1
                words += q.surah(s_last)
        voice_on = params.get("voice_commands") is None or bool(params["voice_commands"])
        meta = {"surah": surah, "ayah_from": a_from, "ayah_to": a_to, "model": model, "mode": params.get("mode"),
                "started": self.clock(), "revealed": params.get("revealed") or [], "corrections": [],
                "continues": continues, "voice_commands": voice_on}
        rv = review.session_meta(params.get("review"), a_from)     # #39: {card, target, level, runup_from, ...}
        if rv:
            meta["review"] = rv
        s = Session(self, words, backend, meta, threshold=float(params.get("threshold", TrackerConfig.threshold)),
                    voice_commands=voice_on, learned=self.learned(),   # #111 / #62 (v0.23, D16)
                    client=str(params["client"]) if params.get("client") else None)    # #59: kept for session_attach
        at = params.get("at")
        if isinstance(at, dict) and params.get("mic_off") and not params.get("after_search"):
            try:
                where = (int(at["surah"]), int(at["ayah"]), int(at.get("idx", 0)))
            except (KeyError, TypeError, ValueError):
                where = None
            k = next((i for i, w in enumerate(s.words) if (w.surah, w.ayah, w.idx) == where), None)
            if k is not None:
                s.begin_at(k)               # #73: the words before it stay unread (pending), never hints
        self._go_on_after_search(s, params.get("after_search"))
        s.closed_before = closed
        self.live[s.id] = s
        while len(self.live) > MAX_LIVE:
            del self.live[min(self.live, key=lambda k: self.live[k].created)]
        return s

    def open_groups(self) -> list[Session]:
        """v0.22 (D1): the sessions (groups) open now, oldest first."""
        return [s for s in list(self.live.values()) if isinstance(s, Session) and not s.finished and not s.save_failed]

    def close_open(self, ended_by: str) -> list[dict]:
        """v0.22 (D1): close every open group (Session.close) -> their `done` messages (auto, ended_by)."""
        out = []
        for s in self.open_groups():
            out += [m for m in s.close(ended_by) if m.get("type") == "done"]
        return out

    def tick(self, now: dt.datetime | None = None) -> list[dict]:
        """v0.22 (#101 P1, plan D1): called every ~30 s by the platform (the PC server's task, Android's Engine): the
        groups idle for GROUP_GAP_S close (ended_by "idle"; with the microphone on in silence too: mic_off) -> their
        messages [state, done{auto}] for the client."""
        out = []
        for s in self.open_groups():
            if s.idle_due(now):
                out += s.close("idle")
        return out

    def go_on_in_group(self, search: "SearchSession") -> Session | None:
        """v0.22 (D1/D3): a find (go_on) at the open group's next words (its cursor - GROUP_BACK to + GROUP_AHEAD) goes
        on in that group, the search's carry pushed into it (a resume with the words said meanwhile): a continuous
        reading is never split in two groups (Review's linked rule reads per group). None: no such group."""
        at = search.found["start"] if search.found else None
        for g in reversed(self.open_groups()):
            if at is None:
                break
            k = next((i for i, w in enumerate(g.words)
                      if (w.surah, w.ayah, w.idx) == (at["surah"], at["ayah"], at["idx"])), None)
            tr = g.tracker
            cur = max(tr.cursor, tr.first)
            # v0.22 review: no further back than the tracker's alignment window (back_window committed words: a repeat
            # it follows); further on than its no-jump (max_skip), its reading goes on at k (resume_at), the words in
            # between not recited: else its LOST rule made the next word a false red mistake and followed nothing
            if k is not None and max(cur - GROUP_BACK, tr.committed - tr.config.back_window) <= k <= cur + GROUP_AHEAD:
                with g.lock:
                    if k > tr.committed + tr.config.max_skip:
                        tr.resume_at(k)
                        g.changes += 1
                if search.carry is not None and len(search.carry):
                    g.push_audio((np.clip(search.carry, -1.0, 32767 / 32768) * 32768).round().astype("<i2").tobytes())
                g.last_act = self.clock()
                if self.last_search is search:
                    self.last_search = None
                return g
        return None

    def _go_on_after_search(self, s: Session, search_id) -> None:
        """#20 (emulator 2026-10-17, X2.13): a session started after Find where I am went on at its ayah's word 0 about
        1 s after the search's last decode, without the words said meanwhile (they went to the search), its audio
        beginning inside a word: the first words turned red although they were said. Started with after_search = the
        id of the last search (it found the place), the session starts at found.start, the first heard word of the
        place (#94, D1: no longer found.next, after the words the search needed), with the search's audio from that
        word on (SearchSession.carry), when its passage holds it (the words before are not recited, X2.1c); a passage
        that does not (a 0.20 client started it at found.next) goes on at found.next with the carry from the found
        word on, as before. Any other start drops the last search. v0.21 review: the session's first push stays under
        CARRY_MAX_S: a carry that grew longer meanwhile (a late find, then a slow page load or start) goes on at the
        first heard word of the place whose audio fits (SearchSession.carry_marks; the words before it not recited)."""
        search, self.last_search = self.last_search, None
        if not search_id or search is None or search.id != search_id or search.found is None or search.carry is None:
            return
        marks = search.carry_marks or [(0, search.found.get("start")), (search.carry_next, search.found["next"])]
        cap = int(search.CARRY_MAX_S * SR)

        def index_of(place) -> int | None:
            at = (place["surah"], place["ayah"], place["idx"])
            return next((i for i, w in enumerate(s.words) if (w.surah, w.ayah, w.idx) == at), None)

        for skip, place in marks:
            if place is None or len(search.carry) - skip > cap:
                continue
            k = index_of(place)
            if k is not None:
                s.go_on_after_search(k, search.carry[skip:])
                return
        # v0.21 review 2: no mark fits under CARRY_MAX_S although the carry is kept (a find in a pause, then a start
        # ~20 s later: the tail after the found word counts too): at found.next with the carry from the found word on,
        # 0.20's hand-off, never a silent loss of the words said meanwhile (#20)
        k = index_of(search.found["next"])
        if k is not None:
            s.go_on_after_search(k, search.carry[search.carry_next:])
        self._log(f"session {s.id} after search {search.id}: no heard word of the place within "
                  f"{search.CARRY_MAX_S:.0f} s of its carry ({len(search.carry) / SR:.1f} s): "
                  + ("goes on at found.next" if k is not None else "found.next not in its passage, no hand-off"))
