"""Meddeb's platform-neutral backend (03_platforms.md §4): pages, reading history, manual marks, progress, settings,
replay clips and the live session (the B3.8 protocol without its transport). The PC server (d04_meddeb/server.py)
serves it over HTTP + WebSocket; the Android app calls it through Chaquopy; the web version will run it in Pyodide.
Only numpy and the standard library: no web framework, no soundfile, no model runtime."""
from __future__ import annotations

import datetime as dt
import io
import json
import platform
import re
import threading
import time
import uuid
import wave
from pathlib import Path
from typing import Callable

import numpy as np

from . import listen
from . import __version__, word_times
from .loudness import RECITER_GAIN, normalize_replay
from .normalize import clean_hyp, normalize
from .profile import MISTAKE_STATUSES, Profile, effective_marks, heard_is_the_word, summarize, word_key
from .progress import progress as compute_progress
from .stats import stats as compute_stats
from .search import find_place
from .storage import DELETABLE as STORAGE_DELETABLE, KINDS as STORAGE_KINDS, NEEDS_NO_SESSION, RECITING
from .quran_text import (DATA, context_words, hizb_of, juz_of, load_quran, n_pages, page_lines, page_of, page_start,
                         start_page_end)
from .report import issue_text, issue_url, report_repo, session_label
from .tajweed_html import TAJWEED_COLORS, TAJWEED_LABELS, ayah_word_html, tajweed_css
from .tracker import TAAWWUDH, Tracker, TrackerConfig

APP_NAME = "Meddeb"
SR = 16000
STEP_SAMPLES = int(0.8 * SR)       # B3.3: one decode per ~0.8 s of new audio
MAX_LIVE = 5                       # sessions whose audio stays in memory for replay
FOLDER_RE = re.compile(r"[\w .()-]+")
SEARCH_WINDOW_S = 20.0             # X2.13: seconds of audio the search transcribes at every step
BEFORE_MAX_S = 30.0                # #36: the ayah before a session longer than this plays only its end ...
BEFORE_TAIL_S = 20.0               # ... from its first word starting in its last 20 s (2:282: 141 s; Claude's default)
TAAWWUDH_KEY = "001000"            # #36: EveryAyah's ta'awwudh file, the cue's fallback before 1:1 and 9:1 (no basmala)


def wav_bytes(audio: np.ndarray | list[np.ndarray], sr: int = SR) -> bytes:
    """16-bit PCM mono WAV with the stdlib (no soundfile on the phone or in the browser). audio: one array, or a list of
    arrays (a session's chunks: converted one by one, never one float copy of a long session; the same bytes)."""
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        group, n = [], 0
        for part in (audio if isinstance(audio, list) else [audio]):
            group.append(np.asarray(part, dtype=np.float32).reshape(-1))
            n += len(group[-1])
            if n >= 1 << 20:                    # ~1 M samples at a time (0.1 s chunks are slow to convert one by one)
                w.writeframes(_pcm16(group))
                group, n = [], 0
        w.writeframes(_pcm16(group))
    return buf.getvalue()


def _pcm16(parts: list[np.ndarray]) -> bytes:
    x = np.concatenate(parts) if parts else np.zeros(0, dtype=np.float32)
    return (np.clip(x, -1.0, 1.0) * 32767).astype("<i2").tobytes()


def read_wav(path: Path) -> np.ndarray:
    with wave.open(str(path), "rb") as w:
        if w.getsampwidth() != 2 or w.getframerate() != SR:
            raise ValueError(f"{path.name}: expected 16 kHz 16-bit PCM")
        pcm = np.frombuffer(w.readframes(w.getnframes()), dtype="<i2").astype(np.float32)
        if w.getnchannels() > 1:
            pcm = pcm.reshape(-1, w.getnchannels()).mean(axis=1)
    return pcm / 32768.0


def mushaf_lines(page: int, ayahs: list[dict]) -> list[dict]:
    """The 15 lines of the Madani page (U1.1b): [{n, kind: words|surah|basmala|empty, runs: [[start, n_words,
    ayah_end]], surah}] where start indexes the page's word list and ayah_end is the ayah number when the run closes
    its ayah (the marker goes after it). Surah headers and basmalas take the lines before the surah's first words
    (data: recite/data/mushaf_lines.json in recite word numbering, tools/fetch_mushaf_lines.py). #40 (v0.15): a surah
    that opens the next page on line 2 (its basmala on line 1; 18 pages) has its header on this page's line 15, the
    only line the layout leaves free there, as printed (it was drawn on neither page)."""
    starts = {(a["surah"], a["ayah"]): a for a in ayahs}
    lines: dict[int, dict] = {n: {"n": n, "kind": "empty", "runs": []} for n in range(1, 16)}
    first_line: dict[int, int] = {}
    for ln, s, a, idx, n in page_lines(page):
        ay = starts.get((s, a))
        if ay is None or ln not in lines:
            continue
        lines[ln]["kind"] = "words"
        lines[ln]["runs"].append([ay["start"] + idx - ay["first_idx"], n, a if idx + n == ay["n_total"] else 0])
        if a == 1 and idx == 0:
            first_line[s] = ln
    for s, ln in first_line.items():
        ay = starts[(s, 1)]
        head = ln - 2 if ay["basmala"] else ln - 1
        if ay["basmala"] and ln - 1 in lines and lines[ln - 1]["kind"] == "empty":
            lines[ln - 1].update(kind="basmala", surah=s)
        if head in lines and lines[head]["kind"] == "empty":
            lines[head].update(kind="surah", surah=s, surah_name_ar=ay["surah_name_ar"], surah_name=ay["surah_name"])
    nxt = page_lines(page + 1) if page < n_pages() else []
    if nxt and nxt[0][2] == 1 and nxt[0][3] == 0:
        # #40: the next page opens a surah too high for its header (and basmala): they take this page's last lines
        ln, s = nxt[0][0], nxt[0][1]
        q = load_quran()
        heads = [(ln - 1, {"kind": "basmala", "surah": s})] if s not in (1, 9) else []
        heads.append((ln - 1 - len(heads), {"kind": "surah", "surah": s, "surah_name_ar": q.chapter_name_ar(s),
                                            "surah_name": q.chapter_name(s)}))
        for at, line in heads:
            if at < 1 and 15 + at in lines and lines[15 + at]["kind"] == "empty":
                lines[15 + at].update(line)
    return [lines[n] for n in range(1, 16)]


def is_joined(surah: int, ayah: int, idx: int) -> bool:
    """U1.1e (v0.12, #22): the spoken (imla'i) word has no written word of its own: the written word before it holds
    both (يَٰبَنِىَّ = يا + بني, بَعْدَمَا = بعد + ما; 369 in the mushaf). The page draws nothing for it (empty tajweed
    html); its partner is always the previous word of its ayah. False past the ayah's last word."""
    html = ayah_word_html(surah, ayah)
    return 0 < idx < len(html) and not html[idx].strip()


def written_text(q, surah: int, ayah: int, idx: int) -> str:
    """U1.5 (#22, D1): the Uthmani text that names word idx in a list: the written word the page draws it in (is_joined,
    the page's grouping), i.e. its head word's Uthmani + every joined part's. A joined part has no Uthmani of its own
    in 367 places (يَٰبَنِىَّ + ""), its own in two (2:181 and 13:37: بَعْدَ + مَا = بَعْدَمَا; review of v0.12: the
    summaries named the part)."""
    words = q.ayah(surah, ayah).words
    k = idx
    while k > 0 and is_joined(surah, ayah, k):
        k -= 1
    m = k + 1
    while m < len(words) and is_joined(surah, ayah, m):
        m += 1
    return "".join(w.uthmani for w in words[k:m])


def _row_text(q, r: dict) -> str:
    """The text of a saved session row (summary.md, session_load): the written word that holds it (written_text) when
    it is a joined part (its saved uthmani is "" or, at 2:181 / 13:37, the part's own; also in sessions saved before
    v0.12: rows are never rewritten) or the head of one; else its uthmani."""
    try:
        s, a, i = r["surah"], r["ayah"], r["idx"]
        if not r.get("uthmani") or is_joined(s, a, i) or is_joined(s, a, i + 1):
            return written_text(q, s, a, i)
    except (KeyError, IndexError, TypeError, ValueError):
        pass
    return r.get("uthmani") or ""


MANUAL_LABEL = "manual labeled mistake"     # X2.12(a) (user, 2026-10-01)


def is_manual_mistake(r: dict) -> bool:
    """A session row whose mistake the user set (X2.12a): no "heard" text, what the model heard is not the reason."""
    return bool(r.get("user")) and r.get("status") in MISTAKE_STATUSES


def verdict_label(r: dict) -> str:
    """manual labeled mistake / wrong / skipped / hint / lost, as in the on-screen summary."""
    if is_manual_mistake(r):
        return MANUAL_LABEL
    if r.get("lost"):
        return "lost"
    return {"wrong": "wrong", "missing": "skipped", "hinted": "hint"}.get(r["status"], r["status"])


def session_words(doc: dict, q) -> list:
    """The word list of a saved session, the one its rows' "i" index (Session.save, X2.1d): from passage{surah,
    ayah_from} to the end of surah_to. surah/ayah_from/ayah_to name the first surah reached only. Sessions saved
    before X2.1d (no passage / surah_to) are the passage they name."""
    p = doc.get("passage") or {"surah": doc["surah"], "ayah_from": doc["ayah_from"]}
    s_to = doc.get("surah_to", doc["surah"])
    if p["surah"] == doc["surah"] == s_to:
        return q.passage(doc["surah"], p["ayah_from"], doc["ayah_to"])
    words = q.passage(p["surah"], p["ayah_from"], q.n_ayat(p["surah"]))
    for s in range(p["surah"] + 1, s_to + 1):
        words += q.surah(s)
    return words


def summary_markdown(doc: dict, q) -> str:
    """summary.md of a saved session: the U1.5 enumeration of mistakes, then the table of flagged words."""
    started = dt.datetime.fromisoformat(doc["started_at"])
    summ, thr, rows = doc["summary"], doc["threshold"], doc["words"]
    s, s_to = doc["surah"], doc.get("surah_to", doc["surah"])
    if s_to != s:       # X2.1d: the rows run to the end of the last surah reached
        last = rows[-1]["ayah"] if rows else q.n_ayat(s_to)
        where = f"Surah {s} ({q.chapter_name(s)}) {doc['ayah_from']} – Surah {s_to} ({q.chapter_name(s_to)}) {last}"
    else:
        where = f"Surah {s} ({q.chapter_name(s)}), ayah {doc['ayah_from']}–{doc['ayah_to']}"
    lines = [f"# {APP_NAME} session {started.strftime('%Y-%m-%d %H:%M:%S')}",
             f"{where}, model {doc['model']}, mode {doc.get('mode')}, threshold {thr}",
             f"Duration {doc['duration_s']} s — accuracy {round(summ['accuracy'] * 100)} %, "
             f"{summ['n_mistakes']} mistakes in {summ['n_recited']} recited words, {len(summ['hinted'])} hints", ""]
    listed = [r for r in rows if r["status"] in MISTAKE_STATUSES and (r["score"] >= thr or r["user"])]
    lines.append(f"## Mistakes ({len(listed)})" if listed else "No mistakes detected.")
    for k, r in enumerate(listed, 1):       # a listed row set by the user is a manual labeled mistake: no heard
        lines.append(f"{k}. {_row_text(q, r)} — {r['surah']}:{r['ayah']} w{r['idx'] + 1} — {verdict_label(r)}"
                     + (f" — heard {r['heard']}" if r["heard"] and not is_manual_mistake(r) else ""))
    lines += ["", "## All flagged words",
              "| word | position | verdict | heard | suspicion | corrected by you |", "|---|---|---|---|---|---|"]
    for r in rows:
        if r["status"] in MISTAKE_STATUSES or r["user"]:
            manual = is_manual_mistake(r)
            lines.append(f"| {_row_text(q, r)} | {r['surah']}:{r['ayah']} w{r['idx'] + 1} | "
                         f"{MANUAL_LABEL if manual else r['status']} | {'—' if manual else r['heard'] or '—'} | "
                         f"{r['score']} | {'yes' if r['user'] else ''} |")
    return "\n".join(lines) + "\n"


def rows_summary(rows: list[dict], thr: float) -> dict:
    """Tracker.summary over a saved session's rows (session_load): the same counts at threshold thr."""
    mistakes = [r["i"] for r in rows if r["status"] in MISTAKE_STATUSES and (float(r["score"] or 0) >= thr or r.get("user"))]
    not_recited = sum(r["status"] == "pending" for r in rows)
    n_recited = len(rows) - not_recited
    return {"n_words": len(rows), "n_recited": n_recited, "n_mistakes": len(mistakes), "mistakes": mistakes,
            "hinted": [r["i"] for r in rows if r.get("hinted")], "not_recited": not_recited, "threshold": thr,
            "accuracy": round(1 - len(mistakes) / n_recited, 4) if n_recited else 0.0}


def state_after_mark(st: dict, event: str) -> dict:
    """ui_logic.js stateAfterMark in Python (X2.12 after Stop): + Mistake makes the word a mistake (wrong, 1), + Correct
    and Remove make it correct (ok, 0, not lost); a user verdict, never concealed."""
    out = dict(st or {"status": "pending", "score": 0, "hyp": None})
    if event == "mistake":
        out.update(status="wrong", score=1)
    else:
        out.update(status="ok", score=0, lost=False)
    out.update(user=True, concealed=False)
    return out


def _when(t: str | None) -> dt.datetime | None:
    try:
        return dt.datetime.fromisoformat(str(t)).replace(tzinfo=None) if t else None
    except ValueError:
        return None


def apply_marks(words: list[dict], marks: list[dict], t_from: dt.datetime, t_to: dt.datetime | None) -> list[dict]:
    """A saved session's state words as the page drew them once it finished: the marks made on its words from its
    start (t_from) until the next session started (t_to, None: no next session; Start clears the page) applied in
    order (stateAfterMark); a mark undone by a double tap again counts for nothing (issue #24: effective_marks over the
    whole file, then the window). words carry surah / ayah / idx."""
    at = {(w["surah"], w["ayah"], w["idx"]): k for k, w in enumerate(words)}
    out = list(words)
    for m in effective_marks(marks):
        t = _when(m.get("t"))
        k = at.get((m.get("surah"), m.get("ayah"), m.get("idx")))
        if k is not None and t is not None and t >= t_from and (t_to is None or t < t_to):
            out[k] = state_after_mark(out[k], m["event"])
    return out


class Session:
    """One live session (B3.8): audio in, verdicts out, saved into the profile when it ends."""

    def __init__(self, app: "App", words: list, backend, meta: dict, threshold: float,
                 voice_commands: bool = True, accepted: dict | None = None) -> None:
        self.app, self.words, self.backend, self.meta = app, list(words), backend, meta
        self.id = uuid.uuid4().hex[:10]
        self.created = time.time()
        alt = [(normalize(w.uthmani) or None) for w in words]
        starts = {i: w.surah for i, w in enumerate(self.words) if i > 0 and w.ayah == 1 and w.idx == 0}   # X2.1d
        self.tracker = Tracker([w.norm for w in words], TrackerConfig(threshold=threshold, voice_commands=voice_commands),
                               expected_alt=alt, surah_starts=starts,
                               start_page_end=start_page_end(self.words),   # X2.1c: the start page
                               accepted=accepted or {})                      # X2.17: forms the user accepted
        self.n_initial = self.n_known = len(self.words)   # X2.1d: words in `started` / known by the client
        self.chunks: list[np.ndarray] = []
        self.last_step_samples = 0
        self.folder: Path | None = None
        self.finished = False
        self.save_failed = False            # U1.17: its save raised (e.g. a full phone): it no longer blocks a delete
        self.voice_out: list[dict] = []     # X2.15: fired commands not sent yet (one per state)
        self.voice_fired: list[dict] = []   # every command of the session (session.json)
        self.after_search: dict | None = None   # #20: {first, carry_s} when it goes on from a search (logs)
        # U1.16 (2026-10-10, v0.9): the PC's POST /api/report names the session (folder_name) in a request thread
        # while a decode may run in the executor: step, command, pause, finish, save and folder_name hold this lock
        # (Android: one engine thread)
        self.lock = threading.RLock()

    def started_message(self) -> dict:
        """B3.8 `started`; #36 (v0.15): + before, the cue of the session's first word (before_cue)."""
        m = self.meta
        index_map = self._index_map(0, self.n_initial)
        return {"type": "started", "n_words": self.n_initial, "model": m["model"], "session": self.id,
                "index_map": index_map, "surah": m["surah"], "ayah_from": m["ayah_from"], "ayah_to": m["ayah_to"],
                "before": self.before_cue()}

    def before_cue(self) -> dict:
        """#36: App.before_cue of the session's first word (tracker.first: the first ayah of the session, or the place
        Find where I am found, X2.13)."""
        w = self.words[min(self.tracker.first, len(self.words) - 1)]
        return self.app.before_cue(w.surah, w.ayah, w.idx)

    def audio(self) -> np.ndarray:
        return np.concatenate(self.chunks) if self.chunks else np.zeros(0, dtype=np.float32)

    def push_audio(self, pcm16: bytes) -> bool:
        """Int16 PCM at 16 kHz. True when a decode step is due (~0.8 s of new audio since the last one)."""
        pcm = np.frombuffer(pcm16, dtype="<i2").astype(np.float32) / 32768.0
        self.chunks.append(pcm)
        self.tracker.push_audio(pcm)
        return self.tracker.total_samples - self.last_step_samples >= STEP_SAMPLES

    def go_on_after_search(self, first: int, carry: np.ndarray) -> None:
        """#20 (X2.13): the session goes on from a search (App._go_on_after_search): the reciter is at word `first` (the
        found place's next word; the words before it are not recited, X2.1c) and `carry` is the audio heard from the
        found word on (it opens the session's audio, so the saved recording and the word times include it)."""
        with self.lock:
            self.tracker.first = self.tracker.committed = first
            self.after_search = {"first": first, "carry_s": round(len(carry) / SR, 2)}
            self.push_audio((np.clip(carry, -1.0, 32767 / 32768) * 32768).round().astype("<i2").tobytes())

    def _index_map(self, lo: int, hi: int) -> list[dict]:
        return [{"surah": w.surah, "ayah": w.ayah, "start": i} for i, w in enumerate(self.words[lo:hi], lo) if w.idx == 0]

    def _extend(self) -> None:
        """X2.1d: once the reciter is within expect_window + 20 words of the passage end, append the next surah(s): the
        session follows into them. Never for an explicit ayah range, before anything was heard, after Stop or past
        An-Nas."""
        tr = self.tracker
        if not self.meta.get("continues") or tr.stopped or not tr.started:
            return
        while self.words[-1].surah < 114 and \
                max(tr.committed, tr.cursor + 1) >= len(self.words) - (tr.config.expect_window + 20):
            s = self.words[-1].surah + 1
            new = load_quran().surah(s)
            self.words.extend(new)
            tr.extend([w.norm for w in new], [(normalize(w.uthmani) or None) for w in new], surah=s)

    def reached(self) -> tuple[int, int]:
        """X2.1d: [lo, hi) of the words of the surahs the reciter reached, from the surah of the actual start (X2.1c)
        to the end of the last surah holding a verdict (the start surah when nothing was heard); the passage's other
        surahs are not part of the session (not "not recited")."""
        tr, ws = self.tracker, self.words
        touched = [i for i, st in enumerate(tr.states) if st.status != "pending"]
        a, b = min(touched + [tr.first]), max(touched, default=tr.first)
        lo = next(i for i, w in enumerate(ws) if w.surah == ws[a].surah)
        hi = max(i for i, w in enumerate(ws) if w.surah == ws[b].surah) + 1
        return lo, hi

    def step(self, final: bool = False) -> dict:
        """One decode; a voice command fired in it is applied (next / eyah) and its `voice` goes into this state
        (B3.8; one per state: a second one fired in the same decode goes into the next state, none after Stop)."""
        with self.lock:
            t0 = time.perf_counter()
            self._extend()
            self.tracker.step(self.backend, final)
            self.last_step_samples = self.tracker.total_samples
            self._apply_voice()
            if final:
                self.voice_out.clear()
            extra = {"voice": self.voice_out.pop(0)} if self.voice_out else {}
            return self.state(latency_s=round(time.perf_counter() - t0, 2), **extra)

    def _ayah_bounds(self, i: int) -> tuple[int, int]:
        """First and last session word index of the ayah of word i."""
        key = (self.words[i].surah, self.words[i].ayah)
        a, b = i, i
        while a > 0 and (self.words[a - 1].surah, self.words[a - 1].ayah) == key:
            a -= 1
        while b + 1 < len(self.words) and (self.words[b + 1].surah, self.words[b + 1].ayah) == key:
            b += 1
        return a, b

    def _hint_written(self, i: int, keep_from: float | None = None) -> int:
        """◂ / the voice «الكلمة التالية» on word i (X2.4, U1.1e, #22): tracker.hint(i), then the following parts of
        its written word (يَٰبَنِىَّ = يا + بني) that were not heard yet: pending, or a mistake not said (concealed, or a
        final wrong / skipped verdict that is neither the user's nor hinted). A part already heard, also provisionally,
        is never hinted (tracker.hint would turn a correct word into a hint). Returns the last index revealed."""
        tr = self.tracker
        tr.hint(i, keep_from=keep_from)
        j = i
        while j + 1 < len(tr.states) and is_joined(self.words[j + 1].surah, self.words[j + 1].ayah, self.words[j + 1].idx):
            st = tr.states[j + 1]
            unsaid = not (st.user_marked or st.said or st.hinted) and \
                (st.concealed or (st.final and st.status in ("wrong", "missing")))
            if st.status != "pending" and not unsaid:
                break
            j += 1
            tr.hint(j, keep_from=keep_from)
        return j

    def _apply_voice(self) -> None:
        """X2.15: the commands the tracker fired in the last decode -> voice_out (B3.8 `voice`, with `words`). The engine
        applies next / eyah itself, as ◂ / ⏮ on the word ◂ would reveal (hint / skip_to to the end of its ayah), after
        settling the words heard before the command and keeping the audio after it: words = the revealed ones (Yasser
        plays them). replay: the cursor's ayah from its first word to the cursor; nothing recited yet from the session's
        first word: words None and `before` = the cue of that first word (#36, before_cue). stop / pause are the
        client's (words None)."""
        tr = self.tracker
        fired, tr.voice = tr.voice, []
        for v in fired:
            words = None
            if v["name"] in ("next", "eyah"):
                tr.settle_before(v["t0"])
                i = tr.next_hidden()
                if i is not None and v["name"] == "next":
                    words = [i, self._hint_written(i, keep_from=v["t1"])]   # U1.1e: the whole written word
                elif i is not None:
                    last = self._ayah_bounds(i)[1]
                    tr.skip_to(last + 1, keep_from=v["t1"])
                    words = [i, last]
            elif v["name"] == "replay" and tr.cursor >= tr.first:
                words = [self._ayah_bounds(tr.cursor)[0], tr.cursor]
            out = {**v, "words": words}
            if v["name"] == "replay" and words is None:
                # #36 (user, 2026-10-23): «عاودها» before anything is recited plays what comes before the first word
                out["before"] = self.before_cue()
            self.voice_out.append(out)
            self.voice_fired.append({**out, "at": round(tr.session_time, 2)})

    def state(self, full: bool = False, **extra) -> dict:
        """The tracker's snapshot as a `state` message; the first one after the passage grew (X2.1d) carries
        extended{index_map (the new ayat), n_words}, before any of the new words can be in a state."""
        self._extend()
        snap = self.tracker.snapshot(delta=not full)
        snap["type"] = "state"
        if len(self.words) > self.n_known:
            snap["extended"] = {"index_map": self._index_map(self.n_known, len(self.words)), "n_words": len(self.words)}
            self.n_known = len(self.words)
        snap.update(extra)
        return snap

    def summary(self) -> dict:
        """tracker.summary() over the surahs reached + the Uthmani text of the listed mistakes (the client may be on
        another page)."""
        lo, hi = self.reached()
        s = self.tracker.summary(lo=lo, hi=hi)
        q = load_quran()      # U1.5 (#22): a joined word is named by its written word
        s["words"] = {str(i): written_text(q, self.words[i].surah, self.words[i].ayah, self.words[i].idx)
                      for i in s["mistakes"]}
        return s

    def command(self, msg: dict) -> dict | None:
        """hint / skip_to / mark / unmark / threshold / summary -> the state message to send (None: nothing to send).
        The reply carries reply_to = the command type (B3.8, 2026-10-01): the page turns only for new recitation
        (X2.12b). hint / skip_to without i (X2.4b, 2026-10-09): the next word not heard yet after the cursor (the word a
        voice «الكلمة التالية» reveals) / the rest of its ayah; the reply carries revealed = [i_from, i_to] (None:
        nothing left in the passage), so the page shows them whatever page it was on. hint{i} (D1, 2026-10-10: ◂ on the
        page's earliest bar) replies revealed = [i, i] too. summary{} (D11, 2026-10-10: the long press on ✗ n) only
        replies with the live summary. U1.1e (v0.12, #22): a hint also reveals the joined part of its written word that
        was not heard yet, and revealed = [i, j] spans both (_hint_written)."""
        with self.lock:
            return self._command(msg)

    def _command(self, msg: dict) -> dict | None:
        kind, tr = msg.get("type"), self.tracker
        if kind == "summary":
            return self.state(summary=self.summary(), reply_to=kind)
        if kind in ("hint", "skip_to") and msg.get("i") is None:
            i = tr.next_hidden()
            if i is None:
                return self.state(reply_to=kind, revealed=None)
            if kind == "hint":
                return self.state(reply_to=kind, revealed=[i, self._hint_written(i)])
            last = self._ayah_bounds(i)[1]
            tr.skip_to(last + 1)
            return self.state(reply_to=kind, revealed=[i, last])
        if kind == "hint":
            i = int(msg["i"])
            if not 0 <= i < len(tr.states):     # out of range: nothing to reveal
                return self.state(reply_to=kind, revealed=None)
            return self.state(reply_to=kind, revealed=[i, self._hint_written(i)])
        if kind == "skip_to":
            tr.skip_to(int(msg["i"]))
            return self.state(reply_to=kind)
        if kind in ("mark", "unmark"):
            i = int(msg["i"])
            if not 0 <= i < len(tr.states):
                return None
            before = tr.states[i].status
            if kind == "mark":
                tr.mark(i, str(msg.get("status", "ok")))
            else:
                tr.unmark(i)
            self.meta["corrections"].append({"i": i, "from": before, "to": tr.states[i].status if kind == "mark" else "auto",
                                             "at": round(tr.session_time, 2)})
            return self.state(summary=self.summary(), reply_to=kind)
        if kind == "threshold":
            tr.set_threshold(float(msg["value"]))
            return self.state(summary=self.summary(), reply_to=kind)
        return None

    def pause(self) -> list[dict]:
        """X2.1b: finish what was heard (not final: words without enough evidence stay provisional). B3.15: the client
        pauses the microphone for ❚❚ and while Yasser plays a voice command's words (X2.14), so the reciter has seen
        the app react: the same command said after the pause is a new one, not the command said twice (REPEAT_S)."""
        with self.lock:
            st = self.step()
            st["paused"] = True
            self.tracker.last_fired.clear()
            return [st, {"type": "paused"}]

    def finish(self) -> dict:
        """Save into the profile (X2.9) once and return the `done` message; call it after the final step. done.nav (D11,
        2026-10-10): the saved sessions around this one (Profile.session_nav; not saved: older = the newest)."""
        with self.lock:
            if not self.finished:
                try:
                    self.folder = self.save()
                except Exception:
                    self.save_failed = True     # a full disk must not lock Settings > Space used (U1.17)
                    raise
                self.finished = True
            s = self.summary()
            folder = self.folder.name if self.folder else None
            s.update(type="done", session=self.id, folder=folder, nav=self.app.profile.session_nav(folder))
            return s

    def stop(self) -> list[dict]:
        """For synchronous transports (Android): final decode + save -> [state, done]."""
        return [self.step(final=True), self.finish()]

    def _doc(self) -> tuple[dict, list[dict]]:
        """session.json and decodes.jsonl of what was heard so far (save)."""
        tr, m = self.tracker, self.meta
        # X2.1d: rows, summary and history cover the surahs reached (row "i" stays the session word index: the one of
        # the client and of `corrections`; `passage` says where index 0 is)
        lo, hi = self.reached()
        w0, w1 = self.words[lo], self.words[hi - 1]
        rows = [{"i": i, "surah": w.surah, "ayah": w.ayah, "idx": w.idx, "word": w.simple, "uthmani": w.uthmani,
                 "status": st.status, "score": round(st.score, 3), "heard": st.hyp, "hinted": st.hinted, "lost": st.lost,
                 "concealed": st.concealed,         # D7 (2026-10-10): a lost word still a bar (session cut off)
                 "user": st.user_marked, "t0": st.t_start, "t1": st.t_end}
                for i, w, st in zip(range(lo, hi), self.words[lo:hi], tr.states[lo:hi])]
        ayah_to = m["ayah_to"] if w0.surah == m["surah"] else load_quran().n_ayat(w0.surah)
        doc = {"app": APP_NAME, "model": m["model"], "mode": m.get("mode"), "started_at": m["started"].isoformat(),
               "ended_at": self.app.clock().isoformat(), "surah": w0.surah, "ayah_from": w0.ayah,
               "ayah_to": ayah_to, "surah_to": w1.surah, "passage": {"surah": m["surah"], "ayah_from": m["ayah_from"]},
               "threshold": tr.config.threshold, "duration_s": round(tr.session_time, 2),
               "summary": tr.summary(lo=lo, hi=hi), "words": rows, "corrections": m.get("corrections", []),
               "revealed_before_start": m.get("revealed", []),
               "voice_commands": tr.config.voice_commands, "voice": self.voice_fired}       # X2.15
        # every decode, plus the words dropped by the voice / foreign rules (B3.15, X2.16)
        lines = sorted([{"t": t, "hyp": h} for t, h in tr.decode_log] + list(tr.voice_log), key=lambda x: x["t"])
        return doc, lines

    @staticmethod
    def _files(doc: dict, lines: list[dict]) -> dict[str, bytes]:
        """The text files of a session folder (the audio aside)."""
        return {"session.json": json.dumps(doc, ensure_ascii=False, indent=1).encode("utf-8"),
                "decodes.jsonl": "".join(json.dumps(x, ensure_ascii=False) + "\n" for x in lines).encode("utf-8"),
                "summary.md": summary_markdown(doc, load_quran()).encode("utf-8")}

    def _folder_key(self) -> tuple[int, int, dt.datetime]:
        """(surah, ayah, started) the session's folder is named after (X2.9): session.json's surah and ayah_from (the
        first of its words in the surahs reached, X2.1d) and the start time."""
        w0 = self.words[self.reached()[0]]
        return w0.surah, w0.ayah, self.meta["started"]

    def folder_name(self) -> str:
        """U1.16 (v0.9, user 2026-10-11): the session's folder name, the saved one, else the one save() would create now
        (Profile.new_session_folder: a same-second twin's " (k)" included). The bug report names a running session by
        it."""
        with self.lock:     # the naming too: a save meanwhile would make its folder a " (2)" twin (review 2026-10-11)
            if self.folder is not None:
                return self.folder.name
            return self.app.profile.new_session_folder(*self._folder_key()).name

    def save(self) -> Path | None:
        with self.lock:
            if self.tracker.total_samples < SR:     # nothing recited
                return None
            doc, lines = self._doc()
            folder = self.app.profile.new_session_folder(*self._folder_key())   # = folder_name() until now
            folder.mkdir(parents=True, exist_ok=True)
            (folder / "audio.wav").write_bytes(wav_bytes(self.chunks))
            for name, data in self._files(doc, lines).items():
                (folder / name).write_bytes(data)
            self.app.profile.session_saved()
            return folder


class SearchSession:
    """X2.13 Find where I am: listens (same transport and messages as a Session), transcribes the last SEARCH_WINDOW_S
    seconds at every step and reports the place once it is certain. Never saved, never in the history.
    #20 (emulator 2026-10-17): once found, it keeps the audio from the found word on (`carry`: CARRY_MARGIN_S before
    that word's end, like the tracker's own cut after a commit, and everything heard since); the session started with
    `after_search` = this id begins with it at found.next (App.start), so the words said while that session was being
    started are heard, never lost."""

    kind = "search"
    CARRY_MARGIN_S = TrackerConfig.cut_margin_s
    CARRY_MAX_S = SEARCH_WINDOW_S         # a session started later than this after the find gets no carry

    def __init__(self, app: "App", backend) -> None:
        self.app, self.backend = app, backend
        self.id = uuid.uuid4().hex[:10]
        self.created = time.time()
        self.buffer = np.zeros(0, dtype=np.float32)
        self.total = self.last_step = 0
        self.found: dict | None = None
        self.hyp = ""
        self.carry: np.ndarray | None = None   # #20: the audio from the found word on (float32, 16 kHz)

    def started_message(self) -> dict:
        return {"type": "started", "search": True, "session": self.id}

    def push_audio(self, pcm16: bytes) -> bool:
        pcm = np.frombuffer(pcm16, dtype="<i2").astype(np.float32) / 32768.0
        self.buffer = np.concatenate([self.buffer, pcm])[-int(SEARCH_WINDOW_S * SR):]
        self.total += len(pcm)
        if self.carry is not None:
            self.carry = np.concatenate([self.carry, pcm])
            if len(self.carry) > self.CARRY_MAX_S * SR:
                self.carry = None              # no session followed: it would no longer start at the found word
        return self.total - self.last_step >= 2 * STEP_SAMPLES

    def step(self, final: bool = False) -> dict:
        self.last_step = self.total
        if self.found is None and len(self.buffer) >= 2 * SR:
            tr = self.backend.transcribe(self.buffer, SR)
            toks, src = [], []                  # the normalized words heard, and the transcript word of each
            for k, w in enumerate(tr.words):
                for t in normalize(w.text).split():
                    toks.append(t)
                    src.append(k)
            keep = clean_hyp(toks)
            toks, src = [toks[k] for k in keep], [src[k] for k in keep]
            self.hyp = " ".join(toks)
            self.found, j = find_place(toks, load_quran())
            if self.found is not None:
                end = tr.words[src[j]].end
                end = len(self.buffer) / SR if end is None else min(float(end), len(self.buffer) / SR)
                self.carry = self.buffer[max(0, int((end - self.CARRY_MARGIN_S) * SR)):].copy()
        return {"type": "search", "session": self.id, "hyp": self.hyp, "found": self.found,
                "heard_s": round(self.total / SR, 1)}

    def command(self, msg: dict) -> dict | None:
        return None

    def pause(self) -> list[dict]:
        return [self.step(), {"type": "paused"}]

    def finish(self) -> dict:
        return {"type": "done", "search": True, "session": self.id, "found": self.found, "folder": None}

    def stop(self) -> list[dict]:
        return [self.step(final=True), self.finish()]


class App:
    def __init__(self, profile: Profile, asr_factory: Callable[[str], object], default_model: str,
                 clock: Callable[[], dt.datetime] = dt.datetime.now) -> None:
        self.profile = profile
        self.asr_factory = asr_factory          # model name -> loaded ASR backend (platform code)
        self.default_model = default_model
        self.clock = clock
        self.live: dict[str, Session] = {}
        self.last_clip: dict | None = None      # X2.18: the last replay's {level, gain_db, limited, seconds} (logs)
        self.last_search: SearchSession | None = None   # #20: the search a start{after_search} goes on from

    def chapters(self) -> list[dict]:
        return json.loads((DATA / "chapters.json").read_text(encoding="utf-8"))

    def tajweed_legend(self) -> dict:
        return {"colors": TAJWEED_COLORS, "labels": TAJWEED_LABELS, "css": tajweed_css()}

    def locate(self, surah: int, ayah: int = 1) -> dict:
        return {"page": page_of(surah, ayah), "juz": juz_of(surah, ayah), "hizb": hizb_of(surah, ayah)}

    def history_for(self, words) -> list[dict | None]:
        hist = self.profile.history()
        return [summarize(hist.get(word_key(w["surah"], w["ayah"], w["idx"]) if isinstance(w, dict) else w.key))
                for w in words]

    def _page_spans(self, n: int) -> dict[tuple[int, int], list[int]]:
        """(surah, ayah) -> [first, end) word range on page n, in reading order: from the 15-line layout, or from the
        page table (whole ayat) when there is no layout."""
        spans: dict[tuple[int, int], list[int]] = {}
        for _ln, s, a, idx, cnt in page_lines(n):
            lo, hi = spans.get((s, a), (idx, idx + cnt))
            spans[(s, a)] = [min(lo, idx), max(hi, idx + cnt)]
        if spans:
            return spans
        q = load_quran()
        s, a = page_start(n)
        end = page_start(n + 1) if n < n_pages() else (115, 1)
        while (s, a) < end and s <= 114:
            spans[(s, a)] = [0, len(q.ayah(s, a).words)]
            a += 1
            if a > q.n_ayat(s):
                s, a = s + 1, 1
        return spans

    @staticmethod
    def _page_ayahs(spans: dict[tuple[int, int], list[int]]) -> list[dict]:
        """The page's ayah entries (page() `ayahs`, what mushaf_lines reads) from its _page_spans."""
        q = load_quran()
        out, start = [], 0
        for (s, a), (lo, hi) in spans.items():
            out.append({"surah": s, "ayah": a, "start": start, "n": hi - lo, "first_idx": lo,
                        "n_total": len(q.ayah(s, a).words), "first_of_surah": a == 1 and lo == 0,
                        "surah_name": q.chapter_name(s), "surah_name_ar": q.chapter_name_ar(s),
                        "basmala": a == 1 and lo == 0 and s not in (1, 9)})
            start += hi - lo
        return out

    def starter_hint(self, page: int) -> dict:
        """#40 (X2.2, user 2026-10-24: "in blind mode, and page still empty … I need to know the eyats before … the
        minimum lines + a random 0 to 2 extra lines"): what a pull down on the empty page shows, the last lines of the
        page before that tell where this page starts. -> {page, prev_page (None for page 1), k and header
        (quran_text.context_words of the page's first ayah: every page begins at an ayah's first word), surah_start:
        {surah, name, header_on_prev} | None (the page opens a surah: its header is the hint; header_on_prev on the 18
        pages whose header is line 15 of the page before, U1.1b), n_min (the minimum lines), lines (line numbers 1-15
        of prev_page, top to bottom: the n_min minimum lines last, up to 2 candidate lines above them, never above the
        page's first line holding something; the page draws 0-2 of them at random from its own page{prev_page} call),
        words (the k words of the context, {surah, ayah, idx} in reading order)}. A surah header on this page itself:
        no line (the toast names the surah)."""
        q = load_quran()
        n = max(1, min(int(page), n_pages()))
        s, a = page_start(n)
        k, header = context_words(s, a)
        prev = n - 1 if n > 1 else None
        out = {"page": n, "prev_page": prev, "k": k, "header": header, "surah_start": None, "n_min": 0, "lines": [],
               "words": []}
        lines = mushaf_lines(prev, self._page_ayahs(self._page_spans(prev))) if prev else []
        if a == 1:
            head = next((ln["n"] for ln in lines if ln["kind"] == "surah" and ln.get("surah") == s), None)
            out["surah_start"] = {"surah": s, "name": q.chapter_name(s), "header_on_prev": head is not None}
            if head is None:
                return out
            at = [head]
        else:
            ctx, b = [], a - 1
            while len(ctx) < k and b >= 1:      # the context never leaves the surah (context_words)
                ctx = list(q.ayah(s, b).words) + ctx
                b -= 1
            ctx = ctx[len(ctx) - k:]
            out["words"] = [{"surah": w.surah, "ayah": w.ayah, "idx": w.idx} for w in ctx]
            word_line = {(ws, wa, i): ln for ln, ws, wa, idx, cnt in page_lines(prev) for i in range(idx, idx + cnt)}
            at = [word_line[(w.surah, w.ayah, w.idx)] for w in ctx if (w.surah, w.ayah, w.idx) in word_line]
            if header:                          # the surah's header (and basmala) name the start of the context
                at += [ln["n"] for ln in lines if ln["kind"] in ("surah", "basmala") and ln.get("surah") == s]
            if not at:
                return out
        lo, hi = min(at), max(at)
        top = max(lo - 2, min(ln["n"] for ln in lines if ln["kind"] != "empty"))
        out.update(n_min=hi - lo + 1, lines=list(range(top, hi + 1)))
        return out

    def page(self, n: int) -> dict:
        """One mushaf page (Madani 604-page numbering), exactly the words its 15 lines hold (an ayah running over two
        pages shows its first words on one and the rest on the next): words with tajweed html and `joined` (U1.1e),
        ayah entries, lines, history (U1.1b, U1.2b)."""
        q = load_quran()
        n = max(1, min(int(n), n_pages()))
        spans = self._page_spans(n)
        words, ayahs = [], self._page_ayahs(spans)
        for (s, a), (lo, hi) in spans.items():
            ay = q.ayah(s, a)
            htmls = ayah_word_html(s, a)
            for w, h in zip(ay.words[lo:hi], htmls[lo:hi]):
                # U1.1e (#22): joined = no written word of its own (the previous one holds it): the page draws one span
                words.append({"surah": w.surah, "ayah": w.ayah, "idx": w.idx, "html": h, "uthmani": w.uthmani,
                              "simple": w.simple, "norm": w.norm, "joined": w.idx > 0 and not h.strip()})
        s0, a0 = next(iter(spans))
        return {"page": n, "n_pages": n_pages(), "juz": juz_of(s0, a0), "hizb": hizb_of(s0, a0),
                "start": {"surah": s0, "ayah": a0}, "words": words, "ayahs": ayahs,
                "lines": mushaf_lines(n, ayahs), "history": self.history_for(words)}

    def history(self, surah: int, ayah_from: int, ayah_to: int) -> dict:
        words = load_quran().passage(surah, ayah_from, ayah_to)
        return {"items": [{"surah": w.surah, "ayah": w.ayah, "idx": w.idx, **h}
                          for w, h in zip(words, self.history_for(words)) if h]}

    def progress(self) -> dict:
        return compute_progress(self.profile.history(), load_quran(), self.clock().date())

    def stats(self) -> dict:
        """U1.19 (issue #13): the Stats page, computed only when it opens (never inside progress(), B3.8)."""
        return compute_stats(self.profile.history(), load_quran(), self.clock().date())

    def listen_targets(self) -> dict:
        """U1.13 quick buttons (Weak page, Next to learn, Manzil) from the Progress numbers (B3.14)."""
        return listen.listen_targets(self.progress(), load_quran())

    def listen_plan(self, params: dict) -> dict:
        """U1.13: {tab: ayah, surah, ayah_from, ayah_to} | {tab: page, page_from, page_to} -> the clips to play (B3.14)."""
        return listen.listen_plan(params, load_quran())

    def reciter_clip(self, params: dict) -> dict:
        """B3.8 reciter_clip{surah, ayah, from_idx?, to_idx?} -> the reciter's ayah file and the part the players cut
        for a voice command (X2.15, D4.6): words from_idx..to_idx (first occurrences), t0_ms from the file start, t1_ms
        None = to the end of the file. Defaults: the whole ayah; indices are clamped to the ayah's words; timed False
        (no timings for that ayah) = the whole file."""
        q = load_quran()
        surah, ayah = int(params["surah"]), int(params["ayah"])
        if not (1 <= surah <= 114 and 1 <= ayah <= q.n_ayat(surah)):
            raise ValueError(f"no ayah {surah}:{ayah}")
        last = len(q.ayah(surah, ayah).words) - 1

        def idx(v, default: int) -> int:
            return default if v is None or str(v).strip() in ("", "null", "undefined") else int(v)
        lo = max(0, min(idx(params.get("from_idx"), 0), last))
        hi = max(lo, min(idx(params.get("to_idx"), last), last))
        t0, t1 = word_times.clip_ms(surah, ayah, lo, hi)
        key = listen.ayah_key(surah, ayah)
        return {"key": key, "url": listen.RECITER["base_url"] + key + ".mp3", "t0_ms": t0, "t1_ms": t1,
                "timed": word_times.timeline(surah, ayah) is not None, "surah": surah, "ayah": ayah,
                "from_idx": lo, "to_idx": hi,
                "gain": RECITER_GAIN}   # X2.18 (2026-10-10): his -14.2 LUFS at the -18 of every Recite sound (volume)

    def before_cue(self, surah: int, ayah: int, idx: int = 0) -> dict:
        """#36 (X2.15, user 2026-10-23: "it should play the Eya before this page, but if a new sourat starts at the
        beginning of this page then just say the sourat name in arabic 'sourat al-bakarah'"): what comes before a
        session's first word (surah:ayah word idx), for a replay said before anything is recited and the car's start
        (B3.8 `before`). Word idx > 0 (a session going on from Find where I am inside an ayah): its words 0..idx-1
        {kind: words, surah, ayah, clip}; an ayah a > 1: Yasser's ayah a-1 {kind: ayah, surah, ayah: a-1, clip} (a clip
        longer than BEFORE_MAX_S: from the first word he starts in its last BEFORE_TAIL_S, repeats included, to its end);
        an ayah 1: the surah's name for the device's offline Arabic voice {kind: surah, surah, name, text: «سورة …»,
        fallback} (no such voice: Yasser's basmala 001001, the ta'awwudh 001000 before Al-Fatihah and At-Tawbah). clip /
        fallback = reciter_clip answers. Every page begins at an ayah's first word, so before a page's first ayah = before
        the page."""
        q = load_quran()
        surah, ayah, idx = int(surah), int(ayah), int(idx)
        if idx > 0:
            return {"kind": "words", "surah": surah, "ayah": ayah,
                    "clip": self.reciter_clip({"surah": surah, "ayah": ayah, "from_idx": 0, "to_idx": idx - 1})}
        if ayah > 1:
            a = ayah - 1
            clip = self.reciter_clip({"surah": surah, "ayah": a})
            t = word_times.timeline(surah, a)
            end = None if t is None else (t[1] if clip["t1_ms"] is None else clip["t1_ms"] / 1000)
            if end is not None and end > BEFORE_MAX_S:
                # #36 review: the cap is measured on the clip played (46:22's file holds the ayah twice, its clip only the
                # first reading) and cuts by time over every word Yasser says, repeats included (50:27: words 0-8, 0-8,
                # 5-8, 9: by first occurrences the cue was word 9 alone, 3.2 s)
                said = [(k, s) for k, s in t[0] if s < end]
                k, s = next(((k, s) for k, s in said if s >= end - BEFORE_TAIL_S), said[-1])
                clip.update(from_idx=k, t0_ms=int(round(s * 1000)))
            return {"kind": "ayah", "surah": surah, "ayah": a, "clip": clip}
        if surah in listen.NO_BASMALA:
            fallback = {"key": TAAWWUDH_KEY, "url": listen.RECITER["base_url"] + TAAWWUDH_KEY + ".mp3", "t0_ms": 0,
                        "t1_ms": None, "timed": False, "surah": 1, "ayah": 0, "from_idx": 0, "to_idx": len(TAAWWUDH) - 1,
                        "gain": RECITER_GAIN}
        else:
            fallback = self.reciter_clip({"surah": 1, "ayah": 1})          # the basmala: 1:1's file (BASMALA_KEY)
        return {"kind": "surah", "surah": surah, "name": q.chapter_name(surah), "text": "سورة " + q.chapter_name_ar(surah),
                "fallback": fallback}

    def versions(self, platform_name: str = "pc") -> dict:
        """B3.8 versions (U1.12 About title): the app version (recite.__version__) and the engine's own components;
        the PC server adds its runtimes and the served model's state, Android answers this call in Kotlin."""
        return {"app": __version__, "platform": platform_name,
                "items": [["Python", platform.python_version()], ["numpy", np.__version__]],
                "profile": str(self.profile.root)}

    def settings(self) -> dict:
        return self.profile.settings()

    def save_settings(self, changes: dict) -> dict:
        return self.profile.save_settings(changes)

    def accepted_forms(self) -> dict[str, set[str]]:
        """X2.17: {expected word (N0): heard forms (N0)} the user accepted: a correct reading of theirs (a session verdict
        overruled, + Correct on a mistake, a mistake removed) that carries what the model heard. Keyed by the word's
        text, so the same pair is accepted wherever that word comes back; a removed reading no longer counts."""
        q, out = load_quran(), {}
        for key, readings in self.profile.history().items():
            forms = {normalize(r.accepts).replace(" ", "") for r in readings if r.outcome == "ok" and r.accepts}
            forms.discard("")
            if not forms:
                continue
            s, a, i = (int(x) for x in key.split(":"))
            try:
                w = q.ayah(s, a).words[i]
            except (KeyError, IndexError):
                continue
            out.setdefault(w.norm, set()).update(forms)
        return out

    # ---- Settings > Space used (U1.17, issue #14)
    def recording(self) -> bool:
        """A recitation not saved yet (running, paused, or stopping before its save; the car's too). A search is never
        saved; a session whose save failed (a full disk) does not count, so the user can free space."""
        return any(isinstance(s, Session) and not s.finished and not s.save_failed for s in list(self.live.values()))

    def storage(self) -> dict:
        """storage{} -> {rows: [{id, bytes, files, deletable, orphans?, sessions?, marks?, folders?}] in STORAGE_KINDS
        order, recording}. Android's android_storage adds the phone's rows (Listen audio, the model, the app, ...)."""
        rows = self.profile.storage()
        return {"rows": [rows[k] for k in STORAGE_KINDS], "recording": self.recording()}

    def storage_delete(self, params: dict) -> dict:
        """storage_delete{what} -> {ok: true, what, bytes, files, kept} | {ok: false, what, reason}: the recordings and
        the history are refused while a recitation is not saved (its save writes those files). ValueError for a kind it
        never deletes."""
        what = str(params.get("what") or "")
        if what not in STORAGE_DELETABLE:
            raise ValueError(f"{what!r} cannot be deleted here")
        if what in NEEDS_NO_SESSION and self.recording():
            return {"ok": False, "what": what, "reason": RECITING}
        r = self.profile.delete(what)
        if what == "recordings":       # the voice kept in memory for replay goes too
            for k in [k for k, s in list(self.live.items()) if isinstance(s, Session) and s.finished]:
                self.live.pop(k, None)
        return r

    def add_mark(self, surah: int, ayah: int, idx: int, event: str) -> dict:
        """X2.12 for a word outside the running session: + Mistake / + Correct / Remove last, and "undo" (issue #24: a
        double tap again cancels the word's newest mark still in effect). + Correct right after a mistake verdict keeps
        what was heard then: that form is accepted for this word from then on (X2.17)."""
        key = word_key(surah, ayah, idx)
        last = (self.profile.history().get(key) or [None])[-1]
        heard = last.heard if event == "correct" and last is not None and last.outcome == "mistake" else None
        self.profile.add_mark(surah, ayah, idx, event, heard=heard)
        return {"key": key, "history": summarize(self.profile.history().get(key))}

    def sessions(self, limit: int = 30) -> list[dict]:
        out = []
        for folder, d in reversed(self.profile.session_docs()):
            try:
                out.append({"folder": folder, "surah": d["surah"], "ayah_from": d["ayah_from"], "ayah_to": d["ayah_to"],
                            "surah_to": d.get("surah_to", d["surah"]), "accuracy": d["summary"]["accuracy"],
                            "n_mistakes": d["summary"]["n_mistakes"], "duration_s": d["duration_s"]})
            except KeyError:
                continue
            if len(out) >= limit:
                break
        return out

    def clip(self, sid: str, start: float, end: float, margin: float = 0.35, folder: str | None = None) -> bytes:
        """WAV of a session between start and end (+ margin): live audio, or the saved file after a restart (B3.7).
        X2.18 (2026-10-10): brought to one loudness (recite/loudness.normalize_replay: -18 LUFS-like, -12..+30 dB, peak
        <= -1 dBFS); what it did stays in last_clip {level, gain_db, limited, seconds} for the logs. The saved audio never
        changes."""
        sess = self.live.get(sid)
        path = self.profile.sessions_dir / folder / "audio.wav" if folder and FOLDER_RE.fullmatch(folder) else None
        if sess is not None:
            audio = sess.audio()
        elif path is not None and path.exists():
            audio = read_wav(path)
        elif path is not None and (path.parent / "session.json").exists():
            raise LookupError("this session's recording was deleted")      # Settings > Space used (U1.17)
        else:
            raise LookupError("unknown session")
        a = int(max(0.0, start - margin) * SR)
        b = int(min(len(audio) / SR, end + margin) * SR)
        if b <= a:
            raise ValueError("empty range")
        y, info = normalize_replay(audio[a:b], SR)
        self.last_clip = {**info, "seconds": round((b - a) / SR, 2)}
        return wav_bytes(y)

    def session_load(self, params: dict) -> dict:
        """D11 (2026-10-10) session_load{folder?, rel?: older | newer, threshold?}: a saved session onto the page, as the
        page had it once it finished (U1.5 ◀ / ▶). {} = the newest; rel moves from folder (no folder: from the session in
        memory, newer than every saved one). -> {folder, nav, started_at, ended_at, duration_s, model, mode, threshold,
        index_map (every ayah of its rows), words (B3.8 state words of its rows; a row still pending without a mark of
        the user's is left out: the page draws a word it was not sent as pending), summary (`done` at the threshold:
        its own by default, every row counted)}. The marks made on its words before the next session started are
        applied (X2.12, stateAfterMark); a v0.5 verdict whose heard form is the word reads correct (issue #5).
        LookupError: no such session / past the ends."""
        def arg(k):
            v = params.get(k)
            return None if v is None or str(v).strip() in ("", "null", "undefined") else str(v)
        folder, rel = arg("folder"), arg("rel")
        if rel not in (None, "older", "newer"):
            raise ValueError(f"rel is older or newer, not {rel!r}")
        names = self.profile.session_folders()
        if folder is not None and (not FOLDER_RE.fullmatch(folder) or folder not in names):
            raise LookupError(f"no saved session {folder!r}")
        target = (folder or (names[-1] if names else None)) if rel is None else \
            self.profile.session_nav(folder, names)[rel]
        if target is None:
            raise LookupError("no saved session there")
        doc = json.loads((self.profile.sessions_dir / target / "session.json").read_text(encoding="utf-8"))
        thr = float(arg("threshold") or doc.get("threshold", TrackerConfig.threshold))
        words = []
        for r in doc.get("words", []):
            w = {"i": r["i"], "surah": r["surah"], "ayah": r["ayah"], "idx": r["idx"], "status": r["status"],
                 "score": r.get("score") or 0, "hyp": r.get("heard"), "hinted": bool(r.get("hinted")),
                 "lost": bool(r.get("lost")), "concealed": bool(r.get("concealed", False)), "user": bool(r.get("user")),
                 "t0": None if r.get("t0") is None else round(r["t0"], 2),
                 "t1": None if r.get("t1") is None else round(r["t1"], 2)}
            if not w["user"] and heard_is_the_word(r):      # issue #5: as the history reads it
                w.update(status="ok", score=0.0, lost=False, concealed=False)
            words.append(w)
        k = names.index(target)
        t_next = None
        if k + 1 < len(names):
            try:
                t_next = dt.datetime.strptime(names[k + 1][:19], "%Y-%m-%d %H-%M-%S")
            except ValueError:
                t_next = None
        t_from = _when(doc.get("started_at"))
        if t_from is not None:
            words = apply_marks(words, self.profile.marks(), t_from, t_next)
        q = load_quran()      # U1.5 (#22): a joined word's row holds uthmani "": its written word names it
        rows = {r["i"]: r for r in doc.get("words", [])}
        nav = self.profile.session_nav(target, names)
        summary = rows_summary(words, thr)
        # the mistakes' rows only (_row_text reads the ayah's tajweed html: not for every word of a long session)
        summary.update(words={str(i): _row_text(q, rows[i]) if i in rows else None for i in summary["mistakes"]},
                       type="done", session="saved", folder=target, nav=nav)
        index_map, seen = [], set()
        for w in words:                             # the ayat of its rows (each from its first word)
            if (w["surah"], w["ayah"]) not in seen:
                seen.add((w["surah"], w["ayah"]))
                index_map.append({"surah": w["surah"], "ayah": w["ayah"], "start": w["i"] - w["idx"]})
        return {"folder": target, "nav": nav, "started_at": doc.get("started_at"), "ended_at": doc.get("ended_at"),
                "duration_s": doc.get("duration_s"), "model": doc.get("model"), "mode": doc.get("mode"),
                "threshold": thr, "surah": doc.get("surah"), "ayah_from": doc.get("ayah_from"),
                "ayah_to": doc.get("ayah_to"), "surah_to": doc.get("surah_to", doc.get("surah")),
                "index_map": index_map,
                "audio": (self.profile.sessions_dir / target / "audio.wav").is_file(),   # U1.17: its recording kept
                # a row still pending without a mark of the user's is what the page draws for a word it was not sent:
                # left out (an Al-Baqarah session's rows were 0.7-0.9 MB of JSON per ◀ / ▶, review of 2026-10-11)
                "words": [{k2: v for k2, v in w.items() if k2 not in ("surah", "ayah", "idx")} for w in words
                          if w["status"] != "pending" or w["user"]],
                "summary": summary}

    def report(self, params: dict) -> dict:
        """U1.16 Report a bug (D3, v0.9, user 2026-10-11, issue #8) report{session?, folder?, screenshot?, device?,
        platform?} -> {title, body, url, session_name}: the prefilled GitHub issue (recite/report.py) naming the app
        version (device: the platform's facts; the PC: recite's), the phone or computer, the screenshot the platform
        took (android_report_shot's {ok, name, folder} or a name; None: none) and the session (session_name, see
        report_session). Writes nothing, sends nothing: the user describes the bug and submits the issue."""
        folder, note = self.report_session(params)
        shot = params.get("screenshot")
        if isinstance(shot, str) and isinstance(params.get("screenshot_folder"), str) and params["screenshot_folder"]:
            shot = {"ok": True, "name": shot, "folder": params["screenshot_folder"]}   # Android: the shot's real folder
        plat = params.get("platform") or "pc"
        title, body = issue_text({"platform": plat, "device": params.get("device"), "screenshot": shot,
                                  "session": folder, "session_note": note})
        return {"title": title, "body": body, "url": issue_url(report_repo(plat), title, body),
                "session_name": session_label(folder, note)}

    def report_session(self, params: dict) -> tuple[str | None, str | None]:
        """(folder name, note) of the session a bug report names: params.session (the page's session: its id, or {id,
        folder}) running or paused -> the folder it will be saved under, "running, not saved yet"; finished -> its saved
        folder (too short to be saved: no folder, a note saying so); else params.folder (or session.folder: a saved
        session the page shows, U1.5) when it is one; else (None, None): "no session". A search (X2.13) is none."""
        s = params.get("session")
        sid = s.get("id") if isinstance(s, dict) else s
        folder = (s.get("folder") if isinstance(s, dict) else None) or params.get("folder")
        sess = self.live.get(sid) if isinstance(sid, str) else None
        if isinstance(sess, Session):
            with sess.lock:     # PC: the stop saves it in another thread; the check and the name are one moment
                if not sess.finished:
                    return sess.folder_name(), "running, not saved yet"
                if sess.folder is not None:
                    return sess.folder.name, None
            if not (isinstance(folder, str) and folder):
                return None, "too short to be saved"
        if isinstance(folder, str) and FOLDER_RE.fullmatch(folder) and folder in self.profile.session_folders():
            return folder, None
        return None, None

    def start(self, params: dict, backend=None) -> Session | SearchSession:
        """B3.8 start{surah, ayah_from, ayah_to?, model, mode, threshold, revealed[], voice_commands} or start{search:
        true} (X2.13); a platform that loads models asynchronously passes the loaded backend. voice_commands (X2.15,
        default true; off: no command fires, the command words are still dropped from the verdicts). after_search (#20:
        the id of the search that found the place): the session goes on from it (_go_on_after_search)."""
        if params.get("search"):
            self.last_search = SearchSession(self, backend if backend is not None else self.asr_factory(
                params.get("model") or self.default_model))
            return self.last_search
        q = load_quran()
        surah = int(params["surah"])
        a_from = int(params.get("ayah_from", 1))
        a_to = int(params.get("ayah_to") or q.n_ayat(surah))
        model = params.get("model") or self.default_model
        backend = backend if backend is not None else self.asr_factory(model)
        # X2.1d: a session that runs to the end of its surah follows the reciter into the next ones (Session._extend);
        # it starts with the page's later surahs too, so that starting anywhere on the page (X2.1c) finds them
        words = q.passage(surah, a_from, a_to)
        continues = a_to >= q.n_ayat(surah)
        if continues:
            page, s_last = page_of(surah, a_from), surah
            while s_last < 114 and page_of(s_last + 1, 1) == page:
                s_last += 1
                words += q.surah(s_last)
        voice_on = params.get("voice_commands") is None or bool(params["voice_commands"])
        meta = {"surah": surah, "ayah_from": a_from, "ayah_to": a_to, "model": model, "mode": params.get("mode"),
                "started": self.clock(), "revealed": params.get("revealed") or [], "corrections": [],
                "continues": continues, "voice_commands": voice_on}
        s = Session(self, words, backend, meta, threshold=float(params.get("threshold", TrackerConfig.threshold)),
                    voice_commands=voice_on, accepted=self.accepted_forms())
        self._go_on_after_search(s, params.get("after_search"))
        self.live[s.id] = s
        while len(self.live) > MAX_LIVE:
            del self.live[min(self.live, key=lambda k: self.live[k].created)]
        return s

    def _go_on_after_search(self, s: Session, search_id) -> None:
        """#20 (emulator 2026-10-17, X2.13): a session started after Find where I am went on at its ayah's word 0 about
        1 s after the search's last decode, without the words said meanwhile (they went to the search), its audio
        beginning inside a word: the first words turned red although they were said. Started with after_search = the
        id of the last search (it found the place), the session starts at found.next (when its passage holds it; the
        words before are not recited, X2.1c) with the search's audio from the found word on (SearchSession.carry). Any
        other start drops the last search."""
        search, self.last_search = self.last_search, None
        if not search_id or search is None or search.id != search_id or search.found is None or search.carry is None:
            return
        nxt = search.found["next"]
        at = (nxt["surah"], nxt["ayah"], nxt["idx"])
        k = next((i for i, w in enumerate(s.words) if (w.surah, w.ayah, w.idx) == at), None)
        if k is not None:
            s.go_on_after_search(k, search.carry)
