"""Canonical Hafs text access: Uthmani (display), imla'i simple (ASR reference), tajweed markup.

Data files live in recite/data/ (see tools/fetch_reference_text.py):
  quran_uthmani.txt       Tanzil Uthmani (with tashkeel, pause marks)      -> display
  quran_simple.txt        Tanzil "simple" imla'i with tashkeel             -> diacritized reference
  quran_simple_clean.txt  Tanzil "simple-clean" imla'i without tashkeel     -> N0 reference
  quran_tajweed.json      quran.com v4 uthmani_tajweed markup per verse     -> tajweed colouring
"""
from __future__ import annotations

import bisect
import gzip
import hashlib
import json
import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from .normalize import alef_insensitive, normalize

DATA = Path(__file__).resolve().parent / "data"
CACHE = DATA / "quran_words.json.gz"      # tools/build_quran_cache.py
CONTEXT = DATA / "ayah_context.json"      # tools/build_ayah_context.py (#40, X2.2 starter hint)
_SOURCES = ("quran_uthmani.txt", "quran_simple.txt", "quran_simple_clean.txt")


def source_fingerprint() -> str | None:
    """SHA-256 prefix of the Tanzil text files the word tables come from; None when they are absent (the phone and
    browser builds ship only the cache)."""
    paths = [DATA / n for n in _SOURCES]
    if not all(p.exists() for p in paths):
        return None
    h = hashlib.sha256()
    for p in paths:
        h.update(p.read_bytes())
    return h.hexdigest()[:16]

# Standalone Uthmani tokens that are not words (pause marks, sajdah, hizb...).
_PAUSE_TOKEN_RE = re.compile("^[ۖ-ۭؐ-ؚ࣓-ࣿـ]+$")


@dataclass(frozen=True)
class Word:
    surah: int
    ayah: int
    idx: int          # 0-based word index inside the ayah
    uthmani: str      # display form with tashkeel (Tanzil Uthmani)
    simple: str       # imla'i form with tashkeel (Tanzil simple)
    norm: str         # N0 normalized form (imla'i, no tashkeel)

    @property
    def key(self) -> str:
        return f"{self.surah}:{self.ayah}:{self.idx}"


@dataclass(frozen=True)
class Ayah:
    surah: int
    ayah: int
    uthmani: str
    simple: str
    simple_clean: str
    words: tuple[Word, ...]

    @property
    def key(self) -> str:
        return f"{self.surah}:{self.ayah}"

    @property
    def norm(self) -> str:
        return " ".join(w.norm for w in self.words)


def _read_tanzil(path: Path) -> dict[tuple[int, int], str]:
    """Read a Tanzil text file. Tanzil prepends the basmala to ayah 1 of every surah except
    1 and 9; we strip it there so ayah 1 holds only its own words (the basmala is recited as a
    separate optional prefix, see recite.align.strip_optional_edges)."""
    out: dict[tuple[int, int], str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        s, a, t = line.split("|", 2)
        s, a, t = int(s), int(a), t.strip()
        if a == 1 and s not in (1, 9):
            toks = t.split()
            if len(toks) > 4 and normalize(" ".join(toks[:4])) == "بسم الله الرحمن الرحيم":
                t = " ".join(toks[4:])
        out[(s, a)] = t
    return out


def uthmani_tokens(text: str) -> list[str]:
    """Split Uthmani text into word tokens, dropping standalone pause-mark tokens."""
    return [t for t in text.split() if not _PAUSE_TOKEN_RE.match(t)]


def _sim(a: str, b: str) -> float:
    from difflib import SequenceMatcher

    return SequenceMatcher(None, a, b).ratio()


def align_display_tokens(u_toks: list[str], s_toks: list[str]) -> list[str]:
    """Map Uthmani tokens onto the imla'i (simple) word segmentation.

    Returns a list with exactly len(s_toks) entries: entry j is the Uthmani text displayed for
    simple word j. When one Uthmani token covers two simple words, the second entry is "" and
    the first carries the whole token; when two Uthmani tokens form one simple word they are
    joined with a space. Uses a small DP over (1:1, 1:2, 2:1) moves scored by letter similarity
    (alef-insensitive so Uthmani spelling differences do not matter)."""
    ua = [alef_insensitive(t) for t in u_toks]
    sa = [alef_insensitive(t) for t in s_toks]
    n, m = len(u_toks), len(s_toks)
    INF = float("inf")
    best: list[list[float]] = [[INF] * (m + 1) for _ in range(n + 1)]
    back: list[list[tuple[int, int] | None]] = [[None] * (m + 1) for _ in range(n + 1)]
    best[0][0] = 0.0
    for i in range(n + 1):
        for j in range(m + 1):
            if best[i][j] == INF:
                continue
            cur = best[i][j]
            if i < n and j < m:  # 1:1
                c = cur + 1 - _sim(ua[i], sa[j])
                if c < best[i + 1][j + 1]:
                    best[i + 1][j + 1], back[i + 1][j + 1] = c, (1, 1)
            if i < n and j + 1 < m:  # 1 uthmani : 2 simple
                c = cur + 1 - _sim(ua[i], sa[j] + sa[j + 1]) + 0.05
                if c < best[i + 1][j + 2]:
                    best[i + 1][j + 2], back[i + 1][j + 2] = c, (1, 2)
            if i + 1 < n and j < m:  # 2 uthmani : 1 simple
                c = cur + 1 - _sim(ua[i] + ua[i + 1], sa[j]) + 0.05
                if c < best[i + 2][j + 1]:
                    best[i + 2][j + 1], back[i + 2][j + 1] = c, (2, 1)
            if i < n:  # drop an uthmani token (should be rare)
                c = cur + 1.0
                if c < best[i + 1][j]:
                    best[i + 1][j], back[i + 1][j] = c, (1, 0)
            if j < m:  # simple word without uthmani token
                c = cur + 1.0
                if c < best[i][j + 1]:
                    best[i][j + 1], back[i][j + 1] = c, (0, 1)
    out: list[str] = []
    i, j = n, m
    while i > 0 or j > 0:
        di, dj = back[i][j]  # type: ignore[misc]
        i, j = i - di, j - dj
        if (di, dj) == (1, 1):
            out.append(u_toks[i])
        elif (di, dj) == (1, 2):
            out.extend(["", u_toks[i]])
        elif (di, dj) == (2, 1):
            out.append(u_toks[i] + " " + u_toks[i + 1])
        elif (di, dj) == (1, 0):
            if out:
                out[-1] = u_toks[i] + " " + out[-1]
        else:  # (0, 1)
            out.append("")
    out.reverse()
    assert len(out) == m, (len(out), m)
    return out


class Quran:
    """The whole mushaf, loaded once (about 77k words)."""

    def __init__(self, use_cache: bool = True) -> None:
        self.ayat: dict[tuple[int, int], Ayah] = {}
        self.surah_len: dict[int, int] = {}
        self.mismatches: list[str] = []
        if not (use_cache and self._load_cache()):
            self._build()
        self._all_words: list[Word] | None = None
        self._tajweed: dict[str, str] | None = None
        self._ngram: dict[int, dict[tuple[str, ...], list[int]]] = {}

    def _load_cache(self) -> bool:
        """Word tables precomputed by tools/build_quran_cache.py; False when absent or built from other texts."""
        if not CACHE.exists():
            return False
        d = json.loads(gzip.decompress(CACHE.read_bytes()).decode("utf-8"))
        fp = source_fingerprint()
        if d.get("format") != 1 or (fp is not None and d.get("fingerprint") != fp):
            return False
        for s, a, uth, simp, clean, words in d["ayat"]:
            ws = tuple(Word(s, a, i, u, sw, nm) for i, (u, sw, nm) in enumerate(words))
            self.ayat[(s, a)] = Ayah(s, a, uth, simp, clean, ws)
            self.surah_len[s] = max(self.surah_len.get(s, 0), a)
        self.mismatches = list(d.get("mismatches", []))
        return True

    def cache_payload(self) -> dict:
        return {"format": 1, "fingerprint": source_fingerprint(), "mismatches": self.mismatches,
                "ayat": [[s, a, ay.uthmani, ay.simple, ay.simple_clean, [[w.uthmani, w.simple, w.norm] for w in ay.words]]
                         for (s, a), ay in sorted(self.ayat.items())]}

    def _build(self) -> None:
        """Compute the word tables from the Tanzil text files (~10 s: the display-token alignment)."""
        uth = _read_tanzil(DATA / "quran_uthmani.txt")
        simp = _read_tanzil(DATA / "quran_simple.txt")
        clean_path = DATA / "quran_simple_clean.txt"
        clean = _read_tanzil(clean_path) if clean_path.exists() else None
        for key in uth:
            s, a = key
            u_toks = uthmani_tokens(uth[key])
            s_toks = simp[key].split()
            if len(u_toks) != len(s_toks):
                self.mismatches.append(f"{s}:{a} uthmani={len(u_toks)} simple={len(s_toks)}")
                # the simple (imla'i) segmentation is the truth (ASR models emit imla'i words);
                # re-segment the Uthmani display tokens onto it (e.g. يَٰٓأَيُّهَا <-> "يا أيها")
                u_toks = align_display_tokens(u_toks, s_toks)
            ws = tuple(
                Word(s, a, i, u, sw, normalize(sw)) for i, (u, sw) in enumerate(zip(u_toks, s_toks))
            )
            self.ayat[key] = Ayah(
                s, a, uth[key], simp[key], clean[key] if clean else normalize(simp[key]), ws
            )
            self.surah_len[s] = max(self.surah_len.get(s, 0), a)

    # ----- access -----
    def ayah(self, surah: int, ayah: int) -> Ayah:
        return self.ayat[(surah, ayah)]

    def n_ayat(self, surah: int) -> int:
        return self.surah_len[surah]

    def chapter_name(self, surah: int) -> str:
        return self._chapters().get(surah, {}).get("name_simple", str(surah))

    def chapter_name_ar(self, surah: int) -> str:
        return self._chapters().get(surah, {}).get("name_arabic", "")

    def _chapters(self) -> dict:
        if not hasattr(self, "_chapters_cache"):
            data = json.loads((DATA / "chapters.json").read_text(encoding="utf-8"))
            self._chapters_cache = {c["id"]: c for c in data}
        return self._chapters_cache

    def passage(self, surah: int, start_ayah: int, end_ayah: int | None = None) -> list[Word]:
        end_ayah = end_ayah or start_ayah
        out: list[Word] = []
        for a in range(start_ayah, end_ayah + 1):
            out.extend(self.ayat[(surah, a)].words)
        return out

    def surah(self, surah: int) -> list[Word]:
        return self.passage(surah, 1, self.surah_len[surah])

    @property
    def all_words(self) -> list[Word]:
        if self._all_words is None:
            self._all_words = [w for k in sorted(self.ayat) for w in self.ayat[k].words]
        return self._all_words

    def tajweed_html(self, surah: int, ayah: int) -> str:
        if self._tajweed is None:
            self._tajweed = json.loads((DATA / "quran_tajweed.json").read_text(encoding="utf-8"))
        return self._tajweed[f"{surah}:{ayah}"]

    # ----- global n-gram index (for localization / mutashabihat) -----
    def ngram_index(self, n: int = 3) -> dict[tuple[str, ...], list[int]]:
        if n not in self._ngram:
            idx: dict[tuple[str, ...], list[int]] = {}
            ws = self.all_words
            for i in range(len(ws) - n + 1):
                key = tuple(w.norm for w in ws[i : i + n])
                idx.setdefault(key, []).append(i)
            self._ngram[n] = idx
        return self._ngram[n]

    def locate(self, hyp_words: list[str], n: int = 3, top_k: int = 3) -> list[tuple[int, int]]:
        """Return [(global_word_position, votes)] of the most likely locations of the
        (normalized) hypothesis words in the mushaf. Position = index into all_words of the
        first hypothesis word."""
        idx = self.ngram_index(n)
        votes: dict[int, int] = {}
        for j in range(len(hyp_words) - n + 1):
            for pos in idx.get(tuple(hyp_words[j : j + n]), ()):
                start = pos - j
                votes[start] = votes.get(start, 0) + 1
        return sorted(votes.items(), key=lambda kv: -kv[1])[:top_k]


@lru_cache(maxsize=1)
def load_quran() -> Quran:
    return Quran()


@lru_cache(maxsize=1)
def vocabulary() -> frozenset[str]:
    """X2.16: the N0 forms of every mushaf word, imla'i (Word.norm) and Uthmani (normalize(uthmani), one or more
    tokens): ~16,500 forms, built once at the first decode that needs it (0.23 s on the PC: each of the 19,000 distinct
    Uthmani spellings normalized once, not each of the 77,800 words, 0.8 s). A decoded word outside it is no Qur'an word
    (side talk, a fragment)."""
    words = load_quran().all_words
    out: set[str] = {w.norm for w in words}
    for u in {w.uthmani for w in words}:
        out.update(normalize(u).split())
    return frozenset(out)


@lru_cache(maxsize=1)
def _contexts() -> tuple[list[int], dict[int, int]]:
    """(ayah_context.json's k per ayah in mushaf order, surah -> index of its ayah 1 in that list)."""
    k = json.loads(CONTEXT.read_text(encoding="utf-8"))["k"]
    q, first, n = load_quran(), {}, 0
    for s in range(1, 115):
        first[s] = n
        n += q.n_ayat(s)
    return k, first


def context_words(surah: int, ayah: int) -> tuple[int, bool]:
    """#40 (X2.2 starter hint): (k, header): the fewest words before the ayah whose sequence occurs only once in the
    Qur'an (N0 letters), so the next word is certain; header = that context reaches the surah's start (k = every word
    before the ayah in its surah, 0 for an ayah 1): the surah's header, which names it, is part of it (a surah start
    counts as unique, so the context never reaches into the surah before). The table: tools/build_ayah_context.py."""
    k, first = _contexts()
    n = k[first[int(surah)] + int(ayah) - 1]
    q = load_quran()
    before = sum(len(q.ayah(surah, a).words) for a in range(1, int(ayah)))
    return n, n == before


# ---------------------------------------------------------------- mushaf pages (Madani 15-line)
# D12 (2026-10-01): pages come from the 15-line layout (mushaf_lines.json), the page the user actually sees; the Tanzil
# metadata (mushaf_meta.json) disagrees with it for 56 ayat (5:77 is printed on page 120, Tanzil says 121) and now
# only gives juz and hizb, plus the pages when the layout file is absent. In the layout no ayah runs over two pages.
N_PAGES = 604
_META: dict | None = None


def _meta() -> dict:
    global _META
    if _META is None:
        _META = json.loads((DATA / "mushaf_meta.json").read_text(encoding="utf-8"))
    return _META


def n_pages() -> int:
    return N_PAGES


_LINES: dict | None = None


def page_lines(page: int) -> list[list[int]]:
    """Madani 15-line layout of a page: [[line, surah, ayah, first_word_idx, n_words], ...] in reading order
    (recite/data/mushaf_lines.json from quran.com, see tools/fetch_mushaf_lines.py); [] if unknown."""
    global _LINES
    if _LINES is None:
        f = DATA / "mushaf_lines.json"
        _LINES = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    return _LINES.get(str(page), [])


_PAGE_AYAT: list[list[tuple[int, int]]] | None = None     # page - 1 -> the (surah, ayah) printed on it, mushaf order
_AYAH_PAGE: dict[tuple[int, int], int] = {}              # (surah, ayah) -> page of its first word
_AYAH_ORDER: list[tuple[int, int]] = []                  # every key of _AYAH_PAGE, sorted (pages of other inputs)


def _layout() -> list[list[tuple[int, int]]]:
    """Precomputed once from the layout; from the Tanzil page table (whole ayat) when the layout is missing."""
    global _PAGE_AYAT, _AYAH_ORDER
    if _PAGE_AYAT is None:
        pages: list[list[tuple[int, int]]] = [[] for _ in range(N_PAGES)]
        first: dict[tuple[int, int], int] = {}
        for p in range(1, N_PAGES + 1):
            for _ln, s, a, idx, _n in page_lines(p):
                if not pages[p - 1] or pages[p - 1][-1] != (s, a):
                    pages[p - 1].append((s, a))
                if idx == 0:
                    first[(s, a)] = p
        if not first:
            starts = [(s, a) for _, s, a in _meta()["pages"]]
            for sa in sorted(load_quran().ayat):
                p = max(1, bisect.bisect_right(starts, sa))
                pages[p - 1].append(sa)
                first[sa] = p
        _AYAH_PAGE.update(first)
        _AYAH_ORDER = sorted(first)
        _PAGE_AYAT = pages
    return _PAGE_AYAT


def page_ayat(page: int) -> list[tuple[int, int]]:
    """Every (surah, ayah) printed on the page (1..604, clamped), in mushaf order."""
    return list(_layout()[max(1, min(int(page), N_PAGES)) - 1])


def page_start(page: int) -> tuple[int, int]:
    """First (surah, ayah) printed on the page (1..604, clamped)."""
    return page_ayat(page)[0]


def start_page_end(words) -> int:
    """X2.1c: the number of leading `words` (Word-like: .surah, .ayah) printed on the page of the first one, the
    session's start page (an ayah running onto the next page counts whole); 0 for no words."""
    if not words:
        return 0
    on_page = set(page_ayat(page_of(words[0].surah, words[0].ayah)))
    n = 0
    while n < len(words) and (words[n].surah, words[n].ayah) in on_page:
        n += 1
    return n


def page_of(surah: int, ayah: int) -> int:
    """Page of the ayah's first word; for a key that is no ayah (2:0, 2:999), the page of the ayah before it."""
    _layout()
    p = _AYAH_PAGE.get((surah, ayah))
    if p is None:
        k = bisect.bisect_right(_AYAH_ORDER, (surah, ayah)) - 1
        p = _AYAH_PAGE[_AYAH_ORDER[k]] if k >= 0 else 1
    return p


def juz_of(surah: int, ayah: int) -> int:
    best = 1
    for idx, s, a in _meta()["juzs"]:
        if (s, a) <= (surah, ayah):
            best = idx
        else:
            break
    return best


def hizb_of(surah: int, ayah: int) -> int:
    """Hizb number (1..60) from the quarter index."""
    best = 1
    for idx, s, a in _meta()["hizb_quarters"]:
        if (s, a) <= (surah, ayah):
            best = idx
        else:
            break
    return (best - 1) // 4 + 1
