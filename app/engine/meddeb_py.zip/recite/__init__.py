"""Recite - Qur'an recitation transcription + mistake detection (Hafs an Asim).

Shared library used by the PoC benchmark (d02_PoC/) and the Meddeb app (d04_meddeb/, exported to Android).
__version__ is the PC app's version, shown in the About title (U1.12); Android shows its own versionName.
"""
__version__ = "0.9.0"
