"""X2.13 Find where I am: locate what the reciter is saying anywhere in the Qur'an.

Candidates come from word-pair votes over the whole text (quran_text.ngram_index(2)), each one is checked by aligning the
heard words against the text around it (a misheard word costs one mismatch, not the location), and a place is only
reported when it is clearly the best: repeated passages (فبأي آلاء ربكما تكذبان, 31 times in Ar-Rahman) give several
equally good places and are not guessed - the client keeps listening until the recitation leaves the repeated part.
"""
from __future__ import annotations

from .align import align, similarity
from .normalize import normalize
from .quran_text import Quran

TAAWWUDH = "اعوذ بالله من الشيطان الرجيم".split()
BASMALA = "بسم الله الرحمن الرحيم".split()
MIN_WORDS = 4          # matched words needed before a place is reported
MIN_RATIO = 0.6        # ... and the share of the heard words they must be
MARGIN = 2             # the best place must match this many words more than any other place
CANDIDATES = 12        # vote leaders checked by alignment


def strip_formulas(hyp: list[str]) -> list[str]:
    """Drop a leading ta'awwudh and basmala (the basmala is also 27:30: it would win every search)."""
    for formula in (TAAWWUDH, BASMALA):
        k = 0
        while k < len(hyp) and k < len(formula) and similarity(hyp[k], formula[k]) >= 0.75:
            k += 1
        if k == len(formula):
            hyp = hyp[k:]
    return hyp


def _check(q: Quran, start: int, hyp: list[str]) -> tuple[int, int, int] | None:
    """(matched words, global index of the last matched word, index in `hyp` of the word heard for it) of the heard
    words aligned around `start`."""
    ws = q.all_words
    lo = max(0, start - 3)
    hi = min(len(ws), start + len(hyp) + 6)
    ref = [w.norm for w in ws[lo:hi]]
    alt = [normalize(w.uthmani) or None for w in ws[lo:hi]]
    al = align(ref, hyp, ref_alt=alt, free_start=True, free_end=True, repeat_window=0)   # no repeats: locating
    ok = [v for v in al.verdicts if v.status == "ok"]
    if not ok:
        return None
    last = max(ok, key=lambda v: v.ref_idx)
    return len(ok), lo + last.ref_idx, last.hyp_idx


def find_position(hyp_words: list[str], q: Quran) -> dict | None:
    """The place of the last heard word, {"surah", "ayah", "idx", "global", "matched", "next": {surah, ayah, idx},
    "page"} where next is the word to continue with; None while the place is not certain."""
    return find_place(hyp_words, q)[0]


def find_place(hyp_words: list[str], q: Quran) -> tuple[dict | None, int | None]:
    """find_position, and the index in `hyp_words` of the heard word the place ends with (#20: the session that goes on
    after the search starts with the audio after that word); (None, None) while the place is not certain."""
    keep = [j for j, h in enumerate(hyp_words) if h]
    nonempty = [hyp_words[j] for j in keep]
    hyp = strip_formulas(nonempty)
    dropped = len(nonempty) - len(hyp)                  # a leading ta'awwudh / basmala
    if len(hyp) < MIN_WORDS:
        return None, None
    idx = q.ngram_index(2)
    votes: dict[int, int] = {}
    for j in range(len(hyp) - 1):
        for pos in idx.get((hyp[j], hyp[j + 1]), ()):
            votes[pos - j] = votes.get(pos - j, 0) + 1
    if not votes:
        return None, None
    leaders = sorted(votes, key=lambda s: -votes[s])[:CANDIDATES]
    checked: dict[int, int] = {}            # global index of the last matched word -> matched words
    heard_at: dict[int, int] = {}           # ... -> the index in hyp of the word heard for it
    for start in leaders:
        r = _check(q, start, hyp)
        if r and r[0] > checked.get(r[1], 0):
            checked[r[1]] = r[0]
            heard_at[r[1]] = r[2]
    if not checked:
        return None, None
    best_end = max(checked, key=lambda e: checked[e])
    best = checked[best_end]
    others = [n for e, n in checked.items() if abs(e - best_end) > len(hyp)]
    if best < MIN_WORDS or best < MIN_RATIO * len(hyp) or (others and best - max(others) < MARGIN):
        return None, None
    ws = q.all_words
    w = ws[best_end]
    nxt = ws[best_end + 1] if best_end + 1 < len(ws) else w
    from .progress import word_pages   # the 15-line layout: the page that shows the next word

    return ({"surah": w.surah, "ayah": w.ayah, "idx": w.idx, "global": best_end, "matched": best,
             "next": {"surah": nxt.surah, "ayah": nxt.ayah, "idx": nxt.idx},
             "page": word_pages().get(nxt.key, 1)}, keep[dropped + heard_at[best_end]])
