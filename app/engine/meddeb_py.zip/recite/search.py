"""X2.13 Find where I am: locate what the reciter is saying anywhere in the Qur'an.

Candidates come from word-pair votes over the whole text (quran_text.ngram_index(2)), each one is checked by aligning the
heard words against the text around it (a misheard word costs one mismatch, not the location), and a place is only
reported when it is clearly the best: repeated passages (فبأي آلاء ربكما تكذبان, 31 times in Ar-Rahman) give several
equally good places and are not guessed - the client keeps listening until the recitation leaves the repeated part.
"""
from __future__ import annotations

from .align import align, similarity
from .normalize import normalize
from .quran_text import Quran

TAAWWUDH = "اعوذ بالله من الشيطان الرجيم".split()
BASMALA = "بسم الله الرحمن الرحيم".split()
MIN_WORDS = 4          # matched words needed before a place is reported
MIN_RATIO = 0.6        # ... and the share of the heard words they must be
MARGIN = 2             # the best place must match this many words more than any other place (1 under R2's guard)
LEADERS = 24           # v0.22 (#102, s102): smoothed-vote leaders checked by alignment (0.21: 12 raw-vote ones)
ONE_WORD_SIM = 0.5     # v0.22: R2's guard: the one word that differs is clearly another (similarity under this)
NEAR_MIN_WORDS = 3     # v0.22 (plan D3): matched words enough for a place on the shown page (X2.1c's 3-word start)
NEAR_MAX_TIES = 2      # v0.22 review: ... which wins a tie with at most this many places elsewhere (more: it waits)
CAND_MIN_WORDS = 3     # #100: a candidate place matched this many words ...
CAND_MIN_RATIO = 0.5   # ... this share of the heard ones, within one word of the best
MAX_CANDIDATES = 6     # #100: the places shown to choose from
TEXT_WORDS = 14        # #100: a candidate's text, from its start
WRONG_BACK = 2         # plan D3: an on-page find starts back over at most this many wrong heard words ...
WRONG_SIM = 0.5        # ... each an attempt at its word (v0.22 review: similarity at least this; never side talk)


def _formula_head(hyp: list[str], formula: list[str]) -> int:
    """How many words at the head of `hyp` are `formula`, or its end (v0.21 review 2: «الله الرحمن الرحيم», the
    basmala whose «بسم» was missed): the longest such suffix, 0 when none."""
    for n in range(len(formula), 0, -1):
        if len(hyp) >= n and all(similarity(hyp[k], f) >= 0.75 for k, f in enumerate(formula[-n:])):
            return n
    return 0


def _strip_parts(hyp: list[str]) -> tuple[list[str], int]:
    """strip_formulas, and how many words the last formula part dropped (0 when none): the part that may be the text
    just before the place (_run_start)."""
    last = 0
    for formula in (TAAWWUDH, BASMALA):
        n = _formula_head(hyp, formula)
        hyp, last = hyp[n:], n or last
    return hyp, last


def strip_formulas(hyp: list[str]) -> list[str]:
    """Drop a leading ta'awwudh and basmala (the basmala is also 27:30: it would win every search), whole or their end
    (v0.21 review 2, #94: a microphone opened late or the 20 s window cut «بسم»: «الله» matched the surah before)."""
    return _strip_parts(hyp)[0]


def _is_formula_word(h: str) -> bool:
    return any(similarity(h, f) >= 0.75 for f in TAAWWUDH + BASMALA)


def _run_start(heard: list[tuple[int, int]], hyp: list[str], q: Quran, part: list[str],
               alone: bool = True) -> list[tuple[int, int]]:
    """v0.21 review 2 (#94): the matched words of the place from its start (found.start = the first one): the first
    word of a contiguous run (the next heard word is the next word of the text: no deletion nor insertion between; a
    stray word matched a few words before the place, with noise between, opened it), never in the surah before the
    found word's when only formula words lie between (a basmala's end matched in its last ayah); the formula part
    dropped last at the head (`part`: the basmala, or its end, or the ta'awwudh) belongs to the place when it is, whole
    and 2 words at least, the very text just before that start in its surah (normalized words equal, not similar:
    Al-Fatiha's 1:1, 1:3 «الرحمن الرحيم», 27:30's basmala; never 2:37's «التواب الرحيم» before 2:38, nor 16:98's
    «...الشيطان الرجيم» for a ta'awwudh said before 16:99); mid-ayah (27:30 w4) only when `alone` (nothing dropped
    before the part: a ta'awwudh's «الرجيم» carried before 27:30 w4 was a red word; the tracker strips it only before an
    ayah's first word). `heard` and the result: [(index in `hyp`, global index)]; a put-back word gets index -n .. -1."""
    ws = q.all_words

    def contiguous_from(k: int) -> int:
        return next((i for i in range(k, len(heard) - 1)
                     if heard[i + 1] == (heard[i][0] + 1, heard[i][1] + 1)), len(heard) - 1)

    k = contiguous_from(0)
    surah = ws[heard[-1][1]].surah
    if ws[heard[k][1]].surah != surah:
        i1 = next(i for i in range(k, len(heard)) if ws[heard[i][1]].surah == surah)
        if all(_is_formula_word(h) for h in hyp[heard[k][0]:heard[i1][0]]):
            k = contiguous_from(i1)
    run = heard[k:]
    j0, g0 = run[0]
    n = len(part)
    if j0 == 0 and n >= 2 and n <= g0 and (alone or ws[g0 - n].idx == 0) and all(
            ws[g0 - n + m].surah == ws[g0].surah and normalize(d) in (ws[g0 - n + m].norm, normalize(ws[g0 - n + m].uthmani))
            for m, d in enumerate(part)):
        run = [(m - n, g0 - n + m) for m in range(n)] + run
    return run


def _window(q: Quran, start: int, hyp: list[str]) -> tuple[int, int]:
    return max(0, start - 3), min(len(q.all_words), start + len(hyp) + 6)


def _check(q: Quran, start: int, hyp: list[str]) -> tuple[int, int, list[tuple[int, int]]] | None:
    """(matched words, global index of the last matched word, [(index in `hyp`, global index)] of the matched words in
    reading order) of the heard words aligned around `start`."""
    ws = q.all_words
    lo, hi = _window(q, start, hyp)
    ref = [w.norm for w in ws[lo:hi]]
    alt = [normalize(w.uthmani) or None for w in ws[lo:hi]]
    al = align(ref, hyp, ref_alt=alt, free_start=True, free_end=True, repeat_window=0)   # no repeats: locating
    ok = sorted((v for v in al.verdicts if v.status == "ok"), key=lambda v: v.ref_idx)
    if not ok:
        return None
    return len(ok), lo + ok[-1].ref_idx, [(v.hyp_idx, lo + v.ref_idx) for v in ok]


def _bound(q: Quran, start: int, hyp: list[str]) -> int:
    """v0.22 (#102): an upper bound of _check's matched words at `start`: the heard words found (normalized or Uthmani
    form, align's exact `eq`) in its window. A leader under the best - 1 is never aligned: it cannot change a decision,
    a candidate nor n_places, and 24 leaders cost about what 12 did."""
    lo, hi = _window(q, start, hyp)
    ws = q.all_words[lo:hi]
    forms = {w.norm for w in ws} | {normalize(w.uthmani) for w in ws}
    return sum(1 for h in hyp if h in forms)


def word_place(g: int, q: Quran) -> dict:
    """#94: {"surah", "ayah", "idx", "page"} of the word at global index `g` (the 15-line layout's page)."""
    from .progress import word_pages

    w = q.all_words[g]
    return {"surah": w.surah, "ayah": w.ayah, "idx": w.idx, "page": word_pages().get(w.key, 1)}


def find_position(hyp_words: list[str], q: Quran) -> dict | None:
    """The place of the last heard word, {"surah", "ayah", "idx", "global", "matched", "next": {surah, ayah, idx},
    "page", "start": {surah, ayah, idx, page}} where next is the word after it and page the page that shows next (kept
    for the 0.20 clients), start the first word heard of the place (#94: where the session that goes on starts, X2.13);
    None while the place is not certain."""
    return find_place(hyp_words, q)[0]


def find_place(hyp_words: list[str], q: Quran, near: dict | None = None
               ) -> tuple[dict | None, list[tuple[int, int]] | None]:
    """find_position, and the heard words of the place: [(index in `hyp_words`, global index)] of the words matched, in
    reading order (#20: the session that goes on after the search starts with the audio of the place's words; #94: from
    its first heard word, heard[0] = found.start); (None, None) while the place is not certain. near: search_place's."""
    r = search_place(hyp_words, q, near=near)
    return r["found"], r["heard"]


def _one_word_apart(q: Quran, hyp: list[str], best_ok: list[tuple[int, int]], rival_ok: list[tuple[int, int]]) -> bool:
    """R2's guard (v0.22, #102, s102): the rival matched every heard word the best did but one, j, at one offset (no
    shift: no inserted or dropped word explains it), and j is clearly another word there: similarity under
    ONE_WORD_SIM to the rival's word and to the 2 after it (a dropped word before it). «ما» heard for «ماذا» (37:85 /
    26:70), «الذي» for «الذين» (4:44 / 2:258), 2:242 with «لكم» dropped (2:187) stay undecided."""
    ws = q.all_words
    bj, rj = dict(best_ok), dict(rival_ok)
    miss = [j for j in bj if j not in rj]
    if len(miss) != 1 or any(j not in bj for j in rj):
        return False
    offs = {g - j for j, g in rival_ok}
    if len(offs) != 1:
        return False
    j = miss[0]
    g = j + offs.pop()
    if not 0 <= g < len(ws):
        return True
    return all(max(similarity(hyp[j], ws[k].norm), similarity(hyp[j], normalize(ws[k].uthmani))) < ONE_WORD_SIM
               for k in (g, g + 1, g + 2) if k < len(ws))


def near_pages(near: dict | None) -> set[int]:
    """The shown page and the next one (plan D3: start{search, near: {page}}); empty without a page."""
    try:
        p = int((near or {}).get("page") or 0)
    except (TypeError, ValueError, AttributeError):
        return set()
    return {p, p + 1} if p > 0 else set()


def _decide(q: Quran, hyp: list[str], checked: dict, ends: list[int], shown: set[int], pages_of) -> int | None:
    """The end (global index) of the place the heard words are surely at, None while unsure (s102's R2, + the shown
    page's prior, plan D3). `checked`: end -> (matched, [(hyp index, global)]); `ends`: the places (distinct ends more
    than len(hyp) apart), the most matched first; pages_of(end): the pages of the place's first and last words."""
    n = len(hyp)

    def rivals(e: int, among: list[int]) -> list[int]:
        return [x for x in among if abs(x - e) > n]

    def sure(e: int, others: list[int], min_words: int) -> bool:
        best = checked[e][0]
        if best < min_words or best < MIN_RATIO * n:
            return False
        second = max((checked[x][0] for x in others), default=0)
        if best - second >= MARGIN:
            return True
        return best - second == 1 and best == n and all(
            _one_word_apart(q, hyp, checked[e][1], checked[x][1]) for x in others if checked[x][0] == second)

    on = [e for e in ends if pages_of(e) & shown]
    if on:
        e = on[0]
        out = [x for x in ends if x not in on]
        best_out = max((checked[x][0] for x in out), default=0)
        if best_out <= checked[e][0]:           # a tie with a place elsewhere goes to the shown page ...
            # v0.22 review: ... with a few places only: an opening said in dozens of places («يا ايها الذين امنوا»)
            # waits for the words that tell them apart (the reciter may be reciting from anywhere)
            if sum(1 for x in out if checked[x][0] >= checked[e][0]) > NEAR_MAX_TIES:
                return None
            return e if sure(e, rivals(e, on), NEAR_MIN_WORDS) else None
        b = max(out, key=lambda x: checked[x][0])
        return b if sure(b, rivals(b, ends), MIN_WORDS) else None
    e = ends[0]
    return e if sure(e, rivals(e, ends), MIN_WORDS) else None


def search_place(hyp_words: list[str], q: Quran, near: dict | None = None) -> dict:
    """X2.13 Find where I am (v0.22, #102 #100, plan D3): {"found", "heard", "candidates", "n_places"}.
    found / heard: find_place's (None while unsure). The rule (R2, s102): word-pair votes per offset, smoothed over
    the offsets s-1, s, s+1 (an inserted or dropped word splits a place's votes over two offsets: 0.21 lost 22:58, 29:42
    and 35:7 that way), the LEADERS best aligned (_check); a place is sure with MIN_WORDS matched, MIN_RATIO of the
    heard words and MARGIN more than any other place, or one more when every heard word matched and each rival one
    behind differs by one clearly other word in place (_one_word_apart: 113:1 / 114:1 on their first ayah). near
    ({"page": p}, the page shown at the microphone's press): a place on page p or p + 1 needs only NEAR_MIN_WORDS
    (X2.1c's 3-word start), wins a tie with places elsewhere (at most NEAR_MAX_TIES of them: more, nothing is found
    yet), and a place elsewhere must beat it as above (2 words, or 1 under the guard).
    candidates (#100: the places the search hesitates between, so that the reciter can choose one): the places with
    CAND_MIN_WORDS matched, CAND_MIN_RATIO of the heard words and within one word of the best, the shown page first,
    then more matched words, then reading order, at most MAX_CANDIDATES: {surah, ayah, idx, global, matched, next, page,
    start: {surah, ayah, idx, page}, text (Uthmani, from start, at most TEXT_WORDS), heard: [(index in hyp_words,
    global)]}; n_places: how many places that many are (the contenders, or the vote leaders tied at the top when more:
    31 for Ar-Rahman's refrain), capped at 99."""
    none = {"found": None, "heard": None, "candidates": [], "n_places": 0}
    keep = [j for j, h in enumerate(hyp_words) if h]
    nonempty = [hyp_words[j] for j in keep]
    hyp, part = _strip_parts(nonempty)
    dropped = len(nonempty) - len(hyp)                  # a leading ta'awwudh / basmala
    if len(hyp) < min(NEAR_MIN_WORDS, CAND_MIN_WORDS):
        return none
    idx = q.ngram_index(2)
    votes: dict[int, int] = {}
    for j in range(len(hyp) - 1):
        for pos in idx.get((hyp[j], hyp[j + 1]), ()):
            votes[pos - j] = votes.get(pos - j, 0) + 1
    if not votes:
        return none
    sm = {s: votes.get(s - 1, 0) + votes[s] + votes.get(s + 1, 0) for s in votes}
    leaders = sorted(sm, key=lambda s: (-sm[s], -votes[s], s))[:LEADERS]
    checked: dict[int, tuple[int, list[tuple[int, int]]]] = {}   # end -> (matched, [(index in hyp, global)])
    top = 0
    for start in leaders:
        if _bound(q, start, hyp) < top - 1:
            continue
        r = _check(q, start, hyp)
        if r and r[0] > checked.get(r[1], (0,))[0]:
            checked[r[1]] = (r[0], r[2])
            top = max(top, r[0])
    if not checked:
        return none
    ws = q.all_words
    from .progress import word_pages   # the 15-line layout
    pages = word_pages()

    def pages_of(e: int) -> set[int]:
        return {pages.get(ws[checked[e][1][0][1]].key, 1), pages.get(ws[e].key, 1)}

    ends: list[int] = []                # one per place (ends within len(hyp): the same place), most matched first
    for e in sorted(checked, key=lambda x: (-checked[x][0], x)):
        if all(abs(e - x) > len(hyp) for x in ends):
            ends.append(e)
    shown = near_pages(near)
    best_end = _decide(q, hyp, checked, ends, shown, pages_of)

    def heard_of(e: int, run_part: list[str], alone: bool) -> list[tuple[int, int]]:
        return [(keep[dropped + j], g) for j, g in _run_start(checked[e][1], hyp, q, run_part, alone=alone)]

    best = checked[ends[0]][0]
    contenders = [e for e in ends if checked[e][0] >= max(CAND_MIN_WORDS, best - 1)
                  and checked[e][0] >= CAND_MIN_RATIO * len(hyp)]
    contenders.sort(key=lambda e: (not (pages_of(e) & shown), -checked[e][0], e))
    cands = []
    for e in contenders[:MAX_CANDIDATES]:
        h = heard_of(e, [], True)
        g0, w = h[0][1], ws[e]
        nx = ws[e + 1] if e + 1 < len(ws) else w
        cands.append({"surah": w.surah, "ayah": w.ayah, "idx": w.idx, "global": e, "matched": checked[e][0],
                      "next": {"surah": nx.surah, "ayah": nx.ayah, "idx": nx.idx},
                      "page": pages.get(w.key, 1), "start": word_place(g0, q),
                      "text": " ".join(x.uthmani for x in ws[g0:min(e + 1, g0 + TEXT_WORDS)]), "heard": h})
    clusters, last = 0, None            # the offsets tied at the top of the smoothed votes, one per place
    for s in sorted(s for s in sm if sm[s] == sm[leaders[0]]):
        if last is None or s - last > len(hyp):
            clusters += 1
        last = s
    n_places = min(99, max(len(contenders), clusters) if len(contenders) > 1 else len(contenders))
    out = {"found": None, "heard": None, "candidates": cands, "n_places": n_places}
    if best_end is None:
        return out
    w = ws[best_end]
    nxt = ws[best_end + 1] if best_end + 1 < len(ws) else w
    run = _run_start(checked[best_end][1], hyp, q, nonempty[dropped - part:dropped], alone=dropped == part)
    if pages_of(best_end) & shown:
        # plan D3 (s102 decision 6): a find on the shown page starts back over at most WRONG_BACK heard words just
        # before its run, at the same offset in the same ayah: wrong first words, which the microphone's session
        # judged red before 0.22 (the search now finds from the first right one), are judged red again. v0.22 review: only
        # an attempt at its word (WRONG_SIM): side talk, a partial basmala or a garbled token before a start mid-ayah is
        # not recited (0.21's X2.1c jump dropped it), never a red word the reciter did not try to say
        for _ in range(WRONG_BACK):
            j, g = run[0]
            if j < 1 or g < 1 or (ws[g - 1].surah, ws[g - 1].ayah) != (ws[g].surah, ws[g].ayah):
                break
            h = hyp[j - 1]
            if max(similarity(h, ws[g - 1].norm), similarity(h, normalize(ws[g - 1].uthmani))) < WRONG_SIM:
                break
            run = [(j - 1, g - 1)] + run
    matched = [(keep[dropped + j], g) for j, g in run]
    out["found"] = {"surah": w.surah, "ayah": w.ayah, "idx": w.idx, "global": best_end, "matched": checked[best_end][0],
                    "next": {"surah": nxt.surah, "ayah": nxt.ayah, "idx": nxt.idx},
                    "page": pages.get(nxt.key, 1), "start": word_place(matched[0][1], q)}
    out["heard"] = matched
    return out
