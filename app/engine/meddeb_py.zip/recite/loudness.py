"""X2.18 One loudness (user, 2026-10-10): in Recite the mistake click, Yasser's voice-command clips and the replay of
one's own recording play at about the same loudness, REPLAY_TARGET (-18 LUFS-like).

- speech_level: a BS.1770-like meter (K-weighting applied in the frequency domain on blocks of BLOCK_S seconds, 20 ms
  frames, an absolute gate at -60 and a relative gate 20 dB under the loudest frame; -0.691 offset): a 1 kHz sine at
  full scale reads -3.08. The blocks keep the memory and the time of one block bounded whatever the clip's length (one
  FFT over a whole 4-minute ayah took 235 MB, review of 2026-10-11).
- normalize_replay: the replay (B3.7) is brought to REPLAY_TARGET, the gain clamped to MIN_GAIN_DB..MAX_GAIN_DB and
  capped so that the sample peak stays at CEILING (-1 dBFS); silence and noise under the gate come back unchanged. Only
  what is played changes: the saved audio.wav and the tracker's input never do.
- RECITER_GAIN: Yasser's EveryAyah files are -14.2 LUFS (median of the 6,236 files, std 1.3 dB): one constant gain
  (0.646) for every clip of his, the players' volume (0..1).

numpy only (no scipy: it runs in Chaquopy); reference and measurements: the round of 2026-10-10 (audio levels).
"""
from __future__ import annotations

import math

import numpy as np

REPLAY_TARGET = -18.0          # LUFS-like level of every Recite sound
MAX_GAIN_DB = 30.0             # never more (a whisper or a far microphone stays a little short)
MIN_GAIN_DB = -12.0            # never less (a very loud clip)
CEILING = 10 ** (-1 / 20)      # -1 dBFS sample peak after the gain
FRAME_S = 0.02                 # meter frames
ABS_GATE = -60.0               # K-weighted frame level under which a frame is silence
REL_GATE = 20.0                # frames more than this under the loudest one are pauses, not speech
RECITER_LUFS = -14.2           # Yasser Al-Dossary, EveryAyah 128 kbps: median integrated loudness of all 6,236 files
RECITER_GAIN = round(10 ** ((REPLAY_TARGET - RECITER_LUFS) / 20), 3)   # 0.646 = -3.8 dB
BLOCK_S = 10.0                 # the K-weighting runs on blocks this long (a whole number of meter frames)
TAIL_S = 0.25                  # the filters' tails (far under it): each block is filtered with this much of the audio
                               # before it (the filters' state) and zero padded by as much (no wrap-around)


def _biquads(sr: int) -> list[tuple[list[float], list[float]]]:
    """BS.1770 K-weighting: the high shelf (+4 dB above ~1.5 kHz, the head) and the high pass (38 Hz), as biquads."""
    g, q, fc = 4.0, 1 / math.sqrt(2), 1500.0
    a_ = 10 ** (g / 40)
    w0 = 2 * math.pi * fc / sr
    al, c = math.sin(w0) / (2 * q), math.cos(w0)
    shelf = ([a_ * ((a_ + 1) + (a_ - 1) * c + 2 * math.sqrt(a_) * al), -2 * a_ * ((a_ - 1) + (a_ + 1) * c),
              a_ * ((a_ + 1) + (a_ - 1) * c - 2 * math.sqrt(a_) * al)],
             [(a_ + 1) - (a_ - 1) * c + 2 * math.sqrt(a_) * al, 2 * ((a_ - 1) - (a_ + 1) * c),
              (a_ + 1) - (a_ - 1) * c - 2 * math.sqrt(a_) * al])
    q, fc = 0.5, 38.0
    w0 = 2 * math.pi * fc / sr
    al, c = math.sin(w0) / (2 * q), math.cos(w0)
    high_pass = ([(1 + c) / 2, -(1 + c), (1 + c) / 2], [1 + al, -2 * c, 1 - al])
    return [shelf, high_pass]


def _k_response(nfft: int, sr: int) -> np.ndarray:
    """The K-weighting filters' frequency response on the nfft-point rfft bins."""
    z = np.exp(-2j * np.pi * np.fft.rfftfreq(nfft, 1 / sr) / sr)
    h = np.ones_like(z)
    for b, a in _biquads(sr):
        h *= (b[0] + b[1] * z + b[2] * z * z) / (a[0] + a[1] * z + a[2] * z * z)
    return h


def _k_blocks(x: np.ndarray, sr: int, block: int):
    """(start, x[start:start + block] K-weighted) for start = 0, block, 2 block...: each block through the filters'
    response on the rfft bins, with the TAIL_S of audio before it and TAIL_S of zero padding; a clip within one block is
    one FFT, as before the blocks (matches scipy's lfilter to 0.0000 dB per frame)."""
    n, lead = len(x), int(TAIL_S * sr)
    resp: dict[int, np.ndarray] = {}
    for s in range(0, n, block):
        a, e = max(0, s - lead), min(n, s + block)
        nfft = 1 << (e - a + lead).bit_length()
        h = resp.get(nfft)
        if h is None:
            h = resp[nfft] = _k_response(nfft, sr)
        y = np.fft.irfft(np.fft.rfft(np.asarray(x[a:e], dtype=np.float64), nfft) * h, nfft)
        yield s, y[s - a:e - a]


def k_weight(x: np.ndarray, sr: int) -> np.ndarray:
    """x through the K-weighting filters (float64), block by block (_k_blocks)."""
    out = np.empty(len(x))
    for s, y in _k_blocks(x, sr, int(BLOCK_S * sr)):
        out[s:s + len(y)] = y
    return out


def speech_level(x: np.ndarray, sr: int) -> float | None:
    """LUFS-like level of the speech in x: the mean power of the 20 ms frames above ABS_GATE and within REL_GATE of the
    loudest one; None when no frame is (silence, noise under the gate, shorter than a frame). The frames' powers are
    taken block by block: no K-weighted copy of the whole clip."""
    n = int(FRAME_S * sr)
    m = len(x) // n
    if m == 0:
        return None
    block = n * max(1, round(BLOCK_S / FRAME_S))           # whole frames (the filters are causal: x[:m * n] is enough)
    p = np.concatenate([(y.reshape(-1, n) ** 2).mean(axis=1) for _s, y in _k_blocks(x[: m * n], sr, block)])
    lev = -0.691 + 10 * np.log10(np.maximum(p, 1e-20))
    sel = (lev > ABS_GATE) & (lev > lev.max() - REL_GATE)
    if not sel.any():
        return None
    return -0.691 + 10 * math.log10(float(p[sel].mean()))


def normalize_replay(x: np.ndarray, sr: int, target: float = REPLAY_TARGET) -> tuple[np.ndarray, dict]:
    """(the clip at `target`, {level, gain_db, limited}): gain = target - level clamped to MIN_GAIN_DB..MAX_GAIN_DB, then
    lowered if the peak would pass CEILING (limited). No speech level: x unchanged, gain 0."""
    x = np.asarray(x, dtype=np.float32)
    level = speech_level(x, sr)
    if level is None:
        return x, {"level": None, "gain_db": 0.0, "limited": False}
    want = min(MAX_GAIN_DB, max(MIN_GAIN_DB, target - level))
    g = 10 ** (want / 20)
    peak = max(float(x.max()), -float(x.min()))            # (no |x| copy of the clip)
    limited = peak * g > CEILING
    if limited:
        g = CEILING / peak
    return np.multiply(x, np.float32(g), dtype=np.float32), {"level": round(level, 2),
                                                             "gain_db": round(20 * math.log10(g), 2),
                                                             "limited": bool(limited)}
