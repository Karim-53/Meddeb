"""Arabic text normalization used everywhere (scoring, alignment, indexing).

N0 = "Tarteel-like" word-level normalization:
  NFC -> drop tatweel -> drop tashkeel / Quranic annotation signs / dagger alef ->
  unify hamza-alef forms (أ إ آ ٱ -> ا), ؤ -> و, ئ -> ي, ى -> ي, ة -> ه, drop standalone ء ->
  drop every non Arabic-letter character -> collapse whitespace.
One wrong letter => the whole word is wrong (word-level scoring, as requested).
Standalone hamza is dropped because ASR models trained on normalized text write شي / السما / جا
for شيء / السماء / جاء; no two Qur'anic words differ only by it.

`alef_insensitive()` additionally drops every ا, mirroring the Quran-Lab benchmark's
second column (tolerates Uthmani/imla'i spelling differences such as الصلوة / الصلاة).
"""
from __future__ import annotations

import re
import unicodedata

# Marks to delete: harakat, shadda, sukun, tanwin, Quranic annotation signs, small letters,
# dagger alef, pause marks, sajdah, hizb signs, tatweel.
_MARKS_RE = re.compile(
    "[ؐ-ًؚ-ٰٟۖ-ۭ࣓-ࣿﹰ-ﹿـ]"
)
# Everything that is not an Arabic letter (after mark removal) becomes a space.
_NON_LETTER_RE = re.compile("[^ء-غف-يٱ-ۓ]+")
_SPACES_RE = re.compile(r"\s+")

_UNIFY = str.maketrans(
    {
        "أ": "ا",  # أ
        "إ": "ا",  # إ
        "آ": "ا",  # آ
        "ٱ": "ا",  # ٱ (hamzat wasl)
        "ٲ": "ا",
        "ٳ": "ا",
        "ؤ": "و",  # ؤ -> و
        "ئ": "ي",  # ئ -> ي
        "ى": "ي",  # ى -> ي
        "ة": "ه",  # ة -> ه
        "ی": "ي",  # farsi yeh
        "ک": "ك",  # keheh
        "ء": None,      # standalone hamza dropped (see module docstring)
    }
)
_GARBAGE_RE = re.compile(r"(.)\1\1")  # three identical consecutive letters never occur in Arabic
MAX_WORD_LEN = 14

TASHKEEL_RE = re.compile("[ً-ْٰٓ-ࣰٕ-ࣳ]")


def strip_marks(text: str) -> str:
    """Remove tashkeel and Quranic signs but keep letters/hamza forms and spacing."""
    text = unicodedata.normalize("NFC", text)
    return _MARKS_RE.sub("", text)


def normalize(text: str) -> str:
    """N0 normalization -> space separated words."""
    text = strip_marks(text)
    text = text.translate(_UNIFY)
    text = _NON_LETTER_RE.sub(" ", text)
    return _SPACES_RE.sub(" ", text).strip()


def words(text: str) -> list[str]:
    n = normalize(text)
    return n.split(" ") if n else []


def alef_insensitive(text: str) -> str:
    return _SPACES_RE.sub(" ", normalize(text).replace("ا", "")).strip()


def has_tashkeel(text: str) -> bool:
    return bool(TASHKEEL_RE.search(text))


def collapse_repeats(words: list[str], max_n: int = 4, keep: int = 2) -> list[int]:
    """Indices to KEEP after collapsing ASR hallucination loops: any n-gram (n <= max_n) repeated
    back-to-back more than `keep` times is cut down to `keep` copies. Safe for Qur'an text: no
    n-gram (n <= 4) is repeated three or more times consecutively anywhere in the mushaf, while
    double repeats (e.g. 97:2 "ليلة القدر" x2) survive with keep=2."""
    drop: set[int] = set()
    i = 0
    L = len(words)
    while i < L:
        cut = False
        for n in range(1, max_n + 1):
            if i + n * (keep + 1) > L:
                break
            g = words[i: i + n]
            r = 1
            while words[i + n * r: i + n * (r + 1)] == g:
                r += 1
            if r > keep:
                for k in range(i + n * keep, i + n * r):
                    drop.add(k)
                i += n * r
                cut = True
                break
        if not cut:
            i += 1
    return [k for k in range(L) if k not in drop]


def is_garbage_token(w: str) -> bool:
    """ASR degeneracies: a letter repeated 3+ times in a row, or an impossibly long word."""
    return bool(_GARBAGE_RE.search(w)) or len(w) > MAX_WORD_LEN


def clean_hyp(words: list[str]) -> list[int]:
    """Indices of hypothesis words to keep: garbage tokens removed, hallucination loops collapsed."""
    keep = [k for k, w in enumerate(words) if not is_garbage_token(w)]
    sub = [words[k] for k in keep]
    return [keep[k] for k in collapse_repeats(sub)]


def normalize_keep_tashkeel(text: str) -> str:
    """Light normalization that keeps harakat (for the diacritized secondary metric):
    NFC, drop tatweel and Quranic pause/annotation signs (not harakat), unify alef/hamza
    letters the same way as N0, collapse spaces."""
    text = unicodedata.normalize("NFC", text)
    text = re.sub("[ـؐ-ؚۖ-ۭ࣓-ࣿ]", "", text)
    text = text.translate(_UNIFY)
    text = re.sub("[^ء-غف-ْٰٱ-ۓٓ-ٕ]+", " ", text)
    return _SPACES_RE.sub(" ", text).strip()
