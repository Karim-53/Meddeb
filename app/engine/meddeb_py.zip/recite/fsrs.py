"""FSRS-6, the default scheduler of the Free Spaced Repetition Scheduler, day-based, standard library only (X2.19,
issue #39, v0.16).

The formulas and the 21 default parameters come from py-fsrs v6.3.2 (fsrs/scheduler.py, MIT License, Copyright (c) 2022
Open Spaced Repetition; THIRD_PARTY_NOTICES.md, licenses/mit_py_fsrs.txt), rewritten here, not copied. Meddeb's use
(the user, 2026-10-25: "FSRS defaults"): two grades only (AGAIN = a fail, GOOD = a pass; HARD and EASY exist for the
formulas), no learning steps (the first review sets the initial stability and difficulty and goes straight to review),
desired retention 0.9, whole local calendar days (a review on the same day as the last one takes FSRS-6's short-term
formula), intervals of at least one day, no fuzz. A fail is due again the same day: the review rules cap the retries
(recite/review.py).
"""
from __future__ import annotations

import math
from dataclasses import dataclass

# py-fsrs v6.3.2 DEFAULT_PARAMETERS (FSRS-6); the last one is the decay (FSRS_DEFAULT_DECAY)
W6 = (0.212, 1.2931, 2.3065, 8.2956, 6.4133, 0.8334, 3.0194, 0.001, 1.8722, 0.1666, 0.796, 1.4835, 0.0614, 0.2629,
      1.6483, 0.6014, 1.8729, 0.5425, 0.0912, 0.0658, 0.1542)
AGAIN, HARD, GOOD, EASY = 1, 2, 3, 4
RETENTION = 0.9
S_MIN = 0.001                   # STABILITY_MIN
D_MIN, D_MAX = 1.0, 10.0
MAX_IVL = 36500                 # py-fsrs maximum_interval (days)


@dataclass(frozen=True)
class State:
    s: float                    # stability: days until the recall probability falls to 90 %
    d: float                    # difficulty, 1..10
    last: int                   # the day (date ordinal) of the last review
    reps: int = 0


class Fsrs:
    def __init__(self, w: tuple[float, ...] = W6, retention: float = RETENTION) -> None:
        if len(w) != 21:
            raise ValueError(f"FSRS-6 takes 21 parameters, not {len(w)}")
        self.w, self.retention = tuple(w), retention
        self.decay = -self.w[20]
        self.factor = 0.9 ** (1 / self.decay) - 1      # so that r(s, s) = 0.9

    def r(self, s: float, days: float) -> float:
        """The recall probability `days` after a review that left stability s (a negative age counts as 0)."""
        return (1 + self.factor * max(0.0, days) / s) ** self.decay

    def interval(self, s: float) -> int:
        """Days until the recall probability reaches the desired retention, rounded, 1..MAX_IVL (= s at 0.9)."""
        ivl = s / self.factor * (self.retention ** (1 / self.decay) - 1)
        return min(max(round(ivl), 1), MAX_IVL)

    def _d0(self, g: int) -> float:
        return self.w[4] - math.exp(self.w[5] * (g - 1)) + 1

    def _next_d(self, d: float, g: int) -> float:
        delta = -self.w[6] * (g - 3)
        damped = d + (10.0 - d) * delta / 9.0                          # linear damping
        return min(max(self.w[7] * self._d0(EASY) + (1 - self.w[7]) * damped, D_MIN), D_MAX)   # mean reversion

    def _short_term(self, s: float, g: int) -> float:
        inc = math.exp(self.w[17] * (g - 3 + self.w[18])) * s ** -self.w[19]
        if g >= HARD:
            inc = max(inc, 1.0)                                         # a pass the same day never lowers S
        return max(s * inc, S_MIN)

    def _recall(self, d: float, s: float, r: float, g: int) -> float:
        hard = self.w[15] if g == HARD else 1.0
        easy = self.w[16] if g == EASY else 1.0
        return s * (1 + math.exp(self.w[8]) * (11 - d) * s ** -self.w[9] * (math.exp((1 - r) * self.w[10]) - 1)
                    * hard * easy)

    def _forget(self, d: float, s: float, r: float) -> float:
        long = self.w[11] * d ** -self.w[12] * ((s + 1) ** self.w[13] - 1) * math.exp((1 - r) * self.w[14])
        return min(long, s / math.exp(self.w[17] * self.w[18]))

    def review(self, st: State | None, g: int, day: int) -> State:
        """The state after a review graded g on `day` (a date ordinal); st None: the first review."""
        if st is None:
            return State(max(self.w[g - 1], S_MIN), min(max(self._d0(g), D_MIN), D_MAX), day, 1)
        days = day - st.last
        if days < 1:
            s = self._short_term(st.s, g)
        else:
            r = self.r(st.s, days)
            s = max(self._recall(st.d, st.s, r, g) if g >= HARD else self._forget(st.d, st.s, r), S_MIN)
        return State(s, self._next_d(st.d, g), day, st.reps + 1)

    def due(self, st: State, g: int) -> int:
        """The day the next review is due after a review graded g that left st: a fail the same day, a pass after
        interval(s)."""
        return st.last if g == AGAIN else st.last + self.interval(st.s)
