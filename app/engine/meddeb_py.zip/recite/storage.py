"""Settings > Space used (U1.17, issue #14): the profile measured by kind, and the user's own deletes.

Kinds of the profile folder:
  recordings     sessions/*/audio.wav (your voice)
  history        sessions/*/session.json, decodes.jsonl, summary.md, marks.jsonl (what Progress, the word colours,
                 the Listen buttons and the accepted heard forms are built from) and review.jsonl (the Review page's
                 events, D4.8, issue #39)
  profile_other  everything else in the profile (settings.json, profile.json, logs/...): never deleted here
  old_reports    logs/reports/ (Meddeb 0.8's bug report files, D4.7)
  backups        the copies an import keeps next to the profile (<name>.before-import-*, Android's <name>.importing)

A symbolic link or a Windows junction below the folder being measured or cleaned is never counted, entered nor
followed; the folder itself is resolved once (a profile reached through a junction still counts). A delete removes
regular files only, each checked to be inside that folder, then the folders it left empty. stdlib only (Chaquopy).
"""
from __future__ import annotations

import os
import re
import stat
from pathlib import Path

RECORDING = "audio.wav"
HISTORY_FILES = ("session.json", "decodes.jsonl", "summary.md")
MARKS = "marks.jsonl"
REVIEW = "review.jsonl"                            # D4.8 (issue #39, v0.16): counted and deleted with the history
REPORTS = ("logs", "reports")                      # v0.8 bug report zips (D4.7)
KINDS = ("recordings", "history", "profile_other", "old_reports", "backups")
DELETABLE = ("recordings", "history", "old_reports", "backups")
NEEDS_NO_SESSION = ("recordings", "history")       # they touch the files a session's save writes
RECITING = "a recitation is running or being saved: stop it first (■)"


def _is_link_entry(e: os.DirEntry) -> bool:
    return e.is_symlink() or bool(getattr(e, "is_junction", lambda: False)())     # 3.12: DirEntry.is_junction


def _is_link(p: Path) -> bool:
    return os.path.islink(p) or bool(getattr(os.path, "isjunction", lambda _p: False)(p))


def _real(top: Path) -> Path:
    return Path(os.path.realpath(top))


def walk_files(top: Path, resolve: bool = True):
    """(path, size) of every regular file under top; links and junctions below it are neither counted nor entered;
    unreadable folders are skipped. resolve: the profile root itself may be reached through a link (resolved once); a
    folder below it (resolve=False) that is a link is not walked at all."""
    if not resolve and _is_link(top):
        return
    top = _real(top)
    if not top.is_dir():
        return
    stack = [top]
    while stack:
        d = stack.pop()
        try:
            with os.scandir(d) as it:
                entries = list(it)
        except OSError:
            continue
        for e in entries:
            try:
                if _is_link_entry(e):
                    continue
                if e.is_dir(follow_symlinks=False):
                    stack.append(Path(e.path))
                elif e.is_file(follow_symlinks=False):
                    yield Path(e.path), e.stat(follow_symlinks=False).st_size
            except OSError:
                continue


def kind_of(rel: tuple[str, ...]) -> str:
    """The kind of a file from its path relative to the profile."""
    if len(rel) == 3 and rel[0] == "sessions":
        return "recordings" if rel[2] == RECORDING else "history" if rel[2] in HISTORY_FILES else "profile_other"
    if rel in ((MARKS,), (REVIEW,)):
        return "history"
    if rel[:2] == REPORTS:
        return "old_reports"
    return "profile_other"


def backup_dirs(root: Path) -> list[Path]:
    """Import's copies next to the profile: <name>.before-import-<stamp> (PC and Android) and Android's unfinished
    <name>.importing; real folders only. A profile reached through a link: next to the link (where import puts them)
    and next to its target."""
    found: dict[str, Path] = {}
    for r in (Path(os.path.abspath(root)), _real(root)):
        pat = re.compile(re.escape(r.name) + r"\.(?:before-import-[\w.-]+|importing)")
        try:
            for d in r.parent.iterdir():
                if pat.fullmatch(d.name) and not _is_link(d) and d.is_dir():
                    found.setdefault(os.path.realpath(d), d)
        except OSError:
            pass
    return sorted(found.values())


def profile_storage(root: Path) -> dict[str, dict]:
    """{kind: {id, bytes, files, deletable, ...}}: recordings + orphans (recordings whose session.json is gone: no
    longer a saved session), history + sessions (folders with a session.json), backups + folders."""
    given, root = root, _real(root)
    rows = {k: {"id": k, "bytes": 0, "files": 0, "deletable": k in DELETABLE} for k in KINDS}
    with_doc, with_audio = set(), set()
    for path, size in walk_files(root):
        rel = path.relative_to(root).parts
        k = kind_of(rel)
        rows[k]["bytes"] += size
        rows[k]["files"] += 1
        if len(rel) == 3 and rel[0] == "sessions":
            if rel[2] == "session.json":
                with_doc.add(rel[1])
            elif rel[2] == RECORDING:
                with_audio.add(rel[1])
    rows["recordings"]["orphans"] = len(with_audio - with_doc)
    rows["history"]["sessions"] = len(with_doc)
    copies = backup_dirs(given)
    for d in copies:
        for _p, size in walk_files(d, resolve=False):
            rows["backups"]["bytes"] += size
            rows["backups"]["files"] += 1
    rows["backups"]["folders"] = len(copies)
    return rows


def _inside(p: Path, top: Path) -> bool:
    try:
        t = os.path.realpath(top)
        return os.path.commonpath([os.path.realpath(p), t]) == t
    except ValueError:                             # another drive
        return False


def remove_files(paths, top: Path) -> dict:
    """Unlinks the regular files among paths that sit inside top: {bytes, files, kept} (kept: refused by the system,
    e.g. a file in use on Windows)."""
    out = {"bytes": 0, "files": 0, "kept": 0}
    for p in paths:
        try:
            st = os.lstat(p)
            if not stat.S_ISREG(st.st_mode) or not _inside(Path(p).parent, top):
                continue
            os.unlink(p)
            out["bytes"] += st.st_size
            out["files"] += 1
        except FileNotFoundError:
            continue
        except OSError:
            out["kept"] += 1
    return out


def prune_empty(top: Path, keep_top: bool = True) -> None:
    """Removes the empty real folders under top, deepest first (top too unless keep_top); links are never entered, and
    a top that is a link is left alone."""
    if _is_link(top):
        return
    top = _real(top)
    dirs, stack = [], [top]
    while stack:
        d = stack.pop()
        dirs.append(d)
        try:
            with os.scandir(d) as it:
                stack += [Path(e.path) for e in it if not _is_link_entry(e) and e.is_dir(follow_symlinks=False)]
        except OSError:
            pass
    for d in sorted(dirs, key=lambda x: len(x.parts), reverse=True):
        if d == top and keep_top:
            continue
        try:
            os.rmdir(d)
        except OSError:
            pass


def delete_profile_data(root: Path, what: str) -> dict:
    """The user's delete of one kind (DELETABLE) -> {ok: True, what, bytes, files, kept}. ValueError for another."""
    if what not in DELETABLE:
        raise ValueError(f"{what!r} cannot be deleted here")
    given, root = root, _real(root)
    total = {"bytes": 0, "files": 0, "kept": 0}

    def add(r: dict) -> None:
        for k in total:
            total[k] += r[k]

    sessions = root / "sessions"
    if what in ("recordings", "history"):
        names = (RECORDING,) if what == "recordings" else HISTORY_FILES
        targets = [p for p, _ in walk_files(sessions, resolve=False)
                   if len(p.relative_to(sessions).parts) == 2 and p.name in names]
        if what == "history":
            targets += [root / MARKS, root / REVIEW]
        add(remove_files(targets, root))
        prune_empty(sessions)                      # sessions/ itself stays
    elif what == "old_reports":
        top = root.joinpath(*REPORTS)
        if not _is_link(root / REPORTS[0]):        # logs/ or logs/reports as a link: never followed
            add(remove_files([p for p, _ in walk_files(top, resolve=False)], top))
            prune_empty(top, keep_top=False)
    else:                                          # backups
        for d in backup_dirs(given):
            add(remove_files([p for p, _ in walk_files(d, resolve=False)], d))
            prune_empty(d, keep_top=False)
    return {"ok": True, "what": what, **total}
