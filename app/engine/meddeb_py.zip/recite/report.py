"""U1.16 Report a bug (D3 of the v0.9 round, user 2026-10-11, issue #8): "when you click on the button it takes a
screenshot automatically and writes in the issue the current app version, the screenshot name and the session name,
without attaching any file or uploading any file".

The platform takes the screenshot (Android: Download/Meddeb/meddeb_shot_<yyyy-mm-dd_HH-MM-SS>.png on the phone; the PC
takes none), App.report names the session, and this module writes the text of the prefilled new-issue page of
REPORT_REPO: two empty prompts (what happened, what was expected), then one line each for the app version (+ Android's
versionCode), the phone (or the computer), on Android Android Auto's last connection (v0.13, #11), the screenshot's
name and where it is, and the session's name. Nothing is
written, attached or sent: the user describes the bug and submits the issue. Pure: the standard library only.

(v0.8's zip with the recording, the logs and the app state, its mu-law audio and report_issue were removed in v0.9:
git history keeps them.)
"""
from __future__ import annotations

from urllib.parse import quote

from . import __version__

REPORT_REPO = "Karim-53/Meddeb_android"   # the tracker of the phone and the PC (the body names the platform)
WEB_REPO = "Karim-53/Meddeb"               # P5.11 (#37, user 2026-10-25): the web app's, public: anyone can report
LABELS = ("bug",)
MAX_URL = 7000                 # the prefilled new-issue URL (GitHub answers 414 above an unpublished limit)
SHOT_FOLDER = "Download/Meddeb"   # where Android saves the screenshot (MediaStore, Android 10+) unless told
WIDTH = 200                    # characters of one fact in the body
CAR_WIDTH = 160                # characters of the Android Auto fact (v0.13, #11)
PLATFORMS = {"android": "Android", "pc": "PC", "web": "Web"}
NO_SESSION = "no session"
TITLE_PLACEHOLDER = "…"        # the user replaces it with a few words


def report_repo(platform: str) -> str:
    """The repository whose issues a report opens: the public Karim-53/Meddeb for the web app (strangers cannot open
    an issue in the private Meddeb_android), Meddeb_android for the phone and the PC."""
    return WEB_REPO if platform == "web" else REPORT_REPO


def _one_line(v, width: int = WIDTH) -> str:
    """A fact as one line of the body: no line break (a value cannot add a line of its own), no backtick (it would
    close the code span around a name), at most width characters."""
    text = " ".join(str(v).replace("`", "'").split())
    return text if len(text) <= width else text[: width - 1] + "…"


def app_version(device: dict | None) -> tuple[str, str | None]:
    """(version, versionCode) of the app: the platform's own (Android's versionName and versionCode in the device
    facts), else recite's __version__ (the PC's version, U1.12) and no code."""
    d = device if isinstance(device, dict) else {}
    version = next((d[k] for k in ("app_version", "version_name", "versionName") if d.get(k) not in (None, "")),
                   __version__)
    code = next((d[k] for k in ("app_version_code", "version_code", "versionCode") if d.get(k) not in (None, "")),
                None)
    return _one_line(version, 40), None if code is None else _one_line(code, 20)


def device_line(platform: str, device: dict | None) -> tuple[str, str]:
    """("Phone", "samsung SM-A336B, Android 15 (SDK 35)") on Android (ReportLogic.deviceJson's manufacturer, model,
    android, sdk); ("Browser", "Chrome 155 on Windows") on the web (engine.js browserFacts); ("Computer", the OS) on
    the PC; a fact the platform did not give is left out (none: unknown)."""
    d = device if isinstance(device, dict) else {}
    f = {k: str(v) for k, v in d.items() if v not in (None, "") and isinstance(v, (str, int, float))}
    if platform == "android":
        phone = " ".join(f[k] for k in ("manufacturer", "model") if k in f)
        system = " ".join(([f"Android {f['android']}"] if "android" in f else []) +
                          ([f"(SDK {f['sdk']})"] if "sdk" in f else []))
        return "Phone", _one_line(", ".join(x for x in (phone, system) if x) or "unknown")
    if platform == "web":
        return "Browser", _one_line(" on ".join(f[k] for k in ("browser", "os") if k in f) or "unknown")
    return "Computer", _one_line(f.get("os") or "unknown")


def car_text(platform: str, device: dict | None) -> str | None:
    """Android Auto's last connection on Android (v0.13, #11, plan D7): Kotlin's DeviceFacts.car (CarFacts.reportLine,
    e.g. "last connection 2026-10-20 08:12 (Meddeb 0.13, cold start, answered after 840 ms); standby bucket active, not
    background restricted"), one line of at most CAR_WIDTH characters; None elsewhere, or without a non-empty string."""
    car = (device if isinstance(device, dict) else {}).get("car")
    if platform != "android" or not isinstance(car, str):
        return None
    return _one_line(car, CAR_WIDTH) or None


def screenshot_text(shot, platform: str) -> str:
    """The screenshot's name and where it is: android_report_shot's answer {ok, name, folder} or a bare name (in
    Download/Meddeb on Android); "none" without one (the PC, a failed capture)."""
    if isinstance(shot, dict):
        name, folder = (shot.get("name") if shot.get("ok", True) else None), shot.get("folder")
    else:
        name, folder = shot, None
    if not isinstance(name, str) or not name.strip():
        return "none"
    if not isinstance(folder, str) or not folder.strip():
        folder = SHOT_FOLDER if platform == "android" else None
    where = (f" in {_one_line(folder)}" if folder else "") + (" on the phone" if platform == "android" else "")
    return f"`{_one_line(name, 120)}`{where}"


def session_label(folder: str | None, note: str | None = None, code: bool = False) -> str:
    """The session's name: its folder (the saved one, or the one a running session will be saved under) + (note), or
    "no session" (+ (note)); code: the folder as a code span (the issue body)."""
    name = (f"`{_one_line(folder)}`" if code else _one_line(folder)) if folder else NO_SESSION
    return f"{name} ({_one_line(note, 80)})" if note else name


def issue_text(info: dict) -> tuple[str, str]:
    """(title, body) of the prefilled issue. info: platform (android | pc | web), device (the platform's facts, B3.8),
    screenshot (android_report_shot's answer or a name; None), session (folder name or None), session_note (e.g.
    "running, not saved yet"), short (the title's words; default a placeholder the user replaces). Title
    "Bug: <short> (Meddeb <version>)"; the body: the two prompts, then the facts (on Android, device.car adds
    "- Android Auto: …" after the Phone line)."""
    plat = str(info.get("platform") or "pc")
    device = info.get("device") if isinstance(info.get("device"), dict) else {}
    version, code = app_version(device)
    short = _one_line(info.get("short") or TITLE_PLACEHOLDER, 100)
    title = f"Bug: {short} (Meddeb {version})"
    label, machine = device_line(plat, device)
    car = car_text(plat, device)
    app = f"Meddeb {version}" + (f" (versionCode {code})" if code else "")
    body = "\n".join([
        "**What happened?**", "", "", "**What did you expect?**", "", "",
        "---",
        f"- App: {app}, {PLATFORMS.get(plat) or _one_line(plat, 20)}",
        f"- {label}: {machine}",
        *([f"- Android Auto: {car}"] if car else []),
        f"- Screenshot: {screenshot_text(info.get('screenshot'), plat)}",
        f"- Session: {session_label(info.get('session'), info.get('session_note'), code=True)}"])
    return title, body


def issue_url(repo: str, title: str, body: str, labels: tuple[str, ...] = LABELS, max_len: int = MAX_URL) -> str:
    """https://github.com/<repo>/issues/new?labels=…&title=…&body=…, at most max_len characters: the body is cut
    from its end until it fits (the facts are a few short lines: only an odd input gets there)."""
    base = (f"https://github.com/{repo}/issues/new?labels={quote(','.join(labels), safe='')}"
            f"&title={quote(title, safe='')}&body=")
    url = base + quote(body, safe="")
    while len(url) > max_len and body:
        body = body[: int(len(body) * 0.9)]
        url = base + quote(body, safe="")
    return url
