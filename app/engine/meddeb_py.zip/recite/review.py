"""The Review page's cards (U1.20, X2.19; issue #39, v0.16), replayed from the reading history (profile.py) and the review
events (review.jsonl, D4.8). Nothing else is stored: the cards, their states and their dates are computed at each call.

User, issue #39 (2026-10-25): "if it has 2 mistakes on 2 sessions out of the 5 last sessions then it becomes a card";
FSRS defaults; 10 cards / 3 new / 2 retries; "an error today → due today; no error → FSRS decides"; the cards with many
errors first; the weak page included; mushaf order for big errors, out of context for almost-fixed ones; the cue gets
shorter and further away as he improves; a card leaves spaced repetition for good "not tied to Manzil's 30 days".

- A word's verdicts: one per session that read it (its last reading of that session: a mark made after ■ amends it; a
  fail when that reading is a mistake or the session revealed the word by a hint, as progress.learned_moment) and one
  per mark made outside any session, in the order the word was said; only those from its ayah's learned moment on
  (#17, the learned session included); a verdict dated after today counts nowhere. Link rule: a pass on an ayah's first
  word (ayah > 1) counts only when the same session read the word before it; a fail always counts.
- Card rule: a word becomes a card at its first verdict that leaves CARD_FAILS fails among its last CARD_WINDOW
  verdicts; the Next to learn page is left out (being learned). It retires at S >= RETIRE_S with its last RETIRE_PASSES
  verdicts passed on as many days; a fail after that brings it back at once. Lapses (fails right after a pass, since its
  birth) >= LEECH_LAPSES: stubborn.
- Nearby words make one card (per surah, mushaf order, the global line (page - 1) x 15 + line): at most JOIN_LINES
  after the card's previous word and less than SPAN_LINES after its first; the target is the ayat they lie in; two
  cards sharing an ayah are one. #87 (v0.20, D13): after their events, two consecutive cards of one surah both
  reviewable today, the second starting at most one ayah after the first's target, are one card for the day (rebuilt
  from both word sets), while the target spans at most MERGE_LINES lines; recomputed at each call.
- Schedule: recite/fsrs.py per word (a fail is due that day, a pass after interval(S)); a card is due when one of its
  words is; MAX_RETRIES retries a day after a fail (a "shown" after today's first fail, unless a "skip" followed it),
  then tomorrow. Today's round: DAILY_CARDS cards, DAILY_NEW of them new (born before today, never shown); #46 (v0.17,
  user 2026-10-26: "update the reviews after each recite session"): a card born from today's mistake is red, to fix
  today, outside DAILY_NEW; review_queue says what today's mistakes made (today_mistakes). #81 (v0.20, D8): given the
  time, a card failed today waits RETRY_GAP from its last showing today (wait_until), after the round's other cards.
"""
from __future__ import annotations

import datetime as dt
import random
import re
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Callable, Iterable, NamedTuple

from .fsrs import AGAIN, GOOD, Fsrs, State
from .normalize import normalize
from .profile import REVIEW_EVENTS, Reading, _overruled
from .progress import next_to_learn
from .quran_text import Quran, page_lines, page_of

CARD_FAILS, CARD_WINDOW = 2, 5          # the user's rule: 2 mistakes in the last 5 sessions
RETIRE_S, RETIRE_PASSES = 60.0, 3       # leaves for good: S >= 60 days, the last 3 verdicts passed on 3 days
LEECH_LAPSES = 8                        # Anki's leech threshold: "stubborn"
MAX_RETRIES = 2                         # after a fail today: at most 2 more showings today
RETRY_GAP = dt.timedelta(minutes=45)    # #81 (v0.20): a retry waits 45 min from the card's last showing today
DAILY_CARDS, DAILY_NEW = 10, 3          # the user's caps
JOIN_LINES, SPAN_LINES = 2, 5           # merging: <= 2 lines after the previous word, < 5 after the first
MERGE_LINES = 15                        # #87 (v0.20): due neighbours merged for the day, a target of at most 15 lines
WEAK_REVIEWS = 2                        # a fail in the card's last 2 reviews: weak (mushaf order), else settling
LEVEL_S = (3.0, 7.0, 21.0)              # cue level 0 / 1 / 2 / 3 by the weakest word's stability (days)
RUNUP_LINES = {0: (0,), 1: (1,), 2: (2, 3), 3: (4, 5)}     # lines of run-up before the target, drawn
CUE_EXTRA = {0: (2,), 1: (1,), 2: (0, 1), 3: (0,)}         # lines of cue above the minimum (#40 measure), drawn
EVENTS = REVIEW_EVENTS
ID_RE = re.compile(r"(\d+):(\d+):(\d+)-(\d+):(\d+):(\d+)")
FSRS = Fsrs()
# the last (history, today, word_states): Profile.history() returns the same dict until the history changes and never
# changes a dict it returned, so the Review page's calls in a row (queue, card, action, queue) replay it once
_STATES: tuple | None = None
_LEARNING: tuple | None = None          # the last (history, its Next to learn page): _learning_page
DAYS =("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")


class Verdict(NamedTuple):
    t: str                      # when the word was said (a session's first reading of it, or the mark's time)
    day: int                    # its local date, as an ordinal
    fail: bool
    session: str | None         # the session's started_at; None: a mark outside any session


@dataclass
class Life:
    """One word's card life over its verdicts (life())."""
    alive: bool = False
    retired: bool = False
    born: str | None = None     # the verdict that made it a card (its latest birth)
    lapses: int = 0
    state: State | None = None


@dataclass
class WordState:
    key: str
    verdicts: list[Verdict]
    alive: bool
    retired: bool
    born: str | None
    lapses: int
    state: State
    last_fail: bool
    due: int                    # date ordinal
    errors: int                 # fails among the last CARD_WINDOW verdicts
    fail_today: str | None      # the time of its first fail verdict today


@dataclass
class Card:
    id: str                     # "s:a:i-s:a:i": its first and last word keys
    surah: int
    target: tuple[int, int]
    words: list[str]
    page: int                   # the page of the target's first ayah
    errors: int = 0
    due: int = 0                # date ordinal
    fail_now: bool = False      # a word whose last verdict is a fail
    weak: bool = False          # a fail in the card's last WEAK_REVIEWS reviews
    lapses: int = 0
    born: str | None = None
    s_min: float = 0.0
    recall: float = 1.0         # the weakest word's recall probability today
    last_day: int | None = None
    last_fail_day: int | None = None
    fail_today: str | None = None
    new: bool = True            # no "shown" since its birth, born before today (#46: DAILY_NEW applies to them)
    new_today: bool = False     # first shown since its birth today (born before today)
    fresh: bool = False         # #46: born from today's mistake, not shown since: a card to fix, outside DAILY_NEW
    suspended: bool = False
    buried: bool = False
    skips_today: int = 0
    shown_today: int = 0
    last_shown: str | None = None   # #81 (v0.20): the time of its latest "shown" today
    wait_until: str | None = None   # #81: "HH:MM", the retry's earliest time (queue with now), else None
    retries_used: int = 0
    retries_left: int = MAX_RETRIES
    level: int = 0
    state: str = "new"
    why: str = ""
    similar: list = field(default_factory=list)     # mutashabihat: empty until QUL's data has a licence (X2.19)


# ---------------------------------------------------------------------------- keys, lines, dates
def parts(key: str) -> tuple[int, int, int]:
    s, a, i = key.split(":")
    return int(s), int(a), int(i)


@lru_cache(maxsize=None)
def _page_word_lines(page: int) -> dict[str, int]:
    return {f"{s}:{a}:{k}": ln for ln, s, a, idx, n in page_lines(page) for k in range(idx, idx + n)}


def gline(key: str) -> int:
    """The global line of a word: (page - 1) x 15 + its line on the 15-line page (a page turn is one line)."""
    s, a, _ = parts(key)
    pg = page_of(s, a)
    return (pg - 1) * 15 + _page_word_lines(pg).get(key, 1)


def ayah_gline(surah: int, ayah: int) -> int:
    return gline(f"{surah}:{ayah}:0")


def _day(t) -> int | None:
    return _date_ordinal(str(t)[:10])


@lru_cache(maxsize=4096)
def _date_ordinal(day: str) -> int | None:
    try:
        return dt.date.fromisoformat(day).toordinal()
    except ValueError:
        return None


def date_text(day: int) -> str:
    """"Wed 29 Oct" (English names whatever the device's locale)."""
    d = dt.date.fromordinal(day)
    return f"{DAYS[d.weekday()]} {d.day} {MONTHS[d.month - 1]}"


def _ago(days: int) -> str:
    return "today" if days <= 0 else "yesterday" if days == 1 else f"{days} days ago"


def due_text(day: int, today: dt.date) -> str:
    return "today" if day <= today.toordinal() else dt.date.fromordinal(day).isoformat()


# ---------------------------------------------------------------------------- verdicts and a word's life
def learned_session(keys: list[str], history: dict[str, list[Reading]]) -> tuple[str, str] | None:
    """(the session, the moment) an ayah was learned: progress.learned_moment's rule (#17: the first session that read
    every word right with no hint; the moment = the latest time its words were said in it), with the session named."""
    clean: dict[str, str] | None = None
    for k in keys:
        last: dict[str, Reading] = {}
        first_t: dict[str, str] = {}
        hinted: set[str] = set()
        for r in history.get(k, ()):
            if r.session is None:
                continue
            last[r.session] = r
            first_t.setdefault(r.session, r.t)
            if r.hinted:
                hinted.add(r.session)
        mine = {s: first_t[s] for s, r in last.items() if r.outcome == "ok" and s not in hinted}
        clean = mine if clean is None else {s: max(t, mine[s]) for s, t in clean.items() if s in mine}
        if not clean:
            return None
    if not clean:
        return None
    sess = min(clean, key=lambda s: (clean[s], s))
    return sess, clean[sess]


def _word_before(key: str, q: Quran) -> str | None:
    """The link rule's word: the previous ayah's last word, for an ayah's first word (ayah > 1); else None."""
    s, a, i = parts(key)
    if i > 0 or a <= 1:
        return None
    prev = q.ayat.get((s, a - 1))
    return f"{s}:{a - 1}:{len(prev.words) - 1}" if prev and prev.words else None


def word_verdicts(key: str, history: dict[str, list[Reading]], q: Quran, today: dt.date,
                  learned: tuple[str, str] | None = None) -> list[Verdict]:
    """A word's verdicts that count (module docstring), in the order it was said. learned: learned_session of its ayah
    when the caller has it."""
    s, a, _ = parts(key)
    if learned is None:
        ay = q.ayat.get((s, a))
        learned = learned_session([w.key for w in ay.words], history) if ay else None
    if learned is None:
        return []
    sess0, moment = learned
    before = _word_before(key, q)
    linked = {r.session for r in history.get(before, ())} - {None} if before else None
    groups: dict[str, list[Reading]] = {}
    out: list[Verdict] = []
    for r in history.get(key, ()):
        if r.session is None:
            out.append(Verdict(r.t, _day(r.t), r.outcome == "mistake", None))
        else:
            groups.setdefault(r.session, []).append(r)
    for sess, rs in groups.items():
        out.append(Verdict(rs[0].t, _day(rs[0].t), rs[-1].outcome == "mistake" or any(r.hinted for r in rs), sess))
    n = today.toordinal()
    keep = [v for v in out if v.day is not None and v.day <= n and (v.session == sess0 or v.t >= moment)
            and (linked is None or v.fail or v.session in linked)]
    return sorted(keep, key=lambda v: (v.t, v.session or ""))


def life(verdicts: list[Verdict], f: Fsrs = FSRS) -> Life:
    """FSRS over the verdicts (Again = a fail, Good = a pass) and the card's birth, retirement, rebirth and lapses."""
    out = Life()
    for i, v in enumerate(verdicts):
        out.state = f.review(out.state, AGAIN if v.fail else GOOD, v.day)
        if out.alive:
            if v.fail and not verdicts[i - 1].fail:
                out.lapses += 1
            last = verdicts[i - RETIRE_PASSES + 1:i + 1] if i >= RETIRE_PASSES - 1 else []
            if not v.fail and out.state.s >= RETIRE_S and len(last) == RETIRE_PASSES and \
                    not any(x.fail for x in last) and len({x.day for x in last}) == RETIRE_PASSES:
                out.alive, out.retired = False, True
        elif v.fail and (out.retired or
                         sum(x.fail for x in verdicts[max(0, i - CARD_WINDOW + 1):i + 1]) >= CARD_FAILS):
            out.alive, out.born, out.lapses = True, v.t, 0
    return out


def word_states(history: dict[str, list[Reading]], q: Quran, today: dt.date, f: Fsrs = FSRS) -> dict[str, WordState]:
    """Every word that is or was a card, by key. A word needs CARD_FAILS readings that are mistakes or hints to have
    as many fail verdicts: the others are not even replayed."""
    n = today.toordinal()
    learned: dict[tuple[int, int], tuple[str, str] | None] = {}
    out: dict[str, WordState] = {}
    for key, rs in history.items():
        if sum(r.outcome == "mistake" or r.hinted for r in rs) < CARD_FAILS:
            continue
        try:
            s, a, _ = parts(key)
        except ValueError:
            continue
        ay = q.ayat.get((s, a))
        if ay is None:
            continue
        if (s, a) not in learned:
            learned[(s, a)] = learned_session([w.key for w in ay.words], history)
        if learned[(s, a)] is None:
            continue
        vs = word_verdicts(key, history, q, today, learned[(s, a)])
        fails = [i for i, v in enumerate(vs) if v.fail]
        if not any(j - i < CARD_WINDOW for i, j in zip(fails, fails[CARD_FAILS - 1:])):
            continue                        # never CARD_FAILS fails among CARD_WINDOW verdicts: never a card
        lf = life(vs, f)
        if lf.born is None:
            continue
        last = vs[-1]
        out[key] = WordState(key, vs, lf.alive, lf.retired, lf.born, lf.lapses, lf.state, last.fail,
                             last.day if last.fail else last.day + f.interval(lf.state.s),
                             sum(v.fail for v in vs[-CARD_WINDOW:]),
                             next((v.t for v in vs if v.fail and v.day == n), None))
    return out


# ---------------------------------------------------------------------------- cards
def level_of(s_min: float, fail_now: bool) -> int:
    """The cue level (X2.19): 0 after a fail or under LEVEL_S[0] days of stability, then 1, 2, 3."""
    if fail_now:
        return 0
    return sum(s_min >= x for x in LEVEL_S)


def _merge(words: list[WordState]) -> list[list[WordState]]:
    groups: list[list[WordState]] = []
    for w in words:
        cur = groups[-1] if groups else None
        g = gline(w.key)
        if cur and parts(cur[0].key)[0] == parts(w.key)[0] and g - gline(cur[-1].key) <= JOIN_LINES \
                and g - gline(cur[0].key) < SPAN_LINES:
            cur.append(w)
        else:
            groups.append([w])
    merged: list[list[WordState]] = []
    for grp in groups:            # an ayah is never in two cards (one longer than SPAN_LINES lines: 2:282)
        if merged and parts(merged[-1][-1].key)[:2] == parts(grp[0].key)[:2]:
            merged[-1].extend(grp)
        else:
            merged.append(grp)
    return merged


def _card(ws: list[WordState], today: dt.date, f: Fsrs) -> Card:
    n = today.toordinal()
    first, last = ws[0].key, ws[-1].key
    s, a1, _ = parts(first)
    reviews: dict[object, tuple[str, int, bool]] = {}     # one per session (or mark): the card's reviews
    for w in ws:
        for v in w.verdicts:
            k = v.session if v.session is not None else ("mark", v.t)
            old = reviews.get(k)
            reviews[k] = (min(old[0], v.t), v.day, old[2] or v.fail) if old else (v.t, v.day, v.fail)
    revs = sorted(reviews.values())
    fails_today = [w.fail_today for w in ws if w.fail_today]
    failed = [w.verdicts[-1].day for w in ws if w.last_fail]
    return Card(id=f"{first}-{last}", surah=s, target=(a1, parts(last)[1]), words=[w.key for w in ws],
                page=page_of(s, a1), errors=sum(w.errors for w in ws), due=min(w.due for w in ws),
                fail_now=bool(failed), weak=any(r[2] for r in revs[-WEAK_REVIEWS:]),
                lapses=max(w.lapses for w in ws), born=min(w.born for w in ws if w.born),
                s_min=min(w.state.s for w in ws), recall=min(f.r(w.state.s, n - w.state.last) for w in ws),
                last_day=revs[-1][1] if revs else None, last_fail_day=max(failed) if failed else None,
                fail_today=min(fails_today) if fails_today else None)


def _event_words(e: dict) -> list[str]:
    """An event's word keys (none when the field is not a list of keys)."""
    ws = e.get("words")
    return [w for w in ws if isinstance(w, str)] if isinstance(ws, list) else []


def _touches(e: dict, c: Card) -> bool:
    return e.get("card") == c.id or bool(set(e.get("words") or ()) & set(c.words))


def _event_index(events: list[dict]) -> dict[str, list[int]]:
    """#39 review (speed): review.jsonl indexed once per call -> {card id or word key: positions of its events} (an id
    holds a "-", a key never). Every card went through every event, two sets built per pair: ~1 s per call after a year
    of events, 4-5 calls per card."""
    out: dict[str, list[int]] = {}
    for i, e in enumerate(events):
        keys = set(_event_words(e))
        cid = e.get("card")
        if isinstance(cid, str):
            keys.add(cid)
        for k in keys:
            out.setdefault(k, []).append(i)
    return out


def _apply_events(c: Card, events: Iterable[dict], today: dt.date, index: dict[str, list[int]] | None = None) -> None:
    """review.jsonl on a card: suspended (until unsuspend), new, shown / skipped today, buried (bury or two skips
    today), the retries used today; then its due date after the retries, level, state and why. index: _event_index of
    the events (a list), so that the card visits its own events only."""
    day, n = today.isoformat(), today.toordinal()
    if index is None:
        mine = [e for e in events if _touches(e, c)]
    else:
        at = set(index.get(c.id, ()))
        for w in c.words:
            at.update(index.get(w, ()))
        mine = [events[i] for i in sorted(at)]
    first_shown = None
    for e in mine:
        ev, t = e.get("event"), str(e.get("t") or "")
        if ev == "suspend":
            c.suspended = True
        elif ev == "unsuspend":
            c.suspended = False
        elif ev == "shown":
            if c.born and t >= c.born and first_shown is None:
                first_shown = t
            c.shown_today += t[:10] == day
            if t[:10] == day and (c.last_shown is None or t > c.last_shown):
                c.last_shown = t
        elif ev == "skip" and t[:10] == day:
            c.skips_today += 1
        elif ev == "bury" and t[:10] == day:
            c.buried = True
    # #46 (v0.17): a card born today (from today's mistake) is no new card: red, to fix today, outside DAILY_NEW
    born_today = bool(c.born) and str(c.born)[:10] == day
    c.new, c.fresh = first_shown is None and not born_today, first_shown is None and born_today
    c.new_today = bool(first_shown) and first_shown[:10] == day and not born_today
    c.buried = c.buried or c.skips_today >= 2
    if c.fail_today:
        seq = [e for e in mine if str(e.get("t") or "")[:10] == day and e.get("event") in ("shown", "skip")]
        c.retries_used = sum(1 for k, e in enumerate(seq) if e["event"] == "shown" and str(e["t"]) > c.fail_today
                             and not (k + 1 < len(seq) and seq[k + 1]["event"] == "skip"))
    c.retries_left = max(0, MAX_RETRIES - c.retries_used)
    if c.fail_now and c.fail_today and c.retries_left == 0 and c.due <= n:
        c.due = n + 1                       # the retries of the day are used: tomorrow
    c.level = level_of(c.s_min, c.fail_now)
    c.state = "stubborn" if c.lapses >= LEECH_LAPSES else "new" if c.new else "red" if c.fail_now else "green"
    c.why = _why(c, today)


def _why(c: Card, today: dt.date) -> str:
    n = today.toordinal()
    if c.suspended:
        return "Suspended"
    if c.state == "stubborn":
        return f"Stubborn: {c.lapses} lapses, try Help me learn first"
    if c.state == "new":
        return f"{c.errors} mistake{'' if c.errors == 1 else 's'} in your last {CARD_WINDOW} readings"
    if c.due > n:
        return f"Next review {date_text(c.due)}"
    if c.fail_now:
        if c.fresh:
            return f"Missed today: {c.errors} mistake{'' if c.errors == 1 else 's'} in your last {CARD_WINDOW} readings"
        if c.fail_today:
            return f"Again today, retry {min(c.retries_used + 1, MAX_RETRIES)} of {MAX_RETRIES}"
        return f"Missed {_ago(n - (c.last_fail_day or n))}, again today"
    return f"Due today (last seen {_ago(n - (c.last_day or n))})"


def _states(history: dict[str, list[Reading]], q: Quran, today: dt.date, f: Fsrs) -> dict[str, WordState]:
    """word_states, cached for the last (history, today) (_STATES)."""
    global _STATES
    cached = _STATES
    if f is FSRS and cached is not None and cached[0] is history and cached[1] == today:
        return cached[2]
    states = word_states(history, q, today, f)
    if f is FSRS:
        _STATES = (history, today, states)
    return states


def _learning_page(history: dict[str, list[Reading]], q: Quran) -> int | None:
    """The Next to learn page (U1.11): being learned, no card there. Cached for the last history, as _STATES."""
    global _LEARNING
    cached = _LEARNING
    if cached is not None and cached[0] is history:
        return cached[1]
    latest = {k: rs[-1] for k, rs in history.items() if rs}
    nxt = next_to_learn(latest, {k for k, r in latest.items() if r.outcome == "mistake"}, q)
    page = page_of(*nxt) if nxt else None
    _LEARNING = (history, page)
    return page


def cards(history: dict[str, list[Reading]], q: Quran, today: dt.date, events: Iterable[dict] = (),
          f: Fsrs = FSRS) -> list[Card]:
    """Every living card (due or not, suspended or not) in mushaf order, with its schedule and its events. #87 (v0.20,
    D13): two consecutive cards both reviewable today whose second starts at most one ayah after the first's target
    are one card for the day (_joins), rebuilt from both word sets with the events of both; a merged card that is no
    longer reviewable once its events are applied (two skips between its parts: buried) stays as its parts."""
    states = _states(history, q, today, f)
    if not states:
        return []
    learning = _learning_page(history, q)               # the Next to learn page: being learned, no card there
    alive = sorted((w for w in states.values() if w.alive and page_of(*parts(w.key)[:2]) != learning),
                   key=lambda w: parts(w.key))
    events = list(events)
    index = _event_index(events)                        # #39 review: each card visits its own events only
    n = today.toordinal()
    out: list[tuple[Card, list[WordState]]] = []        # each card with its words
    for grp in _merge(alive):
        c = _card(grp, today, f)
        _apply_events(c, events, today, index)
        if out and _joins(out[-1][0], c, n, q):
            ws = out[-1][1] + grp
            m = _card(ws, today, f)
            _apply_events(m, events, today, index)
            if _reviewable(m, n):
                out[-1] = (m, ws)
                continue
        out.append((c, grp))
    return [c for c, _ws in out]


def _reviewable(c: Card, n: int) -> bool:
    """Due today (or before), neither suspended nor buried: in today's round when the caps allow it."""
    return c.due <= n and not c.suspended and not c.buried


def _joins(a: Card, b: Card, n: int, q: Quran) -> bool:
    """#87 (v0.20, D13; user, 2026-10-31: "definitely card 1 and 2 must be merged i.e. the finish eya should be the one
    of card 2"): b (the next card in mushaf order) joins a for the day: one surah, both reviewable today, b starting at
    most one ayah after a's target ends, the merged target spanning at most MERGE_LINES lines (from its first ayah's
    first word to its last ayah's last word). Else the next card's grey cue would be the ayah just recited."""
    if a.surah != b.surah or b.target[0] > a.target[1] + 1 or not (_reviewable(a, n) and _reviewable(b, n)):
        return False
    last = q.ayat.get((b.surah, b.target[1]))
    if last is None or not last.words:
        return False
    return gline(last.words[-1].key) - ayah_gline(a.surah, a.target[0]) + 1 <= MERGE_LINES


def _shown_today(events: list[dict], day: str) -> list[list]:
    """#39 review: the cards shown on `day` from review.jsonl alone, gone since or not -> [[card ids, words, new]], one
    per card: its "shown" events sharing a card id or a word (an id changes when a word joins the card); new: one was
    flagged new when shown (review_action)."""
    groups: list[list] = []
    for e in events:
        if e.get("event") != "shown" or str(e.get("t") or "")[:10] != day:
            continue
        g = [{e["card"]} if isinstance(e.get("card"), str) else set(), set(_event_words(e)), bool(e.get("new"))]
        rest = []
        for h in groups:
            if h[0] & g[0] or h[1] & g[1]:
                g = [g[0] | h[0], g[1] | h[1], g[2] or h[2]]
            else:
                rest.append(h)
        groups = rest + [g]
    return groups


def card_dict(c: Card, today: dt.date) -> dict:
    """A card as review_queue sends it (B3.16)."""
    return {"id": c.id, "surah": c.surah, "target": [c.target[0], c.target[1]], "words": list(c.words), "page": c.page,
            "errors": c.errors, "due": due_text(c.due, today), "state": c.state, "level": c.level, "why": c.why,
            "shown_today": c.shown_today, "lapses": c.lapses, "similar": list(c.similar),
            "wait_until": c.wait_until}         # #81 (v0.20): "HH:MM" while the card waits for its retry, else None


def _failed_today(rs: list[Reading], day: str) -> bool:
    """A fail verdict on `day` among a word's readings (word_verdicts' grouping, before its learned-moment and link
    filters): a session of that day whose last reading of the word is a mistake or that revealed it by a hint, or a
    mistake marked outside any session that day."""
    for r in reversed(rs):                  # in time order: only the readings from that day on are looked at
        d = r.t[:10]
        if d < day:
            return False
        if d == day and (r.outcome == "mistake" or r.hinted):
            break
    else:
        return False
    sessions: dict[str, list[Reading]] = {}
    for r in rs:
        if r.session is None:
            if r.t[:10] == day and r.outcome == "mistake":
                return True
        else:
            sessions.setdefault(r.session, []).append(r)
    return any(g[0].t[:10] == day and (g[-1].outcome == "mistake" or any(r.hinted for r in g))
               for g in sessions.values())


def today_mistakes(history: dict[str, list[Reading]], q: Quran, today: dt.date, allc: list[Card],
                   f: Fsrs = FSRS) -> dict:
    """#46 (v0.17): what today's mistakes made -> {words: the words with a fail verdict today, then of those (each in
    the first that holds it) cards: in a living card (allc), next_to_learn: on the Next to learn page (no card there),
    not_learned: their ayah never read clean (no verdict counts yet), one_more: CARD_FAILS - 1 fails in their last
    CARD_WINDOW verdicts (one more mistake makes a card)}. Only the words read today are replayed."""
    day = today.isoformat()
    out = {"words": 0, "cards": 0, "one_more": 0, "not_learned": 0, "next_to_learn": 0}
    in_card = {w for c in allc for w in c.words}
    learned: dict[tuple[int, int], tuple[str, str] | None] = {}
    learning, states = ..., None
    for key, rs in history.items():
        if not rs or not _failed_today(rs, day):
            continue
        try:
            s, a, _ = parts(key)
        except ValueError:
            continue
        ay = q.ayat.get((s, a))
        if ay is None:
            continue
        out["words"] += 1
        if learning is ...:
            learning = _learning_page(history, q)
        if key in in_card:
            out["cards"] += 1
        elif page_of(s, a) == learning:
            out["next_to_learn"] += 1
        else:
            if (s, a) not in learned:
                learned[(s, a)] = learned_session([w.key for w in ay.words], history)
            if learned[(s, a)] is None:
                out["not_learned"] += 1
                continue
            if states is None:
                states = _states(history, q, today, f)        # cards() just replayed them: cached
            w = states.get(key)
            vs = w.verdicts if w is not None else word_verdicts(key, history, q, today, learned[(s, a)])
            out["one_more"] += sum(v.fail for v in vs[-CARD_WINDOW:]) == CARD_FAILS - 1
    return out


def queue(history: dict[str, list[Reading]], q: Quran, today: dt.date, events: Iterable[dict] = (),
          f: Fsrs = FSRS, now: dt.datetime | None = None) -> dict:
    """review_queue (B3.16): today's round (the due cards, not suspended nor buried; the cards shown today count first
    against DAILY_CARDS / DAILY_NEW, then red by most errors, then the lowest recall), ordered weak cards in mushaf
    order, settling ones shuffled by the date, the cards skipped once today last; the counters; the suspended cards;
    today_mistakes (#46). #46 (v0.17): a card born from today's mistake is not new (Card.fresh): red, outside DAILY_NEW.
    #81 (v0.20, D8): now (local time) given, a card waiting for its retry (_wait) goes after the others, the soonest
    first, with wait_until and "Again at HH:MM (retry n of 2)"; it stays in the round and its counters."""
    events = list(events)
    allc = cards(history, q, today, events, f)
    n = today.toordinal()
    suspended = [c for c in allc if c.suspended]
    due = [c for c in allc if not c.suspended and not c.buried and c.due <= n]
    # #39 review: today's showings come from review.jsonl itself, not only from the living cards: a card shown today
    # that has gone since (retired by today's pass, unmade by a Remove, its page now Next to learn) still counts, so no
    # extra card enters; a showing that became two living cards counts as both (the round never passes the caps)
    shown = _shown_today(events, today.isoformat())
    living = [c for c in allc if c.shown_today]
    for c in living:
        if c.new_today:
            for g in shown:
                if c.id in g[0] or set(c.words) & g[1]:
                    g[2] = True
    used = max(len(shown), len(living))
    new_used = max(sum(g[2] for g in shown), sum(c.new_today for c in living))
    chosen = [c for c in due if c.shown_today]

    def priority(c: Card):
        return (not c.fail_now, -c.errors if c.fail_now else 0, c.recall, parts(c.words[0]))
    for c in sorted((c for c in due if not c.shown_today), key=priority):
        if used >= DAILY_CARDS:
            break
        if c.new and new_used >= DAILY_NEW:
            continue
        chosen.append(c)
        used += 1
        new_used += c.new
    pos = lambda c: parts(c.words[0])                     # noqa: E731
    weak = sorted((c for c in chosen if c.weak and not c.skips_today), key=pos)
    settling = sorted((c for c in chosen if not c.weak and not c.skips_today), key=pos)
    random.Random(today.isoformat()).shuffle(settling)    # out of context, a new order every day
    skipped = sorted((c for c in chosen if c.skips_today), key=pos)
    waiting = []
    if now is not None:
        for c in chosen:
            _wait(c, now)
        waiting = sorted((c for c in chosen if c.wait_until), key=lambda c: (c.wait_until, pos(c)))
        weak, settling, skipped = ([c for c in g if not c.wait_until] for g in (weak, settling, skipped))
    ordered = weak + settling + skipped + waiting
    red = sum(c.fail_now for c in ordered)
    return {"today": today.isoformat(),
            "counters": {"red": red, "green": len(ordered) - red, "total_due": len(ordered),
                         "suspended": len(suspended), "waiting": len(due) - len(ordered)},
            "cards": [card_dict(c, today) for c in ordered],
            "suspended": [card_dict(c, today) for c in suspended],
            "today_mistakes": today_mistakes(history, q, today, allc, f)}


def _wait(c: Card, now: dt.datetime) -> None:
    """#81 (v0.20, D8; user, 2026-10-30: "it should have been some other card and not seeing card one before at least
    45min !"): a card with a fail today, still due, shown today waits until its latest showing + RETRY_GAP (the
    showing is recorded when the card starts, so the gap runs from that attempt): wait_until "HH:MM" and its why."""
    if not (c.fail_now and c.fail_today and c.last_shown):
        return
    try:
        until = dt.datetime.fromisoformat(c.last_shown).replace(tzinfo=None) + RETRY_GAP
    except ValueError:
        return
    if now.replace(tzinfo=None) < until:
        c.wait_until = until.strftime("%H:%M")
        c.why = f"Again at {c.wait_until} (retry {min(c.retries_used + 1, MAX_RETRIES)} of {MAX_RETRIES})"


# ---------------------------------------------------------------------------- calls' helpers
def card_id(value) -> str:
    """A card id from a call's `card` (the id, or a card object with its id). ValueError: not a card id."""
    cid = value.get("id") if isinstance(value, dict) else value
    if not isinstance(cid, str) or not ID_RE.fullmatch(cid.strip()):
        raise ValueError(f"not a card id: {cid!r}")
    return cid.strip()


def id_words(cid: str) -> list[str]:
    first, last = card_id(cid).split("-")
    return [first] if first == last else [first, last]


def find(allc: list[Card], cid: str) -> Card | None:
    """The card of that id, else the one holding most of the words between its first and last key (an id changes when
    a word joins or leaves its card); None: no card there."""
    for c in allc:
        if c.id == cid:
            return c
    first, last = (parts(k) for k in card_id(cid).split("-"))
    best, most = None, 0
    for c in allc:
        k = sum(1 for w in c.words if first <= parts(w) <= last)
        if k > most:
            best, most = c, k
    return best


def overlapping(allc: list[Card], surah: int, target: tuple[int, int]) -> list[Card]:
    """#87 (v0.20, D13): the living cards of that surah whose target overlaps target (ayah from, to)."""
    return [c for c in allc if c.surah == surah and c.target[0] <= target[1] and target[0] <= c.target[1]]


def action_cards(allc: list[Card], cid: str) -> tuple[list[str], bool]:
    """review_action's event (D4.8) for a card id -> (its words, new). The living card of that id: its words. #87
    (v0.20, D13) review: an id gone (a merged card split once a part passed) names every living card of its surah whose
    target overlaps the id's ayat, their words joined (Skip / Suspend / Bury reach each part, not only the one
    find() picks); none: the id's own words."""
    for c in allc:
        if c.id == cid:
            return list(c.words), c.new
    ws = id_words(cid)
    s, a0 = parts(ws[0])[:2]
    near = overlapping(allc, s, (a0, parts(ws[-1])[1]))
    if not near:
        return ws, False
    words = sorted({w for c in near for w in c.words}, key=parts)
    return words, any(c.new for c in near)


def session_meta(raw, runup_from: int) -> dict | None:
    """start{review} (B3.16) -> the session's `review` meta: {card, target, level, runup_from, words?, practice?};
    None when it names no card."""
    if not isinstance(raw, dict):
        return None
    try:
        out: dict = {"card": card_id(raw.get("card")), "runup_from": int(runup_from)}
    except (TypeError, ValueError):
        return None
    t = raw.get("target")
    if isinstance(t, (list, tuple)) and len(t) == 2:
        try:
            out["target"] = [int(t[0]), int(t[1])]
        except (TypeError, ValueError):
            pass
    try:
        out["level"] = max(0, min(3, int(raw.get("level"))))
    except (TypeError, ValueError):
        pass
    if isinstance(raw.get("words"), list):
        out["words"] = [str(w) for w in raw["words"]]
    if raw.get("practice"):
        out["practice"] = True
    return out


def ayah_ok(history: dict[str, list[Reading]], q: Quran, surah: int, ayah: int, session: str) -> bool:
    """Every word of the ayah read in that session, its last reading there right, none revealed by a hint."""
    for w in q.ayah(surah, ayah).words:
        rs = [r for r in history.get(w.key, ()) if r.session == session]
        if not rs or rs[-1].outcome != "ok" or any(r.hinted for r in rs):
            return False
    return True


def result(cid: str, card: Card | None, doc: dict | None, history: dict[str, list[Reading]], q: Quran,
           today: dt.date, allc: list[Card] | None = None) -> dict:
    """review_result (B3.16): ✓ / ✗ per ayah of the saved session from the run-up to the target's end, passed when every
    target ayah is ✓, and the card's next review with its reason (from the history that now holds the session). #73
    review: history = every reading (App passes the full one: a practice session's correct readings are ✓ here); a
    practice session (session.json "practice", Hidden) that would pass is no pass: passed False, why "Practice (Hidden):
    not counted", no Help (the card, from the counted history, is as it was); one with a ✗ fails as any. #87 (v0.20,
    D13): allc (every living card) given and the session's card id gone (a card merged for the day, split again once
    a part passed): the next review is the earliest among the living cards whose targets overlap the session's."""
    n = today.toordinal()
    meta = doc.get("review") if doc and isinstance(doc.get("review"), dict) else {}
    s = card.surah if card else parts(id_words(cid)[0])[0]
    target = card.target if card else (parts(id_words(cid)[0])[1], parts(id_words(cid)[-1])[1])
    t = meta.get("target")
    if isinstance(t, list) and len(t) == 2 and all(isinstance(x, int) for x in t):
        target = (t[0], t[1])
    if allc is not None and (card is None or card.id != cid):
        near = overlapping(allc, s, target)
        if near:
            card = min(near, key=lambda c: (c.due, parts(c.words[0])))
    ayat = []
    if doc and doc.get("started_at") and doc.get("surah", s) == s:
        try:
            runup = int(meta.get("runup_from") or (doc.get("passage") or {}).get("ayah_from") or doc.get("ayah_from")
                        or target[0])
        except (TypeError, ValueError):
            runup = target[0]
        for a in range(min(runup, target[0]), target[1] + 1):
            ayat.append({"surah": s, "ayah": a, "ok": ayah_ok(history, q, s, a, doc["started_at"]),
                         "role": "target" if a >= target[0] else "runup"})
    passed = bool(ayat) and all(x["ok"] for x in ayat if x["role"] == "target")
    practice = passed and doc.get("practice") is True        # #73 review: Hidden's pass does not count
    if practice:
        passed = False
    if card is None:
        return {"card": cid, "ayat": ayat, "passed": passed, "next_due": None, "retries_left": 0,
                "why": "No longer a card", "help": bool(ayat) and not passed and not practice}
    if card.suspended:
        why = "Suspended"
    elif practice:
        why = "Practice (Hidden): not counted"
    elif card.fail_now and card.due <= n:
        why = f"Again today, retry {min(card.retries_used + 1, MAX_RETRIES)} of {MAX_RETRIES}"
    elif card.fail_now and card.due == n + 1:
        why = "Again tomorrow"
    elif card.due <= n:
        why = "Again today"
    elif card.due == n + 1:
        why = "Back tomorrow"
    else:
        why = f"Back {date_text(card.due)}, in {card.due - n} days"
    return {"card": card.id, "ayat": ayat, "passed": passed, "next_due": due_text(card.due, today),
            "retries_left": card.retries_left, "why": why, "help": bool(ayat) and not passed and not practice}


# ---------------------------------------------------------------------------- Help (#57, v0.18, D8)
# The user (2026-10-28, #57): "Help = a tip on how not to make this mistake again … mutashabihat: the similar passages,
# the learned ones first … give it a try, I will iterate on it on another issue thread", plus a general learning method
# ("search for an efficient method"). No grammar reasons: the app has no morphology data.
HELP_RUN = (2, 6)                       # the run before a ✗ word that is looked for elsewhere: 2 to 6 words
HELP_TWINS = 5                          # at most 5 other places named
HELP_METHOD = (
    "Recite it from the hint without looking until it is right 3 times in a row (↻).",
    "Recite it again in about an hour.",
    "Once more before you sleep.",
    "Meddeb brings the card back when it is due.",
)
# practice testing and spaced practice (Dunlosky et al.); sleep between two sessions of relearning (Mazza et al.)
HELP_SOURCES = (
    {"title": "Dunlosky et al. 2013, Improving students' learning with effective learning techniques",
     "url": "https://journals.sagepub.com/doi/10.1177/1529100612453266"},
    {"title": "Mazza et al. 2016, Relearn faster and retain longer (sleep)",
     "url": "https://journals.sagepub.com/doi/10.1177/0956797616659930"},
)
FIRST_SENTENCE = {"wrong": "«{w}» was not said right.", "skipped": "You left out «{w}».",
                  "hint": "You needed a hint for «{w}».", "marked": "You marked «{w}» as a mistake.",
                  "lost": "You went on without «{w}».",
                  "inserted": "You added a word before «{w}»."}   # #72 (v0.19): the user's own insertion, nothing heard


@lru_cache(maxsize=2)
def _positions(q: Quran) -> dict[str, int]:
    """Word key -> its index in q.all_words (mushaf order)."""
    return {w.key: i for i, w in enumerate(q.all_words)}


def word_twins(key: str, q: Quran) -> tuple[list[str], list[str]]:
    """D8 (#57): the mutashabihat of a word from the Qur'an text alone (QUL's dataset has no licence, X2.19) -> (run,
    places): run = the keys of the longest run of HELP_RUN words right before the word (inside its surah: never through
    the surah before) that recurs elsewhere, places = the key of the word that follows the run at each other place (the
    run and that word in one surah), in mushaf order; a run of 2 found nowhere else: (that run, []), the word is
    certain after it; no run (the surah's first two words, an unknown key): ([], []). N0 letters (Word.norm), the
    pairs of Quran.ngram_index(2) (the search's index), each place extended backwards word by word."""
    pos = _positions(q).get(key)
    if pos is None:
        return [], []
    ws, lo, hi = q.all_words, HELP_RUN[0], HELP_RUN[1]
    s = ws[pos].surah
    room = 0
    while room < hi and pos - room - 1 >= 0 and ws[pos - room - 1].surah == s:
        room += 1
    if room < lo:
        return [], []
    best, found = lo, []
    for i in q.ngram_index(2).get((ws[pos - 2].norm, ws[pos - 1].norm), ()):
        e = i + 2                                   # the word that follows the run there
        if e == pos or e >= len(ws) or not ws[i].surah == ws[i + 1].surah == ws[e].surah:
            continue
        n = lo
        while n < room and e - n - 1 >= 0 and ws[e - n - 1].surah == ws[e].surah \
                and ws[e - n - 1].norm == ws[pos - n - 1].norm:
            n += 1
        if n > best or not found:
            best, found = n, [e]
        elif n == best:
            found.append(e)
    return [ws[pos - k].key for k in range(best, 0, -1)], [ws[e].key for e in found]


def _places(refs: list[str], more: int) -> str:
    """"2:58", "2:58 and 7:161", "2:58, 7:161 and 20:3", "2:58, 7:161 and 3 more places"."""
    items = refs + ([f"{more} more place{'s' if more > 1 else ''}"] if more else [])
    return items[0] if len(items) == 1 else ", ".join(items[:-1]) + " and " + items[-1]


def _uthmani(q: Quran, key: str) -> str:
    """card_help's written word without App's written_text: the Uthmani token, or for a joined part (no token of its
    own, U1.1e) the token of the word before it that holds it."""
    s, a, i = parts(key)
    ws = q.ayah(s, a).words
    while i > 0 and not ws[i].uthmani:
        i -= 1
    return ws[i].uthmani


def _kind(row: dict, last: Reading, key: str, revealed: set, before: dict | None = None) -> str:
    """The ✗ word's kind: the user's mark when the session's last reading of it is his (his verdict during the session,
    or a + Mistake after ■), else Meddeb's verdict from its session row (session.json `words`): a hint (in the session,
    or before Start, #17), lost, skipped (missing), else wrong. Page review 2026-10-29 (F6): a row the user marked
    during the session whose verdict an unmark gave back (the history's reading is the session's again: #67's double
    tap) says Meddeb's own status from the corrections log (before = profile._overruled's: the status before his
    marks), never "marked" nor the row's own label (his 'ok' read as "was not said right" for a skipped word). #72
    (v0.19, X2.12b): an insertion before the word (the last reading says ins, Meddeb's or the user's) is "inserted"."""
    if last.ins and last.outcome == "mistake":
        return "inserted"
    if last.source == "mark":
        return "marked"
    status = row.get("status")
    if row.get("user"):
        status = str((before or {}).get(row.get("i"), (status,))[0] or "")
        status = status[len("provisional_"):] if status.startswith("provisional_") else status   # settled as ■ does
    if last.hinted or row.get("hinted") or status == "hinted" or key in revealed:
        return "hint"
    if row.get("lost"):
        return "lost"
    return "skipped" if status == "missing" else "wrong"


def card_help(cid: str, card: Card | None, doc: dict | None, history: dict[str, list[Reading]], q: Quran,
              written: Callable[[str], str] | None = None, joined: Callable[[str], bool] | None = None,
              counted: dict[str, list[Reading]] | None = None) -> dict:
    """review_help (B3.16; #57, v0.18, D8) -> {words: [{surah, ayah, idx, word, heard, kind, twins: [{surah, ayah, idx,
    word, learned}], context, unique, text}], method, sources}. The ✗ words: the card's target words (result's target:
    the card's, or the session's review meta) that failed in that saved session as result's ayah verdicts read them
    (ayah_ok: the session's last reading of the word a mistake, or a hint); a word the session never reached is not
    one. word = its written word (written(key): App passes app.written_text, a joined part named by its written word;
    else the Uthmani token); heard = what the model heard there when it is another word (never for the user's mark,
    whose reason it is not); kind = _kind. Twins = word_twins's places, the learned ones first (learned_session: the
    ayah recited once without a mistake or hint, progress's rule), then those followed by another word than here, at
    most HELP_TWINS; context = the run as written (joined(key): a joined part adds nothing to the run's text), unique =
    a run found only here. text = one sentence on what was said, one on the twins, else on the run, else "Say to
    yourself why «word» fits here.". A passed card, no session or another surah's: words []; method and sources always.
    #73 review: history = every reading (result's ✓ / ✗), counted = the counted one for the learned places (a practice
    session's correct readings learn nothing; history when None). ValueError: no card id."""
    cid = card_id(cid)
    written = written or (lambda k: _uthmani(q, k))
    joined = joined or (lambda k: False)
    out = {"words": [], "method": list(HELP_METHOD), "sources": [dict(x) for x in HELP_SOURCES]}
    meta = doc.get("review") if doc and isinstance(doc.get("review"), dict) else {}
    s = card.surah if card else parts(id_words(cid)[0])[0]
    target = card.target if card else (parts(id_words(cid)[0])[1], parts(id_words(cid)[-1])[1])
    t = meta.get("target")
    if isinstance(t, list) and len(t) == 2 and all(isinstance(x, int) for x in t):
        target = (t[0], t[1])
    if not doc or not doc.get("started_at") or doc.get("surah", s) != s:
        return out
    sess = doc["started_at"]
    rows = {(r.get("surah"), r.get("ayah"), r.get("idx")): r for r in doc.get("words", ()) if isinstance(r, dict)}
    revealed = set(doc.get("revealed_before_start") or ())
    before = _overruled(doc)[0]               # page review (F6): Meddeb's verdict under the user's marks, by row "i"
    learned: dict[tuple[int, int], bool] = {}

    def is_learned(k: str) -> bool:
        sa = parts(k)[:2]
        if sa not in learned:
            ay = q.ayat.get(sa)
            learned[sa] = ay is not None and learned_session([w.key for w in ay.words],
                                                             history if counted is None else counted) is not None
        return learned[sa]
    for a in range(target[0], target[1] + 1):
        ay = q.ayat.get((s, a))
        for w in ay.words if ay else ():
            rs = [r for r in history.get(w.key, ()) if r.session == sess]
            if not rs or (rs[-1].outcome == "ok" and not any(r.hinted for r in rs)):
                continue
            row = rows.get((s, a, w.idx)) or {}
            kind = _kind(row, rs[-1], w.key, revealed, before)
            # a mark during the session or after ■ (#72: an insertion of the user's too: what was heard is no reason)
            heard = None if kind == "marked" or rs[-1].source == "mark" else row.get("heard")
            h = normalize(heard or "").replace(" ", "")
            if not h or h in (w.norm, normalize(w.uthmani).replace(" ", "")):
                heard = None
            run, places = word_twins(w.key, q)
            same_next = lambda k: q.ayah(*parts(k)[:2]).words[parts(k)[2]].norm == w.norm   # noqa: E731
            order = sorted(places, key=lambda k: (not is_learned(k), same_next(k), _positions(q)[k]))
            shown = order[:HELP_TWINS]
            # v0.18 review: learned places that all go on with this same word must not hide the ones that go on
            # otherwise (the mutashabihat): one of those takes the last place shown
            other = next((k for k in order if not same_next(k)), None)
            if shown and other is not None and other not in shown:
                shown = shown[:-1] + [other]
            twins = [{"surah": parts(k)[0], "ayah": parts(k)[1], "idx": parts(k)[2], "word": written(k),
                      "learned": is_learned(k)} for k in shown]
            # a joined part (يَٰبَنِىَّ = يا + بني, U1.1e) is named by its written word, which holds the run's last word
            ctx = run[:-1] if run and joined(w.key) else run
            context = " ".join(written(k) for j, k in enumerate(ctx) if j == 0 or not joined(k)) if ctx else None
            word = written(w.key)
            if kind == "inserted" and heard:          # #72: "You added «قل» before «تِلْكَ»."
                first = f"You added «{heard}» before «{word}»."
            else:
                first = f"You said «{heard}»; here it is «{word}»." if heard else FIRST_SENTENCE[kind].format(w=word)
            if twins:
                refs = list(dict.fromkeys(f"{x['surah']}:{x['ayah']}" for x in twins))
                then = " / ".join(f"«{x}»" for x in dict.fromkeys(x["word"] for x in twins))
                where = _places(refs, len(places) - len(shown))
                if all(same_next(k) for k in places):   # every place, not only the ones shown
                    second = f"«{context}» also comes in {where}, followed by «{word}» there too."   # 55:13's refrain
                else:
                    second = f"«{context}» also comes in {where}, followed by {then}; here: «{word}»."
            elif ctx:
                second = f"«{context}» comes only here: it is always followed by «{word}»."
            else:
                second = f"Say to yourself why «{word}» fits here."
            out["words"].append({"surah": s, "ayah": a, "idx": w.idx, "word": word, "heard": heard, "kind": kind,
                                 "twins": twins, "context": context, "unique": bool(run) and not places,
                                 "text": f"{first} {second}"})
    return out


# ---------------------------------------------------------------------------- run-up and cue
def plan(card: Card, level: int, today: dt.date, context: Callable[[int, int], dict],
         lines_of: Callable[[int], list[dict]]) -> dict:
    """The run-up and the cue of a card session (X2.19) -> {runup_from, page, cue: {lines, prev_page, prev_lines,
    header}}. context = App._context_lines, lines_of(page) = mushaf_lines (kinds). The draws are seeded by card + date
    (the same plan all day). #48 (v0.17): the cue lies on one page, `page`: the run-up's (its lines there only), or the
    page before when it has no line on the run-up's page (the run-up starts that page); prev_page / prev_lines only for
    a run-up from ayah 1 whose surah header is on the page before."""
    rng = random.Random(f"{card.id}|{today.isoformat()}")
    level = max(0, min(3, int(level)))
    n_lines, coin, extra = rng.choice(RUNUP_LINES[level]), rng.random(), rng.choice(CUE_EXTRA[level])
    s, a1 = card.surah, card.target[0]
    b = a1
    if n_lines:
        g = ayah_gline(s, a1)
        b = next((x for x in range(a1 - 1, 0, -1) if ayah_gline(s, x) <= g - n_lines), 1)
        if b > 1 and coin < 0.5:
            b -= 1                                      # + 0-1 ayah: never the same start
    if b == a1 > 1 and card.words and card.words[0] == f"{s}:{a1}:0":
        # #39 review: a card on an ayah's first word (a join): the link rule keeps its pass only when the session read
        # the word before it, so a session started at the target (level 0, Recite the join) could never pass the card
        # (✓ passed, yet red and due today again, every day). The run-up starts one ayah before: the join is recited
        b = a1 - 1
    page = page_of(s, b)
    pages = {p: lines_of(p) for p in (page - 1, page) if p >= 1}
    ctx = context(s, b)
    heads = {(p, ln) for p, kinds in ctx["header_lines"].items() if p in pages for ln in kinds.values()}
    header = b == 1 or bool(ctx["header"])
    if b == 1:
        cue = set(heads)                                # the surah's start: its header is the cue
    else:
        cue = {(p, ln) for p, lns in ctx["lines"].items() if p in pages for ln in lns}
        if ctx["header"]:
            cue |= heads
        elif cue and extra:
            p, ln = min(cue)
            added = 0
            while added < extra:
                ln -= 1
                if ln < 1:
                    p, ln = p - 1, 15
                if p not in pages:
                    break
                line = pages[p][ln - 1]
                if line["kind"] == "empty":
                    continue
                if line["kind"] in ("surah", "basmala"):
                    if line.get("surah") == s:          # never above the surah's header
                        cue |= heads
                        header = True
                    break
                cue.add((p, ln))
                added += 1
    lines = sorted(ln for p, ln in cue if p == page)
    prev = sorted(ln for p, ln in cue if p == page - 1)
    if b > 1 and lines:
        prev = []           # #48 (v0.17): only the cue greyed in place on the run-up's page, never a sheet of the page before
    elif b > 1 and prev:
        page, lines, prev = page - 1, prev, []    # #48: the run-up starts its page: the cue is drawn on the page before
    return {"runup_from": b, "page": page,
            "cue": {"lines": lines, "prev_page": page - 1 if prev else None, "prev_lines": prev, "header": header}}
