"""The Review page's cards (U1.20, X2.19; issue #39, v0.16), replayed from the reading history (profile.py) and the review
events (review.jsonl, D4.8). Nothing else is stored: the cards, their states and their dates are computed at each call.

User, issue #39 (2026-10-25): "if it has 2 mistakes on 2 sessions out of the 5 last sessions then it becomes a card";
FSRS defaults; 10 cards / 3 new / 2 retries; "an error today → due today; no error → FSRS decides"; the cards with many
errors first; the weak page included; mushaf order for big errors, out of context for almost-fixed ones; the cue gets
shorter and further away as he improves; a card leaves spaced repetition for good "not tied to Manzil's 30 days".

- A word's verdicts: one per session that read it (its last reading of that session: a mark made after ■ amends it; a
  fail when that reading is a mistake or the session revealed the word by a hint, as progress.learned_moment) and one
  per mark made outside any session, in the order the word was said; only those from its ayah's learned moment on
  (#17, the learned session included); a verdict dated after today counts nowhere. Link rule: a pass on an ayah's first
  word (ayah > 1) counts only when the same session read the word before it; a fail always counts.
- Card rule: a word becomes a card at its first verdict that leaves CARD_FAILS fails among its last CARD_WINDOW
  verdicts, on every page (#116, v0.23: the Next to learn page too; before, it was left out as being learned). It
  retires at S >= RETIRE_S with its last RETIRE_PASSES verdicts passed on as many days; a fail after that brings it back
  at once. Lapses (fails right after a pass, since its birth) >= LEECH_LAPSES: stubborn.
- #116 (v0.23, user 2026-11-04: "a review card on the hole whether i did recite it or never recited it, and hole size
  is relative to the learning around it"): a hole card = a gap of 1 to HOLE_MAX ayat never learned (progress' rule:
  never recited once without a mistake or hint) between learned ayat, the learned words around it, up to the next
  longer gap and across surahs, at least HOLE_RATIO times its words on each side, one of its ayat never recited in full
  or failed in CARD_FAILS tries (holes()); its target is the gap (per surah), it is due every day until the gap is
  recited right once (the ayat are learned: no gap, no card), retries as any card, no FSRS (Card.hole).
- Nearby words make one card (per surah, mushaf order, the global line (page - 1) x 15 + line): at most JOIN_LINES
  after the card's previous word and less than SPAN_LINES after its first; the target is the ayat they lie in; two
  cards sharing an ayah are one. #87 (v0.20, D13): after their events, two consecutive cards of one surah both
  reviewable today, the second starting at most one ayah after the first's target, are one card for the day (rebuilt
  from both word sets), while the target spans at most MERGE_LINES lines; recomputed at each call.
- Schedule: recite/fsrs.py per word (a fail is due that day, a pass after interval(S)); a card is due when one of its
  words is; MAX_RETRIES retries a day after a fail (a "shown" after today's first fail, unless a "skip" followed it),
  then tomorrow. Today's round: DAILY_CARDS cards, DAILY_NEW of them new (born before today, never shown; #116, v0.23:
  Settings' review_daily, default 15, 3 in 10 of them new, daily_caps); #46 (v0.17, user 2026-10-26: "update the
  reviews after each recite session"): a card born from today's mistake is red, to fix today, outside DAILY_NEW;
  review_queue says what today's mistakes made (today_mistakes). #81 (v0.20, D8): given the
  time, a card failed today waits RETRY_GAP from its last showing today (wait_until), after the round's other cards.
  #106 (v0.23, D8): a result says in how many days (due_days) or, for a retry today, minutes (wait_min) it comes back.
- #101 P5 (v0.22, plan D4): a card is a range: any group that reads its target cleanly passes it (range_result).
- #103 (v0.22, plan D6): a card whose mistake sits at an ayah's opening, reached from the ayah before, among ayat that
  open alike (opening_twins) is a join card: Card.similar = its challenges "show ayah i, ask i+1" (join_members,
  join_plan, join_result; the link rule keeps a challenge's pass, Reading.joined), and its ? panel (join_help).
"""
from __future__ import annotations

import datetime as dt
import math
import random
import re
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Callable, Iterable, NamedTuple

from .fsrs import AGAIN, GOOD, Fsrs, State
from .normalize import normalize
from .profile import REVIEW_EVENTS, Reading, _overruled
from .progress import ayah_table
from .quran_text import Quran, load_quran, page_lines, page_of

CARD_FAILS, CARD_WINDOW = 2, 5          # the user's rule: 2 mistakes in the last 5 sessions
RETIRE_S, RETIRE_PASSES = 60.0, 3       # leaves for good: S >= 60 days, the last 3 verdicts passed on 3 days
LEECH_LAPSES = 8                        # Anki's leech threshold: "stubborn"
MAX_RETRIES = 2                         # after a fail today: at most 2 more showings today
RETRY_GAP = dt.timedelta(minutes=45)    # #81 (v0.20): a retry waits 45 min from the card's last showing today
DAILY_CARDS = 15                        # #116 (v0.23, user 2026-11-04: "default to 15"): cards a day (was 10) ...
DAILY_NEW = (3 * DAILY_CARDS + 9) // 10 # ... 3 in 10 of them new, rounded up (#39: 10 / 3): 5 (daily_caps)
DAILY_KEY, DAILY_RANGE = "review_daily", (1, 100)   # #116: Settings › Review › Cards a day (settings.json)
HOLE_MAX, HOLE_RATIO = 3, 3             # #116: a hole card: at most 3 ayat, 3 x its words learned on each side
HOLE_WHY = {True: "A gap between ayat you know: never recited",
            False: "A gap between ayat you know: never recited right"}
JOIN_LINES, SPAN_LINES = 2, 5           # merging: <= 2 lines after the previous word, < 5 after the first
MERGE_LINES = 15                        # #87 (v0.20): due neighbours merged for the day, a target of at most 15 lines
WEAK_REVIEWS = 2                        # a fail in the card's last 2 reviews: weak (mushaf order), else settling
LEVEL_S = (3.0, 7.0, 21.0)              # cue level 0 / 1 / 2 / 3 by the weakest word's stability (days)
RUNUP_LINES = {0: (0,), 1: (1,), 2: (2, 3), 3: (4, 5)}     # lines of run-up before the target, drawn
CUE_EXTRA = {0: (2,), 1: (1,), 2: (0, 1), 3: (0,)}         # lines of cue above the minimum (#40 measure), drawn
EVENTS = REVIEW_EVENTS
ID_RE = re.compile(r"(\d+):(\d+):(\d+)-(\d+):(\d+):(\d+)")
FSRS = Fsrs()
# the last (history, today, word_states): Profile.history() returns the same dict until the history changes and never
# changes a dict it returned, so the Review page's calls in a row (queue, card, action, queue) replay it once
_STATES: tuple | None = None
_HOLES: tuple | None = None             # #116: the last (history, today, holes): holes()
# #116: (surah, ayah) -> (its words' reading lists, its learned moment): a mark gives its word a new list and keeps
# every other (Profile.history / counted), so after a mark holes() replays the learned rule of that ayah alone
_LEARNED_AT: dict[tuple[int, int], tuple[tuple, str | None]] = {}
# #116: (lists, day, the start of the session that first read it in full, tries): _ayah_tries
_TRIED: dict[tuple[int, int], tuple[tuple, int, str | None, list]] = {}
DAYS =("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")


class Verdict(NamedTuple):
    t: str                      # when the word was said (a session's first reading of it, or the mark's time)
    day: int                    # its local date, as an ordinal
    fail: bool
    session: str | None         # the session's started_at; None: a mark outside any session


@dataclass
class Life:
    """One word's card life over its verdicts (life())."""
    alive: bool = False
    retired: bool = False
    born: str | None = None     # the verdict that made it a card (its latest birth)
    lapses: int = 0
    state: State | None = None


@dataclass
class WordState:
    key: str
    verdicts: list[Verdict]
    alive: bool
    retired: bool
    born: str | None
    lapses: int
    state: State
    last_fail: bool
    due: int                    # date ordinal
    errors: int                 # fails among the last CARD_WINDOW verdicts
    fail_today: str | None      # the time of its first fail verdict today


@dataclass
class Card:
    id: str                     # "s:a:i-s:a:i": its first and last word keys
    surah: int
    target: tuple[int, int]
    words: list[str]
    page: int                   # the page of the target's first ayah
    errors: int = 0
    due: int = 0                # date ordinal
    fail_now: bool = False      # a word whose last verdict is a fail
    weak: bool = False          # a fail in the card's last WEAK_REVIEWS reviews
    lapses: int = 0
    born: str | None = None
    s_min: float = 0.0
    recall: float = 1.0         # the weakest word's recall probability today
    last_day: int | None = None
    last_fail_day: int | None = None
    fail_today: str | None = None
    new: bool = True            # no "shown" since its birth, born before today (#46: DAILY_NEW applies to them)
    new_today: bool = False     # first shown since its birth today (born before today)
    fresh: bool = False         # #46: born from today's mistake, not shown since: a card to fix, outside DAILY_NEW
    suspended: bool = False
    buried: bool = False
    skips_today: int = 0
    shown_today: int = 0
    last_shown: str | None = None   # #81 (v0.20): the time of its latest "shown" today
    wait_until: str | None = None   # #81: "HH:MM", the retry's earliest time (queue with now), else None
    retries_used: int = 0
    retries_left: int = MAX_RETRIES
    level: int = 0
    state: str = "new"
    why: str = ""
    # #103 (v0.22, plan D6): a join card's challenges (join_members: {cue, target, own, key}, mushaf order), else []
    similar: list = field(default_factory=list)
    confused_with: list = field(default_factory=list)   # #103: the twins (surah, ayah) whose word the user said there
    hole: list = field(default_factory=list)    # #116 (v0.23): the ayat of its hole(s) (Hole), [] for a word card
    hole_never: bool = False                    # #116: a hole card whose gap was never read at all


# ---------------------------------------------------------------------------- keys, lines, dates
def parts(key: str) -> tuple[int, int, int]:
    s, a, i = key.split(":")
    return int(s), int(a), int(i)


@lru_cache(maxsize=None)
def _page_word_lines(page: int) -> dict[str, int]:
    return {f"{s}:{a}:{k}": ln for ln, s, a, idx, n in page_lines(page) for k in range(idx, idx + n)}


def gline(key: str) -> int:
    """The global line of a word: (page - 1) x 15 + its line on the 15-line page (a page turn is one line)."""
    s, a, _ = parts(key)
    pg = page_of(s, a)
    return (pg - 1) * 15 + _page_word_lines(pg).get(key, 1)


def ayah_gline(surah: int, ayah: int) -> int:
    return gline(f"{surah}:{ayah}:0")


def _day(t) -> int | None:
    return _date_ordinal(str(t)[:10])


@lru_cache(maxsize=4096)
def _date_ordinal(day: str) -> int | None:
    try:
        return dt.date.fromisoformat(day).toordinal()
    except ValueError:
        return None


def date_text(day: int) -> str:
    """"Wed 29 Oct" (English names whatever the device's locale)."""
    d = dt.date.fromordinal(day)
    return f"{DAYS[d.weekday()]} {d.day} {MONTHS[d.month - 1]}"


def _ago(days: int) -> str:
    return "today" if days <= 0 else "yesterday" if days == 1 else f"{days} days ago"


def due_text(day: int, today: dt.date) -> str:
    return "today" if day <= today.toordinal() else dt.date.fromordinal(day).isoformat()


# ---------------------------------------------------------------------------- verdicts and a word's life
def learned_session(keys: list[str], history: dict[str, list[Reading]]) -> tuple[str, str] | None:
    """(the session, the moment) an ayah was learned: progress.learned_moment's rule (#17: the first session that read
    every word right with no hint; the moment = the latest time its words were said in it), with the session named."""
    clean: dict[str, str] | None = None
    for k in keys:
        last: dict[str, Reading] = {}
        first_t: dict[str, str] = {}
        hinted: set[str] = set()
        for r in history.get(k, ()):
            if r.session is None:
                continue
            last[r.session] = r
            first_t.setdefault(r.session, r.t)
            if r.hinted:
                hinted.add(r.session)
        mine = {s: first_t[s] for s, r in last.items() if r.outcome == "ok" and s not in hinted}
        clean = mine if clean is None else {s: max(t, mine[s]) for s, t in clean.items() if s in mine}
        if not clean:
            return None
    if not clean:
        return None
    sess = min(clean, key=lambda s: (clean[s], s))
    return sess, clean[sess]


def _word_before(key: str, q: Quran) -> str | None:
    """The link rule's word: the previous ayah's last word, for an ayah's first word (ayah > 1); else None."""
    s, a, i = parts(key)
    if i > 0 or a <= 1:
        return None
    prev = q.ayat.get((s, a - 1))
    return f"{s}:{a - 1}:{len(prev.words) - 1}" if prev and prev.words else None


def word_verdicts(key: str, history: dict[str, list[Reading]], q: Quran, today: dt.date,
                  learned: tuple[str, str] | None = None) -> list[Verdict]:
    """A word's verdicts that count (module docstring), in the order it was said. learned: learned_session of its ayah
    when the caller has it. #103 (v0.22, plan D6): a join challenge's session (Reading.joined: it showed the ayah before
    and started here) keeps its pass on the ayah's first word, as a linked one."""
    s, a, _ = parts(key)
    if learned is None:
        ay = q.ayat.get((s, a))
        learned = learned_session([w.key for w in ay.words], history) if ay else None
    if learned is None:
        return []
    sess0, moment = learned
    before = _word_before(key, q)
    linked = {r.session for r in history.get(before, ())} - {None} if before else None
    groups: dict[str, list[Reading]] = {}
    out: list[Verdict] = []
    for r in history.get(key, ()):
        if r.session is None:
            out.append(Verdict(r.t, _day(r.t), r.outcome == "mistake", None))
        else:
            groups.setdefault(r.session, []).append(r)
    for sess, rs in groups.items():
        out.append(Verdict(rs[0].t, _day(rs[0].t), rs[-1].outcome == "mistake" or any(r.hinted for r in rs), sess))
        if linked is not None and any(r.joined for r in rs):
            linked = linked | {sess}                    # #103: a join challenge shows the ayah before: linked
    n = today.toordinal()
    keep = [v for v in out if v.day is not None and v.day <= n and (v.session == sess0 or v.t >= moment)
            and (linked is None or v.fail or v.session in linked)]
    return sorted(keep, key=lambda v: (v.t, v.session or ""))


def life(verdicts: list[Verdict], f: Fsrs = FSRS) -> Life:
    """FSRS over the verdicts (Again = a fail, Good = a pass) and the card's birth, retirement, rebirth and lapses."""
    out = Life()
    for i, v in enumerate(verdicts):
        out.state = f.review(out.state, AGAIN if v.fail else GOOD, v.day)
        if out.alive:
            if v.fail and not verdicts[i - 1].fail:
                out.lapses += 1
            last = verdicts[i - RETIRE_PASSES + 1:i + 1] if i >= RETIRE_PASSES - 1 else []
            if not v.fail and out.state.s >= RETIRE_S and len(last) == RETIRE_PASSES and \
                    not any(x.fail for x in last) and len({x.day for x in last}) == RETIRE_PASSES:
                out.alive, out.retired = False, True
        elif v.fail and (out.retired or
                         sum(x.fail for x in verdicts[max(0, i - CARD_WINDOW + 1):i + 1]) >= CARD_FAILS):
            out.alive, out.born, out.lapses = True, v.t, 0
    return out


def word_states(history: dict[str, list[Reading]], q: Quran, today: dt.date, f: Fsrs = FSRS) -> dict[str, WordState]:
    """Every word that is or was a card, by key. A word needs CARD_FAILS readings that are mistakes or hints to have
    as many fail verdicts: the others are not even replayed."""
    n = today.toordinal()
    learned: dict[tuple[int, int], tuple[str, str] | None] = {}
    out: dict[str, WordState] = {}
    for key, rs in history.items():
        if sum(r.outcome == "mistake" or r.hinted for r in rs) < CARD_FAILS:
            continue
        try:
            s, a, _ = parts(key)
        except ValueError:
            continue
        ay = q.ayat.get((s, a))
        if ay is None:
            continue
        if (s, a) not in learned:
            learned[(s, a)] = learned_session([w.key for w in ay.words], history)
        if learned[(s, a)] is None:
            continue
        vs = word_verdicts(key, history, q, today, learned[(s, a)])
        fails = [i for i, v in enumerate(vs) if v.fail]
        if not any(j - i < CARD_WINDOW for i, j in zip(fails, fails[CARD_FAILS - 1:])):
            continue                        # never CARD_FAILS fails among CARD_WINDOW verdicts: never a card
        lf = life(vs, f)
        if lf.born is None:
            continue
        last = vs[-1]
        out[key] = WordState(key, vs, lf.alive, lf.retired, lf.born, lf.lapses, lf.state, last.fail,
                             last.day if last.fail else last.day + f.interval(lf.state.s),
                             sum(v.fail for v in vs[-CARD_WINDOW:]),
                             next((v.t for v in vs if v.fail and v.day == n), None))
    return out


# ---------------------------------------------------------------------------- holes (#116, v0.23)
# The user (2026-11-04, #116): "if i recited by heart 10 ayat let's say 10:1 to 10:10, then i have a constant mistake in
# 10:11 and no mistake in 10:12 to 10:20, will i have a review card about this hole? i think it makes sense to have a
# review card on the hole whether i did recite it or never recited it, and hole size is relative to the learning around
# it … i know 30 ayat then gap 30 ayat then i know 30 ayat: definitely this is 'not a card'". A word's verdicts count
# from its ayah's learned moment on, so an ayah never recited right once had none: its constant mistake made no card.
@dataclass
class Hole:
    """One surah's part of a gap that makes a hole card (holes())."""
    surah: int
    ayat: list[int]
    keys: list[str]             # every word of those ayat
    born: str | None            # when it became a card (the context learned, its CARD_FAILS-th failed try)
    errors: int                 # failed tries among its last CARD_WINDOW
    never: bool                 # none of its words was ever read
    fail_today: str | None      # the time of its first failed try today
    last_day: int | None        # the day of its last try
    last_fail_day: int | None


def _tries(keys: list[str], history: dict[str, list[Reading]], n: int) -> list[tuple[str, int, bool]]:
    """#116: the readings of these words as tries, word_verdicts' grouping with no learned moment (a hole was never
    learned): one per session that read one of them (its first reading's time; a fail: its last reading of one of them
    is a mistake, or it revealed one by a hint) and one per mark outside any session; dated up to day n -> [(t, day,
    fail)] in time order."""
    groups: dict[str, dict[str, list[Reading]]] = {}
    out: list[tuple[str, int, bool]] = []
    for k in keys:
        for r in history.get(k, ()):
            d = _day(r.t)
            if d is None or d > n:
                continue
            if r.session is None:
                out.append((r.t, d, r.outcome == "mistake"))
            else:
                groups.setdefault(r.session, {}).setdefault(k, []).append(r)
    for by in groups.values():
        t = min(rs[0].t for rs in by.values())
        out.append((t, _day(t), any(rs[-1].outcome == "mistake" or any(r.hinted for r in rs) for rs in by.values())))
    return sorted(out)


def holes(history: dict[str, list[Reading]], q: Quran, today: dt.date) -> list[Hole]:
    """#116 (v0.23): the hole cards' gaps, mushaf order, cached for the last (history, today) as _STATES (Android
    counts the backlog after every mark). Ayat in mushaf order are learned (progress' rule, learned_session) or not; a
    known stretch = learned ayat with at most HOLE_MAX ayat not learned between two of them (a longer run ends it: "he
    really doesn't know all that"), across surahs (a short surah alone could never hold a hole: Al-Kawthar's 108:2 has 3
    and 4 words around it); a gap inside it (1 to HOLE_MAX ayat) is a hole when the stretch's learned words before it
    and after it are each at least HOLE_RATIO times its words and one of its ayat was never read in full (v0.23 review:
    before it lay in such a gap, _enclosed) or failed in CARD_FAILS tries (the card rule's 2 mistakes: one failed
    reading may be a false alarm); one Hole per surah part."""
    global _HOLES
    cached = _HOLES
    if cached is not None and cached[0] is history and cached[1] == today:
        return cached[2]
    out = _find_holes(history, q, today)
    _HOLES = (history, today, out)
    return out


def _find_holes(history: dict[str, list[Reading]], q: Quran, today: dt.date) -> list[Hole]:
    n = today.toordinal()
    order, index, sizes = ayah_table(q)
    words = _ayah_keys(q)
    read: set[tuple[int, int]] = set()
    for sa in {k[:k.rfind(":")] for k in history}:      # "s:a" of every word read (no parts() per word: speed)
        try:
            s, a = sa.split(":")
            read.add((int(s), int(a)))
        except ValueError:
            continue
    moment: dict[int, str] = {}                         # mushaf position -> its learned moment
    for sa in read:
        p = index.get(sa)
        if p is None:
            continue
        got = _learned_at(sa, words[sa], history)
        if got is not None:
            moment[p] = got
    pos = sorted(moment)
    out: list[Hole] = []
    i = 0
    while i < len(pos):
        j = i
        while j + 1 < len(pos) and pos[j + 1] - pos[j] - 1 <= HOLE_MAX:
            j += 1
        region, i = pos[i:j + 1], j + 1
        total, seen = sum(sizes[p] for p in region), 0
        for k in range(len(region) - 1):
            seen += sizes[region[k]]
            a, b = region[k], region[k + 1]
            if b - a == 1:
                continue
            need = HOLE_RATIO * sum(sizes[p] for p in range(a + 1, b))
            if need > min(seen, total - seen):
                continue
            # when it became a hole: the latest learned moment among the fewest learned ayat next to it that hold
            # `need` words on each side
            ctx, got = "", 0
            for p in reversed(region[:k + 1]):
                ctx, got = max(ctx, moment[p]), got + sizes[p]
                if got >= need:
                    break
            got = 0
            for p in region[k + 1:]:
                ctx, got = max(ctx, moment[p]), got + sizes[p]
                if got >= need:
                    break
            gp = range(a + 1, b)
            out += _gap(q, [order[p] for p in gp], ctx, history, n,
                        lambda i, start, gp=gp, k=k: _enclosed(gp[i], start, region, k, moment, sizes))
    return out


@lru_cache(maxsize=2)
def _ayah_keys(q: Quran) -> dict[tuple[int, int], list[str]]:
    """(surah, ayah) -> its word keys (Word.key builds them at each call)."""
    return {sa: [w.key for w in ay.words] for sa, ay in q.ayat.items()}


def _same(a: tuple, b: tuple) -> bool:
    return len(a) == len(b) and all(x is y for x, y in zip(a, b))


def _ayah_tries(sa: tuple[int, int], keys: list[str], history: dict[str, list[Reading]],
                n: int) -> tuple[str | None, list]:
    """#116: (when the ayah was first read in full: the start of the session (a mark: its time) that read its last word
    never read before, up to day n; None: some word never read, _tries of its words), kept as _learned_at keeps its
    moment."""
    lists = tuple(history.get(k) for k in keys)
    hit = _TRIED.get(sa)
    if hit is not None and hit[1] == n and _same(hit[0], lists):
        return hit[2], hit[3]
    start: str | None = ""
    for rs in lists:
        # seconds precision, as Reading.t: a saved started_at has microseconds ("2026-09-18T23:00:34.085934")
        first = min(((r.session or r.t)[:19] for r in rs or () if (d := _day(r.t)) is not None and d <= n),
                    default=None)
        if first is None:
            start = None
            break
        start = max(start, first)
    out = (start, _tries(keys, history, n))
    _TRIED[sa] = (lists, n, *out)
    return out


def _enclosed(x: int, start: str, region: list[int], k: int, moment: dict[int, str], sizes: list[int]) -> bool:
    """v0.23 review: whether the mushaf position x, in the gap after region[k] (a known stretch's learned positions),
    already lay in a gap that makes a card (HOLE_MAX, HOLE_RATIO) with the ayat learned before `start` alone (the
    session that first read it in full): then that session was a try of its card (X2.19: it stays until the gap is
    recited right), else a reading from before it was a gap (one wrong reading waits for a second)."""
    def side(idxs):
        cur = x
        for i in idxs:
            p = region[i]
            if abs(p - cur) - 1 > HOLE_MAX:     # the stretch (as learned before start) ends here
                return
            if moment[p] < start:
                yield p
                cur = p
    below, above = side(range(k, -1, -1)), side(range(k + 1, len(region)))
    pb, pa = next(below, None), next(above, None)
    if pb is None or pa is None or pa - pb - 1 > HOLE_MAX:
        return False
    need = HOLE_RATIO * sum(sizes[p] for p in range(pb + 1, pa))
    for first, rest in ((pb, below), (pa, above)):
        got = sizes[first]
        for p in rest:
            if got >= need:
                break
            got += sizes[p]
        if got < need:
            return False
    return True


def _learned_at(sa: tuple[int, int], keys: list[str], history: dict[str, list[Reading]]) -> str | None:
    """learned_session's moment of an ayah, kept while its words' reading lists are the same objects (_LEARNED_AT: the
    history's lists are never changed once returned, a mark makes its word a new one): ~80 ms per call on the PC for
    the user's profile of 2026-10-29 replayed in full, a few ms after a mark."""
    lists = tuple(history.get(k) for k in keys)
    hit = _LEARNED_AT.get(sa)
    if hit is not None and _same(hit[0], lists):
        return hit[1]
    got = learned_session(keys, history)
    _LEARNED_AT[sa] = (lists, got[1] if got else None)
    return _LEARNED_AT[sa][1]


def _gap(q: Quran, gap: list[tuple[int, int]], ctx: str, history: dict[str, list[Reading]], n: int,
         enclosed: Callable[[int, str], bool]) -> list[Hole]:
    """#116: a gap's hole cards (one per surah part) when one of its ayat was not read in full before it lay in a gap
    that makes a card (v0.23 review: enclosed(i, start) for gap[i] first read in full in the session started at
    `start`; so its card stays until the ayah is learned, and a reading from before it was a gap waits for a second)
    or failed in CARD_FAILS tries; born at the later of ctx (its context learned) and the earliest such ayah's
    CARD_FAILS-th failed try (an ayah not read in full then: ctx)."""
    born: str | None = None
    whole = False
    words = _ayah_keys(q)
    for i, sa in enumerate(gap):
        start, tries = _ayah_tries(sa, words[sa], history, n)
        # v0.23 review: decided when it became a gap, not by today's history: the card's own first try reads every
        # word of a never-read ayah, and its one fail (< CARD_FAILS) took the card away (X2.19: it stays until the gap
        # is recited right once); nor by the context's moment alone: a gap read wrong in the session that learned its
        # side made a card at once
        if start is None or enclosed(i, start):
            whole = True                                # never read in full before it was a gap: a hole until learned
            continue
        fails = [t for t, _d, fail in tries if fail]
        if len(fails) >= CARD_FAILS:
            born = fails[CARD_FAILS - 1] if born is None else min(born, fails[CARD_FAILS - 1])
    if not whole and born is None:
        return []
    born = ctx if whole else max(ctx, born)
    out: list[Hole] = []
    for s in dict.fromkeys(sa[0] for sa in gap):
        ayat = [a for s2, a in gap if s2 == s]
        keys = [k for a in ayat for k in words[(s, a)]]
        tries = _ayah_tries((s, ayat[0]), keys, history, n)[1] if len(ayat) == 1 else _tries(keys, history, n)
        fails = [(t, d) for t, d, fail in tries if fail]
        out.append(Hole(s, ayat, keys, born, sum(fail for _t, _d, fail in tries[-CARD_WINDOW:]), not tries,
                        next((t for t, d in fails if d == n), None), tries[-1][1] if tries else None,
                        fails[-1][1] if fails else None))
    return out


# ---------------------------------------------------------------------------- cards
def level_of(s_min: float, fail_now: bool) -> int:
    """The cue level (X2.19): 0 after a fail or under LEVEL_S[0] days of stability, then 1, 2, 3."""
    if fail_now:
        return 0
    return sum(s_min >= x for x in LEVEL_S)


def _merge(words: list[WordState]) -> list[list[WordState]]:
    groups: list[list[WordState]] = []
    for w in words:
        cur = groups[-1] if groups else None
        g = gline(w.key)
        if cur and parts(cur[0].key)[0] == parts(w.key)[0] and g - gline(cur[-1].key) <= JOIN_LINES \
                and g - gline(cur[0].key) < SPAN_LINES:
            cur.append(w)
        else:
            groups.append([w])
    merged: list[list[WordState]] = []
    for grp in groups:            # an ayah is never in two cards (one longer than SPAN_LINES lines: 2:282)
        if merged and parts(merged[-1][-1].key)[:2] == parts(grp[0].key)[:2]:
            merged[-1].extend(grp)
        else:
            merged.append(grp)
    return merged


def _card(ws: list[WordState], today: dt.date, f: Fsrs) -> Card:
    n = today.toordinal()
    first, last = ws[0].key, ws[-1].key
    s, a1, _ = parts(first)
    reviews: dict[object, tuple[str, int, bool]] = {}     # one per session (or mark): the card's reviews
    for w in ws:
        for v in w.verdicts:
            k = v.session if v.session is not None else ("mark", v.t)
            old = reviews.get(k)
            reviews[k] = (min(old[0], v.t), v.day, old[2] or v.fail) if old else (v.t, v.day, v.fail)
    revs = sorted(reviews.values())
    fails_today = [w.fail_today for w in ws if w.fail_today]
    failed = [w.verdicts[-1].day for w in ws if w.last_fail]
    return Card(id=f"{first}-{last}", surah=s, target=(a1, parts(last)[1]), words=[w.key for w in ws],
                page=page_of(s, a1), errors=sum(w.errors for w in ws), due=min(w.due for w in ws),
                fail_now=bool(failed), weak=any(r[2] for r in revs[-WEAK_REVIEWS:]),
                lapses=max(w.lapses for w in ws), born=min(w.born for w in ws if w.born),
                s_min=min(w.state.s for w in ws), recall=min(f.r(w.state.s, n - w.state.last) for w in ws),
                last_day=revs[-1][1] if revs else None, last_fail_day=max(failed) if failed else None,
                fail_today=min(fails_today) if fails_today else None)


def _hole_card(h: Hole, today: dt.date) -> Card:
    """#116 (v0.23): a hole's card: its gap's ayat as the target and all their words, due today (until the gap is
    recited right once: then no hole, no card; the retries of a failed try as any card), red (level 0: the ayah before as
    the run-up, its cue greyed above it, plan()), weak (mushaf order), no FSRS: recall 0."""
    return Card(id=f"{h.keys[0]}-{h.keys[-1]}", surah=h.surah, target=(h.ayat[0], h.ayat[-1]), words=list(h.keys),
                page=page_of(h.surah, h.ayat[0]), errors=h.errors, due=today.toordinal(), fail_now=True, weak=True,
                born=h.born, s_min=0.0, recall=0.0, last_day=h.last_day, last_fail_day=h.last_fail_day,
                fail_today=h.fail_today, hole=list(h.ayat), hole_never=h.never)


def _build(ws: list[WordState], hs: list[Hole], today: dt.date, f: Fsrs) -> Card:
    """A card from its words' states and its holes (#116; #87 joins a hole and a word card for the day): _card when it
    has no hole, else the parts combined as _card combines words (errors summed, the earliest due and birth, the
    weakest recall, weak or red when one part is)."""
    if not hs:
        return _card(ws, today, f)
    cs = ([_card(ws, today, f)] if ws else []) + [_hole_card(h, today) for h in hs]
    if len(cs) == 1:
        return cs[0]
    words = sorted({w for c in cs for w in c.words}, key=parts)
    s, a1 = cs[0].surah, min(c.target[0] for c in cs)

    def pick(xs: list, fn):
        return fn(xs) if xs else None
    return Card(id=f"{words[0]}-{words[-1]}", surah=s, target=(a1, max(c.target[1] for c in cs)), words=words,
                page=page_of(s, a1), errors=sum(c.errors for c in cs), due=min(c.due for c in cs),
                fail_now=any(c.fail_now for c in cs), weak=any(c.weak for c in cs), lapses=max(c.lapses for c in cs),
                born=pick([c.born for c in cs if c.born], min), s_min=min(c.s_min for c in cs),
                recall=min(c.recall for c in cs), last_day=pick([c.last_day for c in cs if c.last_day], max),
                last_fail_day=pick([c.last_fail_day for c in cs if c.last_fail_day], max),
                fail_today=pick([c.fail_today for c in cs if c.fail_today], min),
                hole=sorted({a for c in cs for a in c.hole}), hole_never=all(c.hole_never for c in cs if c.hole))


def _event_words(e: dict) -> list[str]:
    """An event's word keys (none when the field is not a list of keys)."""
    ws = e.get("words")
    return [w for w in ws if isinstance(w, str)] if isinstance(ws, list) else []


def _touches(e: dict, c: Card) -> bool:
    return e.get("card") == c.id or bool(set(e.get("words") or ()) & set(c.words))


def _event_index(events: list[dict]) -> dict[str, list[int]]:
    """#39 review (speed): review.jsonl indexed once per call -> {card id or word key: positions of its events} (an id
    holds a "-", a key never). Every card went through every event, two sets built per pair: ~1 s per call after a year
    of events, 4-5 calls per card."""
    out: dict[str, list[int]] = {}
    for i, e in enumerate(events):
        keys = set(_event_words(e))
        cid = e.get("card")
        if isinstance(cid, str):
            keys.add(cid)
        for k in keys:
            out.setdefault(k, []).append(i)
    return out


def _apply_events(c: Card, events: Iterable[dict], today: dt.date, index: dict[str, list[int]] | None = None) -> None:
    """review.jsonl on a card: suspended (until unsuspend), new, shown / skipped today, buried (bury or two skips
    today), the retries used today; then its due date after the retries, level, state and why. index: _event_index of
    the events (a list), so that the card visits its own events only."""
    day, n = today.isoformat(), today.toordinal()
    if index is None:
        mine = [e for e in events if _touches(e, c)]
    else:
        at = set(index.get(c.id, ()))
        for w in c.words:
            at.update(index.get(w, ()))
        mine = [events[i] for i in sorted(at)]
    first_shown = None
    for e in mine:
        ev, t = e.get("event"), str(e.get("t") or "")
        if ev == "suspend":
            c.suspended = True
        elif ev == "unsuspend":
            c.suspended = False
        elif ev == "shown":
            if c.born and t >= c.born and first_shown is None:
                first_shown = t
            c.shown_today += t[:10] == day
            if t[:10] == day and (c.last_shown is None or t > c.last_shown):
                c.last_shown = t
        elif ev == "skip" and t[:10] == day:
            c.skips_today += 1
        elif ev == "bury" and t[:10] == day:
            c.buried = True
    # #46 (v0.17): a card born today (from today's mistake) is no new card: red, to fix today, outside DAILY_NEW
    born_today = bool(c.born) and str(c.born)[:10] == day
    c.new, c.fresh = first_shown is None and not born_today, first_shown is None and born_today
    c.new_today = bool(first_shown) and first_shown[:10] == day and not born_today
    c.buried = c.buried or c.skips_today >= 2
    if c.fail_today:
        seq = [e for e in mine if str(e.get("t") or "")[:10] == day and e.get("event") in ("shown", "skip")]
        c.retries_used = sum(1 for k, e in enumerate(seq) if e["event"] == "shown" and str(e["t"]) > c.fail_today
                             and not (k + 1 < len(seq) and seq[k + 1]["event"] == "skip"))
    c.retries_left = max(0, MAX_RETRIES - c.retries_used)
    if c.fail_now and c.fail_today and c.retries_left == 0 and c.due <= n:
        c.due = n + 1                       # the retries of the day are used: tomorrow
    c.level = level_of(c.s_min, c.fail_now)
    c.state = "stubborn" if c.lapses >= LEECH_LAPSES else "new" if c.new else "red" if c.fail_now else "green"
    c.why = _why(c, today)


def _why(c: Card, today: dt.date) -> str:
    n = today.toordinal()
    if c.suspended:
        return "Suspended"
    if c.state == "stubborn":
        return f"Stubborn: {c.lapses} lapses, try Help me learn first"
    if c.hole and c.hole == list(range(c.target[0], c.target[1] + 1)):     # #116: a hole card alone
        if c.due > n:
            return f"Next review {date_text(c.due)}"
        if c.fail_today and not c.fresh:
            return f"Again today, retry {min(c.retries_used + 1, MAX_RETRIES)} of {MAX_RETRIES}"
        return HOLE_WHY[c.hole_never]
    if c.state == "new":
        return f"{c.errors} mistake{'' if c.errors == 1 else 's'} in your last {CARD_WINDOW} readings"
    if c.due > n:
        return f"Next review {date_text(c.due)}"
    if c.fail_now:
        if c.fresh:
            return f"Missed today: {c.errors} mistake{'' if c.errors == 1 else 's'} in your last {CARD_WINDOW} readings"
        if c.fail_today:
            return f"Again today, retry {min(c.retries_used + 1, MAX_RETRIES)} of {MAX_RETRIES}"
        return f"Missed {_ago(n - (c.last_fail_day or n))}, again today"
    return f"Due today (last seen {_ago(n - (c.last_day or n))})"


def _states(history: dict[str, list[Reading]], q: Quran, today: dt.date, f: Fsrs) -> dict[str, WordState]:
    """word_states, cached for the last (history, today) (_STATES)."""
    global _STATES
    cached = _STATES
    if f is FSRS and cached is not None and cached[0] is history and cached[1] == today:
        return cached[2]
    states = word_states(history, q, today, f)
    if f is FSRS:
        _STATES = (history, today, states)
    return states


def cards(history: dict[str, list[Reading]], q: Quran, today: dt.date, events: Iterable[dict] = (),
          f: Fsrs = FSRS) -> list[Card]:
    """Every living card (due or not, suspended or not) in mushaf order, with its schedule and its events. #87 (v0.20,
    D13): two consecutive cards both reviewable today whose second starts at most one ayah after the first's target
    are one card for the day (_joins), rebuilt from both word sets with the events of both; a merged card that is no
    longer reviewable once its events are applied (two skips between its parts: buried) stays as its parts. #116 (v0.23,
    user 2026-11-04: "should include everything"): every page has cards, the Next to learn page too (before: none
    there, being learned), and the hole cards (holes()) take their place in mushaf order, #87's joins included."""
    states = _states(history, q, today, f)
    found = holes(history, q, today)
    if not states and not found:
        return []
    alive = sorted((w for w in states.values() if w.alive), key=lambda w: parts(w.key))
    units = sorted([(parts(g[0].key), g, []) for g in _merge(alive)] + [(parts(h.keys[0]), [], [h]) for h in found],
                   key=lambda u: u[0])                  # word groups and holes never share an ayah (holes: no verdict)
    events = list(events)
    index = _event_index(events)                        # #39 review: each card visits its own events only
    n = today.toordinal()
    out: list[tuple[Card, list[WordState], list[Hole]]] = []    # each card with its words and its holes
    for _at, grp, hs in units:
        c = _build(grp, hs, today, f)
        _apply_events(c, events, today, index)
        if out and _joins(out[-1][0], c, n, q):
            ws, hs2 = out[-1][1] + grp, out[-1][2] + hs
            m = _build(ws, hs2, today, f)
            _apply_events(m, events, today, index)
            if _reviewable(m, n):
                out[-1] = (m, ws, hs2)
                continue
        out.append((c, grp, hs))
    learned: dict[tuple[int, int], bool] = {}           # #103: the twins' learned rule, once per call
    for c, ws, _hs in out:
        _join_card(c, ws, history, q, learned)
    return [c for c, _ws, _hs in out]


def _reviewable(c: Card, n: int) -> bool:
    """Due today (or before), neither suspended nor buried: in today's round when the caps allow it."""
    return c.due <= n and not c.suspended and not c.buried


def _joins(a: Card, b: Card, n: int, q: Quran) -> bool:
    """#87 (v0.20, D13; user, 2026-10-31: "definitely card 1 and 2 must be merged i.e. the finish eya should be the one
    of card 2"): b (the next card in mushaf order) joins a for the day: one surah, both reviewable today, b starting at
    most one ayah after a's target ends, the merged target spanning at most MERGE_LINES lines (from its first ayah's
    first word to its last ayah's last word). Else the next card's grey cue would be the ayah just recited."""
    if a.surah != b.surah or b.target[0] > a.target[1] + 1 or not (_reviewable(a, n) and _reviewable(b, n)):
        return False
    last = q.ayat.get((b.surah, b.target[1]))
    if last is None or not last.words:
        return False
    return gline(last.words[-1].key) - ayah_gline(a.surah, a.target[0]) + 1 <= MERGE_LINES


def _shown_today(events: list[dict], day: str) -> list[list]:
    """#39 review: the cards shown on `day` from review.jsonl alone, gone since or not -> [[card ids, words, new]], one
    per card: its "shown" events sharing a card id or a word (an id changes when a word joins the card); new: one was
    flagged new when shown (review_action)."""
    groups: list[list] = []
    for e in events:
        if e.get("event") != "shown" or str(e.get("t") or "")[:10] != day:
            continue
        g = [{e["card"]} if isinstance(e.get("card"), str) else set(), set(_event_words(e)), bool(e.get("new"))]
        rest = []
        for h in groups:
            if h[0] & g[0] or h[1] & g[1]:
                g = [g[0] | h[0], g[1] | h[1], g[2] or h[2]]
            else:
                rest.append(h)
        groups = rest + [g]
    return groups


def card_dict(c: Card, today: dt.date) -> dict:
    """A card as review_queue sends it (B3.16). #103 (v0.22, D6): similar = its join challenges in mushaf order
    ({cue: [s, a], target: [s, a1, a2], own, key: [deciding word per target ayah]}), join_order = the order of today's
    showings (indices into similar, join_order())."""
    return {"id": c.id, "surah": c.surah, "target": [c.target[0], c.target[1]], "words": list(c.words), "page": c.page,
            "errors": c.errors, "due": due_text(c.due, today), "state": c.state, "level": c.level, "why": c.why,
            "shown_today": c.shown_today, "lapses": c.lapses, "similar": [dict(m) for m in c.similar],
            "join_order": join_order(c.id, len(c.similar), today),
            "wait_until": c.wait_until,         # #81 (v0.20): "HH:MM" while the card waits for its retry, else None
            "hole": list(c.hole)}               # #116 (v0.23): the ayat of its gap (a hole card), else []


def _failed_today(rs: list[Reading], day: str) -> bool:
    """A fail verdict on `day` among a word's readings (word_verdicts' grouping, before its learned-moment and link
    filters): a session of that day whose last reading of the word is a mistake or that revealed it by a hint, or a
    mistake marked outside any session that day."""
    for r in reversed(rs):                  # in time order: only the readings from that day on are looked at
        d = r.t[:10]
        if d < day:
            return False
        if d == day and (r.outcome == "mistake" or r.hinted):
            break
    else:
        return False
    sessions: dict[str, list[Reading]] = {}
    for r in rs:
        if r.session is None:
            if r.t[:10] == day and r.outcome == "mistake":
                return True
        else:
            sessions.setdefault(r.session, []).append(r)
    return any(g[0].t[:10] == day and (g[-1].outcome == "mistake" or any(r.hinted for r in g))
               for g in sessions.values())


def today_mistakes(history: dict[str, list[Reading]], q: Quran, today: dt.date, allc: list[Card],
                   f: Fsrs = FSRS) -> dict:
    """#46 (v0.17): what today's mistakes made -> {words: the words with a fail verdict today, then of those (each in
    the first that holds it) cards: in a living card (allc, a hole card's too), not_learned: their ayah never read
    clean (no verdict counts yet; a hole card once its gap qualifies), one_more: CARD_FAILS - 1 fails in their last
    CARD_WINDOW verdicts (one more mistake makes a card)}. Only the words read today are replayed. #116 (v0.23): the
    Next to learn page has cards like any page, so next_to_learn (its words, no card there before) stays 0, kept for
    the pages that read it."""
    day = today.isoformat()
    out = {"words": 0, "cards": 0, "one_more": 0, "not_learned": 0, "next_to_learn": 0}
    in_card = {w for c in allc for w in c.words}
    learned: dict[tuple[int, int], tuple[str, str] | None] = {}
    states = None
    for key, rs in history.items():
        if not rs or not _failed_today(rs, day):
            continue
        try:
            s, a, _ = parts(key)
        except ValueError:
            continue
        ay = q.ayat.get((s, a))
        if ay is None:
            continue
        out["words"] += 1
        if key in in_card:
            out["cards"] += 1
        else:
            if (s, a) not in learned:
                learned[(s, a)] = learned_session([w.key for w in ay.words], history)
            if learned[(s, a)] is None:
                out["not_learned"] += 1
                continue
            if states is None:
                states = _states(history, q, today, f)        # cards() just replayed them: cached
            w = states.get(key)
            vs = w.verdicts if w is not None else word_verdicts(key, history, q, today, learned[(s, a)])
            out["one_more"] += sum(v.fail for v in vs[-CARD_WINDOW:]) == CARD_FAILS - 1
    return out


def due_backlog(history: dict[str, list[Reading]], q: Quran, today: dt.date, events: Iterable[dict] = (),
                f: Fsrs = FSRS) -> int:
    """#91 (v0.21, D4): the Review backlog, every due card neither suspended nor buried (queue's total_due + waiting:
    today's round and the ones past its caps), for progress.learn_lock. No queue built: cards() over the cached word
    states (_STATES; ~25 ms on the PC for the user's profile of 2026-10-29 after a mark, 1 ms when nothing changed).
    #116 (v0.23, user 2026-11-04: "by solving all the review (across multiple days we unlock the next to learn
    again)"): the hole cards and the Next to learn page's cards count too; the caps do not (the cards past them wait)."""
    n = today.toordinal()
    return sum(_reviewable(c, n) for c in cards(history, q, today, events, f))


def daily_caps(daily: int | None = None) -> tuple[int, int]:
    """#116 (v0.23, user 2026-11-04: "the limit of cards a day should be increased, default to 15, and have an input
    about it in the settings"): today's caps (cards, new ones) for `daily` cards a day (None: DAILY_CARDS), clamped to
    DAILY_RANGE; the new ones keep #39's share, 3 in 10, rounded up (10 -> 3, 15 -> 5, 1 -> 1, 100 -> 30)."""
    lo, hi = DAILY_RANGE
    n = DAILY_CARDS if daily is None else max(lo, min(hi, int(daily)))
    return n, (3 * n + 9) // 10


def daily_cards(settings) -> int:
    """#116 (v0.23): Settings › Review › Cards a day, settings.json's DAILY_KEY ("review_daily"): a whole number in
    DAILY_RANGE (out of it: clamped; a fraction: rounded); missing, a bool or not a number: DAILY_CARDS. App passes it
    to queue(daily=) (B3.16)."""
    v = settings.get(DAILY_KEY) if isinstance(settings, dict) else None
    if v is None or isinstance(v, bool):
        return DAILY_CARDS
    try:
        x = round(float(v))
    except (TypeError, ValueError, OverflowError):
        return DAILY_CARDS
    return daily_caps(x)[0]


def queue(history: dict[str, list[Reading]], q: Quran, today: dt.date, events: Iterable[dict] = (),
          f: Fsrs = FSRS, now: dt.datetime | None = None, daily: int | None = None) -> dict:
    """review_queue (B3.16): today's round (the due cards, not suspended nor buried; the cards shown today count first
    against the day's caps (daily_caps(daily): #116, v0.23, the setting review_daily, default DAILY_CARDS = 15 cards,
    DAILY_NEW = 5 of them new; `caps` in the answer), then red by most errors, then the lowest recall), ordered weak
    cards in mushaf order, settling ones shuffled by the date, the cards skipped once today last; the counters; the
    suspended cards;
    today_mistakes (#46). #46 (v0.17): a card born from today's mistake is not new (Card.fresh): red, outside DAILY_NEW.
    #81 (v0.20, D8): now (local time) given, a card waiting for its retry (_wait) goes after the others, the soonest
    first, with wait_until and "Again at HH:MM (retry n of 2)"; it stays in the round and its counters."""
    events = list(events)
    allc = cards(history, q, today, events, f)
    n = today.toordinal()
    suspended = [c for c in allc if c.suspended]
    due = [c for c in allc if not c.suspended and not c.buried and c.due <= n]
    # #39 review: today's showings come from review.jsonl itself, not only from the living cards: a card shown today
    # that has gone since (retired by today's pass, unmade by a Remove, #116: a gap recited right) still counts, so no
    # extra card enters; a showing that became two living cards counts as both (the round never passes the caps)
    shown = _shown_today(events, today.isoformat())
    living = [c for c in allc if c.shown_today]
    for c in living:
        if c.new_today:
            for g in shown:
                if c.id in g[0] or set(c.words) & g[1]:
                    g[2] = True
    used = max(len(shown), len(living))
    new_used = max(sum(g[2] for g in shown), sum(c.new_today for c in living))
    chosen = [c for c in due if c.shown_today]

    def priority(c: Card):
        return (not c.fail_now, -c.errors if c.fail_now else 0, c.recall, parts(c.words[0]))
    cap, new_cap = daily_caps(daily)
    for c in sorted((c for c in due if not c.shown_today), key=priority):
        if used >= cap:
            break
        if c.new and new_used >= new_cap:
            continue
        chosen.append(c)
        used += 1
        new_used += c.new
    pos = lambda c: parts(c.words[0])                     # noqa: E731
    weak = sorted((c for c in chosen if c.weak and not c.skips_today), key=pos)
    settling = sorted((c for c in chosen if not c.weak and not c.skips_today), key=pos)
    random.Random(today.isoformat()).shuffle(settling)    # out of context, a new order every day
    skipped = sorted((c for c in chosen if c.skips_today), key=pos)
    waiting = []
    if now is not None:
        for c in chosen:
            _wait(c, now)
        waiting = sorted((c for c in chosen if c.wait_until), key=lambda c: (c.wait_until, pos(c)))
        weak, settling, skipped = ([c for c in g if not c.wait_until] for g in (weak, settling, skipped))
    ordered = weak + settling + skipped + waiting
    red = sum(c.fail_now for c in ordered)
    return {"today": today.isoformat(),
            "counters": {"red": red, "green": len(ordered) - red, "total_due": len(ordered),
                         "suspended": len(suspended), "waiting": len(due) - len(ordered)},
            "caps": {"cards": cap, "new": new_cap},         # #116: the page says "15 a day, 5 of them new"
            "cards": [card_dict(c, today) for c in ordered],
            "suspended": [card_dict(c, today) for c in suspended],
            "today_mistakes": today_mistakes(history, q, today, allc, f)}


def _wait(c: Card, now: dt.datetime) -> None:
    """#81 (v0.20, D8; user, 2026-10-30: "it should have been some other card and not seeing card one before at least
    45min !"): a card with a fail today, still due, shown today waits until its latest showing + RETRY_GAP (the
    showing is recorded when the card starts, so the gap runs from that attempt): wait_until "HH:MM" and its why."""
    until = _retry_at(c)
    if until is None:
        return
    if now.replace(tzinfo=None) < until:
        c.wait_until = until.strftime("%H:%M")
        c.why = f"Again at {c.wait_until} (retry {min(c.retries_used + 1, MAX_RETRIES)} of {MAX_RETRIES})"


def _retry_at(c: Card) -> dt.datetime | None:
    """#81 (v0.20, D8): when a card with a fail today, shown today, may be shown again: its latest showing today +
    RETRY_GAP (naive local time); None for any other card (no fail today, not shown today)."""
    if not (c.fail_now and c.fail_today and c.last_shown):
        return None
    try:
        return dt.datetime.fromisoformat(c.last_shown).replace(tzinfo=None) + RETRY_GAP
    except ValueError:
        return None


def _wait_min(c: Card, today: dt.date, now: dt.datetime | None) -> int | None:
    """#106 (v0.23, D8; user 2026-11-03: "'X 2:63, review again in 40 min'"): the minutes until the card may be
    shown again (_wait's rule at `now`), rounded up, >= 1: a card failed today, still due today (retries left), shown
    today, not suspended, whose latest showing + RETRY_GAP is after now; else None (ready now, tomorrow, suspended,
    no time given)."""
    if now is None or c.suspended or c.retries_left <= 0 or c.due > today.toordinal():
        return None
    until = _retry_at(c)
    if until is None:
        return None
    left = (until - now.replace(tzinfo=None)).total_seconds()
    return max(1, math.ceil(left / 60)) if left > 0 else None


# ---------------------------------------------------------------------------- calls' helpers
def card_id(value) -> str:
    """A card id from a call's `card` (the id, or a card object with its id). ValueError: not a card id."""
    cid = value.get("id") if isinstance(value, dict) else value
    if not isinstance(cid, str) or not ID_RE.fullmatch(cid.strip()):
        raise ValueError(f"not a card id: {cid!r}")
    return cid.strip()


def id_words(cid: str) -> list[str]:
    first, last = card_id(cid).split("-")
    return [first] if first == last else [first, last]


def find(allc: list[Card], cid: str) -> Card | None:
    """The card of that id, else the one holding most of the words between its first and last key (an id changes when
    a word joins or leaves its card); None: no card there."""
    for c in allc:
        if c.id == cid:
            return c
    first, last = (parts(k) for k in card_id(cid).split("-"))
    best, most = None, 0
    for c in allc:
        k = sum(1 for w in c.words if first <= parts(w) <= last)
        if k > most:
            best, most = c, k
    return best


def overlapping(allc: list[Card], surah: int, target: tuple[int, int]) -> list[Card]:
    """#87 (v0.20, D13): the living cards of that surah whose target overlaps target (ayah from, to)."""
    return [c for c in allc if c.surah == surah and c.target[0] <= target[1] and target[0] <= c.target[1]]


def action_cards(allc: list[Card], cid: str) -> tuple[list[str], bool]:
    """review_action's event (D4.8) for a card id -> (its words, new). The living card of that id: its words. #87
    (v0.20, D13) review: an id gone (a merged card split once a part passed) names every living card of its surah whose
    target overlaps the id's ayat, their words joined (Skip / Suspend / Bury reach each part, not only the one
    find() picks); none: the id's own words."""
    for c in allc:
        if c.id == cid:
            return list(c.words), c.new
    ws = id_words(cid)
    s, a0 = parts(ws[0])[:2]
    near = overlapping(allc, s, (a0, parts(ws[-1])[1]))
    if not near:
        return ws, False
    words = sorted({w for c in near for w in c.words}, key=parts)
    return words, any(c.new for c in near)


def session_meta(raw, runup_from: int) -> dict | None:
    """start{review} (B3.16) -> the session's `review` meta: {card, target, level, runup_from, words?, practice?,
    join?}; None when it names no card. #103 (v0.22, D6): join = [surah, ayah] of the ayah a join challenge shows
    before its run-up (Reading.joined)."""
    if not isinstance(raw, dict):
        return None
    try:
        out: dict = {"card": card_id(raw.get("card")), "runup_from": int(runup_from)}
    except (TypeError, ValueError):
        return None
    t = raw.get("target")
    if isinstance(t, (list, tuple)) and len(t) == 2:
        try:
            out["target"] = [int(t[0]), int(t[1])]
        except (TypeError, ValueError):
            pass
    try:
        out["level"] = max(0, min(3, int(raw.get("level"))))
    except (TypeError, ValueError):
        pass
    if isinstance(raw.get("words"), list):
        out["words"] = [str(w) for w in raw["words"]]
    if raw.get("practice"):
        out["practice"] = True
    j = raw.get("join")
    if isinstance(j, (list, tuple)) and len(j) == 2:
        try:
            if 1 <= int(j[0]) <= 114 and int(j[1]) >= 1:
                out["join"] = [int(j[0]), int(j[1])]
        except (TypeError, ValueError):
            pass
    return out


def ayah_ok(history: dict[str, list[Reading]], q: Quran, surah: int, ayah: int, session: str) -> bool:
    """Every word of the ayah read in that session, its last reading there right, none revealed by a hint."""
    for w in q.ayah(surah, ayah).words:
        rs = [r for r in history.get(w.key, ()) if r.session == session]
        if not rs or rs[-1].outcome != "ok" or any(r.hinted for r in rs):
            return False
    return True


def result(cid: str, card: Card | None, doc: dict | None, history: dict[str, list[Reading]], q: Quran,
           today: dt.date, allc: list[Card] | None = None, now: dt.datetime | None = None) -> dict:
    """review_result (B3.16): ✓ / ✗ per ayah of the saved session from the run-up to the target's end, passed when every
    target ayah is ✓, and the card's next review with its reason (from the history that now holds the session). #73
    review: history = every reading (App passes the full one: a practice session's correct readings are ✓ here); a
    practice session (session.json "practice", Hidden) that would pass is no pass: passed False, why "Practice (Hidden):
    not counted", no Help (the card, from the counted history, is as it was); one with a ✗ fails as any (v0.21, D5:
    practice when a target row was judged in Hidden, a run-up in Hidden is no practice). #87 (v0.20,
    D13): allc (every living card) given and the session's card id gone (a card merged for the day, split again once
    a part passed): the next review is the earliest among the living cards whose targets overlap the session's. #106
    (v0.23, D8): now (local time) gives wait_min (_outcome)."""
    meta = doc.get("review") if doc and isinstance(doc.get("review"), dict) else {}
    s = card.surah if card else parts(id_words(cid)[0])[0]
    target = card.target if card else (parts(id_words(cid)[0])[1], parts(id_words(cid)[-1])[1])
    t = meta.get("target")
    if isinstance(t, list) and len(t) == 2 and all(isinstance(x, int) for x in t):
        target = (t[0], t[1])
    if allc is not None and (card is None or card.id != cid):
        near = overlapping(allc, s, target)
        if near:
            card = min(near, key=lambda c: (c.due, parts(c.words[0])))
    ayat = []
    if doc and doc.get("started_at") and doc.get("surah", s) == s:
        try:
            runup = int(meta.get("runup_from") or (doc.get("passage") or {}).get("ayah_from") or doc.get("ayah_from")
                        or target[0])
        except (TypeError, ValueError):
            runup = target[0]
        for a in range(min(runup, target[0]), target[1] + 1):
            ayat.append({"surah": s, "ayah": a, "ok": ayah_ok(history, q, s, a, doc["started_at"]),
                         "role": "target" if a >= target[0] else "runup"})
    passed = bool(ayat) and all(x["ok"] for x in ayat if x["role"] == "target")
    # #73 review: Hidden's pass does not count; v0.21 (D5): only when a target row was judged in Hidden (the rows'
    # "practice"; a 0.19/0.20 doc, no row flags: the whole session)
    practice = passed and _practice_doc(doc, s, target)
    return _outcome(cid, card, ayat, passed and not practice, practice, today, now)


def _practice_doc(doc: dict, s: int, target: tuple[int, int]) -> bool:
    """#73 review / v0.21 (D5): the saved session judged a row of the target (surah s, ayat target) in Hidden (its
    rows' "practice"; a 0.19/0.20 doc, no row flags: the whole session)."""
    return doc.get("practice") is True and (not doc.get("practice_rows") or any(
        w.get("practice") is True and w.get("surah") == s and target[0] <= (w.get("ayah") or 0) <= target[1]
        for w in doc.get("words") or ()))


def _outcome(cid: str, card: Card | None, ayat: list[dict], passed: bool, practice: bool, today: dt.date,
             now: dt.datetime | None = None) -> dict:
    """result's answer from its ✓ / ✗: the card's next review and its reason (the card from the history that holds
    the reading), help = something read and not passed (a practice pass: no Help). #106 (v0.23, D8): due_days = the
    card's due date - today (0: today, as next_due; None without a card) and wait_min = the minutes before its retry
    today (_wait_min at now; None: no wait), so that the page says "review again in 5 days" / "in 40 min"."""
    n = today.toordinal()
    if card is None:
        return {"card": cid, "ayat": ayat, "passed": passed, "next_due": None, "retries_left": 0,
                "why": "No longer a card", "help": bool(ayat) and not passed and not practice,
                "due_days": None, "wait_min": None}
    if card.suspended:
        why = "Suspended"
    elif practice:
        why = "Practice (Hidden): not counted"
    elif card.fail_now and card.due <= n:
        why = f"Again today, retry {min(card.retries_used + 1, MAX_RETRIES)} of {MAX_RETRIES}"
    elif card.fail_now and card.due == n + 1:
        why = "Again tomorrow"
    elif card.due <= n:
        why = "Again today"
    elif card.due == n + 1:
        why = "Back tomorrow"
    else:
        why = f"Back {date_text(card.due)}, in {card.due - n} days"
    return {"card": card.id, "ayat": ayat, "passed": passed, "next_due": due_text(card.due, today),
            "retries_left": card.retries_left, "why": why, "help": bool(ayat) and not passed and not practice,
            "due_days": max(0, card.due - n), "wait_min": _wait_min(card, today, now)}


def range_result(cid: str, card: Card | None, history: dict[str, list[Reading]], q: Quran, today: dt.date,
                 since: str | None = None, allc: list[Card] | None = None, now: dt.datetime | None = None) -> dict:
    """#101 P5 (v0.22, plan D4; user, 2026-11-02: "I am ok with the proposal do them all"): a card is a range, passed by
    any group that read its target cleanly, a card session or not -> result's answer + session (the started_at of the
    group graded, None: none). v0.22 review: the newest session (started at or after `since`, an ISO time) that read a
    word of the target, alone (an ayah it read in part is ✗: never an older session's full reading of it); ✓ = ayah_ok
    there and, for an ayah whose first word is the card's, the link rule word_verdicts applies (the session read the
    ayah before's last word, or is the join challenge's): else its pass would not move the card. Passed: every target
    ayah ✓; a pass whose readings of the target were judged in Hidden (Reading.practice) is no pass, as result's.
    history = every reading (App's full one); allc as result's (#87: an id gone names its parts' earliest review); now
    as result's (#106: wait_min). #116 (v0.23): no link rule on a hole card's ayat (what closes a hole is the ayah
    learned, progress' rule, which has none) nor without a living card (an id gone: no card to move, ✓ as read: a hole
    recited right is learned, its card gone)."""
    s = card.surah if card else parts(id_words(cid)[0])[0]
    target = card.target if card else (parts(id_words(cid)[0])[1], parts(id_words(cid)[-1])[1])
    if allc is not None and (card is None or card.id != cid):
        near = overlapping(allc, s, target)
        if near:
            card = min(near, key=lambda c: (c.due, parts(c.words[0])))
    keys = set(card.words) if card else None
    hole = set(card.hole) if card else set()
    ays = [ay for a in range(target[0], target[1] + 1) if (ay := q.ayat.get((s, a))) is not None]
    sessions = {r.session for ay in ays for w in ay.words for r in history.get(w.key, ())
                if r.session is not None and (since is None or str(r.session) >= since)}
    sess = max(sessions) if sessions else None
    ayat, practice = [], False

    def linked(ay) -> bool:
        k0 = ay.words[0].key
        before = _word_before(k0, q)
        if before is None or keys is None or k0 not in keys or ay.ayah in hole:
            return True
        return any(r.session == sess for r in history.get(before, ())) or             any(r.joined for r in history.get(k0, ()) if r.session == sess)

    for ay in ays if sess is not None else ():
        ok = ayah_ok(history, q, s, ay.ayah, sess) and linked(ay)
        practice = practice or any(r.practice for w in ay.words for r in history.get(w.key, ()) if r.session == sess)
        ayat.append({"surah": s, "ayah": ay.ayah, "ok": ok, "role": "target"})
    used = [sess] if sess is not None else []
    passed = bool(ayat) and all(x["ok"] for x in ayat)
    practice = passed and practice
    out = _outcome(cid, card, ayat if used else [], passed and not practice, practice, today, now)
    out["session"] = max(used) if used else None
    return out


def join_result(cid: str, card: Card | None, member: dict, doc: dict | None, history: dict[str, list[Reading]],
                q: Quran, today: dt.date, allc: list[Card] | None = None, now: dt.datetime | None = None) -> dict:
    """#103 (v0.22, plan D6): review_result of a join challenge's saved session -> result's answer over the member's
    target (✓ / ✗ per ayah: the whole ayah, it feeds the normal cards) with passed = the challenge's rule: each target
    ayah's opening, its words 0 .. its deciding word (member key), read in that session, its last reading right, no
    hint (a mistake after the deciding word: ✗ on the ayah, the challenge passed); a Hidden pass is no pass (result's
    rule) + join: the member. now as result's (#106: wait_min)."""
    ms, a1, a2 = (int(x) for x in member["target"])
    if allc is not None and (card is None or card.id != cid):
        card = find(allc, cid) or card
    ayat, passed = [], False
    if doc and doc.get("started_at") and doc.get("surah", ms) == ms:
        sess = doc["started_at"]
        ayat = [{"surah": ms, "ayah": a, "ok": ayah_ok(history, q, ms, a, sess), "role": "target"}
                for a in range(a1, a2 + 1)]
        passed = _opening_ok(history, q, member, sess)
    practice = passed and _practice_doc(doc, ms, (a1, a2))
    out = _outcome(cid, card, ayat, passed and not practice, practice, today, now)
    out["join"] = dict(member)
    return out


# ---------------------------------------------------------------------------- Help (#57, v0.18, D8)
# The user (2026-10-28, #57): "Help = a tip on how not to make this mistake again … mutashabihat: the similar passages,
# the learned ones first … give it a try, I will iterate on it on another issue thread", plus a general learning method
# ("search for an efficient method"). No grammar reasons: the app has no morphology data.
HELP_RUN = (2, 6)                       # the run before a ✗ word that is looked for elsewhere: 2 to 6 words
HELP_TWINS = 5                          # at most 5 other places named
HELP_METHOD = (
    "Recite it from the hint without looking until it is right 3 times in a row (↻).",
    "Recite it again in about an hour.",
    "Once more before you sleep.",
    "Meddeb brings the card back when it is due.",
)
# practice testing and spaced practice (Dunlosky et al.); sleep between two sessions of relearning (Mazza et al.)
HELP_SOURCES = (
    {"title": "Dunlosky et al. 2013, Improving students' learning with effective learning techniques",
     "url": "https://journals.sagepub.com/doi/10.1177/1529100612453266"},
    {"title": "Mazza et al. 2016, Relearn faster and retain longer (sleep)",
     "url": "https://journals.sagepub.com/doi/10.1177/0956797616659930"},
)
FIRST_SENTENCE = {"wrong": "«{w}» was not said right.", "skipped": "You left out «{w}».",
                  "hint": "You needed a hint for «{w}».", "marked": "You marked «{w}» as a mistake.",
                  "lost": "You went on without «{w}».",
                  "inserted": "You added a word before «{w}»."}   # #72 (v0.19): the user's own insertion, nothing heard


@lru_cache(maxsize=2)
def _positions(q: Quran) -> dict[str, int]:
    """Word key -> its index in q.all_words (mushaf order)."""
    return {w.key: i for i, w in enumerate(q.all_words)}


def word_twins(key: str, q: Quran) -> tuple[list[str], list[str]]:
    """D8 (#57): the mutashabihat of a word from the Qur'an text alone (QUL's dataset has no licence, X2.19) -> (run,
    places): run = the keys of the longest run of HELP_RUN words right before the word (inside its surah: never through
    the surah before) that recurs elsewhere, places = the key of the word that follows the run at each other place (the
    run and that word in one surah), in mushaf order; a run of 2 found nowhere else: (that run, []), the word is
    certain after it; no run (the surah's first two words, an unknown key): ([], []). N0 letters (Word.norm), the
    pairs of Quran.ngram_index(2) (the search's index), each place extended backwards word by word."""
    pos = _positions(q).get(key)
    if pos is None:
        return [], []
    ws, lo, hi = q.all_words, HELP_RUN[0], HELP_RUN[1]
    s = ws[pos].surah
    room = 0
    while room < hi and pos - room - 1 >= 0 and ws[pos - room - 1].surah == s:
        room += 1
    if room < lo:
        return [], []
    best, found = lo, []
    for i in q.ngram_index(2).get((ws[pos - 2].norm, ws[pos - 1].norm), ()):
        e = i + 2                                   # the word that follows the run there
        if e == pos or e >= len(ws) or not ws[i].surah == ws[i + 1].surah == ws[e].surah:
            continue
        n = lo
        while n < room and e - n - 1 >= 0 and ws[e - n - 1].surah == ws[e].surah \
                and ws[e - n - 1].norm == ws[pos - n - 1].norm:
            n += 1
        if n > best or not found:
            best, found = n, [e]
        elif n == best:
            found.append(e)
    return [ws[pos - k].key for k in range(best, 0, -1)], [ws[e].key for e in found]


def _places(refs: list[str], more: int) -> str:
    """"2:58", "2:58 and 7:161", "2:58, 7:161 and 20:3", "2:58, 7:161 and 3 more places"."""
    items = refs + ([f"{more} more place{'s' if more > 1 else ''}"] if more else [])
    return items[0] if len(items) == 1 else ", ".join(items[:-1]) + " and " + items[-1]


def _uthmani(q: Quran, key: str) -> str:
    """card_help's written word without App's written_text: the Uthmani token, or for a joined part (no token of its
    own, U1.1e) the token of the word before it that holds it."""
    s, a, i = parts(key)
    ws = q.ayah(s, a).words
    while i > 0 and not ws[i].uthmani:
        i -= 1
    return ws[i].uthmani


def _kind(row: dict, last: Reading, key: str, revealed: set, before: dict | None = None) -> str:
    """The ✗ word's kind: the user's mark when the session's last reading of it is his (his verdict during the session,
    or a + Mistake after ■), else Meddeb's verdict from its session row (session.json `words`): a hint (in the session,
    or before Start, #17), lost, skipped (missing), else wrong. Page review 2026-10-29 (F6): a row the user marked
    during the session whose verdict an unmark gave back (the history's reading is the session's again: #67's double
    tap) says Meddeb's own status from the corrections log (before = profile._overruled's: the status before his
    marks), never "marked" nor the row's own label (his 'ok' read as "was not said right" for a skipped word). #72
    (v0.19, X2.12b): an insertion before the word (the last reading says ins, Meddeb's or the user's) is "inserted"."""
    if last.ins and last.outcome == "mistake":
        return "inserted"
    if last.source == "mark":
        return "marked"
    status = row.get("status")
    if row.get("user"):
        status = str((before or {}).get(row.get("i"), (status,))[0] or "")
        status = status[len("provisional_"):] if status.startswith("provisional_") else status   # settled as ■ does
    if last.hinted or row.get("hinted") or status == "hinted" or key in revealed:
        return "hint"
    if row.get("lost"):
        return "lost"
    return "skipped" if status == "missing" else "wrong"


def card_help(cid: str, card: Card | None, doc: dict | None, history: dict[str, list[Reading]], q: Quran,
              written: Callable[[str], str] | None = None, joined: Callable[[str], bool] | None = None,
              counted: dict[str, list[Reading]] | None = None) -> dict:
    """review_help (B3.16; #57, v0.18, D8) -> {words: [{surah, ayah, idx, word, heard, kind, twins: [{surah, ayah, idx,
    word, learned}], context, unique, text}], method, sources}. The ✗ words: the card's target words (result's target:
    the card's, or the session's review meta) that failed in that saved session as result's ayah verdicts read them
    (ayah_ok: the session's last reading of the word a mistake, or a hint); a word the session never reached is not
    one. word = its written word (written(key): App passes app.written_text, a joined part named by its written word;
    else the Uthmani token); heard = what the model heard there when it is another word (never for the user's mark,
    whose reason it is not); kind = _kind. Twins = word_twins's places, the learned ones first (learned_session: the
    ayah recited once without a mistake or hint, progress's rule), then those followed by another word than here, at
    most HELP_TWINS; context = the run as written (joined(key): a joined part adds nothing to the run's text), unique =
    a run found only here. text = one sentence on what was said, one on the twins, else on the run, else "Say to
    yourself why «word» fits here.". A passed card, no session or another surah's: words []; method and sources always.
    #73 review: history = every reading (result's ✓ / ✗), counted = the counted one for the learned places (a practice
    session's correct readings learn nothing; history when None). ValueError: no card id."""
    cid = card_id(cid)
    written = written or (lambda k: _uthmani(q, k))
    joined = joined or (lambda k: False)
    out = {"words": [], "method": list(HELP_METHOD), "sources": [dict(x) for x in HELP_SOURCES]}
    meta = doc.get("review") if doc and isinstance(doc.get("review"), dict) else {}
    s = card.surah if card else parts(id_words(cid)[0])[0]
    target = card.target if card else (parts(id_words(cid)[0])[1], parts(id_words(cid)[-1])[1])
    t = meta.get("target")
    if isinstance(t, list) and len(t) == 2 and all(isinstance(x, int) for x in t):
        target = (t[0], t[1])
    if not doc or not doc.get("started_at") or doc.get("surah", s) != s:
        return out
    sess = doc["started_at"]
    rows = {(r.get("surah"), r.get("ayah"), r.get("idx")): r for r in doc.get("words", ()) if isinstance(r, dict)}
    revealed = set(doc.get("revealed_before_start") or ())
    before = _overruled(doc)[0]               # page review (F6): Meddeb's verdict under the user's marks, by row "i"
    learned: dict[tuple[int, int], bool] = {}

    def is_learned(k: str) -> bool:
        sa = parts(k)[:2]
        if sa not in learned:
            ay = q.ayat.get(sa)
            learned[sa] = ay is not None and learned_session([w.key for w in ay.words],
                                                             history if counted is None else counted) is not None
        return learned[sa]
    for a in range(target[0], target[1] + 1):
        ay = q.ayat.get((s, a))
        for w in ay.words if ay else ():
            rs = [r for r in history.get(w.key, ()) if r.session == sess]
            if not rs or (rs[-1].outcome == "ok" and not any(r.hinted for r in rs)):
                continue
            row = rows.get((s, a, w.idx)) or {}
            kind = _kind(row, rs[-1], w.key, revealed, before)
            # a mark during the session or after ■ (#72: an insertion of the user's too: what was heard is no reason)
            heard = None if kind == "marked" or rs[-1].source == "mark" else row.get("heard")
            h = normalize(heard or "").replace(" ", "")
            if not h or h in (w.norm, normalize(w.uthmani).replace(" ", "")):
                heard = None
            run, places = word_twins(w.key, q)
            same_next = lambda k: q.ayah(*parts(k)[:2]).words[parts(k)[2]].norm == w.norm   # noqa: E731
            order = sorted(places, key=lambda k: (not is_learned(k), same_next(k), _positions(q)[k]))
            shown = order[:HELP_TWINS]
            # v0.18 review: learned places that all go on with this same word must not hide the ones that go on
            # otherwise (the mutashabihat): one of those takes the last place shown
            other = next((k for k in order if not same_next(k)), None)
            if shown and other is not None and other not in shown:
                shown = shown[:-1] + [other]
            twins = [{"surah": parts(k)[0], "ayah": parts(k)[1], "idx": parts(k)[2], "word": written(k),
                      "learned": is_learned(k)} for k in shown]
            # a joined part (يَٰبَنِىَّ = يا + بني, U1.1e) is named by its written word, which holds the run's last word
            ctx = run[:-1] if run and joined(w.key) else run
            context = " ".join(written(k) for j, k in enumerate(ctx) if j == 0 or not joined(k)) if ctx else None
            word = written(w.key)
            if kind == "inserted" and heard:          # #72: "You added «قل» before «تِلْكَ»."
                first = f"You added «{heard}» before «{word}»."
            else:
                first = f"You said «{heard}»; here it is «{word}»." if heard else FIRST_SENTENCE[kind].format(w=word)
            if twins:
                refs = list(dict.fromkeys(f"{x['surah']}:{x['ayah']}" for x in twins))
                then = " / ".join(f"«{x}»" for x in dict.fromkeys(x["word"] for x in twins))
                where = _places(refs, len(places) - len(shown))
                if all(same_next(k) for k in places):   # every place, not only the ones shown
                    second = f"«{context}» also comes in {where}, followed by «{word}» there too."   # 55:13's refrain
                else:
                    second = f"«{context}» also comes in {where}, followed by {then}; here: «{word}»."
            elif ctx:
                second = f"«{context}» comes only here: it is always followed by «{word}»."
            else:
                second = f"Say to yourself why «{word}» fits here."
            out["words"].append({"surah": s, "ayah": a, "idx": w.idx, "word": word, "heard": heard, "kind": kind,
                                 "twins": twins, "context": context, "unique": bool(run) and not places,
                                 "text": f"{first} {second}"})
    return out


# ---------------------------------------------------------------------------- run-up and cue
def plan(card: Card, level: int, today: dt.date, context: Callable[[int, int], dict],
         lines_of: Callable[[int], list[dict]]) -> dict:
    """The run-up and the cue of a card session (X2.19) -> {runup_from, page, cue: {lines, prev_page, prev_lines,
    header}}. context = App._context_lines, lines_of(page) = mushaf_lines (kinds). The draws are seeded by card + date
    (the same plan all day). #48 (v0.17): the cue lies on one page, `page`: the run-up's (its lines there only), or the
    page before when it has no line on the run-up's page (the run-up starts that page); prev_page / prev_lines only for
    a run-up from ayah 1 whose surah header is on the page before."""
    rng = random.Random(f"{card.id}|{today.isoformat()}")
    level = max(0, min(3, int(level)))
    n_lines, coin, extra = rng.choice(RUNUP_LINES[level]), rng.random(), rng.choice(CUE_EXTRA[level])
    s, a1 = card.surah, card.target[0]
    b = a1
    if n_lines:
        g = ayah_gline(s, a1)
        b = next((x for x in range(a1 - 1, 0, -1) if ayah_gline(s, x) <= g - n_lines), 1)
        if b > 1 and coin < 0.5:
            b -= 1                                      # + 0-1 ayah: never the same start
    if b == a1 > 1 and card.words and card.words[0] == f"{s}:{a1}:0":
        # #39 review: a card on an ayah's first word (a join): the link rule keeps its pass only when the session read
        # the word before it, so a session started at the target (level 0, Recite the join) could never pass the card
        # (✓ passed, yet red and due today again, every day). The run-up starts one ayah before: the join is recited
        b = a1 - 1
    page = page_of(s, b)
    pages = {p: lines_of(p) for p in (page - 1, page) if p >= 1}
    ctx = context(s, b)
    heads = {(p, ln) for p, kinds in ctx["header_lines"].items() if p in pages for ln in kinds.values()}
    header = b == 1 or bool(ctx["header"])
    if b == 1:
        cue = set(heads)                                # the surah's start: its header is the cue
    else:
        cue = {(p, ln) for p, lns in ctx["lines"].items() if p in pages for ln in lns}
        if ctx["header"]:
            cue |= heads
        elif cue and extra:
            p, ln = min(cue)
            added = 0
            while added < extra:
                ln -= 1
                if ln < 1:
                    p, ln = p - 1, 15
                if p not in pages:
                    break
                line = pages[p][ln - 1]
                if line["kind"] == "empty":
                    continue
                if line["kind"] in ("surah", "basmala"):
                    if line.get("surah") == s:          # never above the surah's header
                        cue |= heads
                        header = True
                    break
                cue.add((p, ln))
                added += 1
    lines = sorted(ln for p, ln in cue if p == page)
    prev = sorted(ln for p, ln in cue if p == page - 1)
    if b > 1 and lines:
        prev = []           # #48 (v0.17): only the cue greyed in place on the run-up's page, never a sheet of the page before
    elif b > 1 and prev:
        page, lines, prev = page - 1, prev, []    # #48: the run-up starts its page: the cue is drawn on the page before
    return {"runup_from": b, "page": page,
            "cue": {"lines": lines, "prev_page": page - 1 if prev else None, "prev_lines": prev, "header": header}}



# ---------------------------------------------------------------------------- join cards (#103, v0.22, plan D6)
# The user (2026-11-02, #103): "when I have confusion when going from i to i+1 because it is mutashabihat, first
# challenge me with different cards about the mutashabihat … show 62 and ask for 63 then show 82 and ask for 83 and 84
# then show 92 and ask for 93 all three in any order and if I pass all good. if I fail then you explain why these are
# mutashabihat and how to retain them … review cards are not only about mutashabihat". From the Qur'an text alone.
JOIN_OPENING = 2                        # opening twins: the same first 2 normalized words
JOIN_MAX = 4                            # at most 4 challenges per join card
JOIN_CUE_LINES = 5                      # a challenge's cue: at most the last 5 lines of ayah i
JOIN_METHOD = (
    "Tie each ending to the word that decides, 3 times each: {ties}.",
    "{order}",
    "Meddeb asks them again in a new order each time (mixed practice).",
    "Meddeb brings the card back when it is due.",
)
# interleaving similar items helps tell them apart (Kornell & Bjork); practice testing, spacing (Dunlosky et al.)
JOIN_SOURCES = (
    HELP_SOURCES[0],
    {"title": "Kornell & Bjork 2008, Learning concepts and categories: is spacing the \"enemy of induction\"?",
     "url": "https://journals.sagepub.com/doi/10.1111/j.1467-9280.2008.02127.x"},
)


@lru_cache(maxsize=2)
def _openings(q: Quran) -> dict[tuple[str, ...], tuple[tuple[int, int], ...]]:
    """The ayat (ayah > 1: ayah i is shown before) by their first JOIN_OPENING normalized words, the shared ones only
    (~0.1 s on the PC, once per Quran)."""
    out: dict[tuple[str, ...], list[tuple[int, int]]] = {}
    for (s, a), ay in q.ayat.items():
        if a > 1 and len(ay.words) >= JOIN_OPENING:
            out.setdefault(tuple(w.norm for w in ay.words[:JOIN_OPENING]), []).append((s, a))
    return {k: tuple(sorted(v)) for k, v in out.items() if len(v) > 1}


def _shared(x: list[str], y: list[str]) -> int:
    n = 0
    while n < min(len(x), len(y)) and x[n] == y[n]:
        n += 1
    return n


def opening_twins(s: int, a: int, q: Quran) -> list[tuple[int, int, int]]:
    """#103 (D6): the ayat k != (s, a), k.ayah > 1, opening with the same first JOIN_OPENING normalized words ->
    [(surah, ayah, shared: their leading words in common)], mushaf order. An ayah the same word for word (55:13's
    refrain) is left out: nothing to tell apart."""
    ay = q.ayat.get((s, a))
    if ay is None or a <= 1 or len(ay.words) < JOIN_OPENING:
        return []
    mine = [w.norm for w in ay.words]
    out = []
    for s2, a2 in _openings(q).get(tuple(mine[:JOIN_OPENING]), ()):
        if (s2, a2) == (s, a):
            continue
        other = [w.norm for w in q.ayah(s2, a2).words]
        n = _shared(mine, other)
        if n == len(mine) == len(other):
            continue
        out.append((s2, a2, n))
    return out


@lru_cache(maxsize=8192)
def opening_key(s: int, a: int, q: Quran) -> int | None:
    """#103 (D6): the deciding word, the index of the word where the ayah parts from its closest opening twin (2:83:
    2 «ميثاق», 2:63 / 2:93: 10); None: no twin. An ayah that is the start of a longer one: its last word."""
    twins = opening_twins(s, a, q)
    if not twins:
        return None
    return min(max(n for _s, _a, n in twins), len(q.ayah(s, a).words) - 1)


def join_order(cid: str, n: int, today: dt.date) -> list[int]:
    """#103 (D6): "all three show in any order": the order of a join card's challenges today (indices into
    Card.similar), shuffled by the card and the date (the same all day)."""
    order = list(range(n))
    random.Random(f"{cid}|join|{today.isoformat()}").shuffle(order)
    return order


def _join_card(c: Card, ws: list[WordState], history: dict[str, list[Reading]], q: Quran,
               learned: dict[tuple[int, int], bool]) -> None:
    """#103 (D6): c.similar / c.confused_with when the card holds a join confusion: a word (s, j, idx), j > 1, at or
    before ayah j's deciding word (opening_key), one of whose fail verdicts comes from a session that also read ayah
    j - 1's last word (the user came from ayah i), with at least one learned twin (join_members; #116, v0.23: on any
    page, the Next to learn page too). A session that started at j, or a fail past the deciding word: an ordinary card
    (a hole card has no verdict: never a join card)."""
    c.similar, c.confused_with = [], []
    for w in ws:
        s, j, idx = parts(w.key)
        if j <= 1:
            continue
        k = opening_key(s, j, q)
        prev = q.ayat.get((s, j - 1))
        if k is None or idx > k or prev is None or not prev.words:
            continue
        came = {r.session for r in history.get(prev.words[-1].key, ())} - {None}
        failed = {v.session for v in w.verdicts if v.fail and v.session in came}
        if not failed:
            continue
        members = join_members(s, j, history, q, None, learned)
        if members:
            c.similar = members
            c.confused_with = _confused(w.key, failed, history, q)
            return


def _first_heard(heard: str | None) -> str | None:
    toks = normalize(heard or "").split()
    return toks[0] if toks else None


def _confused(key: str, sessions: set, history: dict[str, list[Reading]], q: Quran) -> list[tuple[int, int]]:
    """The twins whose word at the card word's index is what the model heard there in those sessions (heard
    «ميثاقكم» at 2:83:2: 2:63, 2:84, 2:93), mushaf order."""
    s, j, idx = parts(key)
    heard = {h for r in history.get(key, ()) if r.session in sessions and (h := _first_heard(r.heard))}
    out = []
    for s2, a2, _n in opening_twins(s, j, q):
        ws2 = q.ayah(s2, a2).words
        if idx < len(ws2) and ws2[idx].norm in heard:
            out.append((s2, a2))
    return out


def join_members(s: int, j: int, history: dict[str, list[Reading]], q: Quran, learning: int | None = None,
                 learned: dict[tuple[int, int], bool] | None = None) -> list[dict]:
    """#103 (D6): a join card's challenges for ayah (s, j) -> [{cue: [s, i], target: [s, a1, a2], own, key: [deciding
    word per target ayah]}] in mushaf order, [] when no twin is learned (learned_session, progress' rule) off the
    `learning` page (cards() passes None since #116, v0.23: every page counts). One challenge per learned twin and the
    card's own; twins that follow each other in one surah are one challenge (83 and 84: "show 82 and ask for 83 and
    84"); the longest shared opening first, then the same surah, then the nearest in the mushaf; at most JOIN_MAX, the
    card's own always."""
    learned = {} if learned is None else learned

    def is_learned(sa: tuple[int, int]) -> bool:
        if sa not in learned:
            ay = q.ayat.get(sa)
            learned[sa] = ay is not None and learned_session([w.key for w in ay.words], history) is not None
        return learned[sa]
    shared = {(s2, a2): n for s2, a2, n in opening_twins(s, j, q)
              if page_of(s2, a2) != learning and is_learned((s2, a2))}
    if not shared:
        return []
    shared[(s, j)] = len(q.ayah(s, j).words) + 1         # the card's own: always first
    groups: list[list[tuple[int, int]]] = []
    for sa in sorted(shared):
        if groups and groups[-1][-1][0] == sa[0] and groups[-1][-1][1] + 1 == sa[1]:
            groups[-1].append(sa)
        else:
            groups.append([sa])
    g0 = ayah_gline(s, j)
    ranked = sorted(groups, key=lambda g: ((s, j) not in g, -max(shared[x] for x in g), g[0][0] != s,
                                           abs(ayah_gline(*g[0]) - g0)))
    return [{"cue": [g[0][0], g[0][1] - 1], "target": [g[0][0], g[0][1], g[-1][1]], "own": (s, j) in g,
             "key": [opening_key(*x, q) for x in g]} for g in sorted(ranked[:JOIN_MAX])]


def _word_place(key: str) -> tuple[int, int]:
    """(page, line) of a word, also on the page after its ayah's first (an ayah over a page turn)."""
    s, a, _ = parts(key)
    pg = page_of(s, a)
    for p in (pg, pg + 1, pg + 2):
        ln = _page_word_lines(p).get(key) if p <= 604 else None
        if ln is not None:
            return p, ln
    return pg, 1


def join_plan(card: Card, member: dict, q: Quran | None = None) -> dict:
    """#103 (D6): a join challenge's plan, plan()'s shape -> {runup_from: the member's first ayah, page, level 0, cue:
    the last JOIN_CUE_LINES lines of ayah i (the member's cue) greyed, start: {surah, ayah_from, review: {card, target,
    level, join: [s, i]}}}. #48's page rule: the cue's lines on the run-up's page, else on the page before."""
    q = q or load_quran()
    s, a1, a2 = (int(x) for x in member["target"])
    cs, ca = (int(x) for x in member["cue"])
    places = sorted({_word_place(w.key) for w in q.ayah(cs, ca).words})[-JOIN_CUE_LINES:]
    page = page_of(s, a1)
    lines = [ln for p, ln in places if p == page]
    if not lines:
        page -= 1                                       # #48: ayah i ends on the page before
        lines = [ln for p, ln in places if p == page]
    return {"runup_from": a1, "page": page, "level": 0,
            "cue": {"lines": lines, "prev_page": None, "prev_lines": [], "header": False},
            "start": {"surah": s, "ayah_from": a1,
                      "review": {"card": card.id, "target": [a1, a2], "level": 0, "join": [cs, ca]}}}


def _opening_ok(history: dict[str, list[Reading]], q: Quran, member: dict, sess: str) -> bool:
    """A challenge's pass rule: each target ayah's words 0 .. its deciding word read in that session, the last reading
    right, no hint."""
    ms, a1, a2 = (int(x) for x in member["target"])
    keys = list(member.get("key") or ())
    for k, a in enumerate(range(a1, a2 + 1)):
        ws = q.ayah(ms, a).words
        last = min(keys[k] if k < len(keys) and keys[k] is not None else len(ws) - 1, len(ws) - 1)
        for w in ws[:last + 1]:
            rs = [r for r in history.get(w.key, ()) if r.session == sess]
            if not rs or rs[-1].outcome != "ok" or any(r.hinted for r in rs):
                return False
    return True


def join_help(cid: str, card: Card | None, joins: list[tuple[dict, dict | None]], history: dict[str, list[Reading]],
              q: Quran, written: Callable[[str], str] | None = None,
              joined: Callable[[str], bool] | None = None) -> dict:
    """#103 (D6): review_help{joins} -> the ? panel of a join card, "why these are mutashabihat and how to retain them":
    {words: [], group: "«وَإِذْ أَخَذْنَا» opens 4 ayat you learned in Al-Baqarah: 63, 83, 84, 93.", split: the rows of
    the tree of their openings up to each one's deciding word [{depth, segments: [{text, key}], ayat: ["s:a" ending
    there], text}] (key: the deciding word), members: per challenge played [{cue, target, ok (None: no session), heard,
    as_in: the twins it belongs to, text}], counts: the first split [{text, n}], method, sources}. joins = [(member,
    its saved session.json or None)]; the group = the card's challenges (Card.similar), else the members given.
    written / joined: card_help's. ValueError: no card id."""
    cid = card_id(cid)
    written = written or (lambda k: _uthmani(q, k))
    joined = joined or (lambda k: False)
    out = {"words": [], "group": "", "split": [], "members": [], "counts": [], "method": [],
           "sources": [dict(x) for x in JOIN_SOURCES]}
    group = list(card.similar) if card and card.similar else [m for m, _d in joins]
    ayat = sorted({(int(m["target"][0]), a) for m in group for a in range(int(m["target"][1]), int(m["target"][2]) + 1)})
    if not ayat:
        out.update(method=list(HELP_METHOD), sources=[dict(x) for x in HELP_SOURCES])
        return out

    def text(keys: list[str]) -> str:
        return " ".join(written(k) for i, k in enumerate(keys) if i == 0 or not joined(k))

    def key_of(sa: tuple[int, int]) -> int:
        k = opening_key(*sa, q)
        return len(q.ayah(*sa).words) - 1 if k is None else k
    own = next((m for m in group if m.get("own")), group[0])
    first = (int(own["target"][0]), int(own["target"][1]))
    opening = text([f"{first[0]}:{first[1]}:{i}" for i in range(JOIN_OPENING)])
    by_surah: dict[int, list[int]] = {}
    for s, a in ayat:
        by_surah.setdefault(s, []).append(a)
    where = " and in ".join(f"{q.chapter_name(s)}: {', '.join(map(str, a_s))}" for s, a_s in by_surah.items())
    out["group"] = f"«{opening}» opens {len(ayat)} ayat you learned in {where}."
    # the split tree: a radix tree over the openings, the deciding word last on each path
    paths = {sa: [w.norm for w in q.ayah(*sa).words[:key_of(sa) + 1]] for sa in ayat}
    inner: list[tuple[int, str, list[tuple[int, int]]]] = []

    def build(items: list[tuple[int, int]], start: int, depth: int) -> list[tuple[int, int]]:
        n = start
        while all(len(paths[x]) > n for x in items) and len({paths[x][n] for x in items}) == 1:
            n += 1
        ref = items[0]
        ends = [x for x in items if len(paths[x]) == n]
        rest = [x for x in items if len(paths[x]) > n]
        kids: dict[str, list[tuple[int, int]]] = {}
        for x in rest:
            kids.setdefault(paths[x][n], []).append(x)
        order = sorted(kids.values(), key=lambda g: (len(g), g[0]))     # the shortest branch first
        if depth == 0:
            out["counts"] = [{"text": written(f"{g[0][0]}:{g[0][1]}:{n}"), "n": len(g)} for g in order]
        leaves = list(ends)
        if n > start:
            keys = [f"{ref[0]}:{ref[1]}:{i}" for i in range(start, n)]
            segs = [{"text": text(keys[:-1] if ends else keys), "key": False}] if (keys[:-1] if ends else keys) else []
            if ends:
                segs.append({"text": written(keys[-1]), "key": True})
            out["split"].append({"depth": depth, "segments": segs, "ayat": [f"{s}:{a}" for s, a in ends],
                                 "text": " ".join(x["text"] for x in segs)})
            nxt = depth + 1
        else:
            nxt = depth
        for g in order:
            leaves += build(g, n, nxt)
        if depth > 0 and not ends and len(leaves) >= 2 and n > start:
            inner.append((depth, text([f"{ref[0]}:{ref[1]}:{i}" for i in range(start, n)]), sorted(leaves)))
        return leaves
    build(list(ayat), 0, 0)

    def deciding(sa: tuple[int, int]) -> str:
        return written(f"{sa[0]}:{sa[1]}:{key_of(sa)}")

    def ref(s: int, a: int) -> str:
        return str(a) if s == first[0] else f"{s}:{a}"
    for m, doc in joins:
        ms, a1, a2 = (int(x) for x in m["target"])
        cs, ca = (int(x) for x in m["cue"])
        end = written(q.ayah(cs, ca).words[-1].key)
        lead = text([f"{ms}:{a1}:{i}" for i in range(key_of((ms, a1)) + 1)])
        ok, heard, as_in = None, None, []
        if doc and doc.get("started_at") and doc.get("surah", ms) == ms:
            sess = doc["started_at"]
            ok = _opening_ok(history, q, m, sess)
            for a in range(a1, a2 + 1):
                for w in q.ayah(ms, a).words[:key_of((ms, a)) + 1]:
                    rs = [r for r in history.get(w.key, ()) if r.session == sess]
                    h = _first_heard(rs[-1].heard) if rs and rs[-1].outcome == "mistake" else None
                    if h and h != w.norm:
                        heard = rs[-1].heard
                        as_in = [f"{s2}:{b}" for s2, b, _n in opening_twins(ms, a, q)
                                 if w.idx < len(q.ayah(s2, b).words) and q.ayah(s2, b).words[w.idx].norm == h]
                        break
                if heard:
                    break
        t = f"{ca} «…{end}» → {a1} «{lead}»" + (" ✓" if ok else " ✗" if ok is False else "")
        if heard:
            refs = ", ".join(ref(*map(int, x.split(":"))) for x in as_in)
            t += f": you said «{heard}»" + (f" (as in {refs})" if refs else "")
        out["members"].append({"cue": [cs, ca], "target": [ms, a1, a2], "ok": ok, "heard": heard, "as_in": as_in,
                               "text": t})
    ties = "; ".join(f"«{written(q.ayah(int(m['cue'][0]), int(m['cue'][1])).words[-1].key)}» → "
                     f"«{deciding((int(m['target'][0]), int(m['target'][1])))}»" for m in group)
    if inner:
        _d, shared_text, leaves = max(inner, key=lambda x: (x[0], -len(x[2])))
        steps = [f"at {ref(*sa)} with «{deciding(sa)}»" for sa in leaves]
        order = f"Keep the order: «{shared_text}» comes first {steps[0]}, then " + ", then ".join(steps[1:]) + "."
    else:
        order = f"Keep the order of the mushaf: {', '.join(ref(*sa) for sa in ayat)}."
    out["method"] = [JOIN_METHOD[0].format(ties=ties), JOIN_METHOD[1].format(order=order), *JOIN_METHOD[2:]]
    return out
