"""Audio loading / resampling / chunking (16 kHz float32 mono everywhere)."""
from __future__ import annotations

from pathlib import Path

import numpy as np

SR = 16000


def load_audio(path: str | Path, sr: int = SR) -> np.ndarray:
    """Decode wav/flac/mp3/ogg with libsndfile, mix to mono, resample to `sr`."""
    import soundfile as sf

    data, fs = sf.read(str(path), dtype="float32", always_2d=True)
    mono = data.mean(axis=1) if data.shape[1] > 1 else data[:, 0]
    if fs != sr:
        import soxr

        mono = soxr.resample(mono, fs, sr, quality="HQ").astype(np.float32)
    return np.ascontiguousarray(mono, dtype=np.float32)


def rms_frames(audio: np.ndarray, sr: int = SR, frame_s: float = 0.05) -> np.ndarray:
    n = max(1, int(sr * frame_s))
    k = len(audio) // n
    if k == 0:
        return np.array([float(np.sqrt(np.mean(audio**2) + 1e-12))])
    x = audio[: k * n].reshape(k, n)
    return np.sqrt(np.mean(x * x, axis=1) + 1e-12)


def chunk_bounds(audio: np.ndarray, sr: int = SR, max_len: float = 25.0, search: float = 4.0,
                 frame_s: float = 0.05) -> list[tuple[int, int]]:
    """Split long audio into chunks <= max_len seconds, cutting at the quietest 50 ms frame
    inside the last `search` seconds of each chunk. Returns sample index bounds."""
    total = len(audio)
    max_n = int(max_len * sr)
    if total <= max_n:
        return [(0, total)]
    rms = rms_frames(audio, sr, frame_s)
    n = int(sr * frame_s)
    bounds: list[tuple[int, int]] = []
    start = 0
    while total - start > max_n:
        lo_f = (start + max_n - int(search * sr)) // n
        hi_f = (start + max_n) // n
        lo_f = max(lo_f, start // n + 1)
        seg = rms[lo_f:hi_f]
        cut_f = lo_f + int(np.argmin(seg)) if len(seg) else hi_f
        cut = cut_f * n
        bounds.append((start, cut))
        start = cut
    bounds.append((start, total))
    return bounds


# ---------------------------------------------------------------------------- microphone preprocessing
# Every variant is a function audio -> audio at 16 kHz (float32 mono, same length). They were
# measured against the served Whisper model in d02_PoC/benchmark/preprocess_ablation.py (see
# results/preprocess_ablation.md before enabling one in the live tracker).

def highpass(audio: np.ndarray, sr: int = SR, cutoff: float = 80.0, order: int = 2) -> np.ndarray:
    """Zero-phase Butterworth high-pass (offline use: filtfilt has no start-up transient)."""
    from scipy.signal import butter, sosfiltfilt

    if len(audio) < 3 * (2 * order + 1):
        return audio.astype(np.float32)
    sos = butter(order, cutoff, btype="highpass", fs=sr, output="sos")
    return sosfiltfilt(sos, audio.astype(np.float64)).astype(np.float32)


class StreamingHighpass:
    """Causal Butterworth high-pass that keeps its filter state across pushed chunks."""

    def __init__(self, sr: int = SR, cutoff: float = 80.0, order: int = 2) -> None:
        from scipy.signal import butter, sosfilt_zi

        self.sos = butter(order, cutoff, btype="highpass", fs=sr, output="sos")
        self.zi = sosfilt_zi(self.sos) * 0.0

    def __call__(self, audio: np.ndarray) -> np.ndarray:
        from scipy.signal import sosfilt

        if len(audio) == 0:
            return audio.astype(np.float32)
        y, self.zi = sosfilt(self.sos, audio.astype(np.float64), zi=self.zi)
        return y.astype(np.float32)


def rms_normalize(audio: np.ndarray, target_dbfs: float = -20.0, peak_limit: float = 0.99) -> np.ndarray:
    """Scale to `target_dbfs` RMS, then limit the peak to `peak_limit` (plain gain, no compression)."""
    rms = float(np.sqrt(np.mean(audio.astype(np.float64) ** 2) + 1e-12))
    if rms < 1e-6:
        return audio.astype(np.float32)
    gain = 10 ** (target_dbfs / 20) / rms
    peak = float(np.abs(audio).max()) * gain
    if peak > peak_limit:
        gain *= peak_limit / peak
    return (audio * gain).astype(np.float32)


def peak_normalize(audio: np.ndarray, peak: float = 0.9) -> np.ndarray:
    m = float(np.abs(audio).max())
    if m < 1e-6:
        return audio.astype(np.float32)
    return (audio * (peak / m)).astype(np.float32)


def noise_reduce(audio: np.ndarray, sr: int = SR, prop_decrease: float = 0.7) -> np.ndarray:
    """Stationary spectral gating (noisereduce): the noise spectrum is estimated from the whole clip."""
    import noisereduce as nr

    if len(audio) < sr // 4:
        return audio.astype(np.float32)
    y = nr.reduce_noise(y=audio.astype(np.float32), sr=sr, stationary=True, prop_decrease=prop_decrease,
                        n_jobs=1, use_torch=False)
    return np.ascontiguousarray(y, dtype=np.float32)


def noise_floor(audio: np.ndarray, sr: int = SR, frame_s: float = 0.02, pct: float = 15.0) -> float:
    """Adaptive noise floor: low percentile of the 20 ms frame RMS."""
    r = rms_frames(audio, sr, frame_s)
    return float(np.percentile(r, pct))


def soft_gate(audio: np.ndarray, sr: int = SR, floor_mult: float = 3.0, attenuation: float = 0.1,
              frame_s: float = 0.02) -> np.ndarray:
    """Soft noise gate: frames whose RMS is below floor_mult x adaptive floor are scaled by
    `attenuation` (not zeroed); the per-frame gain is smoothed over 5 frames to avoid clicks."""
    n = max(1, int(sr * frame_s))
    k = len(audio) // n
    if k < 5:
        return audio.astype(np.float32)
    r = rms_frames(audio, sr, frame_s)[:k]
    floor = float(np.percentile(r, 15))
    gain = np.where(r >= floor_mult * floor, 1.0, attenuation)
    gain = np.convolve(np.pad(gain, 2, mode="edge"), np.ones(5) / 5, mode="valid")
    g = np.repeat(gain, n)
    out = audio.astype(np.float32).copy()
    out[: k * n] *= g.astype(np.float32)
    return out


def _chain(*fns):
    def run(audio: np.ndarray) -> np.ndarray:
        for f in fns:
            audio = f(audio)
        return audio
    return run


# name -> function audio -> audio (offline / whole buffer). "raw" is the identity.
PREPROCESSORS: dict[str, object] = {
    "raw": lambda a: a,
    "hp80": lambda a: highpass(a, cutoff=80.0),
    "hp120": lambda a: highpass(a, cutoff=120.0),
    "rms20": lambda a: rms_normalize(a, -20.0),
    "peak09": lambda a: peak_normalize(a, 0.9),
    "nr07": lambda a: noise_reduce(a, prop_decrease=0.7),
    "nr10": lambda a: noise_reduce(a, prop_decrease=1.0),
    "gate": lambda a: soft_gate(a),
    "hp80_rms20": _chain(lambda a: highpass(a, cutoff=80.0), lambda a: rms_normalize(a, -20.0)),
    "hp80_nr07_rms20": _chain(lambda a: highpass(a, cutoff=80.0), lambda a: noise_reduce(a, prop_decrease=0.7),
                              lambda a: rms_normalize(a, -20.0)),
}


def preprocess(audio: np.ndarray, name: str | None) -> np.ndarray:
    """Apply the named variant (None / "raw" = identity)."""
    if not name or name == "raw":
        return audio
    return PREPROCESSORS[name](audio)
