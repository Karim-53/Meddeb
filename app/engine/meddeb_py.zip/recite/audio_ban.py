"""The ban of reciter audio that carries ticks (D4.12, #92, v0.22 plan D7; user 2026-11-02: "EveryAyah's [ticked]
audio must be banned and never never used, not even as mirror site nor plan b. EveryAyah's ok audio can be kept no
problem"). A banned file or range is never played, never a fallback, never a mirror.

data/audio_vetting.json (tools/scan_audio_ticks.py, the dev-phase scan every audio source passes before Meddeb plays
it) = {source_id: {"kind": "ayah_files" | "surah_files", "url": template with {SSS} (and {AAA} for per-ayah files),
"method", "thresholds", "date", "scanned", "ticked", "suspect", "short", "banned_ranges", …}}; "banned_ranges" is the
ban ("S" = the whole surah, "S:A", "S:A-B"; ayah 0 = a surah's ta'awwudh / basmala file, banned only with its whole
surah or when listed). Source ids: "everyayah/<folder>", "quranicaudio/<reciter>", "mp3quran/<reciter>/<r>",
"archive.org/<item>". A per-ayah URL matches its source on any host and scheme by its last two path parts ("<folder>/
SSSAAA.mp3": a mirror of EveryAyah's folder is the same audio); a surah file URL by its host (without "www.") and path.
No file: nothing is banned (load() == {}; the file ships with the engine, tests/test_audio_ban.py). Standard library
only (Chaquopy, Pyodide).
"""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path
from urllib.parse import urlsplit

PATH = Path(__file__).resolve().parent / "data" / "audio_vetting.json"
EA_YASSER = "everyayah/Yasser_Ad-Dussary_128kbps"
QA_YASSER = "quranicaudio/yasser_ad-dussary"


@lru_cache(maxsize=1)
def load() -> dict:
    """The whole vetting file; {} when it is missing or unreadable."""
    try:
        doc = json.loads(PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return doc if isinstance(doc, dict) else {}


_PARSED: dict = {}     # id(the loaded doc) -> (doc, {what: parsed}): follows load() and its cache_clear()


def _memo(what, build):
    doc = load()
    hit = _PARSED.get(id(doc))
    if hit is None or hit[0] is not doc:
        _PARSED.clear()
        hit = _PARSED[id(doc)] = (doc, {})
    if what not in hit[1]:
        hit[1][what] = build(doc)
    return hit[1][what]


def _ranges(source: str) -> dict:
    """{surah: [(lo, hi), …]} of a source's ban; (0, 10**6) = the whole surah."""
    return _memo(("ranges", source), lambda doc: _parse_ranges(doc, source))


def _parse_ranges(doc: dict, source: str) -> dict:
    out: dict = {}
    for r in (doc.get(source) or {}).get("banned_ranges", []):
        s, _, a = str(r).partition(":")
        lo, _, hi = a.partition("-")
        span = (0, 10 ** 6) if not a else (int(lo), int(hi or lo))
        out.setdefault(int(s), []).append(span)
    return out


def banned(source: str, surah: int, ayah: int) -> bool:
    """Is (surah, ayah) of this source banned? (ayah 0: the surah's ta'awwudh / basmala file)"""
    return any(lo <= int(ayah) <= hi for lo, hi in _ranges(source).get(int(surah), ()))


def banned_in_surah(source: str, surah: int) -> bool:
    """Does this source's audio of the surah hold anything banned (a surah file to drop from a cache)?"""
    return bool(_ranges(source).get(int(surah)))


def _norm(url: str) -> str:
    p = urlsplit(url)
    host = p.netloc.lower()
    return (host[4:] if host.startswith("www.") else host) + p.path


def _patterns() -> tuple:
    """(source, kind, regex) per vetted source: per-ayah files by their last two path parts, surah files whole."""
    return _memo("patterns", _parse_patterns)


def _parse_patterns(doc: dict) -> tuple:
    out = []
    for sid, e in doc.items():
        tpl, kind = (e or {}).get("url", ""), (e or {}).get("kind")
        if kind == "file" and isinstance((e or {}).get("surah"), int) and "{" not in tpl and tpl:
            # v0.22 review: one file holding (part of) one surah (the Kurd Fatiha on Meddeb's site): a surah file
            out.append((sid, "surah_files", re.compile("^" + re.escape(_norm(tpl)) + r"(?P<s>)$", re.I), e["surah"]))
            continue
        if "{SSS}" not in tpl or kind not in ("ayah_files", "surah_files"):
            continue
        t = _norm(tpl)
        if kind == "ayah_files":
            t = "/".join(t.split("/")[-2:])
        rx = re.escape(t).replace(re.escape("{SSS}"), r"(?P<s>\d{3})").replace(re.escape("{AAA}"), r"(?P<a>\d{3})")
        out.append((sid, kind, re.compile(("(?:^|/)" if kind == "ayah_files" else "^") + rx + "$", re.I), None))
    return tuple(out)


def source_of(url: str) -> tuple[str, int, int | None] | None:
    """(source id, surah, ayah or None for a surah file) of a vetted source's URL; None when no source matches."""
    n = _norm(url)
    for sid, kind, rx, surah in _patterns():
        m = rx.search(n)
        if m:
            a = m.groupdict().get("a")
            return sid, (surah if surah is not None else int(m.group("s"))), (int(a) if a is not None else None)
    return None


def vetted(url: str) -> bool:
    """Does the URL belong to a source that passed the scan (D4.12: every source Meddeb plays must)?"""
    return source_of(url) is not None


def banned_url(url: str, ayah: int | None = None) -> bool:
    """Is this file banned? A surah file: with `ayah`, that ayah's range of it; without, whether it holds any banned
    audio. An unvetted URL is not listed (False): vetted() says whether it was scanned at all."""
    hit = source_of(url)
    if hit is None:
        return False
    sid, s, a = hit
    if a is not None:
        return banned(sid, s, a)
    return banned(sid, s, ayah) if ayah is not None else banned_in_surah(sid, s)
