"""The Stats page (issue #13, D6 of the v0.12 round): what was done today, the overall numbers, the curves over time and
the pace, all from the reading history the Progress page already uses (recite/progress.py). Pure: stdlib only, no
I/O beyond the packaged mushaf layout progress.word_pages() reads once; nothing new is stored. Runs only when the
Stats page asks (never inside progress(), which Android runs after every mark).

API
    stats(history, q, today) -> dict          history = Profile.history() (each word's readings in time order),
                                              q = load_quran(), today = the local date (a datetime: its date)
    ayah_index(sa, q) -> int                  (surah, ayah) -> 0-based mushaf position; None (every ayah recited) ->
                                              6236 (progress.ayah_index). series.next is in these units: the number
                                              of ayat before it.

    {"total_ayat": 6236,
     "today":   {"learned": int, "corrected": int, "pages": float},
     "learned": {"n", "pct"}, "perfect": {"n", "pct"}, "last_learned": {"surah", "ayah", "page"} | None,
     "to_fix":  {"ayat": int, "words": int},                            # issue #96
     "new_learned": {"today", "week", "year", "year_number"},          # these four: exactly progress()'s values
     "avg":    {"window_days": int, "ayat_per_week": float, "pages_per_day": float},
     "series": {"start": "yyyy-mm-dd" | None, "days": [int], "learned": [int], "perfect": [int], "next": [int]},
     "slope":  {"learned": float, "perfect": float, "next": float},    # per week, over the window
     "pace":   {"remaining": int,
                "windows": {"all" | "month" | "week": {"days": int, "ayat": int, "ayat_per_week": float,
                                                       "finish": "yyyy-mm-dd" | None,
                                                       "slope": {"learned", "perfect", "next": float},
                                                       "pages_per_day": float}}},           # issue #80
     "detection": {"all" | "month" | "week": {"tp", "fp", "tn", "fn": int, "precision": float | None,
                                              "recall": float | None, "readings": int}}}       # issue #69

Definitions (a reading's date is its stored local time's t[:10]; readings dated after today count nowhere here, while
progress() still counts them: a clock set back):
- Learned, perfect, last learned, new ayat learned: progress.py's own rules (learned_moment, #17), same numbers;
  perfect = learned with no word whose latest reading is a mistake or a hint (#96, D2, v0.21: a hinted latest reading
  spoils it too). to_fix (#96, user 2026-11-01: "the errors I am counting does not match with the current state") =
  the words whose latest reading is a mistake (any recited word, learned or not, on a page the Progress table lists:
  its Err summed; v0.21 review: a mistake in an ayah cut off on a page with no row counts in neither) and the ayat
  holding them.
- A recitation of a word: the readings of one session (Reading.session) of it; it was said on the date of that
  session's first reading of the word, and its verdict is that session's last reading of it (the marks made on it
  after ■ amend it), as in progress.learned_moment. A mark outside every session is no recitation.
- today.learned = new_learned.today. today.corrected = the words whose last reading dated before today is a mistake,
  whose latest reading is right, and that a recitation said today read right without a hint (a + Correct or a Remove
  made today on an older recitation's false alarm is no correction: nothing was recited; a mistake made and fixed
  today does not count either). today.pages = page-equivalents recited today: per 15-line page, its distinct words
  said in a recitation today / its words, summed, 1 decimal.
- window_days = min(28, max(7, days from the first reading to today, both counted)).
  avg.ayat_per_week = the ayat whose learned date falls in the window x 7 / window_days (= slope.learned).
  avg.pages_per_day = the window's daily page-equivalents summed / window_days (a day without a recitation counts 0);
  pace.windows[k].pages_per_day the same over that window's days (#80: the Over time averages follow Pace over).
- series: from the first reading's date to today, the value at the end of each day: learned = the ayat learned by
  then (today's view of the past: a Remove rewrites the earlier days too); perfect = those of them with no word whose
  latest reading by then is a mistake or a hint (#96); next = ayah_index of Next to learn by then
  (progress.next_to_learn on the readings dated up to that day). One point a day; when that is more than 180 days, one
  point a week counted back from today plus the first day. series.days[i] = the point's day offset from start
  (start + days[-1] = today).
- slope[x] = (x today - x window_days days ago, 0 before the start) x 7 / window_days, on the daily values, 1 decimal.
- pace.remaining = 6236 - learned.n. pace.windows (issue #30: the page's "Pace over" choice; one call gives all three):
  days = min(cap, max(7, days from the first reading to today, both counted)), cap = 28 (month), 7 (week) or none
  (all); ayat = the ayat whose learned date falls in those days; ayat_per_week = ayat x 7 / days, 1 decimal; finish =
  today + ceil(remaining x days / ayat) days, None when nothing remains, ayat = 0 or past year 9999. 'month' is avg's
  window: its numbers are avg's (0.12's pace). #60 (v0.18, D13; user 2026-10-28: "when changing the value in the combo
  box, the x axis of the plot changes to the last 4 weeks, 1 week, begining"): slope = slope[x]'s rule over the
  window's own days (x today - x days ago, 0 before the start, x 7 / days, 1 decimal), the chart's legend for that
  choice; 'month''s = slope.
- detection (issue #69, v0.18; user 2026-10-29: "in the stats show precision recall of the AI mistakes detection
  (subject to the 3 time slots of the combo box …) a positive is a mistake"): over each pace window's days (the
  readings dated from today - days + 1 to today), one count per word a session read (per session x word, on that
  reading's date): the tracker's verdict on it (Reading.ai, profile.ai_verdict; a hint, a word read in silence (#49)
  and a word the tracker did not judge count nowhere) against the user's label on it, the newest reading of the word
  from it up to the word's next session reading (his verdict during the session, then the marks made after ■, a
  Remove included: each one labels the reading of the session it was placed in, Reading.session, i.e. the saved
  session on screen it names (#67 / #69 review: a + Correct made after ◀ loaded an older session labels that one's
  reading) or issue #17's, else the word's newest session reading at or before it; an undone mark counts for nothing; a
  + Mistake / + Correct dated after today counts nowhere, while a Remove or an unmark rewrites the reading it acts on
  whatever its date, as in the series: today's view of the past, page review 2026-10-29; a Remove made with an older
  session on screen acts on that session's reading, profile._Remove). tp = flagged by the AI and still a mistake; fp =
  flagged, then made correct ("AI detected and then removed"); tn = judged ok, no mistake added; fn = judged ok, a
  mistake added on top. precision = tp / (tp + fp), recall = tp / (tp + fn), 3 decimals, None when the denominator is 0; readings =
  tp + fp + tn + fn.

Cost: one pass over the readings plus one over the days (Next to learn only moves forward while words get read, and
moves back only over the ayat with a mistake right before it), never next_to_learn() once per day.
"""
from __future__ import annotations

import datetime as dt

from .profile import Reading
from .progress import TOTAL_AYAT, _pct, ayah_index, ayah_table, learned_moment, new_learned, page_sizes, word_pages
from .quran_text import Quran, page_of

__all__ = ["stats", "ayah_index"]

WINDOW_DAYS = 28            # the averages, the slopes and the pace's default: the last 4 weeks ...
MIN_WINDOW_DAYS = 7         # ... or the days since the first reading, at least a week
DAILY_POINTS = 180          # longer series keep one point a week
WEEK = 7
PACE_WINDOWS = {"all": None, "month": WINDOW_DAYS, "week": WEEK}   # issue #30: the pace's choice of days ('month':
                                                                    # the page's default), None = since the first reading
DETECTION = ("tp", "fp", "tn", "fn")   # issue #69: the AI's verdict (a mistake = a positive) against the user's label


def _pages(keys) -> float:
    """Page-equivalents of a set of words: per page, its words in the set / its words."""
    pages_of, sizes = word_pages(), page_sizes()
    n: dict[int, int] = {}
    for k in keys:
        p = pages_of.get(k)
        if p is not None:
            n[p] = n.get(p, 0) + 1
    return sum((c / sizes[p] for p, c in n.items()), 0.0)


def _is_date(d: str) -> bool:
    """A yyyy-mm-dd date (a reading with a hand-edited time counts nowhere rather than breaking the page)."""
    try:
        return dt.date.fromisoformat(d).isoformat() == d
    except ValueError:
        return False


def _weekly(n_days: int) -> list[int]:
    """The day offsets kept: every day up to DAILY_POINTS days, then one a week back from today plus the first day;
    #60 (v0.18 review): the last WINDOW_DAYS days always one a day (the page's Last 7 days / Last 4 weeks charts)."""
    if n_days <= DAILY_POINTS:
        return list(range(n_days))
    last = n_days - 1
    days = sorted(set(range(last, -1, -WEEK)) | set(range(max(0, last - WINDOW_DAYS), n_days)))
    return days if days[0] == 0 else [0] + days


def stats(history: dict[str, list[Reading]], q: Quran, today: dt.date) -> dict:
    if isinstance(today, dt.datetime):
        today = today.date()
    order, index, sizes = ayah_table(q)
    n_ayat = len(order)
    t_day = today.isoformat()

    dates: dict[str, bool] = {}                            # date string -> _is_date, once per distinct date

    # the history's real words: key -> its ayah's mushaf position (a key outside the Qur'an counts nowhere)
    where: dict[str, int] = {}
    for k in history:
        try:
            s, a, i = map(int, k.split(":"))
        except ValueError:
            continue
        ai = index.get((s, a))
        if ai is not None and 0 <= i < sizes[ai]:
            where[k] = ai

    # 1. progress()'s own definitions: learned (learned_moment, #17), perfect, last learned
    latest = {k: history[k][-1] for k in where if history[k]}
    mistakes = {k for k, r in latest.items() if r.outcome == "mistake"}
    learned_at: dict[tuple[int, int], str] = {}
    perfect: list[tuple[int, int]] = []
    pages_of = word_pages()
    rows: set[int] = set()                                 # the pages the Progress table lists (a fully recited ayah)
    for sa in sorted({order[where[k]] for k in latest}):
        keys = [w.key for w in q.ayat[sa].words]
        if any(k not in latest for k in keys):
            continue
        rows.update(pages_of.get(k) or page_of(*sa) for k in keys)
        moment = learned_moment(keys, history)
        if moment is None:
            continue
        learned_at[sa] = moment
        if not any(k in mistakes or latest[k].hinted for k in keys):     # #96 (D2): a hinted latest reading too
            perfect.append(sa)
    # #96: the words whose latest reading is a mistake (the Progress table's Err, summed) and the ayat holding them;
    # v0.21 review: only on the pages the table lists, so a mistake in an ayah cut off on a page with no row is in
    # neither (the two numbers agree, #96's complaint)
    shown = {k for k in mistakes if (pages_of.get(k) or page_of(*order[where[k]])) in rows}
    to_fix = {"ayat": len({where[k] for k in shown}), "words": len(shown)}
    last = max(perfect, key=lambda sa: (learned_at[sa], sa)) if perfect else None
    news = new_learned(learned_at, today)

    # 2. one pass over the readings dated up to today (each word's readings are in time order, as Profile.history()
    # gives them): each word's outcome at the end of each day it was read, the recitations, today's corrections, the
    # AI's verdicts against the user's labels (#69)
    by_day: dict[str, list[tuple[int, str, str]]] = {}     # date -> (ayah position, word, its state at the day's end:
                                                           # "mistake", "hint" (#96: right, hinted) or "ok")
    recited: dict[str, set[str]] = {}                      # date -> words said in a recitation (#80: every day, for
                                                           # "Since the beginning"; each reader bounds its window)
    judged: dict[str, list[int]] = {}                      # #69: date -> [tp, fp, tn, fn] of the readings of that day
    corrected = 0
    first = "~"                                            # after every date: none seen yet

    def judge(rec: list) -> None:
        """#69: one session reading [date, the AI's verdict, the user's label] counted, when the AI gave one."""
        if rec[1] in ("ok", "mistake"):
            c = judged.setdefault(rec[0], [0, 0, 0, 0])
            c[(0 if rec[1] == "mistake" else 2) + (rec[2] != rec[1])] += 1    # the label agrees: tp / tn, else fp / fn

    for k, ai in where.items():
        before = now = state = day = None
        said: dict[str, list] = {}                         # session -> [date said, verdict, hinted]
        recs: dict[str, list] = {}                         # #69: session -> its reading of the word, as labelled so far
        newest = None                                      # the session of the word's newest session reading
        for r in history[k]:
            d = r.t[:10]
            if d > t_day:
                continue
            ok = dates.get(d)
            if ok is None:
                ok = dates[d] = _is_date(d)
            if not ok:
                continue
            if d != day:
                if day is not None:
                    by_day.setdefault(day, []).append((ai, k, state))
                day = d
                if d < first:
                    first = d
            now = r.outcome
            state = "hint" if now == "ok" and r.hinted else now
            if d < t_day:
                before = now
            if r.session is not None:
                one = said.get(r.session)
                if one is None:
                    said[r.session] = [d, now, r.hinted]
                else:
                    one[1] = now
                    one[2] = one[2] or r.hinted
            # #69: a session's own reading opens its count (one per session x word); a mark labels the reading of the
            # session it was placed in (Reading.session: the saved session on screen it names, #67 / #69 review, or
            # issue #17's), else the newest one before it; the newest label wins (a Remove already made it correct)
            if r.ai is not None:
                one = recs.get(r.session)
                if one is None:
                    recs[r.session] = [d, r.ai, now]
                else:
                    one[2] = now
                newest = r.session
            elif recs:
                recs[r.session if r.session in recs else newest][2] = now
        for one in recs.values():
            judge(one)
        if day is not None:
            by_day.setdefault(day, []).append((ai, k, state))
        right_today = False
        for d, verdict, hinted in said.values():
            recited.setdefault(d, set()).add(k)
            right_today = right_today or (d == t_day and verdict == "ok" and not hinted)
        corrected += before == "mistake" and now == "ok" and right_today

    # 3. the series: one forward pass over the days
    learned_s: list[int] = []
    perfect_s: list[int] = []
    next_s: list[int] = []
    first = None if first == "~" else first
    if first is not None:
        start = dt.date.fromisoformat(first)
        learned_on: dict[str, list[int]] = {}
        for sa, t in learned_at.items():
            if t[:10] <= t_day and _is_date(t[:10]):
                learned_on.setdefault(t[:10], []).append(index[sa])
        unread = list(sizes)                     # per ayah: its words never read yet
        bad = [0] * n_ayat                       # per ayah: its words whose latest reading is a mistake
        spoilt = [0] * n_ayat                    # #96 (D2): ... a mistake or a hint (Perfect; Next to learn: bad)
        is_learned = bytearray(n_ayat)
        outcome_of: dict[str, str] = {}
        n_learned = n_learned_bad = ptr = 0
        for i in range((today - start).days + 1):
            d = (start + dt.timedelta(days=i)).isoformat()
            for ai, k, outcome in by_day.get(d, ()):
                old = outcome_of.get(k)
                if old is None:
                    unread[ai] -= 1
                outcome_of[k] = outcome
                if old == outcome:
                    continue
                bad[ai] += (outcome == "mistake") - (old == "mistake")
                off, was_off = outcome != "ok", old is not None and old != "ok"
                if off and not was_off:
                    spoilt[ai] += 1
                    n_learned_bad += spoilt[ai] == 1 and is_learned[ai]
                elif was_off and not off:
                    spoilt[ai] -= 1
                    n_learned_bad -= spoilt[ai] == 0 and is_learned[ai]
            for ai in learned_on.get(d, ()):
                is_learned[ai] = 1
                n_learned += 1
                n_learned_bad += spoilt[ai] > 0
            while ptr < n_ayat and unread[ptr] == 0:     # the words read only grow: the first unread ayah moves on
                ptr += 1
            nxt = ptr
            if ptr < n_ayat:                             # progress.next_to_learn: back over the mistakes before it
                while nxt > 0 and bad[nxt - 1]:
                    nxt -= 1
            learned_s.append(n_learned)
            perfect_s.append(n_learned - n_learned_bad)
            next_s.append(nxt)

    # 4. the window: averages, slopes; the pace over each window of PACE_WINDOWS
    span = (today - dt.date.fromisoformat(first)).days + 1 if first else 0
    window = min(WINDOW_DAYS, max(MIN_WINDOW_DAYS, span))

    def gained(x: list[int], w: int) -> int:
        """x today minus x w days ago (0 before the start)."""
        return x[-1] - (x[-1 - w] if len(x) > w else 0) if x else 0

    rate = gained(learned_s, window) * WEEK / window
    lo = (today - dt.timedelta(days=window - 1)).isoformat()
    pages_per_day = sum(_pages(ks) for d, ks in recited.items() if d >= lo) / window
    remaining = max(0, TOTAL_AYAT - len(learned_at))
    windows: dict[str, dict] = {}                          # issue #30: the pace over each of the page's choices
    for name, cap in PACE_WINDOWS.items():
        days = max(MIN_WINDOW_DAYS, span) if cap is None else min(cap, max(MIN_WINDOW_DAYS, span))
        n = gained(learned_s, days)
        finish = None
        if remaining and n > 0:
            try:
                finish = (today + dt.timedelta(days=-(-remaining * days // n))).isoformat()
            except OverflowError:                          # past year 9999 (since the beginning, little learned)
                finish = None
        windows[name] = {"days": days, "ayat": n, "ayat_per_week": round(n * WEEK / days, 1), "finish": finish,
                         # #60 (D13): the legend's slopes over this window's days, as `slope` over avg's window
                         "slope": {k: round(gained(x, days) * WEEK / days, 1)
                                   for k, x in (("learned", learned_s), ("perfect", perfect_s), ("next", next_s))},
                         # #80 (D7): the "Pages recited a day" line follows the choice too
                         "pages_per_day": round(sum(_pages(ks) for d, ks in recited.items()
                                                    if d >= (today - dt.timedelta(days=days - 1)).isoformat()) / days, 1)}

    # #69: the AI's detection over the same windows' days
    detection: dict[str, dict] = {}
    for name, w in windows.items():
        since = (today - dt.timedelta(days=w["days"] - 1)).isoformat()
        tp, fp, tn, fn = (sum(c[j] for d, c in judged.items() if d >= since) for j in range(len(DETECTION)))
        detection[name] = {"tp": tp, "fp": fp, "tn": tn, "fn": fn,
                           "precision": round(tp / (tp + fp), 3) if tp + fp else None,
                           "recall": round(tp / (tp + fn), 3) if tp + fn else None,
                           "readings": tp + fp + tn + fn}

    keep = _weekly(len(learned_s))
    return {"total_ayat": TOTAL_AYAT,
            "today": {"learned": news["today"], "corrected": corrected,
                      "pages": round(_pages(recited.get(t_day, ())), 1)},
            "learned": {"n": len(learned_at), "pct": _pct(len(learned_at))},
            "perfect": {"n": len(perfect), "pct": _pct(len(perfect))},
            "to_fix": to_fix,
            "last_learned": {"surah": last[0], "ayah": last[1], "page": page_of(*last)} if last else None,
            "new_learned": news,
            "avg": {"window_days": window, "ayat_per_week": round(rate, 1), "pages_per_day": round(pages_per_day, 1)},
            "series": {"start": first, "days": keep, "learned": [learned_s[i] for i in keep],
                       "perfect": [perfect_s[i] for i in keep], "next": [next_s[i] for i in keep]},
            "slope": {name: round(gained(x, window) * WEEK / window, 1)
                      for name, x in (("learned", learned_s), ("perfect", perfect_s), ("next", next_s))},
            "pace": {"remaining": remaining, "windows": windows},
            "detection": detection}
