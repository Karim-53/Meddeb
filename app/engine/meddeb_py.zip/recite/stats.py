"""The Stats page (issue #13, D6 of the v0.12 round): what was done today, the overall numbers, the curves over time and
the pace, all from the reading history the Progress page already uses (recite/progress.py). Pure: stdlib only, no
I/O beyond the packaged mushaf layout progress.word_pages() reads once; nothing new is stored. Runs only when the
Stats page asks (never inside progress(), which Android runs after every mark).

API
    stats(history, q, today) -> dict          history = Profile.history() (each word's readings in time order),
                                              q = load_quran(), today = the local date (a datetime: its date)
    ayah_index(sa, q) -> int                  (surah, ayah) -> 0-based mushaf position; None (every ayah recited) ->
                                              6236 (progress.ayah_index). series.next is in these units: the number
                                              of ayat before it.

    {"total_ayat": 6236,
     "today":   {"learned": int, "corrected": int, "pages": float},
     "learned": {"n", "pct"}, "perfect": {"n", "pct"}, "last_learned": {"surah", "ayah", "page"} | None,
     "new_learned": {"today", "week", "year", "year_number"},          # these four: exactly progress()'s values
     "avg":    {"window_days": int, "ayat_per_week": float, "pages_per_day": float},
     "series": {"start": "yyyy-mm-dd" | None, "days": [int], "learned": [int], "perfect": [int], "next": [int]},
     "slope":  {"learned": float, "perfect": float, "next": float},    # per week, over the window
     "pace":   {"remaining": int,
                "windows": {"all" | "month" | "week": {"days": int, "ayat": int, "ayat_per_week": float,
                                                       "finish": "yyyy-mm-dd" | None}}}}

Definitions (a reading's date is its stored local time's t[:10]; readings dated after today count nowhere here, while
progress() still counts them: a clock set back):
- Learned, perfect, last learned, new ayat learned: progress.py's own rules (learned_moment, #17), same numbers.
- A recitation of a word: the readings of one session (Reading.session) of it; it was said on the date of that
  session's first reading of the word, and its verdict is that session's last reading of it (the marks made on it
  after ■ amend it), as in progress.learned_moment. A mark outside every session is no recitation.
- today.learned = new_learned.today. today.corrected = the words whose last reading dated before today is a mistake,
  whose latest reading is right, and that a recitation said today read right without a hint (a + Correct or a Remove
  made today on an older recitation's false alarm is no correction: nothing was recited; a mistake made and fixed
  today does not count either). today.pages = page-equivalents recited today: per 15-line page, its distinct words
  said in a recitation today / its words, summed, 1 decimal.
- window_days = min(28, max(7, days from the first reading to today, both counted)).
  avg.ayat_per_week = the ayat whose learned date falls in the window x 7 / window_days (= slope.learned).
  avg.pages_per_day = the window's daily page-equivalents summed / window_days (a day without a recitation counts 0).
- series: from the first reading's date to today, the value at the end of each day: learned = the ayat learned by
  then (today's view of the past: a Remove rewrites the earlier days too); perfect = those of them with no word whose
  latest reading by then is a mistake; next = ayah_index of Next to learn by then (progress.next_to_learn on the
  readings dated up to that day). One point a day; when that is more than 180 days, one point a week counted back
  from today plus the first day. series.days[i] = the point's day offset from start (start + days[-1] = today).
- slope[x] = (x today - x window_days days ago, 0 before the start) x 7 / window_days, on the daily values, 1 decimal.
- pace.remaining = 6236 - learned.n. pace.windows (issue #30: the page's "Pace over" choice; one call gives all three):
  days = min(cap, max(7, days from the first reading to today, both counted)), cap = 28 (month), 7 (week) or none
  (all); ayat = the ayat whose learned date falls in those days; ayat_per_week = ayat x 7 / days, 1 decimal; finish =
  today + ceil(remaining x days / ayat) days, None when nothing remains, ayat = 0 or past year 9999. 'month' is avg's
  window: its numbers are avg's (0.12's pace).

Cost: one pass over the readings plus one over the days (Next to learn only moves forward while words get read, and
moves back only over the ayat with a mistake right before it), never next_to_learn() once per day.
"""
from __future__ import annotations

import datetime as dt
from functools import lru_cache

from .profile import Reading
from .progress import TOTAL_AYAT, _pct, ayah_index, ayah_table, learned_moment, new_learned, word_pages
from .quran_text import Quran, page_of

__all__ = ["stats", "ayah_index"]

WINDOW_DAYS = 28            # the averages, the slopes and the pace's default: the last 4 weeks ...
MIN_WINDOW_DAYS = 7         # ... or the days since the first reading, at least a week
DAILY_POINTS = 180          # longer series keep one point a week
WEEK = 7
PACE_WINDOWS = {"all": None, "month": WINDOW_DAYS, "week": WEEK}   # issue #30: the pace's choice of days ('month':
                                                                    # the page's default), None = since the first reading


@lru_cache(maxsize=1)
def _page_sizes() -> dict[int, int]:
    """Page -> its number of words (15-line layout)."""
    n: dict[int, int] = {}
    for p in word_pages().values():
        n[p] = n.get(p, 0) + 1
    return n


def _pages(keys) -> float:
    """Page-equivalents of a set of words: per page, its words in the set / its words."""
    pages_of, sizes = word_pages(), _page_sizes()
    n: dict[int, int] = {}
    for k in keys:
        p = pages_of.get(k)
        if p is not None:
            n[p] = n.get(p, 0) + 1
    return sum((c / sizes[p] for p, c in n.items()), 0.0)


def _is_date(d: str) -> bool:
    """A yyyy-mm-dd date (a reading with a hand-edited time counts nowhere rather than breaking the page)."""
    try:
        return dt.date.fromisoformat(d).isoformat() == d
    except ValueError:
        return False


def _weekly(n_days: int) -> list[int]:
    """The day offsets kept: every day up to DAILY_POINTS days, then one a week back from today plus the first day."""
    if n_days <= DAILY_POINTS:
        return list(range(n_days))
    days = list(range(n_days - 1, -1, -WEEK))[::-1]
    return days if days[0] == 0 else [0] + days


def stats(history: dict[str, list[Reading]], q: Quran, today: dt.date) -> dict:
    if isinstance(today, dt.datetime):
        today = today.date()
    order, index, sizes = ayah_table(q)
    n_ayat = len(order)
    t_day = today.isoformat()
    oldest = (today - dt.timedelta(days=WINDOW_DAYS - 1)).isoformat()

    dates: dict[str, bool] = {}                            # date string -> _is_date, once per distinct date

    # the history's real words: key -> its ayah's mushaf position (a key outside the Qur'an counts nowhere)
    where: dict[str, int] = {}
    for k in history:
        try:
            s, a, i = map(int, k.split(":"))
        except ValueError:
            continue
        ai = index.get((s, a))
        if ai is not None and 0 <= i < sizes[ai]:
            where[k] = ai

    # 1. progress()'s own definitions: learned (learned_moment, #17), perfect, last learned
    latest = {k: history[k][-1] for k in where if history[k]}
    mistakes = {k for k, r in latest.items() if r.outcome == "mistake"}
    learned_at: dict[tuple[int, int], str] = {}
    perfect: list[tuple[int, int]] = []
    for sa in sorted({order[where[k]] for k in latest}):
        keys = [w.key for w in q.ayat[sa].words]
        if any(k not in latest for k in keys):
            continue
        moment = learned_moment(keys, history)
        if moment is None:
            continue
        learned_at[sa] = moment
        if not any(k in mistakes for k in keys):
            perfect.append(sa)
    last = max(perfect, key=lambda sa: (learned_at[sa], sa)) if perfect else None
    news = new_learned(learned_at, today)

    # 2. one pass over the readings dated up to today (each word's readings are in time order, as Profile.history()
    # gives them): each word's outcome at the end of each day it was read, the recitations, today's corrections
    by_day: dict[str, list[tuple[int, str, str]]] = {}     # date -> (ayah position, word, its outcome at the day's end)
    recited: dict[str, set[str]] = {}                      # date (in the longest window) -> words said in a recitation
    corrected = 0
    first = "~"                                            # after every date: none seen yet
    for k, ai in where.items():
        before = now = day = None
        said: dict[str, list] = {}                         # session -> [date said, verdict, hinted]
        for r in history[k]:
            d = r.t[:10]
            if d > t_day:
                continue
            ok = dates.get(d)
            if ok is None:
                ok = dates[d] = _is_date(d)
            if not ok:
                continue
            if d != day:
                if day is not None:
                    by_day.setdefault(day, []).append((ai, k, now))
                day = d
                if d < first:
                    first = d
            now = r.outcome
            if d < t_day:
                before = now
            if r.session is not None:
                rec = said.get(r.session)
                if rec is None:
                    said[r.session] = [d, now, r.hinted]
                else:
                    rec[1] = now
                    rec[2] = rec[2] or r.hinted
        if day is not None:
            by_day.setdefault(day, []).append((ai, k, now))
        right_today = False
        for d, verdict, hinted in said.values():
            if d >= oldest:
                recited.setdefault(d, set()).add(k)
            right_today = right_today or (d == t_day and verdict == "ok" and not hinted)
        corrected += before == "mistake" and now == "ok" and right_today

    # 3. the series: one forward pass over the days
    learned_s: list[int] = []
    perfect_s: list[int] = []
    next_s: list[int] = []
    first = None if first == "~" else first
    if first is not None:
        start = dt.date.fromisoformat(first)
        learned_on: dict[str, list[int]] = {}
        for sa, t in learned_at.items():
            if t[:10] <= t_day and _is_date(t[:10]):
                learned_on.setdefault(t[:10], []).append(index[sa])
        unread = list(sizes)                     # per ayah: its words never read yet
        bad = [0] * n_ayat                       # per ayah: its words whose latest reading is a mistake
        is_learned = bytearray(n_ayat)
        outcome_of: dict[str, str] = {}
        n_learned = n_learned_bad = ptr = 0
        for i in range((today - start).days + 1):
            d = (start + dt.timedelta(days=i)).isoformat()
            for ai, k, outcome in by_day.get(d, ()):
                old = outcome_of.get(k)
                if old is None:
                    unread[ai] -= 1
                outcome_of[k] = outcome
                if old == outcome:
                    continue
                if outcome == "mistake":
                    bad[ai] += 1
                    n_learned_bad += bad[ai] == 1 and is_learned[ai]
                elif old == "mistake":
                    bad[ai] -= 1
                    n_learned_bad -= bad[ai] == 0 and is_learned[ai]
            for ai in learned_on.get(d, ()):
                is_learned[ai] = 1
                n_learned += 1
                n_learned_bad += bad[ai] > 0
            while ptr < n_ayat and unread[ptr] == 0:     # the words read only grow: the first unread ayah moves on
                ptr += 1
            nxt = ptr
            if ptr < n_ayat:                             # progress.next_to_learn: back over the mistakes before it
                while nxt > 0 and bad[nxt - 1]:
                    nxt -= 1
            learned_s.append(n_learned)
            perfect_s.append(n_learned - n_learned_bad)
            next_s.append(nxt)

    # 4. the window: averages, slopes; the pace over each window of PACE_WINDOWS
    span = (today - dt.date.fromisoformat(first)).days + 1 if first else 0
    window = min(WINDOW_DAYS, max(MIN_WINDOW_DAYS, span))

    def gained(x: list[int], w: int) -> int:
        """x today minus x w days ago (0 before the start)."""
        return x[-1] - (x[-1 - w] if len(x) > w else 0) if x else 0

    rate = gained(learned_s, window) * WEEK / window
    lo = (today - dt.timedelta(days=window - 1)).isoformat()
    pages_per_day = sum(_pages(ks) for d, ks in recited.items() if d >= lo) / window
    remaining = max(0, TOTAL_AYAT - len(learned_at))
    windows: dict[str, dict] = {}                          # issue #30: the pace over each of the page's choices
    for name, cap in PACE_WINDOWS.items():
        days = max(MIN_WINDOW_DAYS, span) if cap is None else min(cap, max(MIN_WINDOW_DAYS, span))
        n = gained(learned_s, days)
        finish = None
        if remaining and n > 0:
            try:
                finish = (today + dt.timedelta(days=-(-remaining * days // n))).isoformat()
            except OverflowError:                          # past year 9999 (since the beginning, little learned)
                finish = None
        windows[name] = {"days": days, "ayat": n, "ayat_per_week": round(n * WEEK / days, 1), "finish": finish}

    keep = _weekly(len(learned_s))
    return {"total_ayat": TOTAL_AYAT,
            "today": {"learned": news["today"], "corrected": corrected,
                      "pages": round(_pages(recited.get(t_day, ())), 1)},
            "learned": {"n": len(learned_at), "pct": _pct(len(learned_at))},
            "perfect": {"n": len(perfect), "pct": _pct(len(perfect))},
            "last_learned": {"surah": last[0], "ayah": last[1], "page": page_of(*last)} if last else None,
            "new_learned": news,
            "avg": {"window_days": window, "ayat_per_week": round(rate, 1), "pages_per_day": round(pages_per_day, 1)},
            "series": {"start": first, "days": keep, "learned": [learned_s[i] for i in keep],
                       "perfect": [perfect_s[i] for i in keep], "next": [next_s[i] for i in keep]},
            "slope": {name: round(gained(x, window) * WEEK / window, 1)
                      for name, x in (("learned", learned_s), ("perfect", perfect_s), ("next", next_s))},
            "pace": {"remaining": remaining, "windows": windows}}
