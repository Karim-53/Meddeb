"""The user's profile folder (D4.4) and the per-word reading history built from it (U1.2b, X2.12).

    profile1/
      profile.json   {"name", "format": 1, "created"}
      settings.json  UI settings (model, threshold, text mode, toggles, last page)
      marks.jsonl    manual marks, append-only: {"t", "surah", "ayah", "idx", "event": "mistake" | "correct" | "remove" |
                     "undo" | "unmark"} (+ "session": the started_at an unmark gives its verdict back to, #67; the
                     saved session on screen a mark labels, when it read the word, #67 / #69 review; + "ins": true on
                     a mistake: an insertion before the word, #72 v0.19, X2.12b)
      review.jsonl   the Review page's events, append-only (D4.8, issue #39): {"t", "event": "shown" | "suspend" |
                     "unsuspend" | "bury" | "skip", "card", "words": [keys], "new"?: true} (recite/review.py)
      sessions/<yyyy-mm-dd hh-mm-ss sourah N eyah M>/   audio.wav, session.json, decodes.jsonl, summary.md (X2.9)
      unsaved/<session id>/   a running session's checkpoint: audio.pcm, decodes.jsonl, checkpoint(.prev).json, lock (X2.9,
                     #45: temporary, gone once that session's folder is saved, by ■ or by App.recover_unsaved)
      logs/          the device's logs (never exported)

A word's history is every reading of it in time order: each saved session's verdict (a mistake when the status is a
mistake and its score reached that session's threshold, or the user set it) and each manual mark; a "remove" event
acts on the newest reading that existed at that moment (one naming the saved session on screen: that session's newest
reading of the word, page review 2026-10-29): a mistake becomes a correct reading (the word was read, and read
correctly), a correct reading is dropped. An "undo" event (issue #24: a double tap again on the word) cancels that
word's newest mark still in effect, whatever its event (effective_marks); an undo with nothing to cancel is ignored.
A session's reading also keeps the tracker's own verdict on the word, before the user's (Reading.ai, ai_verdict, issue
#69: the Stats page's precision and recall), also once a Remove made it correct. An "unmark" event (issue #67: a double
tap again on Meddeb's verdict that the user had labelled) gives the session it names its own verdict back on that word:
the user's labels on that session's reading go (his verdict during the session, a Remove, a mark made after ■ amending
it, issue #17), so the reading is Meddeb's again with its nature (wrong, skipped, lost, a hint) and what was heard;
a reading of that session a Remove dropped comes back too (page review 2026-10-29).
A + Mistake / + Correct / Remove made while a saved session was on screen names it (#67 / #69 review): the mark is
that session's reading of the word when it read it (issue #17's rule otherwise). Nothing is ever deleted from the folder (sessions, marks) except by the user's own delete in Settings > Space used
(U1.17, issue #14: Profile.delete, recite/storage.py); unsaved/ is a temporary folder (#45). history_with (#45): the
history with sessions not saved yet (a running one as ■ would save it now), without touching the cache. counted (#73,
v0.19): the history Progress, Stats and Review count, without the correct readings of the practice sessions (Hidden,
session.json "practice"); the popover keeps the whole history.

Profile keeps the history in memory (issue #23): each session.json's readings by its file stamp (parsed again only when
it changes) and every word's events, so that a mark replays its own word alone instead of a rebuild from every file.
"""
from __future__ import annotations

import datetime as dt
import io
import json
import threading
import zipfile
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Callable, NamedTuple

from .normalize import normalize
from .storage import EXPORT_KINDS, delete_profile_data, export_files, profile_storage

MISTAKE_STATUSES = frozenset({"wrong", "missing", "hinted"})
# issue #69: the statuses that were the AI's mistake on screen when the user overruled them (red, or taupe: being
# confirmed, which a double tap also takes for a mistake, #24)
AI_FLAGGED = frozenset({"wrong", "missing", "provisional_wrong", "provisional_missing"})
EVENTS = ("mistake", "correct", "remove", "undo", "unmark")   # undo: issue #24 (the double tap's undo); unmark: #67
REVIEW_EVENTS = ("shown", "suspend", "unsuspend", "bury", "skip")   # review.jsonl (D4.8, issue #39, v0.16)
HISTORY_DEPTH = 10          # readings kept for the colour rule (last 5) and the popover list (last 10), U1.2b


@dataclass(frozen=True)
class Reading:
    t: str                       # ISO time, seconds precision
    outcome: str                 # "ok" | "mistake"
    source: str                  # "session" | "mark"
    heard: str | None = None
    accepts: str | None = None   # X2.17: a correct reading of the user's: the heard form it accepts (never shown);
    # review of 0.19 (C4): over an insertion (ai_ins) the extra words, kept for an unmark, never accepted (accepted_forms)
    relabelled: bool = False     # issue #5: a saved mistake read as correct (it was a mistake on screen back then)
    # issue #17: where it was read (the session's started_at; None for a mark made outside a session) and whether the
    # word was revealed by a hint in that session. Provenance only: not part of a reading's equality
    session: str | None = field(default=None, compare=False)
    hinted: bool = field(default=False, compare=False)
    # issue #69 (the Stats page's precision / recall): on a session's own reading, the tracker's verdict before the
    # user's (ai_verdict): "ok" | "mistake", or why it gave none: "hint", "silent", "none". None: a manual mark
    ai: str | None = field(default=None, compare=False)
    # #67 review: the user's label during the session took the word's hint back (mark{unhint}, S10*): an unmark gives
    # the hint back with Meddeb's verdict (_meddebs), as the live unmark does
    unhinted: bool = field(default=False, compare=False)
    # #72 (v0.19, X2.12b): the mistake is an insertion before the word (a session row's "ins", a mark's "ins"); ai_ins:
    # Meddeb's own verdict on the reading (ai) was one (the row's, or under a label of the user's the corrections log's
    # from_ins, whatever its score: drawn as a ⚡ only when ai is "mistake"): an unmark gives it back. Not part of a
    # reading's equality: a v0.18 history is the same
    ins: bool = field(default=False, compare=False)
    ai_ins: bool = field(default=False, compare=False)
    # #73 (v0.21, D5): the session's verdict on the word came in Hidden (the row's "practice"; every reading of a
    # 0.19/0.20 practice session, whose rows carry no flag): counted_history drops that session's pass on the word.
    # Not part of a reading's equality
    practice: bool = field(default=False, compare=False)
    # #103 (v0.22, plan D6): the first word of a join card's challenge, its session showing the ayah before it only
    # (session.json review.join names that ayah): review.word_verdicts' link rule keeps this session's pass on it. Not
    # part of a reading's equality
    joined: bool = field(default=False, compare=False)


def word_key(surah: int, ayah: int, idx: int) -> str:
    return f"{surah}:{ayah}:{idx}"


def heard_is_the_word(w: dict) -> bool:
    """Issue #5 (2026-10-10): a saved "missing" (skipped) or "lost" row whose heard form IS its word (either spelling,
    N0, spaces removed): the model heard the expected word, so the verdict was an engine defect, not a mistake. Up to
    v0.5, ◂ pressed after a word heard but not committed yet made it "skipped" keeping what was heard (up to v0.7 when
    an attempt before it was not confirmed yet), and the lost rule marked the word the decode started with while the
    committed pointer lagged. Only these two shapes: a plain "wrong" never pairs the word itself (align), and a future
    verdict may differ below N0 (tashkeel, B3.11)."""
    h = normalize(w.get("heard") or "").replace(" ", "")
    return bool(h) and (w.get("status") == "missing" or bool(w.get("lost"))) and \
        any(h == normalize(w.get(f) or "").replace(" ", "") for f in ("word", "uthmani"))


def session_readings(doc: dict) -> list[tuple[str, Reading]]:
    """One saved session's verdicts as readings, timed at the session start + the word's time in the recording. A
    verdict the user set during the session is the user's reading (X2.12a, 2026-10-01): source "mark", no heard text
    (what the model heard is not the reason of a manual labeled mistake). An engine verdict whose heard form is the word
    itself reads as a correct reading (issue #5, heard_is_the_word): relabelled when read (relabelled: a Remove made on
    it then still finds the mistake it removed), the file never changes."""
    try:
        start = dt.datetime.fromisoformat(doc["started_at"])
    except (KeyError, ValueError):
        return []
    thr = float(doc.get("threshold", 0.5))
    revealed = set(doc.get("revealed_before_start") or [])   # issue #17: a word revealed before Start is a hint too
    before, silent, unhinted, ins_before = _overruled(doc)
    # #73 (v0.21, D5): practice per word (the rows' "practice", "practice_rows"); a 0.19/0.20 practice doc: every row
    whole = doc.get("practice") is True and not doc.get("practice_rows")
    # #103 (v0.22, D6): a join challenge's session shows ayah i (review.join = [surah, i]) and starts at i + 1
    join = doc["review"].get("join") if isinstance(doc.get("review"), dict) else None
    joined = f"{join[0]}:{join[1] + 1}:0" if isinstance(join, list) and len(join) == 2 and \
        all(isinstance(x, int) for x in join) else None
    out = []
    for w in doc.get("words", []):
        status = w.get("status", "pending")
        if status == "pending":
            continue
        user = bool(w.get("user"))
        mistake = status in MISTAKE_STATUSES and (float(w.get("score") or 0) >= thr or user)
        relabelled = mistake and not user and heard_is_the_word(w)   # issue #5: the model heard the word itself
        bad = mistake and not relabelled
        t = (start + dt.timedelta(seconds=float(w.get("t0") or 0))).isoformat(timespec="seconds")
        key = word_key(w["surah"], w["ayah"], w["idx"])
        hinted = bool(w.get("hinted")) or key in revealed
        ai = ai_verdict(w, thr, hinted, before, silent)
        ins = bad and bool(w.get("ins"))                 # #72: an insertion before the word (X2.12b)
        out.append((key,
                    Reading(t, "mistake" if bad else "ok", "mark" if user else "session",
                            None if user else w.get("heard"),
                            w.get("heard") if user and not bad else None,   # X2.17: the user overruled what was heard
                            relabelled, session=doc["started_at"], hinted=hinted,
                            ai=ai, unhinted=user and w.get("i") in unhinted, ins=ins,
                            # review of 0.19 (C4): under a label, the log's from_ins alone (the saved threshold is the
                            # last one, not the mark's): its readers that need Meddeb's ⚡ check ai == "mistake"
                            ai_ins=(w.get("i") in ins_before) if user else (ai == "mistake" and ins),
                            practice=whole or w.get("practice") is True, joined=key == joined)))
    return out


def _overruled(doc: dict) -> tuple[dict, set, set, set]:
    """Issue #69: what a session's `corrections` log says of the rows the user set ({i, from, to, at[, from_score,
    unhint, silent, from_ins, ins]}: one entry per mark or unmark of his during the session, to "auto" for an unmark,
    and one per word read in silence, #49): per row index "i", the verdict the tracker had given the word before his
    marks still in effect, (status, score) (the "from" and "from_score" of his first mark after his last unmark: an
    unmark puts the tracker's verdict back, Tracker.unmark; the score None in a log older than v0.18), the rows read in
    silence, (#67 review) the rows whose hint a mark of his still in effect took back (unhint: an unmark gives it back)
    and (#72, v0.19) the rows whose verdict before his marks was an insertion (that first mark's from_ins)."""
    before: dict = {}
    silent: set = set()
    unhinted: set = set()
    ins: set = set()
    for c in doc.get("corrections") or ():
        if not isinstance(c, dict) or c.get("i") is None:
            continue
        if c.get("silent"):
            silent.add(c["i"])
        elif c.get("to") == "auto":
            before.pop(c["i"], None)
            unhinted.discard(c["i"])
            ins.discard(c["i"])
        else:
            if c["i"] not in before and c.get("from_ins"):
                ins.add(c["i"])
            before.setdefault(c["i"], (c.get("from"), c.get("from_score")))
            if c.get("unhint"):
                unhinted.add(c["i"])
    return before, silent, unhinted, ins


def ai_verdict(w: dict, thr: float, hinted: bool, before: dict, silent: set) -> str:
    """Issue #69 (user, 2026-10-29: "a positive is a mistake … in silent recitation mode you will not count none of the
    above"): the tracker's own verdict on a saved row w (thr: its session's threshold; hinted: the user asked for the
    word, Reading.hinted; before, silent: _overruled), before the user's:
    - "silent": a word read in the mind with the microphone off (#49: hint{silent} / skip_to{silent} make it the user's
      correct reading), also once unmarked;
    - "mistake": a wrong / skipped / lost word at or above the threshold (a relabelled one too, issue #5: it was the
      AI's false alarm); on a row the user overruled, the verdict before his marks: a status of AI_FLAGGED (red, or
      taupe: being confirmed) whose score (from_score, v0.18) reached the threshold, as on screen (#67 / #69 review: a
      wrong word under the threshold was drawn correct; a log older than v0.18 has no score: flagged, as the status
      was); a word the AI flagged stays its verdict when the user then asked for it (◂ reveals the red bar or the lost
      word, X2.4b);
    - "hint": a word the user asked for (◂, the voice next, ⏮, or ◂ before Start, #17) that the AI had not flagged;
    - "ok": any other verdict of the tracker's (a wrong word under the threshold, a saved provisional one: ok, as the
      history reads them);
    - "none": the user's verdict on a word the tracker had not judged (not reached yet, or a session saved without
      the log)."""
    i = w.get("i")
    if i is not None and i in silent:
        return "silent"
    if w.get("user"):
        status, score = before.get(i, (None, None)) if i is not None else (None, None)
        flagged = status in AI_FLAGGED and (score is None or float(score) >= thr)
    else:
        status = w.get("status")
        flagged = status in ("wrong", "missing") and float(w.get("score") or 0) >= thr
    if flagged:
        return "mistake"
    if hinted or status == "hinted":
        return "hint"
    return "none" if status in (None, "pending") else "ok"


def _when_iso(t) -> dt.datetime | None:
    try:
        return dt.datetime.fromisoformat(str(t))
    except (TypeError, ValueError):
        return None


def _session_of(t, starts: list[tuple[dt.datetime, str]]) -> str | None:
    """The started_at of the latest session that started at or before t (None: before every session)."""
    when = _when_iso(t)
    if when is None:
        return None
    best = None
    for start, name in starts:
        if start <= when:
            best = name
        else:
            break
    return best


class _Unmark(NamedTuple):
    """Issue #67: an "unmark" event in a word's events: the session (its started_at) whose own verdict comes back."""
    session: str | None


class _Remove(NamedTuple):
    """Page review 2026-10-29 (F1): a "remove" made while a saved session was on screen, naming it (marks.jsonl
    "session", when that session read the word): it acts on that session's newest reading of the word, not on the
    word's newest reading (a newer session's: the history then disagreed with the session view, which applied it to
    its own word). A remove naming no session stays None: X2.12's "Remove last", on the newest reading."""
    session: str


# (time, order, reading; None = a remove; _Remove = a remove naming its session; _Unmark, #67)
_Event = tuple[str, int, "Reading | _Unmark | _Remove | None"]


@dataclass
class _Index:
    """Every word's events in the order build_history replays them, and what places a mark in a session (issue #17).
    Profile keeps one while its history is cached, so that a mark replays its own word alone (issue #23)."""
    events: dict[str, list[_Event]] = field(default_factory=dict)
    read_in: dict[str, set[str]] = field(default_factory=dict)        # word -> the sessions that read it (issue #17)
    starts: list[tuple[dt.datetime, str]] = field(default_factory=list)   # every session's start, sorted
    order: int = 0                                                    # the next event's order (ties on equal times)
    marks: dict[str, list[int]] = field(default_factory=dict)         # word -> the orders of its marks in effect (#24)
    sessions_end: int = 0                                             # orders below it: the sessions' readings (#45)
    named: set[int] = field(default_factory=set)                      # #67 review: marks placed in the session they name


def _session_index(per_session: list[tuple[object, list[tuple[str, Reading]]]]) -> _Index:
    """(started_at, session_readings) of every saved session in folder order -> their events, read_in and starts."""
    ix = _Index()
    for started_at, readings in per_session:
        for key, r in readings:
            ix.events.setdefault(key, []).append((r.t, ix.order, r))
            ix.read_in.setdefault(key, set()).add(r.session)
            ix.order += 1
        if (when := _when_iso(started_at)) is not None:
            ix.starts.append((when, started_at))
    ix.starts.sort()
    ix.sessions_end = ix.order
    return ix


def _history_with(ix: _Index, base: dict[str, list[Reading]],
                  extra: list[tuple[object, list[tuple[str, Reading]]]]) -> dict[str, list[Reading]]:
    """#45 (v0.17): base (_history_of(ix)) with sessions not saved yet, (started_at, session_readings) newer than every
    saved one, as a rebuild with them saved gives it: their readings after the saved sessions' and before the marks
    (equal times), the marks made after their start placed again (issue #17: amending the one that read the word, else
    none). Only the words whose events change are replayed; ix and base are left alone."""
    if not extra:
        return base
    begins = [(w, s) for s, _r in extra if (w := _when_iso(s)) is not None]
    starts = sorted(ix.starts + begins)
    first = min((w for w, _s in begins), default=None)
    shift = sum(len(r) for _s, r in extra)            # a rebuild numbers the marks after these readings
    new: dict[str, list[_Event]] = {}
    read_in: dict[str, set[str]] = {}
    order = ix.sessions_end
    for _s, readings in extra:
        for key, r in readings:
            new.setdefault(key, []).append((r.t, order, r))
            read_in.setdefault(key, set()).add(r.session)
            order += 1
    keys = set(new)
    if first is not None:                             # a mark made after their start may name another session now
        for key in ix.marks:
            if any(o >= ix.sessions_end and (w := _when_iso(t)) is not None and w >= first
                   for t, o, _r in ix.events.get(key, ())):
                keys.add(key)
    hist = dict(base)
    for key in keys:
        seen = ix.read_in.get(key, set()) | read_in.get(key, set())
        events = []
        for t, o, r in ix.events.get(key, ()):
            if o >= ix.sessions_end:                  # a mark (_add_mark_event's rule, with these sessions too)
                named = o in ix.named                 # #67: an unmark, #67 review: a mark naming its session (saved)
                o += shift
                if isinstance(r, Reading) and not named:
                    sess = _session_of(t, starts)
                    sess = sess if sess in seen else None
                    if sess != r.session:            # v0.21 review: practice as that session's reading of it
                        own = [x for _t, o2, x in ix.events.get(key, ()) if o2 < ix.sessions_end]
                        own += [x for _t, _o, x in new.get(key, ())]
                        r = replace(r, session=sess, practice=sess is not None and any(
                            isinstance(x, Reading) and x.session == sess and x.practice for x in own))
            events.append((t, o, r))
        readings = _fold(events + new.get(key, []))
        if readings:
            hist[key] = readings
        else:
            hist.pop(key, None)
    return hist


def effective_marks(marks: list[dict]) -> list[dict]:
    """Issue #24: the marks still in effect, in file order. An "undo" cancels the newest mark of its word that is still
    in effect (a stack per word: two undos cancel the two newest) and is dropped itself; an undo with nothing left to
    cancel on its word is ignored. build_history applies the same rule as it goes (_add_mark_event)."""
    out: list[dict | None] = []
    stacks: dict[tuple, list[int]] = {}
    for m in marks:
        key = (m.get("surah"), m.get("ayah"), m.get("idx"))
        if m.get("event") == "undo":
            stack = stacks.get(key)
            if stack:
                out[stack.pop()] = None
            continue
        stacks.setdefault(key, []).append(len(out))
        out.append(m)
    return [m for m in out if m is not None]


def _add_mark_event(ix: _Index, m: dict) -> str:
    """One mark (a marks.jsonl record) appended to its word's events, after every event already in ix; -> its key.
    An "undo" (issue #24) takes that word's newest mark still in effect out of its events instead (effective_marks).
    An "unmark" (issue #67) names its session ("session"), a mark in effect like the others (an undo cancels it)."""
    key = word_key(m["surah"], m["ayah"], m["idx"])
    if m["event"] == "undo":
        stack = ix.marks.get(key)
        if stack:
            order = stack.pop()
            ix.events[key] = [e for e in ix.events.get(key, []) if e[1] != order]
        return key
    if m["event"] == "unmark":
        ix.events.setdefault(key, []).append((m["t"], ix.order, _Unmark(m.get("session"))))
        ix.marks.setdefault(key, []).append(ix.order)
        ix.order += 1
        return key
    # issue #17: a + Mistake / + Correct made after ■ amends the recitation it was made on: the latest session started
    # before it (the window the session view applies marks in, app.apply_marks), when it read the word. #67 / #69
    # review: a mark made while a saved session was on screen names it ("session", Profile.add_mark): that one, when it
    # read the word (a + Correct on an older session loaded with ◀ labels that session's reading, not a newer one's)
    named = m.get("session")
    if named is not None and named in ix.read_in.get(key, ()):
        sess = named
        ix.named.add(ix.order)
    else:
        named = None
        sess = _session_of(m.get("t"), ix.starts)
        sess = sess if sess in ix.read_in.get(key, ()) else None
    if m["event"] == "remove":
        # page review (F1): a Remove naming the session on screen acts on that session's reading (_Remove), else on the
        # newest reading (None)
        r = _Remove(named) if named is not None else None
    else:
        # v0.21 review (D5, "sessions before 0.21 unchanged"): a mark placed in a session is practice when that session's
        # own reading of the word is (judged in Hidden; every word of a 0.19/0.20 practice session), so it stays out of
        # the counted history even when a Remove dropped that reading (_counted_keys filters per practice reading)
        prac = sess is not None and any(isinstance(e[2], Reading) and e[2].session == sess and e[2].practice
                                        for e in ix.events.get(key, ()) if e[1] < ix.sessions_end)
        r = Reading(m["t"], "mistake" if m["event"] == "mistake" else "ok", "mark",
                    accepts=m.get("heard") if m["event"] == "correct" else None, session=sess,
                    ins=m["event"] == "mistake" and m.get("ins") is True,   # #72: + Inserted before
                    practice=prac)
    ix.events.setdefault(key, []).append((m["t"], ix.order, r))
    ix.marks.setdefault(key, []).append(ix.order)
    ix.order += 1
    return key


def _meddebs(r: Reading, session: str | None) -> Reading | None:
    """Issue #67 (the user: "it should be back to the previous state of AI detected mistake not manually labeled
    mistake"): a reading once that session's labels of the user's go. The user's verdict on the session's own reading
    (his label during the session, a Remove: Reading.ai, #69, is the tracker's verdict under it) is the tracker's again:
    a mistake (a hint too: counted, hinted) or a correct reading, with what was heard (the heard form the user's
    correct reading accepted, X2.17: none for his mistake); a mark of his amending that session (made after ■, issue
    #17: no ai) goes; his own reading of a word the tracker never judged (#49 silent, "none") and anything of another
    session or of none stays. #67 review: a hint his label took back (mark{unhint}, S10*: Reading.unhinted) is a hint
    again, a red bar revealed with ◂ too, as the live unmark gives it back. #72 (v0.19): Meddeb's insertion too
    (Reading.ai_ins)."""
    if r.session is None or r.session != session or r.source != "mark":
        return r
    if r.ai in ("ok", "mistake", "hint"):
        return Reading(r.t, "ok" if r.ai == "ok" else "mistake", "session", r.accepts, session=r.session,
                       hinted=r.hinted or r.ai == "hint" or r.unhinted, ai=r.ai, ins=r.ai == "mistake" and r.ai_ins,
                       ai_ins=r.ai_ins, practice=r.practice,       # #73 (v0.21): still that session's practice word
                       joined=r.joined)          # v0.22 review (#103): still the join challenge's reading (link rule)
    return None if r.ai is None else r


def _fold(events: list[_Event]) -> list[Reading]:
    """One word's events replayed in time order (session readings first on equal times, marks in the order they were
    written), removals and unmarks (#67) applied. Page review 2026-10-29: a remove naming a session (_Remove, F1) acts
    on that session's newest reading of the word (none left: nothing); a session's reading a remove dropped (a correct
    one) comes back with that session's unmark, as its verdict (_meddebs), in time order (F3: the unmark of a label
    the popover's Remove had dropped gave nothing back, while the session view drew Meddeb's verdict again)."""
    cur: list[Reading] = []
    dropped: list[Reading] = []                       # F3: the session readings removes dropped, until their unmark
    for _t, _order, r in sorted(events, key=lambda e: (e[0], e[1])):
        if isinstance(r, _Unmark):
            cur = [x for x in (_meddebs(x, r.session) for x in cur) if x is not None]
            back = sorted((x for x in dropped if x.session == r.session), key=lambda x: x.t)
            dropped = [x for x in dropped if x.session != r.session]
            for x in back:
                y = _meddebs(x, r.session)           # a mark amending that session (no ai) stays gone
                if y is not None:
                    cur.insert(next((k for k, c in enumerate(cur) if c.t > y.t), len(cur)), y)
        elif r is None or isinstance(r, _Remove):
            j = len(cur) - 1 if r is None else \
                next((k for k in range(len(cur) - 1, -1, -1) if cur[k].session == r.session), -1)
            if j < 0:
                continue
            x = cur[j]
            # X2.12: removing a mistake means the word was read, and read correctly; removing a correct reading drops
            # it. A relabelled reading (issue #5) was the mistake on screen when the user removed it: the user's ok
            if x.outcome == "mistake" or x.relabelled:
                # X2.17: it was heard right; issue #17: it stays that session's reading (a false alarm removed; #69:
                # with the AI's verdict on it)
                cur[j] = Reading(x.t, "ok", "mark", accepts=x.heard, session=x.session, hinted=x.hinted, ai=x.ai,
                                 unhinted=x.unhinted, ai_ins=x.ai_ins,   # #72: Meddeb's insertion, for an unmark
                                 practice=x.practice,                     # #73 (v0.21): its practice word
                                 joined=x.joined)        # v0.22 review (#103): the join's reading (the link rule)
            else:
                cur.pop(j)
                if x.session is not None:
                    dropped.append(x)
        else:
            cur.append(r)
    return cur


def _history_of(ix: _Index) -> dict[str, list[Reading]]:
    return {key: readings for key, evs in ix.events.items() if (readings := _fold(evs))}


def counted_history(hist: dict[str, list[Reading]], practice) -> dict[str, list[Reading]]:
    """#73 (v0.19, D4; user 2026-10-29: "hidden mode … nor does it count the page even if recited … but mistakes will
    stay of course"): the history Progress, Stats and Review count: without the correct, non-hinted readings of the
    practice sessions (their started_at in `practice`: Hidden at some moment, session.json "practice"), also the + Correct
    / Remove made on them after ■ (a correct reading of that session; review of 0.19: a session whose verdict on the word
    is a pass, its last reading correct and none hinted, leaves with all its readings, _counted_keys); their mistakes
    and hints stay, so do readings of other sessions or of none. hist itself when there is no practice session (its
    identity is review.py's cache key). #73 (v0.21, D5): per word: a session of `practice` is practice on a word only
    when one of its readings of the word is (Reading.practice: judged in Hidden, or a 0.19/0.20 practice session);
    its other words count."""
    if not practice:
        return hist
    return _counted_keys({}, hist, practice, hist)


def _counted_keys(out: dict, hist: dict[str, list[Reading]], practice, keys) -> dict[str, list[Reading]]:
    """#73 review: counted_history's rule for `keys` alone, written into out (a copy of a counted view whose other words
    are unchanged: a mark's word, #23; the words a running session changes, #45); a word with nothing left leaves it.
    Review of 0.19 (C1): per practice session, as learned_moment / review.word_verdicts read its verdict on the word (its
    last reading, none hinted): a pass leaves with all its readings (a + Correct after ■ on its false alarm is a reading
    after the mistake: dropped alone, it brought the AI's mistake back as that session's verdict); a fail keeps its
    mistakes and hints. #73 (v0.21, D5): `practice` names the sessions that hold practice words; on each word only those
    with a practice reading of it (Reading.practice) are filtered: the + Correct / Remove after ■ naming the session
    (no flag of their own) follow that session's verdict, as C1 says."""
    for key in keys:
        readings = hist.get(key) or []
        prac = {r.session for r in readings if r.practice and r.session in practice}
        last: dict[str, Reading] = {}
        hinted: set[str] = set()
        for r in readings:
            if r.session in prac:
                last[r.session] = r
                if r.hinted:
                    hinted.add(r.session)
        passed = {s for s, r in last.items() if r.outcome == "ok" and s not in hinted}
        kept = [r for r in readings if not (r.session in prac and
                                            (r.session in passed or (r.outcome == "ok" and not r.hinted)))]
        if kept:
            out[key] = kept if len(kept) < len(readings) else readings
        else:
            out.pop(key, None)
    return out


def build_history(session_docs: list[dict], marks: list[dict]) -> dict[str, list[Reading]]:
    """Every word's readings in time order, removals applied (a removed mistake turns into a correct reading; session
    readings first on equal times, marks in the order they were written); an undone mark counts for nothing (#24)."""
    ix = _session_index([(doc.get("started_at"), session_readings(doc)) for doc in session_docs])
    for m in marks:
        _add_mark_event(ix, m)
    return _history_of(ix)


# ---------------------------------------------------------------- #111 / #62 (v0.23, D16): learning from the labels
LEARN_RECENT = 5            # the last readings (watch list) / alarms (known false-alarm place) a place is judged on
LEARN_NEAR = 3              # a heard form that is the text of a word this close is an alignment shift, never learned
LEARN_TRAVEL = 2            # labels of one form, over the places of a text, before it is accepted wherever that text is
LEARN_BACK = 2              # labels after a confirmed mistake at a place before its forms are accepted again
PRIOR_LABELS = 2            # false alarms the user overruled at a place before it is a known false-alarm place
WATCH_SLIPS = 2             # slips of one kind in the place's last LEARN_RECENT readings before it is watched


@dataclass
class Learned:
    """#111 (v0.23, D16; user 2026-11-04: "given a word abcd, the mic transcribes abcf but the user corrects it (false
    positive), then in the next pass both abcd and abcf will not raise any mistake … without overfitting"): what the
    user's labels teach the tracker, per profile (built from this profile's history only: the tenant isolation), rebuilt
    at each Start (learn); nothing new is stored. text: X2.17's table, {word text (N0): heard forms (N0) accepted
    wherever that text is expected} (the forms that travel); at: {word key: heard forms accepted at that place}; priors:
    the known false-alarm places; watch (#62): {word key: {"ins": an insertion watch, "forms": the first words of the
    insertions Meddeb heard there}}."""
    text: dict[str, set[str]] = field(default_factory=dict)
    at: dict[str, set[str]] = field(default_factory=dict)
    priors: set[str] = field(default_factory=set)
    watch: dict[str, dict] = field(default_factory=dict)


@dataclass
class _Rec:
    """#111 (D16): one reading of a word as the user left it: a session's reading (ai: Meddeb's verdict on it, ai_ins:
    an insertion; heard: what Meddeb heard) with his last label on it (label: his verdict during the session, a Remove,
    a + Mistake / + Correct placed in it after ■; the reading itself when he said nothing), or a mark of no session."""
    t: str
    ai: str | None
    ai_ins: bool
    heard: str | None
    label: Reading
    hinted: bool

    @property
    def slip(self) -> str | None:
        """The user's confirmed slip on it: "ins" (an insertion before the word), "word" (a wrong or skipped word), None
        (correct, or a hint: the word asked for is no slip the tracker could hear)."""
        if self.label.outcome != "mistake" or self.hinted or self.ai == "hint":
            return None
        return "ins" if self.label.ins else "word"


def _label_records(readings: list[Reading]) -> list[_Rec]:
    """#111 (D16): a word's readings (history order) as records, as the Stats page counts them (#69): one per session
    that read the word, labelled by the newest reading of that session (a mark placed in it, else the word's newest
    session's), and one per mark when no session read the word before it."""
    out: list[_Rec] = []
    by: dict = {}
    newest = None
    for r in readings:
        if r.ai is not None:
            rec = by.get(r.session)
            if rec is None:
                rec = by[r.session] = _Rec(r.t, r.ai, r.ai_ins, r.heard, r, r.hinted)
                out.append(rec)
            else:
                rec.label, rec.hinted, rec.ai_ins = r, rec.hinted or r.hinted, rec.ai_ins or r.ai_ins
            newest = r.session
        elif by:
            rec = by[r.session if r.session in by else newest]
            rec.label, rec.hinted = r, rec.hinted or r.hinted
        else:
            out.append(_Rec(r.t, None, False, None, r, r.hinted))
    return out


def _near_texts(q, s: int, a: int, i: int) -> set[str]:
    """The N0 forms (both spellings) of the words within LEARN_NEAR positions of word i of s:a (into the ayat around)."""
    ws = list(q.ayah(s, a).words)
    lo, hi = i - LEARN_NEAR, i + LEARN_NEAR
    near = [w for k, w in enumerate(ws) if k != i and lo <= k <= hi]
    if lo < 0 and a > 1:
        near += list(q.ayah(s, a - 1).words)[lo:]
    if hi >= len(ws) and a < q.n_ayat(s):
        near += list(q.ayah(s, a + 1).words)[: hi - len(ws) + 1]
    return {f for w in near for f in [w.norm] + normalize(w.uthmani).split()}


def learn(hist: dict[str, list[Reading]]) -> Learned:
    """#111 / #62 (v0.23, D16): the learned tables of a history (Profile.history(): the user's labels, Reading.ai Meddeb's
    verdicts under them).
    - Learned forms (X2.17 rewritten): a heard form X the user labelled correct at a place (his correct label carrying
      what was heard: a verdict overruled, a Remove, + Correct after ■) is accepted at that place, never when X is the
      text of a word within LEARN_NEAR positions (an alignment shift: «فلما» for «باسمايهم»), a lone letter, or the
      extra words of an insertion; a confirmed mistake there (a wrong or skipped word the user kept or added) after the
      last such label withdraws the place's forms, back after LEARN_BACK new labels. X travels to every place of the
      same text when it was labelled LEARN_TRAVEL times over that text's places, is no Qur'an word and no mistake was
      confirmed at any of them.
    - Known false-alarm place (priors): PRIOR_LABELS alarms of Meddeb's (wrong / skipped / lost words) the user
      overruled there, no confirmed mistake among its last LEARN_RECENT alarms and no wrong / skipped word confirmed in
      its last LEARN_RECENT readings.
    - Watch list (#62): WATCH_SLIPS slips of one kind (an insertion before the word, or a wrong / skipped word) in the
      place's last LEARN_RECENT readings; an insertion watch keeps the first word of the insertions Meddeb heard there.
      A word watch and a known false-alarm place exclude each other by construction; an insertion watch may sit on one
      (Tracker._evidence: the prior decides the word's own verdicts, the watch its attempts)."""
    from .quran_text import load_quran, vocabulary

    q, vocab = load_quran(), vocabulary()
    out = Learned()
    travel: dict[str, dict[str, int]] = {}            # text -> heard form -> labels over its places
    shaky: set[str] = set()                           # texts with a confirmed mistake at one of their places
    for key, readings in hist.items():
        try:
            s, a, i = (int(x) for x in key.split(":"))
            w = q.ayah(s, a).words[i]
        except (KeyError, IndexError, ValueError):
            continue
        recs = _label_records(readings)
        forms: list[tuple[int, str]] = []             # (record index, X) of the correct labels carrying X
        last_mistake = -1
        for n, rec in enumerate(recs):
            if rec.slip == "word":
                last_mistake = n
            elif rec.label.outcome == "ok" and rec.label.accepts and not (rec.ai_ins or rec.label.ai_ins):
                x = normalize(rec.label.accepts).replace(" ", "")
                if len(x) >= 2 and x != w.norm:
                    forms.append((n, x))
        if forms:
            near = _near_texts(q, s, a, i)
            forms = [(n, x) for n, x in forms if x not in near]
        if last_mistake >= 0:
            shaky.add(w.norm)
        # v0.23 review: only a mistake after a label withdraws (one before the first label withdraws nothing)
        withdrawn = last_mistake >= 0 and any(n < last_mistake for n, _x in forms)
        if forms and sum(1 for n, _x in forms if n > last_mistake) >= (LEARN_BACK if withdrawn else 1):
            out.at[key] = {x for _n, x in forms}
        for _n, x in forms:
            if x not in vocab:
                c = travel.setdefault(w.norm, {})
                c[x] = c.get(x, 0) + 1
        alarms = [rec for rec in recs if rec.ai == "mistake" and not rec.ai_ins]
        slips = [rec.slip for rec in recs[-LEARN_RECENT:]]
        if sum(1 for rec in alarms if rec.label.outcome == "ok") >= PRIOR_LABELS and "word" not in slips and \
                not any(rec.label.outcome == "mistake" for rec in alarms[-LEARN_RECENT:]):
            out.priors.add(key)
        if slips.count("ins") >= WATCH_SLIPS or slips.count("word") >= WATCH_SLIPS:
            ins = slips.count("ins") >= WATCH_SLIPS
            # the extra words of Meddeb's own ⚡ only (a session reading's heard is the word itself otherwise)
            heard = {normalize(rec.heard).split()[0] for rec in recs[-LEARN_RECENT:]
                     if ins and rec.slip == "ins" and rec.ai_ins and rec.heard and normalize(rec.heard).split()}
            out.watch[key] = {"ins": ins, "forms": sorted(heard)}
    for text, counts in travel.items():
        if text in shaky:
            continue
        fs = {x for x, c in counts.items() if c >= LEARN_TRAVEL}
        if fs:
            out.text[text] = fs
    return out


def summarize(readings: list[Reading] | None, depth: int = HISTORY_DEPTH, newest: str | None = None) -> dict | None:
    """What the page and the popover need (U1.2b, U1.4): the last `depth` readings, newest last. Issue #67 (the page's
    double tap without the session on screen, X2.12): a reading that is the user's verdict on a session's own reading
    says the tracker's verdict under it, `ai`: "ok" | "mistake" (a hint: a mistake); a reading of the newest saved
    session (newest: its started_at, Profile.newest_session) says `last`: true. Both only when so. #67 review: a mark
    made after ■ amending the newest session's reading (issue #17: a popover button, a double tap's own `mistake`; no
    ai of its own) says `amends`: true and, as `ai`, the verdict of that session's own reading of the word (when it gave
    one): once that session left the screen the double tap gives it back (`unmark`) instead of a manual mistake on top
    (the issue's symptom)."""
    if not readings:
        return None
    last = readings[-depth:]
    own = None
    if newest is not None:      # the newest session's own verdict on the word (one reading of it at most)
        own = next((r.ai for r in readings if r.session == newest and r.ai in ("ok", "mistake", "hint")), None)

    def one(r: Reading) -> dict:
        d = {"when": r.t[:16].replace("T", " "), "outcome": r.outcome, "heard": r.heard, "source": r.source}
        if r.ins and r.outcome == "mistake":           # #72 (v0.19): an insertion before the word (X2.12b)
            d["ins"] = True
        if r.source == "mark" and r.ai in ("ok", "mistake", "hint"):
            d["ai"] = "ok" if r.ai == "ok" else "mistake"
            if r.ai_ins and r.ai == "mistake":         # #72: Meddeb's verdict under his label was an insertion
                d["ai_ins"] = True
        elif r.source == "mark" and r.ai is None and newest is not None and r.session == newest:
            d["amends"] = True
            if own is not None:
                d["ai"] = "ok" if own == "ok" else "mistake"
        if newest is not None and r.session == newest:
            d["last"] = True
        return d
    return {"n": len(last), "bad5": sum(r.outcome == "mistake" for r in last[-5:]),
            "bad10": sum(r.outcome == "mistake" for r in last), "last": last[-1].t[:10],
            "readings": [one(r) for r in last]}


EXPORT_MANIFEST = "export.json"     # D4.9 (#71, v0.19): profile1/export.json, the zip's first entry
AUDIO_SUFFIXES = (".wav", ".pcm")    # stored without compression (deflate saved a third of them for a lot of CPU)


def export_manifest(kinds, created: str | None = None) -> dict:
    """D4.9: what profile1/export.json says: {format: 1, app (recite's version), created (ISO), kinds}."""
    from . import __version__
    return {"format": 1, "app": __version__,
            "created": created or dt.datetime.now().isoformat(timespec="seconds"), "kinds": list(kinds)}


def _export_kinds(kinds) -> list[str]:
    """The kinds asked (None = all) in the dialog's order; ValueError for another."""
    asked = set(EXPORT_KINDS if kinds is None else kinds)
    if asked - set(EXPORT_KINDS):
        raise ValueError(f"unknown export kinds: {sorted(asked - set(EXPORT_KINDS))}")
    return [k for k in EXPORT_KINDS if k in asked]


def write_export_zip(root: Path, dst, kinds=None, created: str | None = None) -> list[str]:
    """D4.4 / D4.9 (#71, v0.19): the profile's files of those kinds (None = all; storage.export_files: the logs go
    with the settings, v0.8's old reports never) zipped into dst (a path or a writable binary file: written as it
    goes, never the whole zip in memory) as the Android app writes it: entries under "profile1/", export.json first,
    the audio stored, the rest deflated. A file gone meanwhile, or that cannot be read (T4 review: a lock), is
    skipped. -> the kinds written."""
    kinds = _export_kinds(kinds)
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(f"profile1/{EXPORT_MANIFEST}", json.dumps(export_manifest(kinds, created), indent=1) + "\n")
        for rel, _size in export_files(Path(root), kinds):
            stored = rel.endswith(AUDIO_SUFFIXES)
            try:
                z.write(Path(root) / rel, f"profile1/{rel}",
                        compress_type=zipfile.ZIP_STORED if stored else zipfile.ZIP_DEFLATED)
            except (FileNotFoundError, PermissionError):
                continue
    return kinds


def export_zip(root: Path, kinds=None, created: str | None = None) -> bytes:
    """write_export_zip into memory (small exports, tests): the PC server and tools write to a file instead."""
    buf = io.BytesIO()
    write_export_zip(root, buf, kinds, created)
    return buf.getvalue()


def _zip_manifest(data: bytes | str | Path) -> dict | None:
    """D4.9: a profile zip's profile1/export.json, None without one (an export before v0.19) or when unreadable."""
    try:
        with zipfile.ZipFile(io.BytesIO(data) if isinstance(data, (bytes, bytearray, memoryview)) else data) as z:
            name = next((n for n in z.namelist() if n.replace("\\", "/").split("/", 1)[-1] == EXPORT_MANIFEST), None)
            if name is None:
                return None
            doc = json.loads(z.read(name))
    except (zipfile.BadZipFile, OSError, ValueError):
        return None
    return doc if isinstance(doc, dict) else None


def zip_kinds(data: bytes | str | Path) -> list[str] | None:
    """D4.9: the kinds a profile zip says it holds (its profile1/export.json), None without one (an export before
    v0.19: every kind) or when it cannot be read."""
    kinds = (_zip_manifest(data) or {}).get("kinds")
    return [k for k in kinds if k in EXPORT_KINDS] if isinstance(kinds, list) else None


def partial_kinds(data: bytes | str | Path) -> list[str]:
    """D4.9 (T4 review, 2026-10-30): the kinds a profile zip holds only in part (export.json "partial": Android's
    copy for the PC keeps the mistake history of its last 30 days); the import names them with the missing ones."""
    part = (_zip_manifest(data) or {}).get("partial")
    return [k for k in EXPORT_KINDS if k in part] if isinstance(part, list) else []


def missing_kinds(data: bytes | str | Path) -> list[str]:
    """D4.9: the export kinds a profile zip lacks (the import warns about them: they stay only in the copy of the
    profile it replaces); [] for a zip without export.json."""
    kinds = zip_kinds(data)
    return [] if kinds is None else [k for k in EXPORT_KINDS if k not in kinds]


class _SessionFile(NamedTuple):
    """What the profile keeps of one saved session.json (issue #23): its stamp, whether it parses into a JSON object
    (U1.5: a torn file is no session), and its readings. Never the whole document (1-2 MB with its pending rows)."""
    stamp: tuple[int, int] | None          # (mtime_ns, size)
    ok: bool
    started_at: object = None
    readings: tuple = ()
    practice: bool = False                 # #73 (v0.19, D4): it holds practice words (v0.21: per reading, Reading.practice)

    @classmethod
    def of(cls, stamp: tuple[int, int] | None, doc) -> "_SessionFile":
        if not isinstance(doc, dict):
            return cls(stamp, False)
        try:
            readings = tuple(session_readings(doc))
        except (KeyError, TypeError, ValueError, AttributeError):
            readings = ()                  # rows of another shape: listed, nothing for the history (it used to crash)
        return cls(stamp, True, doc.get("started_at"), readings, any(r.practice for _k, r in readings))


class Profile:
    """One profile folder; every write goes through it so that the cached history stays right."""

    def __init__(self, root: Path | str, clock: Callable[[], dt.datetime] = dt.datetime.now) -> None:
        self.root = Path(root)
        self.clock = clock
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        meta = self.root / "profile.json"
        if not meta.exists():
            meta.write_text(json.dumps({"name": self.root.name, "format": 1, "created": self.now()}, indent=1) + "\n",
                            encoding="utf-8")
        # issue #23: the history and its events stay cached; a mark replays its own word, a saved session re-reads its
        # own file. The PC server answers calls on several threads: a lock around the caches, and a new history dict
        # per change (a caller iterating the one it got is never disturbed)
        self._lock = threading.RLock()
        self._history: dict[str, list[Reading]] | None = None
        self._index: _Index | None = None
        self._practice: frozenset = frozenset()          # #73: the practice sessions' started_at, with _history
        self._counted: tuple | None = None               # #73 review: (_history, its counted view), a mark updates it
        self._sessions: dict[str, _SessionFile] = {}   # folder -> its session.json as last read (U1.5, U1.2b)
        self._marks_stamp: tuple[int, int] | None = None   # marks.jsonl's (mtime, size) after this profile's last mark

    @property
    def sessions_dir(self) -> Path:
        return self.root / "sessions"

    @property
    def logs_dir(self) -> Path:
        return self.root / "logs"

    @property
    def unsaved_dir(self) -> Path:
        """unsaved/<session id>/: a running session's checkpoint (X2.9, #45; recite/app.py Session.checkpoint)."""
        return self.root / "unsaved"

    @property
    def marks_path(self) -> Path:
        return self.root / "marks.jsonl"

    @property
    def settings_path(self) -> Path:
        return self.root / "settings.json"

    @property
    def review_path(self) -> Path:
        return self.root / "review.jsonl"

    def now(self) -> str:
        return self.clock().isoformat(timespec="seconds")

    # ---- settings (D4.4: in the profile, not in the browser)
    def settings(self) -> dict:
        try:
            return json.loads(self.settings_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def save_settings(self, changes: dict) -> dict:
        merged = {**self.settings(), **changes}
        self.settings_path.write_text(json.dumps(merged, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
        return merged

    # ---- manual marks (X2.12)
    def add_mark(self, surah: int, ayah: int, idx: int, event: str, heard: str | None = None,
                 session: str | None = None, ins: bool = False) -> dict:
        """event in EVENTS ('undo', issue #24: cancels that word's newest mark still in effect). heard (X2.17): for a
        'correct' mark, the heard form of the mistake it answers (accepted from then on). 'unmark' (issue #67) gives
        its own verdict back to a session, named in the record ("session"), so that a later session never changes what
        it did; ValueError when no session read the word (nothing written). session (#67 / #69 review: the saved
        session on screen, its folder or started_at, session_named): a mark made while it was on screen labels that
        session's reading of the word, when it read it ("session" in the record: the history places the mark there,
        the session view applies it whatever the window, Stats counts it for that reading), else issue #17's rule (no
        "session"); an unmark gives that session its verdict back, else the session of the word's newest reading that
        has one. ins (#72, v0.19, X2.12b): a mistake that is an insertion before the word ("ins": true; ignored on any
        other event)."""
        if event not in EVENTS:
            raise ValueError(f"unknown mark event {event!r}")
        rec = {"t": self.now(), "surah": int(surah), "ayah": int(ayah), "idx": int(idx), "event": event}
        if heard and event == "correct":
            rec["heard"] = heard
        if ins and event == "mistake":
            rec["ins"] = True
        key = word_key(surah, ayah, idx)
        named = self.session_named(session) if session and event != "undo" else None
        if named is not None:
            with self._lock:
                self.history()
                if named not in self._index.read_in.get(key, ()):
                    named = None                         # it did not read the word: issue #17's rule
        if event == "unmark" and named is None:
            named = next((r.session for r in reversed(self.history().get(key, [])) if r.session is not None), None)
            if named is None:
                raise ValueError("no session read this word: no verdict of Meddeb's to give back")
        if named is not None:
            rec["session"] = named
        with self._lock:
            torn = self._marks_torn()                    # a power cut's torn last line: the mark starts a new one
            with self.marks_path.open("a", encoding="utf-8") as f:
                f.write(("\n" if torn else "") + json.dumps(rec) + "\n")
            self._marks_stamp = self._stamp(self.marks_path)
            if self._history is not None and self._index is not None:
                # issue #23: that word alone is replayed (its events + this one), no rebuild from every session.json
                key = _add_mark_event(self._index, rec)
                readings = _fold(self._index.events.get(key, []))
                hist = dict(self._history)
                if readings:
                    hist[key] = readings
                else:
                    hist.pop(key, None)
                # #73 review: the counted view follows for that word alone (no pass over every reading per mark)
                c = self._counted
                if c is not None and c[0] is self._history:
                    view = hist if not self._practice else _counted_keys(dict(c[1]), hist, self._practice, (key,))
                    self._counted = (hist, view)
                self._history = hist
            else:
                self._history = self._index = None
        return rec

    def _marks_torn(self) -> bool:
        """Does marks.jsonl end in the middle of a line? Not read when it is as this profile last wrote it (opening it
        for reading costs ~10 ms per mark on Windows, its virus scan)."""
        stamp = self._stamp(self.marks_path)
        if stamp is None or stamp[1] == 0 or stamp == self._marks_stamp:
            return False
        try:
            with self.marks_path.open("rb") as f:
                f.seek(-1, io.SEEK_END)
                return f.read(1) != b"\n"
        except OSError:
            return False

    def marks(self) -> list[dict]:
        out = []
        if self.marks_path.exists():
            for line in self.marks_path.read_text(encoding="utf-8").splitlines():
                try:
                    m = json.loads(line)
                except ValueError:
                    continue            # a torn last line (power cut) must not lose the other marks
                if isinstance(m, dict) and m.get("event") in EVENTS:
                    out.append(m)
        return out

    # ---- the Review page's events (D4.8, issue #39, v0.16)
    def add_review_event(self, event: str, card: str, words: list[str], t: str | None = None, new: bool = False) -> dict:
        """Appends {"t", "event", "card", "words"} to review.jsonl (event in REVIEW_EVENTS; t: the caller's clock, the
        profile's by default; new: + "new": true, a "shown" of a card never shown since its birth, for the daily caps
        once the card is gone, #39 review). A torn last line (a power cut) is left behind: the event starts a new line."""
        if event not in REVIEW_EVENTS:
            raise ValueError(f"unknown review event {event!r}")
        rec = {"t": t or self.now(), "event": event, "card": str(card), "words": [str(w) for w in words]}
        if new:
            rec["new"] = True
        with self._lock:
            torn = False
            try:
                with self.review_path.open("rb") as f:
                    f.seek(0, io.SEEK_END)
                    if f.tell():
                        f.seek(-1, io.SEEK_END)
                        torn = f.read(1) != b"\n"
            except OSError:
                pass
            with self.review_path.open("a", encoding="utf-8") as f:
                f.write(("\n" if torn else "") + json.dumps(rec) + "\n")
        return rec

    def review_events(self) -> list[dict]:
        """review.jsonl's events in file order; a line that does not parse (a torn last line) is skipped."""
        out = []
        try:
            text = self.review_path.read_text(encoding="utf-8")
        except OSError:
            return out
        for line in text.splitlines():
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if isinstance(e, dict) and e.get("event") in REVIEW_EVENTS:
                out.append(e)
        return out

    # ---- sessions (X2.9)
    @staticmethod
    def session_folder_name(surah: int, ayah: int, started: dt.datetime) -> str:
        """A session folder's name, "<yyyy-mm-dd hh-mm-ss> sourah N eyah M" (the start time, session.json's surah and
        ayah_from). Pure: new_session_folder adds " (k)" to a same-second twin; the bug report names a running session
        by the folder it will be saved under (U1.16, v0.9, Session.folder_name), so both come from here."""
        return f"{started.strftime('%Y-%m-%d %H-%M-%S')} sourah {surah} eyah {ayah}"

    def new_session_folder(self, surah: int, ayah: int, started: dt.datetime) -> Path:
        """The folder a session saved now gets (not created): session_folder_name, + " (k)" when it exists."""
        name = self.session_folder_name(surah, ayah, started)
        folder, k = self.sessions_dir / name, 2
        while folder.exists():
            folder = self.sessions_dir / f"{name} ({k})"
            k += 1
        return folder

    @staticmethod
    def _stamp(f: Path) -> tuple[int, int] | None:
        try:
            st = f.stat()
        except OSError:
            return None
        return st.st_mtime_ns, st.st_size

    def _scan(self, docs: bool = False) -> list[tuple[str, _SessionFile, dict | None]]:
        """Every */session.json in folder order with what the profile keeps of it, parsed again only when it is new or
        its (mtime, size) changed (issue #23: a rebuild after a save parses the new file alone); a folder gone leaves the
        cache. docs: also parse and return every document (session_docs)."""
        with self._lock:
            known, seen, out = self._sessions, {}, []
            for f in sorted(self.sessions_dir.glob("*/session.json")):
                name, stamp = f.parent.name, self._stamp(f)
                entry = known.get(name)
                fresh = entry is not None and stamp is not None and entry.stamp == stamp
                doc = None
                if docs or not fresh:
                    try:
                        doc = json.loads(f.read_text(encoding="utf-8"))
                    except (OSError, ValueError):
                        doc = None
                    if not fresh:
                        entry = _SessionFile.of(stamp, doc)
                seen[name] = entry
                out.append((name, entry, doc if isinstance(doc, dict) else None))
            self._sessions = seen
            return out

    def session_docs(self) -> list[tuple[str, dict]]:
        """(folder, session.json) of every saved session in folder order; a file that does not parse into a JSON object
        (torn by a crash or a power cut during save) is skipped, and so is its folder in session_folders."""
        return [(name, doc) for name, _entry, doc in self._scan(docs=True) if doc is not None]

    def session_folders(self) -> list[str]:
        """The saved sessions' folder names in time order (the names start with yyyy-mm-dd hh-mm-ss; a same-second
        " (k)" sorts after its twin): the folders whose session.json parses, as in session_docs (the history), so that
        ◀ / ▶ step over a torn one and "k of N" counts what the history has. Each file is parsed once, until its mtime
        or size changes: a ◀ / ▶ only lists and stats the files (the cache the history uses, issue #23)."""
        return sorted(name for name, entry, _doc in self._scan() if entry.ok)

    def session_nav(self, folder: str | None, names: list[str] | None = None) -> dict:
        """U1.5 session browser (D11, 2026-10-10): {older, newer, index, count} around a saved session, index = its
        0-based place from the oldest ("k of N" shows index + 1). A session not saved (None, too short) or unknown is
        newer than every saved one: older = the newest saved session, newer and index None. names: session_folders()
        when the caller has it."""
        names = self.session_folders() if names is None else names
        if folder not in names:
            return {"older": names[-1] if names else None, "newer": None, "index": None, "count": len(names)}
        k = names.index(folder)
        return {"older": names[k - 1] if k > 0 else None, "newer": names[k + 1] if k + 1 < len(names) else None,
                "index": k, "count": len(names)}

    def session_saved(self) -> None:
        """A session.json was written: the next history() rebuilds, parsing that new file alone (issue #23)."""
        with self._lock:
            self._history = self._index = None

    def _drop_caches(self) -> None:
        with self._lock:
            self._history = self._index = None
            self._sessions = {}

    # ---- export / import (D4.4: one profile moves between devices as a zip whose entries start with "profile1/")
    def export_zip(self, kinds=None) -> bytes:
        return export_zip(self.root, kinds, created=self.now())

    def import_zip(self, data: bytes | str | Path) -> Path:
        """Replace the profile with an exported one (its bytes, or the path of the zip: the web app's zip stays on the
        browser's disk, P5.11). The current content (logs stay) moves to a sibling folder <name>.before-import-<stamp>,
        which is returned; nothing is deleted."""
        with zipfile.ZipFile(io.BytesIO(data) if isinstance(data, (bytes, bytearray, memoryview)) else data) as z:
            entries = []
            for info in z.infolist():
                rel = Path(info.filename.replace("\\", "/").split("/", 1)[-1])
                if info.is_dir() or not rel.parts or rel.parts[0] == "logs" or rel.parts == (EXPORT_MANIFEST,):
                    continue                    # the device's own logs stay; export.json (D4.9) is no profile file
                if rel.is_absolute() or ".." in rel.parts:
                    raise ValueError(f"entry {info.filename} points outside the profile")
                entries.append((info, rel))
            if not any(rel.parts[0] in ("sessions", "marks.jsonl", "settings.json", "profile.json") for _, rel in entries):
                raise ValueError("this zip holds no Meddeb profile")
            backup = self.root.parent / f"{self.root.name}.before-import-{self.clock().strftime('%Y%m%d-%H%M%S')}"
            backup.mkdir(parents=True)
            for child in list(self.root.iterdir()):
                if child.name != "logs":
                    child.rename(backup / child.name)
            for info, rel in entries:
                dst = self.root / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                dst.write_bytes(z.read(info))
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self._drop_caches()
        return backup

    def history(self) -> dict[str, list[Reading]]:
        """Every word's readings (build_history over the saved sessions and marks.jsonl), cached: a mark updates its
        word in place of a rebuild, a rebuild re-reads only new or changed session files (issue #23). The dict returned
        is never changed afterwards (a mark makes a new one)."""
        with self._lock:
            if self._history is None:
                entries = [e for _name, e, _doc in self._scan() if e.ok]
                ix = _session_index([(e.started_at, e.readings) for e in entries])
                for m in self.marks():
                    _add_mark_event(ix, m)
                self._index, self._history = ix, _history_of(ix)
                self._practice = frozenset(e.started_at for e in entries if e.practice)
            return self._history

    def counted(self, hist: dict[str, list[Reading]] | None = None, docs=()) -> dict[str, list[Reading]]:
        """#73 (v0.19, D4): the history Progress, Stats and Review count (counted_history): hist (history() by default;
        history_with(docs) for the running sessions, #45) without the correct readings of the practice sessions, the
        saved ones' (session.json "practice") and those of `docs` (session.json documents not saved yet) marked so. The
        word popover, its colours, the #67 labels and X2.17's accepted forms keep reading history(). #73 review: the
        counted view of history() is kept next to it (the same dict while it is the same; a mark refilters its word,
        add_mark); another hist refilters only the words whose readings differ from history()'s (#45's merged one: the
        running sessions' words), the others taken from that view."""
        with self._lock:
            base = self.history()
            practice = self._practice
            c = self._counted
            if c is None or c[0] is not base:
                c = self._counted = (base, counted_history(base, practice))
            view = c[1]
        extra = {d.get("started_at") for d in docs if isinstance(d, dict) and d.get("practice") is True}
        if hist is None or hist is base:
            return view
        every = practice | extra
        if not every:
            return hist
        changed = [k for k, rs in hist.items() if base.get(k) is not rs]
        out = _counted_keys(dict(view), hist, every, changed)
        for k in base.keys() - hist.keys():
            out.pop(k, None)
        return out

    def session_named(self, name: str | None) -> str | None:
        """#67 / #69 review: the started_at of the saved session `name` names: its folder (what the page shows after ■
        or a session loaded with ◀) or its started_at itself (what the history keys readings by, Reading.session);
        None: no such saved session."""
        if not name:
            return None
        name = str(name)
        with self._lock:
            known = self._sessions.get(name)     # the cache the history uses (a mark costs no listing, issue #23)
        if known is not None and known.ok and isinstance(known.started_at, str) and \
                (self.sessions_dir / name / "session.json").exists():
            return known.started_at
        entries = {folder: e for folder, e, _doc in self._scan() if e.ok}
        if name in entries:
            started = entries[name].started_at
            return started if isinstance(started, str) else None
        return name if any(e.started_at == name for e in entries.values()) else None

    def folder_of(self, started_at: str | None) -> str | None:
        """#101 (v0.22, plan D4): the folder of the saved session that started at `started_at` (session_named's
        reverse: review_result without a folder names the group it read); None: none saved (a running one)."""
        if not started_at:
            return None
        return next((folder for folder, e, _doc in reversed(self._scan()) if e.ok and e.started_at == started_at), None)

    def newest_session(self) -> str | None:
        """Issue #67: the started_at of the newest saved session (the history's `last`, summarize), None: none."""
        with self._lock:
            self.history()
            return self._index.starts[-1][1] if self._index is not None and self._index.starts else None

    def history_with(self, docs: list[dict]) -> dict[str, list[Reading]]:
        """#45 (v0.17): the history as history() will give it once these session.json documents are saved (sessions not
        saved yet, newer than every saved one: a running session as ■ would save it now, Session.preview_doc). Parses no
        file and leaves the cached history alone: a new dict (history() itself when docs is empty)."""
        with self._lock:
            base = self.history()
            if not docs:
                return base
            return _history_with(self._index, base, [(d.get("started_at"), session_readings(d)) for d in docs])

    # ---- Settings > Space used (U1.17, issue #14)
    def storage(self) -> dict[str, dict]:
        """The profile's space by kind (recite/storage.py), with the number of manual marks still in effect (an undone
        mark and its undo count for nothing, issue #24) in the history row."""
        rows = profile_storage(self.root)
        rows["history"]["marks"] = len(effective_marks(self.marks()))
        return rows

    def delete(self, what: str) -> dict:
        """The user's own delete (U1.17): recordings | history | old_reports | backups; the caches follow."""
        r = delete_profile_data(self.root, what)
        self._drop_caches()
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        return r
