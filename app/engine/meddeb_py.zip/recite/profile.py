"""The user's profile folder (D4.4) and the per-word reading history built from it (U1.2b, X2.12).

    profile1/
      profile.json   {"name", "format": 1, "created"}
      settings.json  UI settings (model, threshold, text mode, toggles, last page)
      marks.jsonl    manual marks, append-only: {"t", "surah", "ayah", "idx", "event": "mistake" | "correct" | "remove" |
                     "undo"}
      sessions/<yyyy-mm-dd hh-mm-ss sourah N eyah M>/   audio.wav, session.json, decodes.jsonl, summary.md (X2.9)
      logs/          the device's logs (never exported)

A word's history is every reading of it in time order: each saved session's verdict (a mistake when the status is a
mistake and its score reached that session's threshold, or the user set it) and each manual mark; a "remove" event
acts on the newest reading that existed at that moment: a mistake becomes a correct reading (the word was read, and
read correctly), a correct reading is dropped. An "undo" event (issue #24: a double tap again on the word) cancels that
word's newest mark still in effect, whatever its event (effective_marks); an undo with nothing to cancel is ignored.
Nothing is ever deleted from the folder (sessions, marks) except by the user's own delete in Settings > Space used
(U1.17, issue #14: Profile.delete, recite/storage.py).

Profile keeps the history in memory (issue #23): each session.json's readings by its file stamp (parsed again only when
it changes) and every word's events, so that a mark replays its own word alone instead of a rebuild from every file.
"""
from __future__ import annotations

import datetime as dt
import io
import json
import threading
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, NamedTuple

from .normalize import normalize
from .storage import delete_profile_data, profile_storage

MISTAKE_STATUSES = frozenset({"wrong", "missing", "hinted"})
EVENTS = ("mistake", "correct", "remove", "undo")   # undo: issue #24 (the double tap's undo)
HISTORY_DEPTH = 10          # readings kept for the colour rule (last 5) and the popover list (last 10), U1.2b


@dataclass(frozen=True)
class Reading:
    t: str                       # ISO time, seconds precision
    outcome: str                 # "ok" | "mistake"
    source: str                  # "session" | "mark"
    heard: str | None = None
    accepts: str | None = None   # X2.17: a correct reading of the user's: the heard form it accepts (never shown)
    relabelled: bool = False     # issue #5: a saved mistake read as correct (it was a mistake on screen back then)
    # issue #17: where it was read (the session's started_at; None for a mark made outside a session) and whether the
    # word was revealed by a hint in that session. Provenance only: not part of a reading's equality
    session: str | None = field(default=None, compare=False)
    hinted: bool = field(default=False, compare=False)


def word_key(surah: int, ayah: int, idx: int) -> str:
    return f"{surah}:{ayah}:{idx}"


def heard_is_the_word(w: dict) -> bool:
    """Issue #5 (2026-10-10): a saved "missing" (skipped) or "lost" row whose heard form IS its word (either spelling,
    N0, spaces removed): the model heard the expected word, so the verdict was an engine defect, not a mistake. Up to
    v0.5, ◂ pressed after a word heard but not committed yet made it "skipped" keeping what was heard (up to v0.7 when
    an attempt before it was not confirmed yet), and the lost rule marked the word the decode started with while the
    committed pointer lagged. Only these two shapes: a plain "wrong" never pairs the word itself (align), and a future
    verdict may differ below N0 (tashkeel, B3.11)."""
    h = normalize(w.get("heard") or "").replace(" ", "")
    return bool(h) and (w.get("status") == "missing" or bool(w.get("lost"))) and \
        any(h == normalize(w.get(f) or "").replace(" ", "") for f in ("word", "uthmani"))


def session_readings(doc: dict) -> list[tuple[str, Reading]]:
    """One saved session's verdicts as readings, timed at the session start + the word's time in the recording. A
    verdict the user set during the session is the user's reading (X2.12a, 2026-10-01): source "mark", no heard text
    (what the model heard is not the reason of a manual labeled mistake). An engine verdict whose heard form is the word
    itself reads as a correct reading (issue #5, heard_is_the_word): relabelled when read (relabelled: a Remove made on
    it then still finds the mistake it removed), the file never changes."""
    try:
        start = dt.datetime.fromisoformat(doc["started_at"])
    except (KeyError, ValueError):
        return []
    thr = float(doc.get("threshold", 0.5))
    revealed = set(doc.get("revealed_before_start") or [])   # issue #17: a word revealed before Start is a hint too
    out = []
    for w in doc.get("words", []):
        status = w.get("status", "pending")
        if status == "pending":
            continue
        user = bool(w.get("user"))
        mistake = status in MISTAKE_STATUSES and (float(w.get("score") or 0) >= thr or user)
        relabelled = mistake and not user and heard_is_the_word(w)   # issue #5: the model heard the word itself
        bad = mistake and not relabelled
        t = (start + dt.timedelta(seconds=float(w.get("t0") or 0))).isoformat(timespec="seconds")
        out.append((word_key(w["surah"], w["ayah"], w["idx"]),
                    Reading(t, "mistake" if bad else "ok", "mark" if user else "session",
                            None if user else w.get("heard"),
                            w.get("heard") if user and not bad else None,   # X2.17: the user overruled what was heard
                            relabelled, session=doc["started_at"],
                            hinted=bool(w.get("hinted")) or word_key(w["surah"], w["ayah"], w["idx"]) in revealed)))
    return out


def _when_iso(t) -> dt.datetime | None:
    try:
        return dt.datetime.fromisoformat(str(t))
    except (TypeError, ValueError):
        return None


def _session_of(t, starts: list[tuple[dt.datetime, str]]) -> str | None:
    """The started_at of the latest session that started at or before t (None: before every session)."""
    when = _when_iso(t)
    if when is None:
        return None
    best = None
    for start, name in starts:
        if start <= when:
            best = name
        else:
            break
    return best


_Event = tuple[str, int, "Reading | None"]         # (time, order, reading; None = a remove)


@dataclass
class _Index:
    """Every word's events in the order build_history replays them, and what places a mark in a session (issue #17).
    Profile keeps one while its history is cached, so that a mark replays its own word alone (issue #23)."""
    events: dict[str, list[_Event]] = field(default_factory=dict)
    read_in: dict[str, set[str]] = field(default_factory=dict)        # word -> the sessions that read it (issue #17)
    starts: list[tuple[dt.datetime, str]] = field(default_factory=list)   # every session's start, sorted
    order: int = 0                                                    # the next event's order (ties on equal times)
    marks: dict[str, list[int]] = field(default_factory=dict)         # word -> the orders of its marks in effect (#24)


def _session_index(per_session: list[tuple[object, list[tuple[str, Reading]]]]) -> _Index:
    """(started_at, session_readings) of every saved session in folder order -> their events, read_in and starts."""
    ix = _Index()
    for started_at, readings in per_session:
        for key, r in readings:
            ix.events.setdefault(key, []).append((r.t, ix.order, r))
            ix.read_in.setdefault(key, set()).add(r.session)
            ix.order += 1
        if (when := _when_iso(started_at)) is not None:
            ix.starts.append((when, started_at))
    ix.starts.sort()
    return ix


def effective_marks(marks: list[dict]) -> list[dict]:
    """Issue #24: the marks still in effect, in file order. An "undo" cancels the newest mark of its word that is still
    in effect (a stack per word: two undos cancel the two newest) and is dropped itself; an undo with nothing left to
    cancel on its word is ignored. build_history applies the same rule as it goes (_add_mark_event)."""
    out: list[dict | None] = []
    stacks: dict[tuple, list[int]] = {}
    for m in marks:
        key = (m.get("surah"), m.get("ayah"), m.get("idx"))
        if m.get("event") == "undo":
            stack = stacks.get(key)
            if stack:
                out[stack.pop()] = None
            continue
        stacks.setdefault(key, []).append(len(out))
        out.append(m)
    return [m for m in out if m is not None]


def _add_mark_event(ix: _Index, m: dict) -> str:
    """One mark (a marks.jsonl record) appended to its word's events, after every event already in ix; -> its key.
    An "undo" (issue #24) takes that word's newest mark still in effect out of its events instead (effective_marks)."""
    key = word_key(m["surah"], m["ayah"], m["idx"])
    if m["event"] == "undo":
        stack = ix.marks.get(key)
        if stack:
            order = stack.pop()
            ix.events[key] = [e for e in ix.events.get(key, []) if e[1] != order]
        return key
    # issue #17: a + Mistake / + Correct made after ■ amends the recitation it was made on: the latest session started
    # before it (the window the session view applies marks in, app.apply_marks), when it read the word
    sess = _session_of(m.get("t"), ix.starts)
    sess = sess if sess in ix.read_in.get(key, ()) else None
    r = None if m["event"] == "remove" else Reading(m["t"], "mistake" if m["event"] == "mistake" else "ok", "mark",
                                                     accepts=m.get("heard") if m["event"] == "correct" else None,
                                                     session=sess)
    ix.events.setdefault(key, []).append((m["t"], ix.order, r))
    ix.marks.setdefault(key, []).append(ix.order)
    ix.order += 1
    return key


def _fold(events: list[_Event]) -> list[Reading]:
    """One word's events replayed in time order (session readings first on equal times, marks in the order they were
    written), removals applied."""
    cur: list[Reading] = []
    for _t, _order, r in sorted(events, key=lambda e: (e[0], e[1])):
        if r is None:
            # X2.12: removing a mistake means the word was read, and read correctly; removing a correct reading drops
            # it. A relabelled reading (issue #5) was the mistake on screen when the user removed it: the user's ok
            if cur and (cur[-1].outcome == "mistake" or cur[-1].relabelled):
                # X2.17: it was heard right; issue #17: it stays that session's reading (a false alarm removed)
                cur[-1] = Reading(cur[-1].t, "ok", "mark", accepts=cur[-1].heard, session=cur[-1].session,
                                  hinted=cur[-1].hinted)
            elif cur:
                cur.pop()
        else:
            cur.append(r)
    return cur


def _history_of(ix: _Index) -> dict[str, list[Reading]]:
    return {key: readings for key, evs in ix.events.items() if (readings := _fold(evs))}


def build_history(session_docs: list[dict], marks: list[dict]) -> dict[str, list[Reading]]:
    """Every word's readings in time order, removals applied (a removed mistake turns into a correct reading; session
    readings first on equal times, marks in the order they were written); an undone mark counts for nothing (#24)."""
    ix = _session_index([(doc.get("started_at"), session_readings(doc)) for doc in session_docs])
    for m in marks:
        _add_mark_event(ix, m)
    return _history_of(ix)


def summarize(readings: list[Reading] | None, depth: int = HISTORY_DEPTH) -> dict | None:
    """What the page and the popover need (U1.2b, U1.4): the last `depth` readings, newest last."""
    if not readings:
        return None
    last = readings[-depth:]
    return {"n": len(last), "bad5": sum(r.outcome == "mistake" for r in last[-5:]),
            "bad10": sum(r.outcome == "mistake" for r in last), "last": last[-1].t[:10],
            "readings": [{"when": r.t[:16].replace("T", " "), "outcome": r.outcome, "heard": r.heard, "source": r.source}
                         for r in last]}


def export_zip(root: Path) -> bytes:
    """A profile folder without its logs, as the Android app writes it (entries start with "profile1/")."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(Path(root).rglob("*")):
            rel = f.relative_to(root)
            if f.is_file() and rel.parts[0] != "logs":
                z.write(f, f"profile1/{rel.as_posix()}")
    return buf.getvalue()


class _SessionFile(NamedTuple):
    """What the profile keeps of one saved session.json (issue #23): its stamp, whether it parses into a JSON object
    (U1.5: a torn file is no session), and its readings. Never the whole document (1-2 MB with its pending rows)."""
    stamp: tuple[int, int] | None          # (mtime_ns, size)
    ok: bool
    started_at: object = None
    readings: tuple = ()

    @classmethod
    def of(cls, stamp: tuple[int, int] | None, doc) -> "_SessionFile":
        if not isinstance(doc, dict):
            return cls(stamp, False)
        try:
            readings = tuple(session_readings(doc))
        except (KeyError, TypeError, ValueError, AttributeError):
            readings = ()                  # rows of another shape: listed, nothing for the history (it used to crash)
        return cls(stamp, True, doc.get("started_at"), readings)


class Profile:
    """One profile folder; every write goes through it so that the cached history stays right."""

    def __init__(self, root: Path | str, clock: Callable[[], dt.datetime] = dt.datetime.now) -> None:
        self.root = Path(root)
        self.clock = clock
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        meta = self.root / "profile.json"
        if not meta.exists():
            meta.write_text(json.dumps({"name": self.root.name, "format": 1, "created": self.now()}, indent=1) + "\n",
                            encoding="utf-8")
        # issue #23: the history and its events stay cached; a mark replays its own word, a saved session re-reads its
        # own file. The PC server answers calls on several threads: a lock around the caches, and a new history dict
        # per change (a caller iterating the one it got is never disturbed)
        self._lock = threading.RLock()
        self._history: dict[str, list[Reading]] | None = None
        self._index: _Index | None = None
        self._sessions: dict[str, _SessionFile] = {}   # folder -> its session.json as last read (U1.5, U1.2b)
        self._marks_stamp: tuple[int, int] | None = None   # marks.jsonl's (mtime, size) after this profile's last mark

    @property
    def sessions_dir(self) -> Path:
        return self.root / "sessions"

    @property
    def logs_dir(self) -> Path:
        return self.root / "logs"

    @property
    def marks_path(self) -> Path:
        return self.root / "marks.jsonl"

    @property
    def settings_path(self) -> Path:
        return self.root / "settings.json"

    def now(self) -> str:
        return self.clock().isoformat(timespec="seconds")

    # ---- settings (D4.4: in the profile, not in the browser)
    def settings(self) -> dict:
        try:
            return json.loads(self.settings_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def save_settings(self, changes: dict) -> dict:
        merged = {**self.settings(), **changes}
        self.settings_path.write_text(json.dumps(merged, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
        return merged

    # ---- manual marks (X2.12)
    def add_mark(self, surah: int, ayah: int, idx: int, event: str, heard: str | None = None) -> dict:
        """event in EVENTS ('undo', issue #24: cancels that word's newest mark still in effect). heard (X2.17): for a
        'correct' mark, the heard form of the mistake it answers (accepted from then on)."""
        if event not in EVENTS:
            raise ValueError(f"unknown mark event {event!r}")
        rec = {"t": self.now(), "surah": int(surah), "ayah": int(ayah), "idx": int(idx), "event": event}
        if heard and event == "correct":
            rec["heard"] = heard
        with self._lock:
            torn = self._marks_torn()                    # a power cut's torn last line: the mark starts a new one
            with self.marks_path.open("a", encoding="utf-8") as f:
                f.write(("\n" if torn else "") + json.dumps(rec) + "\n")
            self._marks_stamp = self._stamp(self.marks_path)
            if self._history is not None and self._index is not None:
                # issue #23: that word alone is replayed (its events + this one), no rebuild from every session.json
                key = _add_mark_event(self._index, rec)
                readings = _fold(self._index.events.get(key, []))
                hist = dict(self._history)
                if readings:
                    hist[key] = readings
                else:
                    hist.pop(key, None)
                self._history = hist
            else:
                self._history = self._index = None
        return rec

    def _marks_torn(self) -> bool:
        """Does marks.jsonl end in the middle of a line? Not read when it is as this profile last wrote it (opening it
        for reading costs ~10 ms per mark on Windows, its virus scan)."""
        stamp = self._stamp(self.marks_path)
        if stamp is None or stamp[1] == 0 or stamp == self._marks_stamp:
            return False
        try:
            with self.marks_path.open("rb") as f:
                f.seek(-1, io.SEEK_END)
                return f.read(1) != b"\n"
        except OSError:
            return False

    def marks(self) -> list[dict]:
        out = []
        if self.marks_path.exists():
            for line in self.marks_path.read_text(encoding="utf-8").splitlines():
                try:
                    m = json.loads(line)
                except ValueError:
                    continue            # a torn last line (power cut) must not lose the other marks
                if isinstance(m, dict) and m.get("event") in EVENTS:
                    out.append(m)
        return out

    # ---- sessions (X2.9)
    @staticmethod
    def session_folder_name(surah: int, ayah: int, started: dt.datetime) -> str:
        """A session folder's name, "<yyyy-mm-dd hh-mm-ss> sourah N eyah M" (the start time, session.json's surah and
        ayah_from). Pure: new_session_folder adds " (k)" to a same-second twin; the bug report names a running session
        by the folder it will be saved under (U1.16, v0.9, Session.folder_name), so both come from here."""
        return f"{started.strftime('%Y-%m-%d %H-%M-%S')} sourah {surah} eyah {ayah}"

    def new_session_folder(self, surah: int, ayah: int, started: dt.datetime) -> Path:
        """The folder a session saved now gets (not created): session_folder_name, + " (k)" when it exists."""
        name = self.session_folder_name(surah, ayah, started)
        folder, k = self.sessions_dir / name, 2
        while folder.exists():
            folder = self.sessions_dir / f"{name} ({k})"
            k += 1
        return folder

    @staticmethod
    def _stamp(f: Path) -> tuple[int, int] | None:
        try:
            st = f.stat()
        except OSError:
            return None
        return st.st_mtime_ns, st.st_size

    def _scan(self, docs: bool = False) -> list[tuple[str, _SessionFile, dict | None]]:
        """Every */session.json in folder order with what the profile keeps of it, parsed again only when it is new or
        its (mtime, size) changed (issue #23: a rebuild after a save parses the new file alone); a folder gone leaves the
        cache. docs: also parse and return every document (session_docs)."""
        with self._lock:
            known, seen, out = self._sessions, {}, []
            for f in sorted(self.sessions_dir.glob("*/session.json")):
                name, stamp = f.parent.name, self._stamp(f)
                entry = known.get(name)
                fresh = entry is not None and stamp is not None and entry.stamp == stamp
                doc = None
                if docs or not fresh:
                    try:
                        doc = json.loads(f.read_text(encoding="utf-8"))
                    except (OSError, ValueError):
                        doc = None
                    if not fresh:
                        entry = _SessionFile.of(stamp, doc)
                seen[name] = entry
                out.append((name, entry, doc if isinstance(doc, dict) else None))
            self._sessions = seen
            return out

    def session_docs(self) -> list[tuple[str, dict]]:
        """(folder, session.json) of every saved session in folder order; a file that does not parse into a JSON object
        (torn by a crash or a power cut during save) is skipped, and so is its folder in session_folders."""
        return [(name, doc) for name, _entry, doc in self._scan(docs=True) if doc is not None]

    def session_folders(self) -> list[str]:
        """The saved sessions' folder names in time order (the names start with yyyy-mm-dd hh-mm-ss; a same-second
        " (k)" sorts after its twin): the folders whose session.json parses, as in session_docs (the history), so that
        ◀ / ▶ step over a torn one and "k of N" counts what the history has. Each file is parsed once, until its mtime
        or size changes: a ◀ / ▶ only lists and stats the files (the cache the history uses, issue #23)."""
        return sorted(name for name, entry, _doc in self._scan() if entry.ok)

    def session_nav(self, folder: str | None, names: list[str] | None = None) -> dict:
        """U1.5 session browser (D11, 2026-10-10): {older, newer, index, count} around a saved session, index = its
        0-based place from the oldest ("k of N" shows index + 1). A session not saved (None, too short) or unknown is
        newer than every saved one: older = the newest saved session, newer and index None. names: session_folders()
        when the caller has it."""
        names = self.session_folders() if names is None else names
        if folder not in names:
            return {"older": names[-1] if names else None, "newer": None, "index": None, "count": len(names)}
        k = names.index(folder)
        return {"older": names[k - 1] if k > 0 else None, "newer": names[k + 1] if k + 1 < len(names) else None,
                "index": k, "count": len(names)}

    def session_saved(self) -> None:
        """A session.json was written: the next history() rebuilds, parsing that new file alone (issue #23)."""
        with self._lock:
            self._history = self._index = None

    def _drop_caches(self) -> None:
        with self._lock:
            self._history = self._index = None
            self._sessions = {}

    # ---- export / import (D4.4: one profile moves between devices as a zip whose entries start with "profile1/")
    def export_zip(self) -> bytes:
        return export_zip(self.root)

    def import_zip(self, data: bytes | str | Path) -> Path:
        """Replace the profile with an exported one (its bytes, or the path of the zip: the web app's zip stays on the
        browser's disk, P5.11). The current content (logs stay) moves to a sibling folder <name>.before-import-<stamp>,
        which is returned; nothing is deleted."""
        with zipfile.ZipFile(io.BytesIO(data) if isinstance(data, (bytes, bytearray, memoryview)) else data) as z:
            entries = []
            for info in z.infolist():
                rel = Path(info.filename.replace("\\", "/").split("/", 1)[-1])
                if info.is_dir() or not rel.parts or rel.parts[0] == "logs":
                    continue
                if rel.is_absolute() or ".." in rel.parts:
                    raise ValueError(f"entry {info.filename} points outside the profile")
                entries.append((info, rel))
            if not any(rel.parts[0] in ("sessions", "marks.jsonl", "settings.json", "profile.json") for _, rel in entries):
                raise ValueError("this zip holds no Meddeb profile")
            backup = self.root.parent / f"{self.root.name}.before-import-{self.clock().strftime('%Y%m%d-%H%M%S')}"
            backup.mkdir(parents=True)
            for child in list(self.root.iterdir()):
                if child.name != "logs":
                    child.rename(backup / child.name)
            for info, rel in entries:
                dst = self.root / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                dst.write_bytes(z.read(info))
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self._drop_caches()
        return backup

    def history(self) -> dict[str, list[Reading]]:
        """Every word's readings (build_history over the saved sessions and marks.jsonl), cached: a mark updates its
        word in place of a rebuild, a rebuild re-reads only new or changed session files (issue #23). The dict returned
        is never changed afterwards (a mark makes a new one)."""
        with self._lock:
            if self._history is None:
                ix = _session_index([(e.started_at, e.readings) for _name, e, _doc in self._scan() if e.ok])
                for m in self.marks():
                    _add_mark_event(ix, m)
                self._index, self._history = ix, _history_of(ix)
            return self._history

    # ---- Settings > Space used (U1.17, issue #14)
    def storage(self) -> dict[str, dict]:
        """The profile's space by kind (recite/storage.py), with the number of manual marks still in effect (an undone
        mark and its undo count for nothing, issue #24) in the history row."""
        rows = profile_storage(self.root)
        rows["history"]["marks"] = len(effective_marks(self.marks()))
        return rows

    def delete(self, what: str) -> dict:
        """The user's own delete (U1.17): recordings | history | old_reports | backups; the caches follow."""
        r = delete_profile_data(self.root, what)
        self._drop_caches()
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        return r
