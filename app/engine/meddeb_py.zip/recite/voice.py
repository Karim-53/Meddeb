"""Voice commands (X2.15) as the tracker detects them (B3.15): pure matchers over the words of the normal rolling decode
of the served speech model (no second model; user, 2026-10-04), unit-tested without audio. The tracker
(recite/tracker.py) consumes the fired spans and drops the command words before anything else sees the decoded words.

  * «صدق الله العظيم» (stop): a word one edit from صدق then, 1-4 words later, one edit from العظيم (one_edit, not
    similarity: on the phone recite.align.similarity is difflib's ratio, with which the old 0.66 / 0.70 thresholds let
    «صادقين قل انما العلم», 67:25-26, fire stop); complete once it ends FORMULA_SETTLE_S before the buffer end (a
    beginning still being said is held out of that decode); never where the expected words around the cursor hold both
    (6:115 only, «صدقا ... العليم»). Dropped from the verdicts with the commands off too (X2.16 R4: it is no Qur'an word
    sequence, «صدق الله» alone is 3:95 / 33:22).
  * Command phrases (COMMAND_TEMPLATES): a phrase as word slots, each slot = the decoded forms accepted for that word
    (normalized, exact; a Qur'an word only inside a phrase), plus the phrase decoded as one word (glued). No similarity
    score, so the same words fire on the PC (rapidfuzz) and on the phone (Chaquopy: difflib); none of them matches the
    mushaf (tests/test_voice_commands.py scans every 1-4-word window, both spellings, any neighbours glued, and the
    windows one recognition error away: one word one edit from a form, the others exact). Complete once its last
    word ends COMMAND_SETTLE_S before the buffer end; a match still being said, and the first words of a phrase at the
    very end of the decode, are held out of that decode; never where the template matches the expected words around
    the cursor. Dropped from the verdicts with the commands off too.
  * Spoken variants (user, 2026-10-11, issue #9: «loosen the other voice commands with similar text», as
    «الكلمة التالية» in v0.8): with / without the article, ة / ه, a dialect word or a synonym («كمّل», «بقية», «عاود»,
    «راحة», «مولانا»), each with the forms the served model wrote for edge-tts voices in the user's pauses; every form
    keeps the mushaf scan at 0 and 0 windows one recognition error away (one word one edit from a form, the others
    exact), and fires 0 times in the user's 8 sessions, Yasser and the benchmark. A single word that would be one letter
    from a Qur'an word («عاود»: «عاد», «داود»; «أعدها»: «بعدها») is an island word only.
  * The user's own voice (his Tunisian recordings, 2026-10-11; tests/test_user_voice_commands.py): «باقي آية» written
    «بق الاي» / «ذات الايه» (bqi_aya) or, said alone, «بق الي» (ISLAND_PHRASES: one letter from «أبق إلى» 37:140, so
    only a whole island decode, phrase_guarded); «أعطيني باقي الآية» (aatini_baqi_aya); «الكلمة الموالية»
    (kalima_taliya); «استراحة (قصيرة)» written «السراحه (قصير)»; «صدق» written «سبق» (FORMULA_FIRST); the formula said
    alone through the island decode (Tracker._island_pass); island words «عد» / «نعد» («عاود») and the forms of his
    English "stop" («اتق», «اتب», «اتقط»), "pause" («خز», «رز») and "repeat" («ربت», «بت») said alone. Not taken:
    «صدق الله» alone (Qur'an text), «ن» (his "next": a Qur'an letter, 68:1), single letters.
  * Said twice: the same command again within REPEAT_S of the end of the last one is consumed, not fired again (the
    reciter repeating a command the app had not reacted to yet); formula included.
  * Consumed spans (session seconds): a word lying mostly inside a fired span, or starting in one, is a re-decode of
    the command (the buffer is re-decoded every 0.8 s): dropped, so a command fires once.
  * Island word (user, 2026-10-10: «كلمة» said alone = next; a Qur'an word, so never a template): the rolling decode glues
    a lone short word onto the word before it, even across 2 s of silence (measured 3/72), so a burst of speech of
    ISLAND_MIN_S-ISLAND_MAX_S with ISLAND_GAP_S of quiet frames before and after it (island_bursts, on the session's
    frame energy) is decoded once more, alone, by the same model, padded with its own quiet (ISLAND_PRE_S /
    ISLAND_POST_S; Tracker._island_pass): the only extra decode. Exactly one word of ISLAND_WORDS there fires its
    command (island_command; next: «كلمة»; 2026-10-11: replay «عاود» / «أعدها», pause «استراحة» written «اتراح»)
    unless it sounds like an expected word around the cursor (lone_guarded: expected_hit, one edit from one, or one
    holding the command's ISLAND_ROOTS root, كلم for next; before the start: the start page, at most 400 words); a whole
    command phrase found alone in an island decode fires too (via 'island', guarded like the rolling decode), «استراحة»
    alone included; off-track or with the commands off nothing is decoded. 18 island decodes in 33 min of the user's
    recitation (8 sessions, about 0.55 per minute), none fired (also with the 2026-10-11 words).
Measured (edge-tts voices mixed into the user's recordings, 2026-10-04/05, held-out voices, rolling decode at the
pauses): «الكلمة التالية» 81 % (with the 2026-10-10 forms and the island decode, implementation measured: 69/78 = 88 % on 16
held-out voices in the user's 3 pause contexts), «باقي الآية» 90 %, «عاودها مرّة» 79 %, «صدق الله العظيم» 92 %, «استراحة
قصيرة» 83 %; «كلمة» alone: 72/72 through the island decode (TTS, after 1 s and 2 s pauses); 0 false commands over the 8 recorded sessions, 20.7 min of Yasser, 1,402 benchmark decodes and the whole Qur'an text.
The 2026-10-11 variants (16 edge-tts voices x 2 rates after a 1 s pause in 3 contexts, 96 runs each; forms taken
from the calibration-recording context, then measured in the user's two pause contexts / all three): «باقي آية»
57/64 / 84/96, «بقية الآية» 60/64 / 90/96, «كمّل الآية» 62/64 / 91/96, «عاود مرّة» 48/64 / 71/96, «عاودها مرّة أخرى»
60/64 / 90/96, «عاود» alone 39/64 / 58/96 and «أعدها» alone 50/64 / 76/96 (island decode), «صدق الله مولانا العظيم»
60/64 / 90/96 (68/96 before), «صدق الله العلي العظيم» 90/96, «استراحة» alone 53/64 / 76/96, «راحة قصيرة» and
«استراحة صغيرة» 90/96; the shipped phrases unchanged (89-90/96; «عاودها مرّة» fires about 0.7 s later (median): it
waits for «أخرى»).
The user's 23 recordings (2026-10-11), spliced after a 1 s and a 2 s pause into 6 real pauses of his recitation (12 runs
each): 160/276 fired their command (75 before), 154/230 in the 5 quiet contexts (next 30/70, eyah 27/40, replay 28/40,
stop 39/50, pause 30/30); 17 recordings fire, 6 never (the model writes nothing usable, or «صدق الله» alone); 0 wrong
or double commands, no new mistake from a command. In the noisy PC-microphone session no island decode is possible.
Stdlib + recite.align.similarity (expected_hit only); it runs in Chaquopy, later in Pyodide.
"""
from __future__ import annotations

from collections.abc import Iterable, Sequence
from typing import NamedTuple

from .align import similarity

COMMANDS = ("next", "eyah", "replay", "stop", "pause")
SADAQA = ("صدق", "الله", "العظيم")

FORMULA_MAX_GAP = 4          # ~العظيم 1-4 words after ~صدق («صدق العظيم», «صدق ان الله العظيم», «صدق الله مولانا
                             # العظيم» decoded «صدق ا ل مولانا العظيم», 2026-10-11)
FORMULA_MIDDLE = frozenset("ا ان انه ل له العل العلي مانا ملانا مولانا".split())   # held after ~صدق at the end of
                             # a decode like ~الله: «صدق الله مولانا / العلي العظيم» as decoded (2026-10-11)
FORMULA_FIRST = frozenset({"سبق"})   # ~صدق also as the model wrote the user's «صدق» in one of his pauses (2026-10-11):
                             # «سبق» then ~العظيم within 1-4 words is in no mushaf window, nor one letter from one
FORMULA_SETTLE_S = 0.15      # complete: ~العظيم ends this long before the buffer end
COMMAND_SETTLE_S = 0.15      # a command phrase is complete once its last word ends this long before the buffer end
REPEAT_S = 2.0               # the same command again within this long after the end of the last one: said twice
EXTEND_WAIT_S = 1.0          # a phrase that begins a longer one of the same command («عاودها» / «عاودها مرّة») waits
                             # this long after its end for the rest (else «مرّة», a Qur'an word, would be an attempt)
EXPECTED_SIM = 0.75          # a decoded word this close to an expected word (or its prefix / suffix) is recitation
CONSUME_PAD_S = 0.05         # a fired span is consumed with this margin
CONSUME_START_SLACK_S = 0.15  # a word starting this close before a consumed span (or inside it) is a re-decode of it ...
CTC_FRAME_S = 0.08           # ... but a word starting one model frame before its end (or later) is the next word
ISLAND_GAP_S = 1.0           # island word (2026-10-10): no speech frame this long before and after its burst ...
ISLAND_MIN_S, ISLAND_MAX_S = 0.15, 1.6   # ... a burst of speech frames this long (quiet gaps < ISLAND_BRIDGE_S bridged)
ISLAND_BRIDGE_S = 0.12
ISLAND_PRE_S, ISLAND_POST_S = 1.0, 0.6   # the island decode: the burst with its own quiet tiled to this before / after ...
ISLAND_QUIET_S = 0.35        # ... taken from this much audio on each side of the burst
ISLAND_WORDS = {"next": frozenset("الكلمه اللمه كرم كلم كلما كلمت كلمه كلمهه لمه".split()),   # «كلمة» alone (kilma)
                # «عاود» / «أعدها» alone (2026-10-11, #9): no Qur'an words, but one letter from «عاد», «داود» / «بعدها»,
                # so never a template of the rolling decode
                # + «عد» / «نعد»: the user's own «(ن)عاود» (his recording, 2026-10-11): «عد» one letter from «عاد»,
                # «بعد», «عدد» ..., «نعد» a Qur'an word (19:84); «ربت» / «بت»: his English "repeat" (one letter from
                # «رب», «ربك» / «به», «بك» ...)
                "replay": frozenset("اعدها عاود عد نعد ربت بت".split()),
                # «استراحة» alone as the island decode writes it: one letter from «أتراب» (38:52), so not in the one-word
                # template; «خز» / «رز»: the user's English "pause" (one letter from «خذ», «خر» / «رزق», «رب»)
                "pause": frozenset("اتراح خز رز".split()),
                # the user's English "stop" said alone (his recordings, 2026-10-11): «اتق» is a Qur'an word (33:1
                # «اتق الله»), «اتب» / «اتقط» one letter from «اتبع» / «اتقن»; island only, guarded like the others
                "stop": frozenset("اتب اتق اتقط".split())}
ISLAND_QURAN = frozenset("كلم كلما كلمت كلمه اتق نعد".split())   # those that are Qur'an words: island only, mushaf-scan
                             # exempt
ISLAND_PHRASES = {"eyah": frozenset({"بق الي", "بق اليه"})}   # whole decodes of a lone burst, never a template of the
                             # rolling decode: the user's «باقي الآية» (2026-10-11) as his island decodes wrote it, one
                             # letter from «إذ أبق إلى» (37:140) / «به إليه» (13:36); guarded like a phrase of the expected
                             # words (phrase_guarded)
KALIMA_ROOT = "كلم"          # an expected word holding it (كلمات, وكلمته, يكلم ...) makes a lone «كلمة» recitation
ISLAND_ROOTS = {"next": KALIMA_ROOT}   # per command: an expected word holding the root guards its island words


def one_edit(a: str, b: str) -> bool:
    """a and b are equal or one edit apart (Levenshtein distance <= 1). Stdlib, no similarity backend."""
    if a == b:
        return True
    la, lb = len(a), len(b)
    if abs(la - lb) > 1:
        return False
    if la == lb:
        return sum(x != y for x, y in zip(a, b)) == 1
    if la > lb:
        a, b, la = b, a, lb
    i = 0
    while i < la and a[i] == b[i]:
        i += 1
    return a[i:] == b[i + 1:]


class Template(NamedTuple):
    """A command phrase: slots[k] = the decoded (normalized) forms accepted for its k-th word; glued = forms of the
    whole phrase decoded as one word. Listed forms only: no similarity score, the same words fire on every platform.
    tail: its last slot is UKHRA, a word said after a shorter phrase of the same command («عاودها مرّة» + «أخرى»): a
    match whose last word sounds like an expected word ends before it (command_hits)."""
    cmd: str                  # one of COMMANDS
    key: str
    slots: tuple              # tuple[frozenset[str], ...]
    glued: frozenset = frozenset()
    tail: bool = False


def template_hits(words: Sequence[str], tp: Template) -> list[tuple[int, int]]:
    """(first, last) word index of every match of one template: its slots filled by consecutive words, or its glued
    form by one word."""
    out = []
    n, k = len(words), len(tp.slots)
    for i in range(n):
        if words[i] in tp.glued:
            out.append((i, i))
        elif i + k <= n and all(words[i + s] in tp.slots[s] for s in range(k)):
            out.append((i, i + k - 1))
    return out


def command_hits(words: Sequence[str], templates: Iterable[Template],
                 expected: Iterable[str | None] = ()) -> list[tuple[int, int, Template]]:
    """Every command phrase of one decode -> [(first word, last word, template)] in word order, overlaps resolved (the
    longest match first, then the earliest). A tail template's match whose last word is (close to) an `expected` word
    (expected_hit) is left out: that word is recitation («فعدة من أيام أخر» 2:184 said right after «عاودها مرّة»;
    review 2026-10-11), the shorter phrase before it matches alone (tests: every tail template has one)."""
    expected = [e for e in expected if e]
    cand = sorted(((i, j, tp) for tp in templates for i, j in template_hits(words, tp)
                   if not (tp.tail and j > i and expected and expected_hit(words[j], expected))),
                  key=lambda h: (h[0] - h[1], h[0]))
    used: set[int] = set()
    out = []
    for i, j, tp in cand:
        if used.isdisjoint(range(i, j + 1)):
            used.update(range(i, j + 1))
            out.append((i, j, tp))
    return sorted(out, key=lambda h: h[0])


def partial_at_end(words: Sequence[str], templates: Iterable[Template]) -> int | None:
    """A phrase still being said: the last decoded words fill the first slots of a multi-word template -> the index
    of its first word (held out of this decode), else None."""
    n, best = len(words), None
    for tp in templates:
        for m in range(1, len(tp.slots)):
            if m <= n and all(words[n - m + s] in tp.slots[s] for s in range(m)):
                best = n - m if best is None else min(best, n - m)
    return best


def extendable(words: Sequence[str], tp: Template, templates: Iterable[Template]) -> bool:
    """`words` (a match of tp) are also the first words of a longer template of the same command: the rest may still
    come («عاودها» then «مرّة»)."""
    n = len(words)
    return any(t.cmd == tp.cmd and len(t.slots) > n and all(words[s] in t.slots[s] for s in range(n)) for t in templates)


def recited_templates(expected_seqs: Iterable[Sequence[str]], templates: Iterable[Template]) -> set[str]:
    """Keys of the templates matching the expected words around the cursor (in either spelling): recitation there."""
    seqs = [list(x) for x in expected_seqs]
    return {tp.key for tp in templates for x in seqs if template_hits(x, tp)}


def expected_hit(token: str, expected: Iterable[str | None]) -> bool:
    """The token is (close to) an expected word, or a beginning / end of one of 2+ letters (a word cut by the buffer
    or a hesitation, «بيس» for «بيسما» 2:90): then it is recitation, never a command."""
    for e in expected:
        if not e:
            continue
        if similarity(token, e) >= EXPECTED_SIM or (len(token) >= 2 and (e.startswith(token) or e.endswith(token))):
            return True
    return False


def sadaqa_like(word: str) -> bool:
    """The formula's first word: one edit from صدق, or one of FORMULA_FIRST."""
    return one_edit(word, SADAQA[0]) or word in FORMULA_FIRST


def holds_formula(expected: Iterable[str | None]) -> bool:
    """The expected words around the cursor hold both ~صدق and ~العظيم: the formula there is recitation."""
    ex = [e for e in expected if e]
    return any(sadaqa_like(e) for e in ex) and any(one_edit(e, SADAQA[2]) for e in ex)


def formula_hits(words: Sequence[str], ends: Sequence[float], buf_s: float,
                 expected: Iterable[str | None] = ()) -> list[tuple[int, int, bool]]:
    """«صدق الله العظيم» in one decode -> [(first word, last word, complete)] (word indices, inclusive). Complete = a
    full formula ending FORMULA_SETTLE_S before the buffer end (`stop`); the others (a full one still being said, or
    a beginning «صدق» / «صدق الله» / «صدق الله مولانا» as the last decoded words, unless it is the expected text) are
    only held out of this decode. Nothing where the expected words hold the formula's words (holds_formula)."""
    expected = list(expected)
    if holds_formula(expected):
        return []
    out: list[tuple[int, int, bool]] = []
    used: set[int] = set()
    n = len(words)
    for i in range(n):
        if i in used or not sadaqa_like(words[i]):
            continue
        for j in range(i + 1, min(n, i + 1 + FORMULA_MAX_GAP)):
            if one_edit(words[j], SADAQA[2]):
                out.append((i, j, ends[j] <= buf_s - FORMULA_SETTLE_S))
                used.update(range(i, j + 1))
                break
    for k in range(max(0, n - FORMULA_MAX_GAP), n):   # a beginning still being said at the end of the decode
        if any(x in used for x in range(k, n)):
            continue
        if sadaqa_like(words[k]) and \
                all(one_edit(words[x], SADAQA[1]) or words[x] in FORMULA_MIDDLE for x in range(k + 1, n)) and \
                not expected_hit(words[k], expected):
            out.append((k, n - 1, False))
            break
    return out


def in_spans(s: float, e: float, spans: Iterable[tuple[float, float]]) -> bool:
    """A decoded word [s, e] (session seconds) is a re-decode of consumed audio: half of it or more inside a consumed
    span (padded by CONSUME_PAD_S), or it starts inside one (CTC smears a re-decoded word over the silence after it:
    «انتظرر» after «انتظر»). A word said right after the command (no pause) starts at its end: kept."""
    for a, b in spans:
        ov = min(e, b) - max(s, a)
        if ov > 0 and ov >= 0.5 * max(e - s, CTC_FRAME_S):
            return True
        if a - CONSUME_START_SLACK_S <= s < b - CONSUME_PAD_S - CTC_FRAME_S:
            return True
    return False


def overlaps(s: float, e: float, spans: Iterable[tuple[float, float]]) -> bool:
    return any(min(e, b) - max(s, a) > 0 for a, b in spans)


# ---------------------------------------------------------------- command phrases (B3.15)
# Decoded forms of TTS voices (6 screening + 10 held-out Arabic voices, 3 rates) mixed into the user's recordings,
# 2026-10-04/05; extend a slot with the forms the model writes for the user's own voice (a data-only change; the
# mushaf scan of tests/test_voice_commands.py must stay empty).
UKHRA = frozenset("اخر اخري اخرير اخي".split())   # «أخرى» after «عاودها مرّة» (the tail templates' last slot)
AWEDHA_MARRA_GLUED = frozenset("اومرش عاودمر عاودمره عاودهامر عاودهامره عاومر عاوهامر عودهامر".split())   # «عاودها
                             # مرّة» / «عاود مرّة» decoded as one word
COMMAND_TEMPLATES: tuple[Template, ...] = (
    Template("next", "kalima_taliya",   # «الكلمة التالية», «كلمة التالية», «كلمة تالية» (user, 2026-10-10); never «تال»
             # alone nor «كلمهتال» glued: one letter from «فلما كلمه قال» (12:54) / «كل مختال» glued (31:18);
             # «الكلمة الموالية» (Tunisian «the following word», the user's recording, 2026-10-11)
             (frozenset("الكل الكللمه الكلم الكلمه الكلمهه الكلمهي الكمه اللمه المه كلم كلما كلمت كلمه كلمهه كمه "
                        "لمه".split()),
              frozenset("التال التاله التالي التاليه التل التلي تاله تالي تاليه تري تل تلي يالي "
                        "الموال الموالي المواليه المواله الموله المويله".split())),
             frozenset("الكلمهال الكلمهالتال الكلمهالتاله الكلمهالتالي الكلمهالتاليه كالتال كلمهالتال كلمهالتالي "
                       "كلمهالتاليه كلمهتالي كلمهتاليه".split())),
    Template("eyah", "baqi_aya",   # «باقي الآية», «باقي آية», «بقية الآية» (user, 2026-10-11, #9); never «بق»
             # (one letter from «أبق إلى» 37:140), «بقيت» («بقيت الله» 11:86), «الا» («بشيء إلا» 13:14), glued
             # «باقاي» («بلقاء» 30:8)
             (frozenset("باق باقي بقي بقيه".split()),
              frozenset("ال الاي الايه الي اليه اي ايه".split())),
             frozenset("باقياي باقيايه بقياي بقيايه بقيهالايه".split())),
    Template("eyah", "bqi_aya",   # the user's Tunisian «بْقِي آية» / «باقي الآية» as the model writes it (his recordings,
             # 2026-10-11): «بق» (and «ذات» in some pauses) never with «الي» / «اليه» («إذ أبق إلى» 37:140, «به إليه»
             # 13:36: one letter away; those two only through the island decode, ISLAND_PHRASES) nor «ال» («ذات ال…»,
             # a cut «ذات اليمين» 18:18)
             (frozenset("بق ذات".split()),
              frozenset("الاي الايه اي ايه".split())),
             frozenset()),
    Template("eyah", "aatini_baqi_aya",   # «أعطيني باقي الآية» (Tunisian «give me the rest of the ayah», the user's
             # recording, 2026-10-11): without it the leftover «اعطيني» would be an attempt before the next word
             (frozenset("ااتني اعتني اعطني اعطيني تاتني تعتن تعتني تعني عتني عطيني فعتن ناتني نعتن نعتني نعني "
                        "واتن".split()),
              frozenset("باق باقي بق بقي".split()),
              frozenset("الاي الايه الي اليه اي ايه".split())),
             frozenset()),
    Template("eyah", "kammel_aya",   # «كمّل الآية» (Tunisian «complete the ayah»; user, 2026-10-11, #9); never
             # «كل» (a Qur'an word: «كل آية» 6:25), «ايه» / «الا» after it («كل آية», «إن كل إلا» 38:14), glued
             # «كملا» («عملا»)
             (frozenset("كامل كمل كملل".split()),
              frozenset("ال الاي الايه الي اليه اي".split())),
             frozenset("كملاي كملالايه".split())),
    Template("replay", "awedha",   # «عاودها»
             (frozenset("ااودها ااودهار عاودها عاودهار عاودهاروا عاودهام عاوضها ععاودها وعاودها يعاودها".split()),),
             frozenset()),
    Template("replay", "awedha_marra",   # «عاودها مرّة», «عاود مرّة» (user, 2026-10-11, #9); never «عاد» (a
             # Qur'an word) nor «عاو» («كل عام مرة» 9:126); + the first words of awedha_marra_ukhra (review
             # 2026-10-11: «ااودها مر» fired as «ااودها» and left «مر أخرى» to the alignment)
             (frozenset("اادها ااودها اعاودها اعودها اودها عادها عاود عاوددها عاودها عاودهام عاوذ عودها "
                        "ععاودها".split()),
              frozenset("م مر مره مرش مري مه".split())),
             AWEDHA_MARRA_GLUED),
    Template("replay", "awedha_marra_ukhra",   # «عاودها مرّة أخرى» (2026-10-11, #9): «أخرى» left over would be
             # an attempt before the next word; as the longer phrase, «عاودها مرّة» at the end of a decode waits
             # EXTEND_WAIT_S; an expected «أخر» / «أخرى» there stays recitation (tail)
             (frozenset("اادها ااودها اعاودها اعودها اودها عادها عاود عاوددها عاودها عاودهام عاوذ عودها "
                        "ععاودها".split()),
              frozenset("م مر مره مرش مري مه".split()),
              UKHRA),
             frozenset(), tail=True),
    Template("replay", "awedha_marra_glued_ukhra",   # the same with «عاودها مرّة» decoded as one word (11/96 TTS runs,
             # review 2026-10-11): without it the glued word fired at once and «أخرى» was left over
             (AWEDHA_MARRA_GLUED, UKHRA),
             frozenset(), tail=True),
    Template("pause", "istiraha_qasira",   # «استراحة قصيرة», «راحة قصيرة», «استراحة صغيرة» (user, 2026-10-11, #9)
             (frozenset("ااسراحه ااستراح ااستراحه اراح اراحه اتراح اتراحه استراح استراحا استراحه اسراح اسراحه راح راحه "
                        "ستراحه ااسراح السراح السراحه والاستراح".split()),   # «السراحه»: the user's «استراحة» (2026-10-11)
              frozenset("الصغير ص صغ صغير صغيره قصير قصيرا قصيرر قصيرم قصيرن قصيره قير قيره قيرن قسيرا "
                        "قسيره خسيرا".split())),
             frozenset("السراحسيرا".split())),
    Template("pause", "istiraha",   # «استراحة» alone (2026-10-11, #9; no Qur'an word); never «اراح» / «اتراح»: one
             # letter from «أراد» / «أتراب» (38:52), nor «السراح» («السراء» 3:134)
             (frozenset("ااستراح ااستراحه اراحه اتراحه استراح استراحه استراحوا اسراح اسراحه السراحه".split()),),
             frozenset()),
)


# ---------------------------------------------------------------- island words (B3.15, user 2026-10-10)
def island_bursts(energetic: Sequence[bool], frame_s: float) -> list[tuple[int, int]]:
    """Frame spans [a, b) of the bursts of speech frames lasting ISLAND_MIN_S-ISLAND_MAX_S (gaps < ISLAND_BRIDGE_S
    bridged) with ISLAND_GAP_S of non-speech frames before and after them inside `energetic` (the history must hold
    that quiet: a burst near either edge never counts)."""
    runs: list[list[int]] = []
    k, n = 0, len(energetic)
    while k < n:
        if energetic[k]:
            j = k
            while j < n and energetic[j]:
                j += 1
            if runs and (k - runs[-1][1]) * frame_s < ISLAND_BRIDGE_S:
                runs[-1][1] = j
            else:
                runs.append([k, j])
            k = j
        else:
            k += 1
    out = []
    for i, (a, b) in enumerate(runs):
        before = (a - (runs[i - 1][1] if i else 0)) * frame_s
        after = ((runs[i + 1][0] if i + 1 < len(runs) else n) - b) * frame_s
        if ISLAND_MIN_S <= (b - a) * frame_s <= ISLAND_MAX_S and before >= ISLAND_GAP_S and after >= ISLAND_GAP_S:
            out.append((a, b))
    return out


def lone_guarded(token: str, expected: Iterable[str | None], root: str | None = KALIMA_ROOT) -> bool:
    """A lone word near expected words that sound like it is recitation: expected_hit, one edit from one («كلا» 78:4,
    «الم» 2:1, both often recited alone, are one edit from كلم / كلما; «عاد» from عاود), or an expected word holding
    `root` (the command's ISLAND_ROOTS; none: no root check)."""
    expected = [e for e in expected if e]
    return expected_hit(token, expected) or any(one_edit(token, e) or bool(root and root in e) for e in expected)


def phrase_guarded(words: Sequence[str], expected: Iterable[str | None]) -> bool:
    """Consecutive expected words each one edit from the words of the phrase (in order): recitation («ابق الي» 37:140
    for «بق الي»). `expected` may be both spellings one after the other: a window across them only guards more."""
    ex = [e for e in expected if e]
    k = len(words)
    return any(all(one_edit(w, e) for w, e in zip(words, ex[i:i + k])) for i in range(len(ex) - k + 1))


def island_command(words: Sequence[str], expected: Iterable[str | None]) -> str | None:
    """The island decode of a lone burst -> the command it says: exactly one word of ISLAND_WORDS (not lone_guarded),
    or exactly a phrase of ISLAND_PHRASES (not phrase_guarded); else None."""
    expected = list(expected)
    if len(words) == 1:
        for cmd, forms in ISLAND_WORDS.items():
            if words[0] in forms and not lone_guarded(words[0], expected, ISLAND_ROOTS.get(cmd)):
                return cmd
        return None
    said = " ".join(words)
    for cmd, forms in ISLAND_PHRASES.items():
        if said in forms and not phrase_guarded(words, expected):
            return cmd
    return None
