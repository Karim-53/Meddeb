"""Per-word tajweed-coloured HTML for the UI: Tanzil's letters in the colours of quran.com's `uthmani_tajweed` markup.

The source markup wraps letters in <tajweed class=RULE>...</tajweed>; a rule can span the space
between two words (e.g. idgham across a word boundary), so we first flatten the markup into a
(char, rule) sequence, re-base its letters on the Tanzil text (v0.13, #28: quran.com's letters differ
in about 6,950 words), split on spaces, then re-wrap each word. Words are finally mapped onto the
imla'i word segmentation used by the aligner (see recite.quran_text.align_display_tokens).
"""
from __future__ import annotations

import html
import re
from functools import lru_cache

from .normalize import alef_insensitive, normalize
from .quran_text import _PAUSE_TOKEN_RE, load_quran

_TOKEN_RE = re.compile(r"<tajweed class=(\w+)>|</tajweed>|<span class=end>.*?</span>|<[^>]+>")
# v0.13 (#28): quran.com's uthmani_tajweed writes the small (superscript) alif ٰ U+0670 as ٲ U+0672 (alef with a wavy
# hamza, drawn «أْ» by Amiri Quran) wherever no tatweel carries it: 1,561 places (ذَٰلِكَ 2:2, ٱلصَّلَوٰةَ 2:3). Each is a
# U+0670 of the Tanzil text, and Hafs never uses U+0672.
_SOURCE_FIXES = str.maketrans({"\u0672": "\u0670"})
# what only quran.com has and the page keeps when re-based on Tanzil (#28): kashidas, ZWNJ, pause marks ۖ..ۜ ۞ ۩
_KEPT = frozenset("\u0640\u200c\u06de\u06e9" + "".join(map(chr, range(0x06D6, 0x06DD))))
# quran.com's short vowel where Tanzil writes its tanween: the iqlab of ضَلَـٰلاَۢ (Tanzil ضَلَـٰلًۢا, 10 words)
_TANWEEN_VOWEL = {"\u064b": "\u064e", "\u064c": "\u064f", "\u064d": "\u0650"}
_WORD_RE = re.compile(r"\S+")
_BASMALA = "بسم الله الرحمن الرحيم"

# colours used by the common "tajweed mushaf" schemes (same keys as quran.com classes)
TAJWEED_COLORS: dict[str, str] = {
    "ham_wasl": "#AAAAAA", "slnt": "#AAAAAA", "laam_shamsiyah": "#AAAAAA",
    "madda_normal": "#537FFF", "madda_permissible": "#4050FF", "madda_necessary": "#000EBC",
    "madda_obligatory": "#2144C1",
    "qalaqah": "#DD0008", "ikhafa_shafawi": "#D500B7", "ikhafa": "#9400A8",
    "idgham_shafawi": "#58B800", "iqlab": "#26BFFD", "idgham_ghunnah": "#169777",
    "idgham_wo_ghunnah": "#169200", "ghunnah": "#FF7E1E", "idgham_mutajanisayn": "#A1A1A1",
}
TAJWEED_LABELS: dict[str, str] = {
    "ham_wasl": "همزة وصل", "slnt": "حرف صامت", "laam_shamsiyah": "لام شمسية",
    "madda_normal": "مد طبيعي", "madda_permissible": "مد جائز", "madda_necessary": "مد لازم",
    "madda_obligatory": "مد واجب", "qalaqah": "قلقلة", "ikhafa_shafawi": "إخفاء شفوي",
    "ikhafa": "إخفاء", "idgham_shafawi": "إدغام شفوي", "iqlab": "إقلاب",
    "idgham_ghunnah": "إدغام بغنة", "idgham_wo_ghunnah": "إدغام بغير غنة", "ghunnah": "غنة",
    "idgham_mutajanisayn": "إدغام متجانسين",
}


def flatten(markup: str) -> list[tuple[str, str | None]]:
    out: list[tuple[str, str | None]] = []
    cls: str | None = None
    pos = 0
    for m in _TOKEN_RE.finditer(markup):
        for ch in html.unescape(markup[pos:m.start()]).translate(_SOURCE_FIXES):
            out.append((ch, cls))
        tok = m.group(0)
        if m.group(1):
            cls = m.group(1)
        elif tok == "</tajweed>":
            cls = None
        pos = m.end()
    for ch in html.unescape(markup[pos:]).translate(_SOURCE_FIXES):
        out.append((ch, cls))
    return out


def _written_words(text: str) -> list[tuple[int, int]]:
    """(start, end) of each written word of an ayah's text: the standalone pause-mark tokens (۞, ۩) are no words."""
    return [m.span() for m in _WORD_RE.finditer(text) if not _PAUSE_TOKEN_RE.match(m.group())]


def _rebase_on_tanzil(chars: list[tuple[str, str | None]], text: str) -> list[tuple[str, str | None]] | None:
    """v0.13 (#28, D1): the ayah's (char, rule) sequence with Tanzil's letters (`text`) and quran.com's rules; None when
    the written-word counts differ (2:181, 13:37: بَعْدَمَا is one written word in quran.com, two in Tanzil). Each written
    word is diffed with its Tanzil word (difflib; the same result as one diff of the whole ayah, in half the time). An
    equal char keeps its rule, a replaced one takes the rule of the source char at the same offset; a char only Tanzil
    has takes the rule its two source neighbours share (else none), unless the same mark was dropped a place or two away
    in the word (a moved tanween: قَلِيلاً -> قَلِيلًا, shadda before / after the vowel), or, for a tanween, its short
    vowel (the iqlab of ضَلَـٰلاَۢ -> ضَلَـٰلًۢا, 10 words, where no tanween was dropped): it keeps that mark's rule. The
    kashidas, ZWNJ and pause marks only quran.com has stay, and so does all between the words (the spaces, the
    standalone ۞ / ۩ split_words drops)."""
    from difflib import SequenceMatcher

    src = "".join(c for c, _ in chars)
    rules = [r for _, r in chars]
    src_words, tanzil_words = _written_words(src), _written_words(text)
    if len(src_words) != len(tanzil_words):
        return None
    out: list[tuple[str, str | None]] = []

    def insert(p: int, ch: str, dropped: set[int]) -> None:
        for mark in (ch, _TANWEEN_VOWEL[ch]) if ch in _TANWEEN_VOWEL else (ch,):
            for d in (p, p - 1, p + 1, p - 2, p + 2, p - 3, p + 3):
                if d in dropped and src[d] == mark:
                    dropped.discard(d)
                    out.append((ch, rules[d]))
                    return
        prev = rules[p - 1] if p > 0 else None
        nxt = rules[p] if p < len(rules) else None
        out.append((ch, prev if prev == nxt else None))

    pos = 0
    for (lo, hi), (t_lo, t_hi) in zip(src_words, tanzil_words):
        out.extend(chars[pos:lo])
        pos = hi
        word = text[t_lo:t_hi]
        ops = [(op, lo + i1, lo + i2, j1, j2)        # source offsets in the ayah: the neighbours of a word's edge too
               for op, i1, i2, j1, j2 in SequenceMatcher(None, src[lo:hi], word, autojunk=False).get_opcodes()]
        dropped = {i for op, i1, i2, j1, j2 in ops if op != "equal" for i in range(i1 + j2 - j1, i2)
                   if src[i] not in _KEPT}
        for op, i1, i2, j1, j2 in ops:
            if op == "equal":
                out.extend(zip(word[j1:j2], rules[i1:i2]))
                continue
            for k in range(max(i2 - i1, j2 - j1)):
                if k < j2 - j1:
                    if i1 + k < i2:
                        out.append((word[j1 + k], rules[i1 + k]))
                    else:
                        insert(i2, word[j1 + k], dropped)
                elif src[i1 + k] in _KEPT:
                    out.append(chars[i1 + k])
    out.extend(chars[pos:])
    return out


def split_words(chars: list[tuple[str, str | None]]) -> list[list[tuple[str, str | None]]]:
    words: list[list[tuple[str, str | None]]] = []
    cur: list[tuple[str, str | None]] = []
    for ch, cls in chars:
        if ch.isspace():
            if cur:
                words.append(cur)
                cur = []
        else:
            cur.append((ch, cls))
    if cur:
        words.append(cur)
    # drop standalone pause-mark tokens
    return [w for w in words if not _PAUSE_TOKEN_RE.match("".join(c for c, _ in w))]


def word_to_html(word: list[tuple[str, str | None]]) -> str:
    parts: list[str] = []
    buf: list[str] = []
    cur: str | None = None

    def flush() -> None:
        if not buf:
            return
        text = html.escape("".join(buf))
        if cur:
            parts.append(f'<span class="tj tj-{cur}" title="{TAJWEED_LABELS.get(cur, cur)}">{text}</span>')
        else:
            parts.append(text)
        buf.clear()

    for ch, cls in word:
        if cls != cur:
            flush()
            cur = cls
        buf.append(ch)
    flush()
    return "".join(parts)


def _groups(u_plain: list[str], s_toks: list[str]) -> list[list[int]]:
    """Map Uthmani token indices onto simple words (1:1, 1:2, 2:1 moves, similarity-scored)."""
    from difflib import SequenceMatcher

    def sim(a: str, b: str) -> float:
        return SequenceMatcher(None, a, b).ratio()

    ua = [alef_insensitive(t) for t in u_plain]
    sa = [alef_insensitive(t) for t in s_toks]
    n, m = len(ua), len(sa)
    INF = float("inf")
    best = [[INF] * (m + 1) for _ in range(n + 1)]
    back: list[list[tuple[int, int] | None]] = [[None] * (m + 1) for _ in range(n + 1)]
    best[0][0] = 0.0
    for i in range(n + 1):
        for j in range(m + 1):
            if best[i][j] == INF:
                continue
            cur = best[i][j]
            moves = []
            if i < n and j < m:
                moves.append((1, 1, 1 - sim(ua[i], sa[j])))
            if i < n and j + 1 < m:
                moves.append((1, 2, 1 - sim(ua[i], sa[j] + sa[j + 1]) + 0.05))
            if i + 1 < n and j < m:
                moves.append((2, 1, 1 - sim(ua[i] + ua[i + 1], sa[j]) + 0.05))
            if i < n:
                moves.append((1, 0, 1.0))
            if j < m:
                moves.append((0, 1, 1.0))
            for di, dj, c in moves:
                if cur + c < best[i + di][j + dj]:
                    best[i + di][j + dj], back[i + di][j + dj] = cur + c, (di, dj)
    groups: list[list[int]] = [[] for _ in range(m)]
    i, j = n, m
    pending_u: list[int] = []
    while i > 0 or j > 0:
        di, dj = back[i][j]  # type: ignore[misc]
        i, j = i - di, j - dj
        if (di, dj) == (1, 1):
            groups[j] = [i] + pending_u
            pending_u = []
        elif (di, dj) == (1, 2):
            groups[j] = [i] + pending_u
            groups[j + 1] = []
            pending_u = []
        elif (di, dj) == (2, 1):
            groups[j] = [i, i + 1] + pending_u
            pending_u = []
        elif (di, dj) == (1, 0):
            pending_u = [i] + pending_u
        else:
            groups[j] = []
    if pending_u and groups:
        groups[0] = pending_u + groups[0]
    return groups


@lru_cache(maxsize=8192)
def ayah_word_html(surah: int, ayah: int) -> tuple[str, ...]:
    """HTML per imla'i word of the ayah (same length as Quran.ayah(surah, ayah).words)."""
    q = load_quran()
    ay = q.ayah(surah, ayah)
    chars = flatten(q.tajweed_html(surah, ayah))
    words = split_words(chars)
    plain = ["".join(c for c, _ in w) for w in words]   # the grouping below reads quran.com's words (#22 unchanged)
    # v0.13 (#28, D1): Tanzil's letters (quran_text already drops the basmala it prepends to ayah 1: be defensive);
    # an ayah whose written-word count would change keeps quran.com's (2:181, 13:37: بَعْدَمَا = بَعْدَ مَا)
    text = ay.uthmani
    if ayah == 1 and surah not in (1, 9) and normalize(" ".join(text.split()[:4])) == _BASMALA:
        text = " ".join(text.split()[4:])
    rebased = _rebase_on_tanzil(chars, text)
    if rebased is not None:
        words = split_words(rebased)
    # quran.com keeps the basmala out of ayah 1, but be defensive
    if ayah == 1 and surah not in (1, 9) and len(plain) >= 4 and normalize(" ".join(plain[:4])) == _BASMALA \
            and not ay.norm.startswith(_BASMALA):
        words, plain = words[4:], plain[4:]
    s_toks = [w.simple for w in ay.words]
    if len(plain) == len(s_toks):
        groups = [[i] for i in range(len(plain))]
    else:
        groups = _groups(plain, s_toks)
    out: list[str] = []
    for g in groups:
        out.append(" ".join(word_to_html(words[i]) for i in g))
    return tuple(out)


def tajweed_css() -> str:
    return "\n".join(f".tj-{k}{{color:{v}}}" for k, v in TAJWEED_COLORS.items())
