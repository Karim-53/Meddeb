"""Common ASR interface: 16 kHz float32 mono audio in -> words (+ timestamps, + confidence) out."""
from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np


@dataclass
class WordHyp:
    text: str                 # raw model output for the word (may contain tashkeel)
    start: float | None = None
    end: float | None = None
    prob: float | None = None  # model confidence in [0, 1] when available


@dataclass
class Transcript:
    text: str
    words: list[WordHyp] = field(default_factory=list)
    meta: dict = field(default_factory=dict)  # backend-specific extras (segments, logprobs...)

    def as_dict(self) -> dict:
        return {
            "text": self.text,
            "words": [
                {"text": w.text, "start": w.start, "end": w.end, "prob": w.prob} for w in self.words
            ],
            "meta": self.meta,
        }


class ASRBackend:
    name: str = "base"
    supports_word_prob: bool = False
    supports_streaming: bool = False

    def load(self) -> None:  # pragma: no cover - interface
        raise NotImplementedError

    def transcribe(self, audio: np.ndarray, sr: int = 16000) -> Transcript:  # pragma: no cover
        raise NotImplementedError

    def unload(self) -> None:
        pass

    def timed_transcribe(self, audio: np.ndarray, sr: int = 16000) -> tuple[Transcript, float]:
        t0 = time.perf_counter()
        tr = self.transcribe(audio, sr)
        return tr, time.perf_counter() - t0


def gpu_mem_used_mb() -> float | None:
    """Device-wide used VRAM (MB) via nvidia-smi — works for CTranslate2/ONNX too, and does not
    need a torch CUDA context (torch cu126 cannot create one on this machine's driver 531.41)."""
    import subprocess

    try:
        out = subprocess.run(
            ["nvidia-smi", "--query-gpu=memory.used", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=10, check=True,
        ).stdout.strip().splitlines()[0]
        return float(out)
    except Exception:  # noqa: BLE001
        return None
