"""NeMo FastConformer-CTC exports (Muno459/fastconformer-quran) through ONNX Runtime.

The ONNX graph contains the encoder + CTC head only: it takes NeMo-style log-mel features
(``audio_signal`` [1, 80, T] float32, ``length`` int64[1]) and returns ``logprobs`` [1, T', 1025]
(log-softmax, blank = 1024, one frame per 80 ms after the 8x subsampling). The feature front end
is re-implemented here in numpy after NeMo's ``AudioToMelSpectrogramPreprocessor`` /
``FilterbankFeatures`` (16 kHz, 25 ms Hann window, 10 ms hop, n_fft 512, 80 slaney mel bands
0-8 kHz, power spectrum, log(x + 2^-24), per-feature mean/std normalization, pre-emphasis
0.97, no dither at inference). The model author's own numpy pipeline
(``tajweed/aligner.py`` in the HF repo, NPL-1.1) was used as the reference while validating it;
that file is not copied here.

Decoding is greedy CTC over the SentencePiece pieces listed in ``tokens.txt`` (``▁`` marks a
word start), so the output keeps the model's diacritics (harakat). Word times come from the first
/ last frame of the word's tokens, the confidence is the mean over the word's non-blank frames of
exp(max log-prob).
"""
from __future__ import annotations

import math
import os
from pathlib import Path
from typing import Callable

import numpy as np

from ..audio import chunk_bounds
from .base import ASRBackend, Transcript, WordHyp

SR = 16000
N_FFT = 512
WIN = 400          # 0.025 s
HOP = 160          # 0.010 s
N_MELS = 80
LOG_GUARD = 2.0 ** -24
NORM_EPS = 1e-5
SUBSAMPLING = 8
FRAME_S = HOP * SUBSAMPLING / SR   # 0.08 s per output frame
BLANK_ID = 1024


def slaney_mel_filterbank(sr: int = SR, n_fft: int = N_FFT, n_mels: int = N_MELS, fmin: float = 0.0,
                          fmax: float | None = None) -> np.ndarray:
    """librosa.filters.mel(htk=False, norm='slaney') in numpy: (n_mels, n_fft // 2 + 1)."""
    fmax = sr / 2 if fmax is None else fmax
    f_sp = 200.0 / 3
    min_log_hz = 1000.0
    min_log_mel = min_log_hz / f_sp
    logstep = math.log(6.4) / 27.0

    def hz_to_mel(f: np.ndarray) -> np.ndarray:
        f = np.asarray(f, dtype=np.float64)
        return np.where(f >= min_log_hz, min_log_mel + np.log(np.maximum(f, 1e-9) / min_log_hz) / logstep, f / f_sp)

    def mel_to_hz(m: np.ndarray) -> np.ndarray:
        m = np.asarray(m, dtype=np.float64)
        return np.where(m >= min_log_mel, min_log_hz * np.exp(logstep * (m - min_log_mel)), f_sp * m)

    mel_f = mel_to_hz(np.linspace(hz_to_mel(fmin), hz_to_mel(fmax), n_mels + 2))
    fft_f = np.linspace(0, sr / 2, n_fft // 2 + 1)
    fdiff = np.diff(mel_f)
    ramps = mel_f[:, None] - fft_f[None, :]
    lower = -ramps[:-2] / fdiff[:-1, None]
    upper = ramps[2:] / fdiff[1:, None]
    fb = np.maximum(0.0, np.minimum(lower, upper))
    fb *= (2.0 / (mel_f[2:] - mel_f[:-2]))[:, None]
    return fb.astype(np.float32)


class NemoLogMel:
    """NeMo FilterbankFeatures at inference time (dither off), numpy only."""

    def __init__(self, preemph: float | None = 0.97, center: bool = True, unbiased_std: bool = True) -> None:
        self.preemph = preemph
        self.center = center
        self.unbiased_std = unbiased_std
        self.window = np.hanning(WIN).astype(np.float32)          # torch.hann_window(periodic=False)
        self.fb = slaney_mel_filterbank()                           # (80, 257)

    def __call__(self, audio: np.ndarray) -> np.ndarray:
        """audio float32 mono 16 kHz -> (80, T) float32, per-feature normalized."""
        x = np.asarray(audio, dtype=np.float32)
        if self.preemph:
            x = np.concatenate([x[:1], x[1:] - self.preemph * x[:-1]])
        if self.center:
            # torch.stft(center=True, pad_mode="reflect"); the 400-sample window sits in the
            # middle of each 512-sample frame, so frame t covers samples [t*hop-200, t*hop+200)
            pad = N_FFT // 2
            if len(x) < pad + 1:
                x = np.pad(x, (0, pad + 1 - len(x)))
            x = np.pad(x, (pad, pad), mode="reflect")
            n_frames = 1 + (len(x) - N_FFT) // HOP
            offset = (N_FFT - WIN) // 2
        else:
            x = np.pad(x, (0, WIN - 1))
            n_frames = max(1, 1 + (len(x) - WIN) // HOP)
            offset = 0
        idx = offset + HOP * np.arange(n_frames)[:, None] + np.arange(WIN)[None, :]
        frames = x[idx] * self.window
        spec = np.fft.rfft(frames, n=N_FFT, axis=1)
        power = (spec.real ** 2 + spec.imag ** 2).astype(np.float32)   # (T, 257)
        mel = power @ self.fb.T                                          # (T, 80)
        feats = np.log(mel + LOG_GUARD).T                                # (80, T)
        mean = feats.mean(axis=1, keepdims=True)
        std = feats.std(axis=1, keepdims=True, ddof=1 if (self.unbiased_std and feats.shape[1] > 1) else 0)
        return ((feats - mean) / (std + NORM_EPS)).astype(np.float32)


def greedy(lp: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Greedy CTC per output frame: the best token id and its probability exp(max log-prob)."""
    ids = lp.argmax(axis=1)
    return ids, np.exp(lp[np.arange(len(ids)), ids])


def _preload_cuda_dlls() -> None:
    """onnxruntime-gpu (CUDA 12 build) needs cuBLAS / cuDNN 9 DLLs: torch ships them in torch/lib."""
    try:
        import torch  # noqa: F401

        lib = Path(torch.__file__).parent / "lib"
        if lib.exists() and hasattr(os, "add_dll_directory"):
            os.add_dll_directory(str(lib))
            os.environ["PATH"] = str(lib) + os.pathsep + os.environ.get("PATH", "")
    except Exception:  # noqa: BLE001
        pass


class OnnxCtcBackend(ASRBackend):
    supports_word_prob = True

    def __init__(self, name: str, model_dir: str | Path, device: str = "cpu", quantized: bool = False,
                 chunk_s: float | None = 30.0, preemph: float | None = 0.97, threads: int | None = None,
                 onnx_file: str = "onnx/model.onnx", onnx_q8_file: str = "onnx/model.q8.onnx",
                 encoder: Callable[[np.ndarray], tuple[np.ndarray, np.ndarray]] | None = None) -> None:
        # chunk_s: the encoder is full-context (O(T^2) attention, positional table sized for
        # 5000 output frames = 6.7 min); long audio is cut on silence into chunks <= chunk_s
        # (recite.audio.chunk_bounds) and the times are offset. None = whole file in one pass.
        # encoder: the platform's model runtime (03_platforms.md §4), features (80, T) float32 -> (ids, conf)
        # per 80 ms output frame. None = onnxruntime in this process (PC); the Android app passes ONNX Runtime
        # Android through Chaquopy, so only the encoder pass is platform code.
        self.name = name
        self.model_dir = Path(model_dir)
        self.device = device
        self.quantized = quantized
        self.chunk_s = chunk_s
        self.threads = threads
        self.onnx_path = self.model_dir / (onnx_q8_file if quantized else onnx_file)
        self.tokens_path = self.model_dir / "tokens.txt"
        self.feat = NemoLogMel(preemph=preemph)
        self.session = None
        self.pieces: dict[int, str] = {}
        self.blank_id = BLANK_ID
        self.providers: list[str] = []
        self.encoder = encoder

    def load(self) -> None:
        for line in self.tokens_path.read_text(encoding="utf-8").splitlines():
            parts = line.rstrip("\n").split(" ")
            if len(parts) >= 2 and parts[-1].isdigit():
                self.pieces[int(parts[-1])] = " ".join(parts[:-1])
        self.blank_id = max(self.pieces) + 1 if self.pieces else BLANK_ID
        if self.encoder is not None:
            self.providers = ["injected encoder"]
            return
        import onnxruntime as ort

        if self.device == "cuda":
            _preload_cuda_dlls()
            providers = ["CUDAExecutionProvider", "CPUExecutionProvider"]
        else:
            providers = ["CPUExecutionProvider"]
        available = ort.get_available_providers()
        providers = [p for p in providers if p in available] or ["CPUExecutionProvider"]
        so = ort.SessionOptions()
        so.log_severity_level = 3
        if self.threads:
            so.intra_op_num_threads = self.threads
        self.session = ort.InferenceSession(str(self.onnx_path), sess_options=so, providers=providers)
        self.providers = list(self.session.get_providers())
        if self.device == "cuda" and self.providers[0] != "CUDAExecutionProvider":
            print(f"[{self.name}] WARNING: CUDA requested but active providers are {self.providers}")
        print(f"[{self.name}] onnxruntime {ort.__version__} providers={self.providers} "
              f"file={self.onnx_path.name}")

    def unload(self) -> None:
        self.session = None
        import gc

        gc.collect()

    def logprobs(self, audio: np.ndarray) -> np.ndarray:
        """One encoder pass -> (T', 1025) log-probs."""
        if len(audio) < SR // 4:
            audio = np.pad(audio, (0, SR // 4 - len(audio)))
        feats = self.feat(audio)[None]
        length = np.array([feats.shape[2]], dtype=np.int64)
        (lp,) = self.session.run(["logprobs"], {"audio_signal": feats, "length": length})
        return lp[0]

    def frames(self, audio: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """One encoder pass -> (best token id, its probability) per 80 ms output frame."""
        if len(audio) < SR // 4:
            audio = np.pad(audio, (0, SR // 4 - len(audio)))
        if self.encoder is not None:
            return self.encoder(self.feat(audio))
        return greedy(self.logprobs(audio))

    def _decode(self, lp: np.ndarray, t0: float) -> list[WordHyp]:
        return self._decode_ids(*greedy(lp), t0)

    def _decode_ids(self, ids: np.ndarray, conf: np.ndarray, t0: float) -> list[WordHyp]:
        words: list[WordHyp] = []
        cur: list[str] = []
        cur_p: list[float] = []
        start = end = None
        prev = -1

        def flush() -> None:
            nonlocal cur, cur_p, start, end
            text = "".join(cur).strip()
            if text:
                words.append(WordHyp(text, start, end, float(np.mean(cur_p)) if cur_p else None))
            cur, cur_p, start, end = [], [], None, None

        for t, i in enumerate(ids.tolist()):
            if i == self.blank_id:
                prev = i
                continue
            if i == prev:                       # same token held over consecutive frames
                end = t0 + (t + 1) * FRAME_S
                cur_p.append(float(conf[t]))
                continue
            prev = i
            piece = self.pieces.get(i, "")
            if piece in ("<unk>", "<s>", "</s>", "<pad>"):
                continue
            if piece.startswith("▁"):
                flush()
                piece = piece[1:]
                start = t0 + t * FRAME_S
            elif start is None:
                start = t0 + t * FRAME_S
            end = t0 + (t + 1) * FRAME_S
            cur.append(piece)
            cur_p.append(float(conf[t]))
        flush()
        return words

    def transcribe(self, audio: np.ndarray, sr: int = SR) -> Transcript:
        assert sr == SR and (self.session is not None or self.encoder is not None)
        audio = np.asarray(audio, dtype=np.float32)
        bounds = chunk_bounds(audio, sr, max_len=self.chunk_s) if self.chunk_s else [(0, len(audio))]
        words: list[WordHyp] = []
        n_frames = 0
        for a, b in bounds:
            if b - a < sr // 20:
                continue
            ids, conf = self.frames(audio[a:b])
            n_frames += len(ids)
            words.extend(self._decode_ids(ids, conf, a / sr))
        return Transcript(text=" ".join(w.text for w in words), words=words,
                          meta={"chunks": len(bounds), "frames": n_frames, "providers": self.providers})
