"""The Progress page (U1.11): what has been learned and what needs revising, computed from the reading history.

A word counts as a mistake when its latest reading is a mistake (user's rule, 2026-09-27). An ayah is learned once it
was recited at least once entirely without any mistake or hint (issue #17, user 2026-10-14): one session read every
word of it right, none revealed by a hint (the user's marks made after that session's ■ amend it); its learned moment
is the end of the first such recitation. It is perfect when learned and none of its words counts as a mistake now. An
ayah is recited once each of its words has at least one reading (the old "learned" of 2026-09-27).

Table rows are the pages holding words of a recited ayah: Err = the words of the page that count as a mistake (any
word), Last revised = the oldest latest-reading date among the page's recited words (when its recited part was last
recited whole), surahs = the surahs printed on the page (#38, the page's Surah column). Weak page = the highest Err,
ties -> the smallest page (2026-10-01), with the colour of its Err (issue #10); Manzil = the oldest Last revised, ties -> the smallest page. Next to learn = the first ayah with a word never
read, moved back over the ayat with a mistake right before it (the user's rule of 2026-09-28, unchanged by #17). Last
learned = the most recently learned ayah among those with no word counting as a mistake (issue #10, 2026-10-13: an
ayah that still has a mistake is to learn again, so Last learned is never Next to learn). New ayat learned (issue #13)
= the learned ayat whose learned moment falls today, from this week's Monday, from 1 January; the readings' local
dates as stored, a date after today counts nowhere. Pages are the 15-line layout's (D12). Last revised (and the Manzil
date) is green under WARN_DAYS, orange from WARN_DAYS, red from REVISE_DAYS (user, 2026-10-04). Issue #13 (v0.12, D6):
next_advanced_today = Next to learn's mushaf position now minus its position at midnight (over each word's latest
reading dated before today), for the Progress page's "Next to learn" check; the Stats page's numbers are in stats.py,
never here (Android runs progress() after every mark).
"""
from __future__ import annotations

import datetime as dt
from functools import lru_cache

from .profile import Reading
from .quran_text import Quran, n_pages, page_ayat, page_lines, page_of

TOTAL_AYAT = 6236
WARN_DAYS = 6                # "last revised" turns orange from this age on (U1.11, user 2026-10-04)
REVISE_DAYS = 30             # ... and red from this one


@lru_cache(maxsize=1)
def word_pages() -> dict[str, int]:
    """'surah:ayah:idx' -> Madani page, from the 15-line layout (recite/data/mushaf_lines.json)."""
    out: dict[str, int] = {}
    for page in range(1, n_pages() + 1):
        for _line, s, a, idx, n in page_lines(page):
            for k in range(idx, idx + n):
                out[f"{s}:{a}:{k}"] = page
    return out


def err_level(n: int) -> str:
    return "ok" if n == 0 else ("warn" if n <= 2 else "bad")


def revised_level(revised: str, today: dt.date) -> str:
    """Colour of a "last revised" date (yyyy-mm-dd...): ok < WARN_DAYS <= warn < REVISE_DAYS <= bad (U1.11)."""
    age = (today - dt.date.fromisoformat(revised[:10])).days
    return "ok" if age < WARN_DAYS else ("warn" if age < REVISE_DAYS else "bad")


def _pct(n: int) -> float:
    return round(100 * n / TOTAL_AYAT, 1)


def new_learned(learned_at: dict[tuple[int, int], str], today: dt.date) -> dict:
    """Issue #13 (user, 2026-10-13): how many ayat were learned today, this week (from Monday) and this year. An ayah
    counts once, on the local date of its learned moment (learned_at: the end of its first recitation without a
    mistake or hint, #17; times are stored in the device's local time); a date after today counts in none."""
    monday = today - dt.timedelta(days=today.weekday())
    jan1 = today.replace(month=1, day=1)
    n = {"today": 0, "week": 0, "year": 0}
    for t in learned_at.values():
        try:
            d = dt.date.fromisoformat(t[:10])
        except ValueError:
            continue                    # a hand-edited time: counted nowhere rather than breaking the page
        if d > today:
            continue
        n["today"] += d == today
        n["week"] += d >= monday
        n["year"] += d >= jan1
    return {**n, "year_number": today.year}


def learned_moment(keys: list[str], history: dict[str, list[Reading]]) -> str | None:
    """Issue #17 (user, 2026-10-14: "an eya is counted toward total learned and last learned only if it got recited at
    least once entirely without any mistake or hint"): the end of the first session in which every word of the ayah was
    read right and none was revealed by a hint (the latest time among its words' readings of that session); None when
    no session did. A word's verdict in a session is its last reading of that session: the user's marks made on it
    after ■ belong to it (Profile.build_history), a + Mistake spoils it, a + Correct or a Remove of a false alarm
    rights it. A mark made outside a session's window is no recitation."""
    clean: dict[str, str] | None = None            # session -> the latest time of its right readings of these words
    for k in keys:
        last: dict[str, Reading] = {}
        first_t: dict[str, str] = {}
        hinted: set[str] = set()
        for r in history.get(k, ()):
            if r.session is None:
                continue
            last[r.session] = r
            first_t.setdefault(r.session, r.t)     # the time it was said (a later mark keeps it)
            if r.hinted:
                hinted.add(r.session)
        mine = {s: first_t[s] for s, r in last.items() if r.outcome == "ok" and s not in hinted}
        clean = mine if clean is None else {s: max(t, mine[s]) for s, t in clean.items() if s in mine}
        if not clean:
            return None
    return min(clean.values()) if clean else None


@lru_cache(maxsize=2)
def ayah_table(q: Quran) -> tuple[list[tuple[int, int]], dict[tuple[int, int], int], tuple[int, ...]]:
    """The ayat in mushaf order, their 0-based positions and their word counts."""
    order = sorted(q.ayat)
    return order, {sa: i for i, sa in enumerate(order)}, tuple(len(q.ayat[sa].words) for sa in order)


def ayah_index(sa: tuple[int, int] | None, q: Quran) -> int:
    """0-based mushaf position of (surah, ayah); None (every ayah recited, next_to_learn) -> 6236: the number of ayat
    before it."""
    order, index, _ = ayah_table(q)
    return len(order) if sa is None else index[(sa[0], sa[1])]


def _at_midnight(history: dict[str, list[Reading]], today: dt.date) -> dict[str, Reading]:
    """Each word's latest reading dated before today (the readings are in time order)."""
    day = today.isoformat()
    out: dict[str, Reading] = {}
    for k, rs in history.items():
        for r in reversed(rs):
            if r.t[:10] < day:
                out[k] = r
                break
    return out


def next_to_learn(latest: dict[str, Reading], mistakes: set[str], q: Quran) -> tuple[int, int] | None:
    """From 1:1 in mushaf order, the first ayah with a word never read, moved back over the ayat with a mistake right
    before it (1:4 when 1:4-1:6 have mistakes and 1:7 was never recited); None when every ayah was recited."""
    order = ayah_table(q)[0]
    for k, sa in enumerate(order):
        if any(w.key not in latest for w in q.ayat[sa].words):
            while k > 0 and any(w.key in mistakes for w in q.ayat[order[k - 1]].words):
                k -= 1
            return order[k]
    return None


def progress(history: dict[str, list[Reading]], q: Quran, today: dt.date) -> dict:
    pages_of = word_pages()
    latest = {k: rs[-1] for k, rs in history.items() if rs}
    mistakes = {k for k, r in latest.items() if r.outcome == "mistake"}

    def page(key: str) -> int:
        s, a, _ = map(int, key.split(":"))
        return pages_of.get(key) or page_of(s, a)

    learned: list[tuple[int, int]] = []
    learned_at: dict[tuple[int, int], str] = {}
    page_words: dict[int, list[str]] = {}
    perfect: list[tuple[int, int]] = []
    for sa in sorted({tuple(map(int, k.split(":")[:2])) for k in latest}):
        ay = q.ayat.get(sa)
        keys = [w.key for w in ay.words] if ay else []
        if not keys or any(k not in latest for k in keys):
            continue
        for k in keys:                              # a recited ayah: its page is in the table (Err, Last revised)
            page_words.setdefault(page(k), []).append(k)
        moment = learned_moment(keys, history)
        if moment is None:                          # issue #17: never recited entirely without a mistake or hint
            continue
        learned.append(sa)
        learned_at[sa] = moment
        if not any(k in mistakes for k in keys):
            perfect.append(sa)
    err: dict[int, int] = {}
    for k in mistakes:
        err[page(k)] = err.get(page(k), 0) + 1
    rows = []
    for pg in sorted(page_words):
        revised = min(latest[k].t for k in page_words[pg])[:10]
        e = err.get(pg, 0)
        rows.append({"page": pg, "err": e, "err_level": err_level(e), "last_revised": revised,
                     "revised_level": revised_level(revised, today),
                     # #38 (user, 2026-10-23): the surahs printed on the page, mushaf order (the page names them)
                     "surahs": list(dict.fromkeys(s for s, _a in page_ayat(pg)))})
    manzil = min(rows, key=lambda r: (r["last_revised"], r["page"])) if rows else None
    worst = max((r["err"] for r in rows), default=0)
    # U1.11 revised (user, 2026-10-01): ties go to the smallest page, the last revised date no longer counts
    weak = min((r for r in rows if r["err"] == worst), key=lambda r: r["page"]) if worst else None
    # issue #10 (user, 2026-10-13): "it does not make sense to have the learned eya the same as next to learn". Next to
    # learn moves back over the ayat that still have a mistake (user, 2026-09-28): such an ayah is to learn again, so
    # Last learned is the most recently completed ayah with no word counting as a mistake (never Next to learn, which
    # is either not learned or has a mistake)
    last = max(perfect, key=lambda sa: (learned_at[sa], sa)) if perfect else None
    nxt = next_to_learn(latest, mistakes, q)
    # issue #13 (D6): did Next to learn move forward today? (the Progress page's check; can be negative)
    then = _at_midnight(history, today)
    nxt_then = next_to_learn(then, {k for k, r in then.items() if r.outcome == "mistake"}, q)
    return {"total_ayat": TOTAL_AYAT,
            "learned": {"n": len(learned), "pct": _pct(len(learned))},
            "perfect": {"n": len(perfect), "pct": _pct(len(perfect))},
            "new_learned": new_learned(learned_at, today),
            "manzil": {"page": manzil["page"], "last_revised": manzil["last_revised"],
                       "revised_level": manzil["revised_level"]} if manzil else None,
            "weak": {"page": weak["page"], "err": weak["err"], "err_level": weak["err_level"]} if weak else None,
            "next_to_learn": {"surah": nxt[0], "ayah": nxt[1], "page": page_of(*nxt)} if nxt else None,
            "last_learned": {"surah": last[0], "ayah": last[1], "page": page_of(*last)} if last else None,
            "next_advanced_today": ayah_index(nxt, q) - ayah_index(nxt_then, q),
            "pages": rows}
