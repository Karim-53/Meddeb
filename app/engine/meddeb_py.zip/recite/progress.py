"""The Progress page (U1.11): what has been learned and what needs revising, computed from the reading history.

A word counts as a mistake when its latest reading is a mistake (user's rule, 2026-09-27). An ayah is learned once it
was recited at least once entirely without any mistake or hint (issue #17, user 2026-10-14): one session read every
word of it right, none revealed by a hint (the user's marks made after that session's ■ amend it); its learned moment
is the end of the first such recitation. It is perfect when learned and none of its words counts as a mistake now or
was last read after a hint (#96, D2: its latest reading hinted). An ayah is recited once each of its words has at least
one reading (the old "learned" of 2026-09-27).

Table rows are the pages holding words of a recited ayah: Err = the words of the page that count as a mistake (any
word), Last revised = the oldest latest-reading date among the page's recited words (when its recited part was last
recited whole), surahs = the surahs printed on the page (#38, the page's Surah column), starts = those whose ayah 1
is on it, words / learned_words = the page's words and those of Perfect ayat (#95, the Surah labels and the pie; v0.21 review: learned, no mistake or hint now). Weak page = the highest Err,
ties -> the smallest page (2026-10-01), with the colour of its Err (issue #10); Manzil = the oldest Last revised, ties -> the smallest page. Next to learn = the first ayah with a word never
read, moved back over the ayat with a mistake right before it (the user's rule of 2026-09-28, unchanged by #17). Last
learned = the most recently learned ayah among those with no word counting as a mistake (issue #10, 2026-10-13: an
ayah that still has a mistake is to learn again, so Last learned is never Next to learn). New ayat learned (issue #13)
= the learned ayat whose learned moment falls today, from this week's Monday, from 1 January; the readings' local
dates as stored, a date after today counts nowhere. Pages are the 15-line layout's (D12). Last revised (and the Manzil
date) is green under WARN_DAYS, orange from WARN_DAYS, red from REVISE_DAYS (user, 2026-10-04); once more than
PRAYER_PAGES pages hold a learned ayah, page 1 (Al-Fatiha) is always green, revised today (#117) and never the Manzil (#77). Issue #13 (v0.12, D6):
next_advanced_today = Next to learn's mushaf position now minus its position at midnight (over each word's latest
reading dated before today), for the Progress page's "Next to learn" check; the Stats page's numbers are in stats.py,
never here (Android runs progress() after every mark). #91 (v0.21, D4): learn_lock = the advice lock on Next to learn
(3 or more red pages besides its own, or more than 10 review cards due; none once it moved forward today).
"""
from __future__ import annotations

import datetime as dt
from functools import lru_cache

from .profile import Reading
from .quran_text import Quran, n_pages, page_ayat, page_lines, page_of

TOTAL_AYAT = 6236
WARN_DAYS = 6                # "last revised" turns orange from this age on (U1.11, user 2026-10-04)
REVISE_DAYS = 30             # ... and red from this one
FATIHA_PAGE = 1              # #77 (D4): Al-Fatiha's page ...
PRAYER_PAGES = 10            # ... always green and never the Manzil once MORE than this many pages hold a learned ayah
LOCK_RED_PAGES = 3           # #91 (D4): Next to learn is locked from this many red pages (its own page not counted) ...
LOCK_DUE = 15                # ... or with MORE than this many review cards due (today's round + the ones waiting);
                             # #116 (v0.23): a day's cards (Settings > Review > Cards a day, review.DAILY_CARDS; was 10)


@lru_cache(maxsize=1)
def word_pages() -> dict[str, int]:
    """'surah:ayah:idx' -> Madani page, from the 15-line layout (recite/data/mushaf_lines.json)."""
    out: dict[str, int] = {}
    for page in range(1, n_pages() + 1):
        for _line, s, a, idx, n in page_lines(page):
            for k in range(idx, idx + n):
                out[f"{s}:{a}:{k}"] = page
    return out


@lru_cache(maxsize=1)
def page_sizes() -> dict[int, int]:
    """Page -> its number of words (15-line layout): the Progress pie's whole (#95) and the Stats page's sizes."""
    n: dict[int, int] = {}
    for p in word_pages().values():
        n[p] = n.get(p, 0) + 1
    return n


def err_level(n: int) -> str:
    return "ok" if n == 0 else ("warn" if n <= 2 else "bad")


def revised_level(revised: str, today: dt.date) -> str:
    """Colour of a "last revised" date (yyyy-mm-dd...): ok < WARN_DAYS <= warn < REVISE_DAYS <= bad (U1.11)."""
    age = (today - dt.date.fromisoformat(revised[:10])).days
    return "ok" if age < WARN_DAYS else ("warn" if age < REVISE_DAYS else "bad")


def _pct(n: int) -> float:
    return round(100 * n / TOTAL_AYAT, 1)


def new_learned(learned_at: dict[tuple[int, int], str], today: dt.date) -> dict:
    """Issue #13 (user, 2026-10-13): how many ayat were learned today, this week (from Monday) and this year. An ayah
    counts once, on the local date of its learned moment (learned_at: the end of its first recitation without a
    mistake or hint, #17; times are stored in the device's local time); a date after today counts in none."""
    monday = today - dt.timedelta(days=today.weekday())
    jan1 = today.replace(month=1, day=1)
    n = {"today": 0, "week": 0, "year": 0}
    for t in learned_at.values():
        try:
            d = dt.date.fromisoformat(t[:10])
        except ValueError:
            continue                    # a hand-edited time: counted nowhere rather than breaking the page
        if d > today:
            continue
        n["today"] += d == today
        n["week"] += d >= monday
        n["year"] += d >= jan1
    return {**n, "year_number": today.year}


def learned_moment(keys: list[str], history: dict[str, list[Reading]]) -> str | None:
    """Issue #17 (user, 2026-10-14: "an eya is counted toward total learned and last learned only if it got recited at
    least once entirely without any mistake or hint"): the end of the first session in which every word of the ayah was
    read right and none was revealed by a hint (the latest time among its words' readings of that session); None when
    no session did. A word's verdict in a session is its last reading of that session: the user's marks made on it
    after ■ belong to it (Profile.build_history), a + Mistake spoils it, a + Correct or a Remove of a false alarm
    rights it. A mark made outside a session's window is no recitation."""
    clean: dict[str, str] | None = None            # session -> the latest time of its right readings of these words
    for k in keys:
        last: dict[str, Reading] = {}
        first_t: dict[str, str] = {}
        hinted: set[str] = set()
        for r in history.get(k, ()):
            if r.session is None:
                continue
            last[r.session] = r
            first_t.setdefault(r.session, r.t)     # the time it was said (a later mark keeps it)
            if r.hinted:
                hinted.add(r.session)
        mine = {s: first_t[s] for s, r in last.items() if r.outcome == "ok" and s not in hinted}
        clean = mine if clean is None else {s: max(t, mine[s]) for s, t in clean.items() if s in mine}
        if not clean:
            return None
    return min(clean.values()) if clean else None


@lru_cache(maxsize=2)
def ayah_table(q: Quran) -> tuple[list[tuple[int, int]], dict[tuple[int, int], int], tuple[int, ...]]:
    """The ayat in mushaf order, their 0-based positions and their word counts."""
    order = sorted(q.ayat)
    return order, {sa: i for i, sa in enumerate(order)}, tuple(len(q.ayat[sa].words) for sa in order)


def ayah_index(sa: tuple[int, int] | None, q: Quran) -> int:
    """0-based mushaf position of (surah, ayah); None (every ayah recited, next_to_learn) -> 6236: the number of ayat
    before it."""
    order, index, _ = ayah_table(q)
    return len(order) if sa is None else index[(sa[0], sa[1])]


def _at_midnight(history: dict[str, list[Reading]], today: dt.date) -> dict[str, Reading]:
    """Each word's latest reading dated before today (the readings are in time order)."""
    day = today.isoformat()
    out: dict[str, Reading] = {}
    for k, rs in history.items():
        for r in reversed(rs):
            if r.t[:10] < day:
                out[k] = r
                break
    return out


def next_to_learn(latest: dict[str, Reading], mistakes: set[str], q: Quran) -> tuple[int, int] | None:
    """From 1:1 in mushaf order, the first ayah with a word never read, moved back over the ayat with a mistake right
    before it (1:4 when 1:4-1:6 have mistakes and 1:7 was never recited); None when every ayah was recited."""
    order = ayah_table(q)[0]
    for k, sa in enumerate(order):
        if any(w.key not in latest for w in q.ayat[sa].words):
            while k > 0 and any(w.key in mistakes for w in q.ayat[order[k - 1]].words):
                k -= 1
            return order[k]
    return None


def learn_lock(p: dict, due, limit: int = LOCK_DUE) -> dict | None:
    """#91 (v0.21, D4; user, 2026-11-01: "ok we only lock the next to learn, if 3 weak pages or 10+ review … yes just
    advice and since he can see it, he can still do it by himself, if he did it then replace the lock by a checked
    box"): the lock on Next to learn, from a progress() result p -> None or {reason, red_pages, due}. Locked when
    LOCK_RED_PAGES or more rows are red (err_level bad), Next to learn's own page not counted (the page being learned),
    or when more than LOCK_DUE review cards are due; the red pages come first. None when Next to learn moved forward
    today (done: the checked box wins) or every ayah is recited. `due` = the Review backlog (review.due_backlog), an int
    or a callable counted only when the red pages do not lock already (None in the result then; Android runs
    progress() after every mark); None: no review (counted as 0)."""
    nxt = p.get("next_to_learn")
    if not nxt or (p.get("next_advanced_today") or 0) >= 1:
        return None
    red = sum(r["err_level"] == "bad" and r["page"] != nxt["page"] for r in p.get("pages") or ())
    if red >= LOCK_RED_PAGES:
        return {"reason": f"Locked: fix the weak pages first ({red} red pages)", "red_pages": red, "due": None}
    n = int((due() if callable(due) else due) or 0)
    if n > limit:   # #116 (v0.23): more cards than a day holds (App passes Cards a day)
        return {"reason": f"Locked: catch up the Review first ({n} cards due)", "red_pages": red, "due": n}
    return None


def progress(history: dict[str, list[Reading]], q: Quran, today: dt.date, due=None, lock_due: int = LOCK_DUE) -> dict:
    """U1.11 from the reading history (the module's docstring); `due`: the Review backlog for learn_lock (#91)."""
    pages_of = word_pages()
    latest = {k: rs[-1] for k, rs in history.items() if rs}
    mistakes = {k for k, r in latest.items() if r.outcome == "mistake"}

    def page(key: str) -> int:
        s, a, _ = map(int, key.split(":"))
        return pages_of.get(key) or page_of(s, a)

    learned: list[tuple[int, int]] = []
    learned_at: dict[tuple[int, int], str] = {}
    page_words: dict[int, list[str]] = {}
    perfect: list[tuple[int, int]] = []
    for sa in sorted({tuple(map(int, k.split(":")[:2])) for k in latest}):
        ay = q.ayat.get(sa)
        keys = [w.key for w in ay.words] if ay else []
        if not keys or any(k not in latest for k in keys):
            continue
        for k in keys:                              # a recited ayah: its page is in the table (Err, Last revised)
            page_words.setdefault(page(k), []).append(k)
        moment = learned_moment(keys, history)
        if moment is None:                          # issue #17: never recited entirely without a mistake or hint
            continue
        learned.append(sa)
        learned_at[sa] = moment
        # #96 (D2, user 2026-11-01): a word whose latest reading is a hint (read right after ◂) spoils Perfect too
        if not any(k in mistakes or latest[k].hinted for k in keys):
            perfect.append(sa)
    # #95 (v0.21, D3): the pie's share, the words on each page of the learned ayat (an ayah over two pages on both);
    # v0.21 review (the user: "how much of the page is actually still to be learned"): of the Perfect ones, a learned
    # ayah with a mistake or a hint now is to learn again (Next to learn moves back over it)
    learned_on: dict[int, int] = {}
    for s, a in perfect:
        for w in q.ayat[(s, a)].words:
            learned_on[page(w.key)] = learned_on.get(page(w.key), 0) + 1
    sizes = page_sizes()
    err: dict[int, int] = {}
    for k in mistakes:
        err[page(k)] = err.get(page(k), 0) + 1
    # #77 (D4, user 2026-10-30: "more than 10 pages ... he is probably in the age of prayer and does not need to
    # recite fatiha regularly"): an ayah counts on the page it starts on
    prays = len({page_of(*sa) for sa in learned}) > PRAYER_PAGES
    rows = []
    for pg in sorted(page_words):
        revised = min(latest[k].t for k in page_words[pg])[:10]
        if prays and pg == FATIHA_PAGE:
            # #117 (v0.23, user 2026-11-04: "it should be reset to today, even without reciting"): he recites it in
            # every prayer, so its date is today (read from 1:2, the basmala 1:1 kept it 13 days old)
            revised = today.isoformat()
        e = err.get(pg, 0)
        rows.append({"page": pg, "err": e, "err_level": err_level(e), "last_revised": revised,
                     "revised_level": "ok" if prays and pg == FATIHA_PAGE else revised_level(revised, today),
                     # #38 (user, 2026-10-23): the surahs printed on the page, mushaf order (the page names them)
                     "surahs": list(dict.fromkeys(s for s, _a in page_ayat(pg))),
                     # #95 (v0.21, D3; user, 2026-11-01: "a small pie that show how much of the page is actually
                     # still to be learned … if both names are on the same page then put '... • Mariem'"): the page's
                     # words, those of learned ayat, the surahs whose ayah 1 is on the page (others go on from before)
                     "words": sizes.get(pg, len(page_words[pg])), "learned_words": learned_on.get(pg, 0),
                     "starts": [s for s, a in page_ayat(pg) if a == 1]})
    manzil = min((r for r in rows if not (prays and r["page"] == FATIHA_PAGE)),
                 key=lambda r: (r["last_revised"], r["page"]), default=None)
    worst = max((r["err"] for r in rows), default=0)
    # U1.11 revised (user, 2026-10-01): ties go to the smallest page, the last revised date no longer counts
    weak = min((r for r in rows if r["err"] == worst), key=lambda r: r["page"]) if worst else None
    # issue #10 (user, 2026-10-13): "it does not make sense to have the learned eya the same as next to learn". Next to
    # learn moves back over the ayat that still have a mistake (user, 2026-09-28): such an ayah is to learn again, so
    # Last learned is the most recently completed ayah with no word counting as a mistake (never Next to learn, which
    # is either not learned or has a mistake)
    last = max(perfect, key=lambda sa: (learned_at[sa], sa)) if perfect else None
    nxt = next_to_learn(latest, mistakes, q)
    # issue #13 (D6): did Next to learn move forward today? (the Progress page's check; can be negative)
    then = _at_midnight(history, today)
    nxt_then = next_to_learn(then, {k for k, r in then.items() if r.outcome == "mistake"}, q)
    out = {"total_ayat": TOTAL_AYAT,
           "learned": {"n": len(learned), "pct": _pct(len(learned))},
           "perfect": {"n": len(perfect), "pct": _pct(len(perfect))},
           "new_learned": new_learned(learned_at, today),
           "manzil": {"page": manzil["page"], "last_revised": manzil["last_revised"],
                      "revised_level": manzil["revised_level"]} if manzil else None,
           "weak": {"page": weak["page"], "err": weak["err"], "err_level": weak["err_level"]} if weak else None,
           "next_to_learn": {"surah": nxt[0], "ayah": nxt[1], "page": page_of(*nxt)} if nxt else None,
           "last_learned": {"surah": last[0], "ayah": last[1], "page": page_of(*last)} if last else None,
           "next_advanced_today": ayah_index(nxt, q) - ayah_index(nxt_then, q),
           "pages": rows}
    out["learn_lock"] = learn_lock(out, due, lock_due)
    # v0.21 review (#91): done today hides the lock until midnight, yet the car may read a presets file written today
    # on a cold start tomorrow: the lock that applies once the date changes, with the date it was computed
    if out["learn_lock"] is None and (out.get("next_advanced_today") or 0) >= 1:
        later = learn_lock({**out, "next_advanced_today": 0}, due, lock_due)
        if later:
            out["learn_lock_next_day"] = {**later, "date": today.isoformat()}
    return out
