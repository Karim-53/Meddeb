"""Yasser Al-Dossary's ayah and word times inside QuranicAudio's whole-surah files (D4.10, #92, round decision D9):
Listen, Review ▶ and the car play his surah file (no EveryAyah ticks), each clip a time range of it.

data/yasser_qa_timings.json.gz (tools/build_qa_timings.py, from Quran Android's timings database) gives, per surah
"S": "basmala" = [start, end] ms or null (Al-Fatiha: its 1:1 is the basmala; At-Tawbah: none, its ayah-0 stretch is
the ta'awwudh, kept apart as "taawwudh"; surahs 79-114: the file has none), "ayat" = [[start, end, [word starts]], ...]
in ms from the file start (an ayah ends where the next one starts, the last 300 ms after its last word, capped at the
file's end; the word starts are every occurrence in time order, inside the clip), "file_ms" = the file's length.
No file, or a surah missing from it: untimed, None everywhere (the players keep EveryAyah). Standard library only
(Chaquopy, Pyodide).
"""
from __future__ import annotations

import gzip
import json
import zlib
from functools import lru_cache
from pathlib import Path

PATH = Path(__file__).resolve().parent / "data" / "yasser_qa_timings.json.gz"


@lru_cache(maxsize=1)
def load() -> dict:
    """The whole timings file ({"format", "source", "audio", "unit", "surahs"}); {} when it is missing or unreadable."""
    try:
        raw = PATH.read_bytes()
        doc = json.loads(gzip.decompress(raw) if raw[:2] == b"\x1f\x8b" else raw)
    except (OSError, ValueError, EOFError, zlib.error):     # zlib.error: a broken deflate stream (damaged copy)
        return {}
    return doc if isinstance(doc, dict) else {}


def _surah(surah: int) -> dict | None:
    e = load().get("surahs", {}).get(str(int(surah)))
    return e if isinstance(e, dict) else None


def _ayah(surah: int, ayah: int) -> list | None:
    e = _surah(surah)
    ayat = e.get("ayat", []) if e else []
    return ayat[int(ayah) - 1] if 1 <= int(ayah) <= len(ayat) else None


def qa_range(surah: int, ayah: int) -> tuple[int, int] | None:
    """[from_ms, to_ms) of the ayah inside its surah file; None when untimed."""
    a = _ayah(surah, ayah)
    return (int(a[0]), int(a[1])) if a else None


def qa_basmala(surah: int) -> tuple[int, int] | None:
    """[from_ms, to_ms) of the basmala before ayah 1 inside the surah file; None when the file has none (1, 9, 79-114)
    or the surah is untimed."""
    e = _surah(surah)
    b = e.get("basmala") if e else None
    return (int(b[0]), int(b[1])) if b else None


def qa_word_starts(surah: int, ayah: int) -> list[int] | None:
    """The start (ms in the surah file) of every word occurrence of the ayah, in time order; None when untimed."""
    a = _ayah(surah, ayah)
    return [int(t) for t in a[2]] if a else None


def qa_file_ms(surah: int) -> int | None:
    """The surah file's length in ms; None when untimed."""
    e = _surah(surah)
    return int(e["file_ms"]) if e and e.get("file_ms") else None


def qa_url(surah: int) -> str | None:
    """The surah file's URL (three-digit name); None when the surah is untimed (no range to play in it)."""
    tpl = load().get("audio")
    return tpl.replace("{sss}", f"{int(surah):03d}") if tpl and _surah(surah) else None
