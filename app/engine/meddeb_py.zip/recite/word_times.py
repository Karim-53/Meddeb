"""Word boundaries inside Yasser Al-Dossary's per-ayah EveryAyah files (D4.6), for the voice commands' reciter audio
(X2.15: "next" plays the revealed word, "eyah" the rest of the ayah, "replay" the ayah up to the cursor).

data/yasser_word_timings.json.gz (tools/build_word_timings.py, computed once on the PC with the served model) gives,
per "surah:ayah", the start of every word in recite's word numbering (quran_text, Tanzil simple segmentation), in
centiseconds: a plain ayah is [duration, start of word 1, ..., start of word n-1] (word 0 starts at 0); an ayah where
Yasser repeats words is {"d": duration, "seq": [[word idx, start], ...]} in time order. Every entry ends where the next
one starts, the last at the end of the file. A word plays its occurrence in reading order (D11): the first one after
the previous word's, so a stray early match (a later word found in a madd, 2:124) never plays the wrong audio, and such
an entry ahead of the reading is skipped when a clip ends (it belongs to the word being said). The ayah-1 files carry no
basmala, so word 0 is the ayah's first word (001001 is Al-Fatiha's own 1:1).
No file, or an ayah missing from it: untimed, the clip is the whole ayah. Standard library only (Chaquopy, Pyodide).
"""
from __future__ import annotations

import gzip
import json
import zlib
from functools import lru_cache
from pathlib import Path

PATH = Path(__file__).resolve().parent / "data" / "yasser_word_timings.json.gz"
UNIT_MS = {"cs": 10, "ms": 1}


@lru_cache(maxsize=1)
def load() -> dict:
    """The whole timings file ({"format", "reciter", "unit", ..., "ayat"}); {} when it is missing or unreadable."""
    try:
        raw = PATH.read_bytes()
        doc = json.loads(gzip.decompress(raw) if raw[:2] == b"\x1f\x8b" else raw)
    except (OSError, ValueError, EOFError, zlib.error):     # zlib.error: a broken deflate stream (damaged copy)
        return {}
    return doc if isinstance(doc, dict) else {}


def _entries(surah: int, ayah: int) -> tuple[list[tuple[int, int]], int, int] | None:
    """([(word idx, start)] in time order, duration, ms per unit) in the file's own integer unit; None when untimed."""
    doc = load()
    e = doc.get("ayat", {}).get(f"{int(surah)}:{int(ayah)}")
    if not e:
        return None
    unit = UNIT_MS.get(doc.get("unit", "cs"), 10)
    if isinstance(e, list):
        return [(0, 0)] + [(k + 1, int(t)) for k, t in enumerate(e[1:])], int(e[0]), unit
    return [(int(k), int(t)) for k, t in e["seq"]], int(e["d"]), unit


def _reading(entries: list[tuple[int, int]]) -> tuple[dict[int, int], set[int]]:
    """({word idx: position of the entry it plays}, positions of stray entries). Each word takes its first entry after
    the previous word's (its first occurrence when there is none); an entry that is not taken and comes before the
    reading has reached the word before it is stray (a false match ahead), a repetition behind the reading is not."""
    chosen: dict[int, int] = {}
    prev = -1
    for idx in sorted({k for k, _ in entries}):
        pos = [j for j, (k, _) in enumerate(entries) if k == idx]
        j = next((p for p in pos if p > prev), pos[0])
        chosen[idx] = j
        prev = max(prev, j)
    taken, stray, reached = set(chosen.values()), set(), -1
    for j, (k, _) in enumerate(entries):
        if j in taken:
            reached = max(reached, k)
        elif k > reached + 1:
            stray.add(j)
    return chosen, stray


def _span(entries: list[tuple[int, int]], dur: int, idx: int) -> tuple[int, int] | None:
    """[start, end) of word idx's entry in reading order: it ends where the next entry that is not stray starts (the
    last at `dur`)."""
    chosen, stray = _reading(entries)
    j = chosen.get(idx)
    if j is None:
        return None
    end = next((t for p, (_, t) in enumerate(entries) if p > j and p not in stray), dur)
    return entries[j][1], end


def timeline(surah: int, ayah: int) -> tuple[list[tuple[int, float]], float] | None:
    """([(word idx, start s)] in time order, file duration s); None when the ayah is untimed."""
    got = _entries(surah, ayah)
    if got is None:
        return None
    entries, dur, unit = got
    return [(k, t * unit / 1000) for k, t in entries], dur * unit / 1000


def word_span(surah: int, ayah: int, idx: int) -> tuple[float, float] | None:
    """[start, end) seconds of word idx's occurrence in reading order; None when untimed or no such word."""
    got = _entries(surah, ayah)
    span = _span(got[0], got[1], int(idx)) if got else None
    return (span[0] * got[2] / 1000, span[1] * got[2] / 1000) if span else None


def clip_ms(surah: int, ayah: int, from_idx: int, to_idx: int) -> tuple[int, int | None]:
    """(t0, t1) ms of the clip from word from_idx to word to_idx inside the ayah's file: t0 = the start of from_idx's
    occurrence in reading order (0 for word 0), t1 = the end of to_idx's, i.e. the start of the next entry that is not
    stray (None = the end of the file). Untimed ayah or unknown from word: (0, None), the whole ayah."""
    got = _entries(surah, ayah)
    from_idx, to_idx = int(from_idx), max(int(from_idx), int(to_idx))   # a reversed range plays the from word
    first = _span(got[0], got[1], from_idx) if got else None
    if first is None:
        return 0, None
    entries, dur, unit = got
    t0 = 0 if from_idx == 0 else first[0]
    last = _span(entries, dur, to_idx)
    end = last[1] if last is not None else dur
    if end <= t0:                          # to_idx's occurrence before from_idx's (no entry after it): the from word alone
        end = first[1]
    return t0 * unit, None if end >= dur else end * unit
